# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Reloj Mundial — hora actual en las principales ciudades del mundo."""
import os
import sys
import calendar
import datetime
import urllib.parse

import xbmcgui
import xbmcplugin

_ICON_RELOJ = os.path.join(os.path.dirname(__file__), "resources", "media", "reloj_mundial.png")

_CIUDADES = [
    ("Madrid / Barcelona",  1,    "EU",     "CET/CEST (UTC+1/+2)"),
    ("Canarias",            0,    "EU",     "WET/WEST (UTC+0/+1)"),
    ("Lisboa",              0,    "EU",     "WET/WEST (UTC+0/+1)"),
    ("Londres",             0,    "EU",     "GMT/BST  (UTC+0/+1)"),
    ("París / Berlín",      1,    "EU",     "CET/CEST (UTC+1/+2)"),
    ("El Cairo",            2,    "EG",     "EET/EEST (UTC+2/+3)"),
    ("Moscú",               3,    None,     "MSK (UTC+3)"),
    ("Dubai",               4,    None,     "GST (UTC+4)"),
    ("Nueva Delhi",         5.5,  None,     "IST (UTC+5:30)"),
    ("Bangkok",             7,    None,     "ICT (UTC+7)"),
    ("Pekín / Shanghái",    8,    None,     "CST (UTC+8)"),
    ("Tokio / Seúl",        9,    None,     "JST/KST (UTC+9)"),
    ("Sídney",              10,   "AU_SYD", "AEST/AEDT (UTC+10/+11)"),
    ("Auckland",            12,   "NZ",     "NZST/NZDT (UTC+12/+13)"),
    ("Buenos Aires",        -3,   None,     "ART (UTC-3)"),
    ("São Paulo",           -3,   None,     "BRT (UTC-3)"),
    ("Ciudad de México",    -6,   None,     "CST (UTC-6)"),
    ("Nueva York",          -5,   "US",     "EST/EDT (UTC-5/-4)"),
    ("Los Ángeles",         -8,   "US",     "PST/PDT (UTC-8/-7)"),
    ("Hawái",               -10,  None,     "HST (UTC-10)"),
]

_DIAS_ES  = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
_MESES_ES = ["ene", "feb", "mar", "abr", "may", "jun",
             "jul", "ago", "sep", "oct", "nov", "dic"]

# Fuente de verdad en himnos.py — importar en lugar de duplicar
from himnos import CIUDAD_A_PAIS as _CIUDAD_A_PAIS


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _last_weekday(year, month, weekday):
    last_day = calendar.monthrange(year, month)[1]
    d = datetime.date(year, month, last_day)
    days_back = (d.weekday() - weekday) % 7
    return d - datetime.timedelta(days=days_back)


def _nth_weekday(year, month, weekday, n):
    d = datetime.date(year, month, 1)
    days_to_first = (weekday - d.weekday()) % 7
    return d + datetime.timedelta(days=days_to_first + (n - 1) * 7)


def _effective_offset(base_h, dst_rule, today):
    if dst_rule is None:
        return base_h
    y = today.year
    if dst_rule == "EU":
        if _last_weekday(y, 3, 6) <= today < _last_weekday(y, 10, 6):
            return base_h + 1
    elif dst_rule == "US":
        if _nth_weekday(y, 3, 6, 2) <= today < _nth_weekday(y, 11, 6, 1):
            return base_h + 1
    elif dst_rule == "EG":
        if _last_weekday(y, 4, 4) <= today <= _last_weekday(y, 10, 3):
            return base_h + 1
    elif dst_rule == "AU_SYD":
        if today >= _nth_weekday(y, 10, 6, 1) or today < _nth_weekday(y, 4, 6, 1):
            return base_h + 1
    elif dst_rule == "NZ":
        if today >= _last_weekday(y, 9, 6) or today < _nth_weekday(y, 4, 6, 1):
            return base_h + 1
    return base_h


def _hora_ciudad(base_h, dst_rule):
    now_utc = datetime.datetime.now(datetime.timezone.utc)
    offset_h = _effective_offset(base_h, dst_rule, now_utc.date())
    total_min = int(offset_h * 60)
    tz = datetime.timezone(datetime.timedelta(minutes=total_min))
    now = now_utc.astimezone(tz)
    dia  = _DIAS_ES[now.weekday()]
    mes  = _MESES_ES[now.month - 1]
    fecha = "{0} {1} {2}".format(dia, now.day, mes)
    hora  = now.strftime("%H:%M")
    return hora, fecha


def reloj_mundial_menu():
    h = int(sys.argv[1])
    now_utc = datetime.datetime.now(datetime.timezone.utc)
    utc_label = "[COLOR grey]UTC ahora: {0}[/COLOR]".format(now_utc.strftime("%H:%M:%S"))
    li_utc = xbmcgui.ListItem(label=utc_label)
    li_utc.setArt({"icon": "DefaultIconInfo.png"})
    li_utc.setInfo("video", {"plot": "Hora universal coordinada (UTC) en este momento."})
    li_utc.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li_utc, isFolder=False)

    li_sep = xbmcgui.ListItem(label="[COLOR gray]────────────────────────────────────────[/COLOR]")
    li_sep.setArt({"icon": "DefaultAddonNone.png"})
    li_sep.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li_sep, isFolder=False)

    today = now_utc.date()
    for ciudad, base_h, dst_rule, zona in _CIUDADES:
        hora, fecha = _hora_ciudad(base_h, dst_rule)
        offset_real = _effective_offset(base_h, dst_rule, today)
        sign = "+" if offset_real >= 0 else "-"
        abs_h = abs(offset_real)
        h_int, h_frac = int(abs_h), abs_h % 1
        utc_str = "UTC{0}{1}{2}".format(sign, h_int, ":30" if h_frac else "")
        label = "[B]{0}[/B]   [COLOR deepskyblue]{1}[/COLOR]   [COLOR grey]{2}[/COLOR]".format(
            ciudad, hora, fecha
        )
        plot = "{0}\nHora local: [B]{1}[/B]   {2}\nZona: {3}   ({4})".format(
            ciudad, hora, fecha, zona, utc_str
        )
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": _ICON_RELOJ})
        li.setInfo("video", {"title": ciudad, "plot": plot})
        li.setProperty("IsPlayable", "false")
        pais_code = _CIUDAD_A_PAIS.get(ciudad)
        if pais_code:
            city_action = _u(action="play_himno_pais", pais=pais_code)
            li.setProperty("IsPlayable", "true")
        else:
            city_action = _u(action="noop")
        xbmcplugin.addDirectoryItem(handle=h, url=city_action, listitem=li, isFolder=False)

    li_ref = xbmcgui.ListItem(label="[COLOR gold][ Actualizar ][/COLOR]")
    li_ref.setArt({"icon": "DefaultIconInfo.png"})
    li_ref.setInfo("video", {"plot": "Recarga el reloj con la hora actual."})
    li_ref.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="reloj_mundial_menu"),
        listitem=li_ref,
        isFolder=True,
    )
    xbmcplugin.endOfDirectory(h)
