# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import os
import json
import time

import xbmcaddon
import xbmcvfs

_ESPATV_TMDB_API_KEY = "273ffd2f428df3e0ef479eeb8d632541"

_PROFILE_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
if not os.path.exists(_PROFILE_PATH):
    os.makedirs(_PROFILE_PATH, exist_ok=True)

_DEBUG_FILE = os.path.join(_PROFILE_PATH, 'debug_state.json')
_PRIORITY_FILE = os.path.join(_PROFILE_PATH, 'priority_state.json')
_RECENT_FILE = os.path.join(_PROFILE_PATH, 'recent_state.json')
_FAV_FILE = os.path.join(_PROFILE_PATH, 'favorites.json')
_DL_FILE = os.path.join(_PROFILE_PATH, 'downloads_history.json')
_DURATION_FILE = os.path.join(_PROFILE_PATH, 'min_duration.json')
_ADVANCED_SEARCH_FILE = os.path.join(_PROFILE_PATH, 'advanced_search_state.json')
_TRAKT_SETTINGS_FILE = os.path.join(_PROFILE_PATH, 'trakt_settings.json')
_IPTV_CACHE_FILE = os.path.join(_PROFILE_PATH, 'iptv_cache_settings.json')
_IPTV_CACHE_DIR = os.path.join(_PROFILE_PATH, 'iptv_cache')


def _load_json(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return default

def _save_json(path, data):
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        return True
    except OSError:
        return False

def _flag_get(path, key, default=False):
    return _load_json(path, {}).get(key, default)

def _flag_set(path, key, value):
    return _save_json(path, {key: value})


def is_debug_active():
    return _flag_get(_DEBUG_FILE, 'active', False)

def set_debug_active(state):
    _flag_set(_DEBUG_FILE, 'active', state)


def is_prioritize_match_active():
    return _flag_get(_PRIORITY_FILE, 'active', False)

def set_prioritize_match(state):
    _flag_set(_PRIORITY_FILE, 'active', state)


def is_recent_active():
    return _flag_get(_RECENT_FILE, 'active', False)

def set_recent_active(state):
    _flag_set(_RECENT_FILE, 'active', state)


def get_favorites():
    return _load_json(_FAV_FILE, [])

def add_favorite(title, url, icon, platform, action, params=None):
    favs = get_favorites()
    if any(f['title'] == title and f['platform'] == platform for f in favs):
        return False
    favs.append({
        "title": title, "url": url, "icon": icon,
        "platform": platform, "action": action, "params": params or {}
    })
    return _save_json(_FAV_FILE, favs)

def remove_favorite(url):
    favs = get_favorites()
    new_favs = [f for f in favs if f['url'] != url]
    if len(favs) == len(new_favs):
        return False
    return _save_json(_FAV_FILE, new_favs)

def rename_favorite(url, new_title):
    favs = get_favorites()
    for f in favs:
        if f['url'] == url:
            f['title'] = new_title
            return _save_json(_FAV_FILE, favs)
    return False

def move_favorite(url, direction):
    favs = get_favorites()
    index = next((i for i, f in enumerate(favs) if f['url'] == url), -1)
    if index == -1:
        return False
    if direction == "up" and index > 0:
        favs[index], favs[index - 1] = favs[index - 1], favs[index]
    elif direction == "down" and index < len(favs) - 1:
        favs[index], favs[index + 1] = favs[index + 1], favs[index]
    else:
        return False
    return _save_json(_FAV_FILE, favs)


def get_downloads():
    return _load_json(_DL_FILE, [])

def log_download(title, path, vid):
    dls = get_downloads()
    dls.insert(0, {
        "title": title, "path": path, "vid": vid,
        "date": time.strftime("%d/%m/%Y %H:%M"),
    })
    _save_json(_DL_FILE, dls[:50])

def remove_download(path):
    dls = get_downloads()
    new_dls = [d for d in dls if d['path'] != path]
    _save_json(_DL_FILE, new_dls)


def get_min_duration():
    return _load_json(_DURATION_FILE, {}).get('minutes', 0)

def set_min_duration(minutes):
    _save_json(_DURATION_FILE, {'minutes': minutes})


def is_advanced_search_active():
    return _flag_get(_ADVANCED_SEARCH_FILE, 'active', True)

def set_advanced_search_active(state):
    _flag_set(_ADVANCED_SEARCH_FILE, 'active', state)


_ESPATV_TRAKT_CLIENT_ID = "df506cf48d65deed029739f6f97f71b06714bb8da1e820df25d932c983a2b3ae"

_DEFAULT_TRAKT_LIST_IDS = [
    "805405", "1282987", "2748259", "797798", "832943",
    "4737076", "4834057", "9429302", "851495", "1558961",
    "6544049", "3785062", "20579314", "11512456", "2142753",
    "2143363", "1211468", "11416887", "801239", "6652041",
    "20770365", "1326415", "1076107", "20492899", "20770267",
    "20772087", "21583416"
]

def get_trakt_settings():
    return _load_json(_TRAKT_SETTINGS_FILE, {"api_key": "", "lists": []})

def save_trakt_settings(data):
    _save_json(_TRAKT_SETTINGS_FILE, data)

def get_trakt_api_key():
    return get_trakt_settings().get("api_key", "") or _ESPATV_TRAKT_CLIENT_ID

def set_trakt_api_key(key):
    data = get_trakt_settings()
    data["api_key"] = key
    save_trakt_settings(data)

def get_trakt_lists():
    return get_trakt_settings().get("lists", [])

def add_trakt_list(list_id, name, user, item_count=0):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    for l in lists:
        if l['id'] == list_id:
            l['name'] = name
            l['user'] = user
            l['item_count'] = item_count
            save_trakt_settings(data)
            return
    lists.append({"id": list_id, "name": name, "user": user, "item_count": item_count})
    data["lists"] = lists
    save_trakt_settings(data)

def remove_trakt_list(list_id):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    if list_id in _DEFAULT_TRAKT_LIST_IDS:
        removed = data.get("removed_defaults", [])
        if list_id not in removed:
            removed.append(list_id)
        data["removed_defaults"] = removed
    data["lists"] = [l for l in lists if l['id'] != list_id]
    save_trakt_settings(data)

def seed_default_trakt_lists(api_key=''):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    removed_defaults = set(data.get("removed_defaults", []))
    existing_ids = {l['id'] for l in lists}
    new_ids = [lid for lid in _DEFAULT_TRAKT_LIST_IDS if lid not in existing_ids and lid not in removed_defaults]
    if not new_ids:
        return
    names = {lid: "Lista Trakt #{0}".format(lid) for lid in new_ids}
    if api_key:
        try:
            import requests as _req
            from concurrent.futures import ThreadPoolExecutor
            headers = {'trakt-api-key': api_key, 'trakt-api-version': '2', 'Content-Type': 'application/json'}
            def fetch_name(lid):
                try:
                    r = _req.get('https://api.trakt.tv/lists/{0}'.format(lid),
                                 headers=headers, timeout=5)
                    if r.status_code == 200:
                        return lid, r.json().get('name', names[lid])
                except (_req.RequestException, ValueError):
                    pass
                return lid, names[lid]
            with ThreadPoolExecutor(max_workers=8) as ex:
                for lid, name in ex.map(fetch_name, new_ids):
                    names[lid] = name
        except (ImportError, RuntimeError):
            pass
    for lid in new_ids:
        lists.append({"id": lid, "name": names[lid], "user": "official", "item_count": 0})
    data["lists"] = lists
    save_trakt_settings(data)


# TTL en segundos: 0 desactivado, 3600=1h, 43200=12h, 86400=1d, 604800=1sem
_IPTV_CACHE_TTL_OPTIONS = [
    (0, "Desactivada"),
    (3600, "1 hora"),
    (43200, "12 horas"),
    (86400, "1 día"),
    (604800, "1 semana"),
]

def _load_iptv_cache_cfg():
    return _load_json(_IPTV_CACHE_FILE, {"active": False, "ttl": 0})

def _save_iptv_cache_cfg(cfg):
    _save_json(_IPTV_CACHE_FILE, cfg)

def is_iptv_cache_active():
    return _load_iptv_cache_cfg().get("active", False)

def set_iptv_cache_active(state):
    cfg = _load_iptv_cache_cfg()
    cfg["active"] = state
    if state and cfg.get("ttl", 0) == 0:
        cfg["ttl"] = 43200
    elif not state:
        clear_iptv_cache_files()
    _save_iptv_cache_cfg(cfg)

def get_iptv_cache_ttl():
    cfg = _load_iptv_cache_cfg()
    if not cfg.get("active", False):
        return 0
    return cfg.get("ttl", 0)

def set_iptv_cache_ttl(ttl_seconds):
    cfg = _load_iptv_cache_cfg()
    cfg["ttl"] = ttl_seconds
    if ttl_seconds > 0:
        cfg["active"] = True
    _save_iptv_cache_cfg(cfg)

def reset_iptv_cache_defaults():
    _save_iptv_cache_cfg({"active": False, "ttl": 0})
    clear_iptv_cache_files()

def clear_iptv_cache_files():
    if not os.path.exists(_IPTV_CACHE_DIR):
        return
    for name in os.listdir(_IPTV_CACHE_DIR):
        try:
            os.remove(os.path.join(_IPTV_CACHE_DIR, name))
        except OSError:
            continue

def get_iptv_cache_dir():
    if not os.path.exists(_IPTV_CACHE_DIR):
        os.makedirs(_IPTV_CACHE_DIR, exist_ok=True)
    return _IPTV_CACHE_DIR
