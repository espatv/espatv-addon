# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Festivos Nacionales y Autonómicos de España (datos 2025-2026 hardcoded)."""
import datetime
import sys
import urllib.parse
import os

import xbmcgui
import xbmcplugin

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

# (mes, dia, nombre)
_NACIONALES_2025 = [
    (1,  1,  "Año Nuevo"),
    (1,  6,  "Epifanía del Señor — Reyes Magos"),
    (4,  18, "Viernes Santo"),
    (5,  1,  "Día del Trabajo"),
    (8,  15, "Asunción de la Virgen"),
    (10, 12, "Fiesta Nacional de España"),
    (11, 1,  "Todos los Santos"),
    (12, 6,  "Día de la Constitución Española"),
    (12, 8,  "Inmaculada Concepción"),
    (12, 25, "Natividad del Señor — Navidad"),
]

_NACIONALES_2026 = [
    (1,  1,  "Año Nuevo"),
    (1,  6,  "Epifanía del Señor — Reyes Magos"),
    (4,  3,  "Viernes Santo"),
    (5,  1,  "Día del Trabajo"),
    (8,  15, "Asunción de la Virgen"),
    (10, 12, "Fiesta Nacional de España"),
    (11, 1,  "Todos los Santos"),
    (12, 7,  "Día de la Constitución Española (trasladado)"),
    (12, 8,  "Inmaculada Concepción"),
    (12, 25, "Natividad del Señor — Navidad"),
]

# (código, nombre, [(mes, dia, nombre), ...])
_CCAA_INFO = [
    ("AN", "Andalucía",             [(2, 28, "Día de Andalucía")]),
    ("AR", "Aragón",                [(4, 23, "Día de Aragón"), (10, 12, "Fiesta Nacional de España")]),
    ("AS", "Asturias",              [(9, 8,  "Día de Asturias")]),
    ("IB", "Islas Baleares",        [(3, 1,  "Día de las Islas Baleares")]),
    ("CN", "Canarias",              [(5, 30, "Día de Canarias")]),
    ("CB", "Cantabria",             [(8, 15, "Nuestra Señora La Virgen Grande")]),
    ("CM", "Castilla-La Mancha",    [(5, 31, "Día de Castilla-La Mancha")]),
    ("CL", "Castilla y León",       [(4, 23, "Día de Castilla y León")]),
    ("CT", "Cataluña",              [(9, 11, "Diada de Catalunya"), (6, 24, "Sant Joan")]),
    ("CE", "Ceuta",                 [(3, 5,  "Día de Ceuta")]),
    ("VC", "Comunitat Valenciana",  [(10, 9, "Día de la Comunitat Valenciana"), (3, 19, "San José / Las Fallas")]),
    ("EX", "Extremadura",           [(9, 8,  "Día de Extremadura")]),
    ("GA", "Galicia",               [(7, 25, "Día de Galicia"), (5, 17, "Día das Letras Galegas")]),
    ("RI", "La Rioja",              [(6, 9,  "Día de La Rioja")]),
    ("MD", "Comunidad de Madrid",   [(5, 2,  "Día de la Comunidad de Madrid"), (5, 15, "San Isidro")]),
    ("ML", "Melilla",               [(9, 17, "Día de Melilla")]),
    ("MU", "Región de Murcia",      [(6, 9,  "Día de la Región de Murcia")]),
    ("NC", "Navarra",               [(9, 27, "Día de Navarra"), (7, 7,  "San Fermín")]),
    ("PV", "País Vasco",            [(10, 25, "Día del País Vasco"), (7, 31, "San Ignacio de Loyola")]),
]

_DIAS_ES   = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
_MESES_ES  = ["", "enero", "febrero", "marzo", "abril", "mayo", "junio",
              "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _fecha_str(year, month, day):
    try:
        d = datetime.date(year, month, day)
        return "{0} {1} de {2} de {3}".format(_DIAS_ES[d.weekday()], day, _MESES_ES[month], year)
    except ValueError:
        return "{0}/{1}/{2}".format(day, month, year)


def _days_until(year, month, day):
    try:
        target = datetime.date(year, month, day)
        return (target - datetime.date.today()).days
    except ValueError:
        return None


def _build_items_zona(year, zona_code):
    nacionales = _NACIONALES_2025 if year == 2025 else _NACIONALES_2026
    items = []
    for mes, dia, nombre in nacionales:
        days_left = _days_until(year, mes, dia)
        items.append({
            "nombre":    nombre,
            "fecha_str": _fecha_str(year, mes, dia),
            "days_left": days_left,
            "tipo":      "nacional",
            "date":      datetime.date(year, mes, dia) if 1 <= mes <= 12 and 1 <= dia <= 31 else None,
        })
    if zona_code != "ES":
        ccaa_extra = next((extras for code, _, extras in _CCAA_INFO if code == zona_code), [])
        for mes, dia, nombre in ccaa_extra:
            days_left = _days_until(year, mes, dia)
            items.append({
                "nombre":    nombre,
                "fecha_str": _fecha_str(year, mes, dia),
                "days_left": days_left,
                "tipo":      "autonomico",
                "date":      datetime.date(year, mes, dia) if 1 <= mes <= 12 and 1 <= dia <= 31 else None,
            })
    items.sort(key=lambda x: (x["date"] or datetime.date.max))
    return items


def festivos_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_festivos.png")

    li_nac = xbmcgui.ListItem(label="[B][COLOR gold]Festivos Nacionales (toda España)[/COLOR][/B]")
    li_nac.setArt({"icon": icon})
    li_nac.setInfo("video", {"plot": "Festivos nacionales comunes a todo el territorio español."})
    li_nac.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="festivos_zona", zona="ES"),
                                listitem=li_nac, isFolder=True)

    for code, nombre, _ in _CCAA_INFO:
        li = xbmcgui.ListItem(label="[B][COLOR deepskyblue]{0}[/COLOR][/B]".format(nombre))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Festivos nacionales mas los festivos propios de {0}.".format(nombre)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="festivos_zona", zona=code),
                                    listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def festivos_zona(zona_code):
    h = int(sys.argv[1])
    icon = _icon("cat_festivos.png")
    if zona_code == "ES":
        titulo = "Festivos Nacionales"
    else:
        titulo = next((nombre for code, nombre, _ in _CCAA_INFO if code == zona_code), zona_code)

    xbmcplugin.setPluginCategory(h, titulo)
    today = datetime.date.today()

    for year in (today.year, today.year + 1):
        items = _build_items_zona(year, zona_code)
        sep = xbmcgui.ListItem(label="[COLOR gold]── Festivos {0} — {1} ──[/COLOR]".format(year, titulo))
        sep.setArt({"icon": icon})
        sep.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep, isFolder=False)

        for it in items:
            days_left = it["days_left"]
            if days_left is None:
                continue
            if days_left < 0:
                color = "grey"
                resta = "ya paso"
            elif days_left == 0:
                color = "tomato"
                resta = "HOY"
            elif days_left <= 7:
                color = "gold"
                resta = "en {0} dia{}".format(days_left, "s" if days_left != 1 else "")
            elif days_left <= 30:
                color = "khaki"
                resta = "en {0} dias".format(days_left)
            else:
                color = "white"
                resta = "en {0} dias".format(days_left)

            tipo_str = ("[COLOR deepskyblue][nacional][/COLOR]" if it["tipo"] == "nacional"
                        else "[COLOR plum][autonomico][/COLOR]")
            label = "[B][COLOR {0}]{1}[/COLOR][/B]   [COLOR grey]{2}[/COLOR]   {3}".format(
                color, it["nombre"], it["fecha_str"], tipo_str
            )
            plot = "{0}\n{1}\n{2}\n{3}".format(
                it["nombre"], it["fecha_str"], resta, "Festivo " + it["tipo"]
            )
            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": icon})
            li.setInfo("video", {"title": it["nombre"], "plot": plot})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
