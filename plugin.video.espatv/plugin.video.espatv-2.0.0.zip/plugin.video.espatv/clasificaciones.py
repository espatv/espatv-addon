# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Clasificaciones deportivas españolas via ESPN public API."""
import datetime
import json
import os
import sys
import time
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG_TAG = "[EspaTV-Clasificaciones]"
_ADDON = xbmcaddon.Addon()
_PROFILE_DIR = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
from _user_agents import UA_DESKTOP, desktop_headers as _dh, ACCEPT_JSON

_CACHE_TTL = 60 * 60
_JSON_HEADERS = {"User-Agent": UA_DESKTOP, "Accept": "application/json"}

_ESPN_STANDINGS = (
    "https://site.api.espn.com/apis/v2/sports/{sport}/{league}/standings"
)

_COMPETITIONS = [
    {
        "id": "laliga",
        "name": "LaLiga EA Sports",
        "sport": "soccer",
        "league": "esp.1",
        "color": "gold",
        "icon": "DefaultAddonPVRClient.png",
        "desc": "Clasificación de la Primera División del fútbol español.",
    },
    {
        "id": "segunda",
        "name": "LaLiga Hypermotion (2ª)",
        "sport": "soccer",
        "league": "esp.2",
        "color": "orange",
        "icon": "DefaultAddonPVRClient.png",
        "desc": "Clasificación de la Segunda División del fútbol español.",
    },
    {
        "id": "rfef",
        "name": "Primera RFEF (3ª)",
        "sport": "soccer",
        "league": "esp.3",
        "color": "coral",
        "icon": "DefaultAddonPVRClient.png",
        "desc": "Clasificación de la Primera Federación (3ª División española).",
    },
    {
        "id": "champions",
        "name": "UEFA Champions League",
        "sport": "soccer",
        "league": "uefa.champions",
        "color": "deepskyblue",
        "icon": "DefaultAddonPVRClient.png",
        "desc": "Clasificación de la fase de grupos de la Champions League.",
    },
]


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), level)


def _cache_path(comp_id):
    return os.path.join(_PROFILE_DIR, "clasif_{0}.json".format(comp_id))


def _fetch(sport, league, comp_id):
    cache = _cache_path(comp_id)
    cached = _load_json_cache(cache, _CACHE_TTL)
    if cached is not None:
        return cached
    url = _ESPN_STANDINGS.format(sport=sport, league=league)
    try:
        data = _http_get_json(url, _JSON_HEADERS)
    except Exception as exc:
        _log("Error fetching {0}: {1}".format(comp_id, exc), xbmc.LOGERROR)
        return None
    _save_json_cache(cache, data)
    return data


def _stat(stats, name, default=0):
    """Extrae el valor de una stat por nombre del array ESPN."""
    for s in stats:
        if s.get("name") == name or s.get("shortDisplayName", "").lower() == name.lower():
            v = s.get("value", default)
            return int(v) if isinstance(v, float) and v == int(v) else v
    return default


def _parse_standings(data):
    """Devuelve lista de dicts con datos de cada equipo."""
    rows = []
    try:
        groups = data.get("standings", [])
        if not groups and "children" in data:
            groups = data["children"]
        for group in groups:
            entries = group.get("standings", {}).get("entries", [])
            if not entries:
                entries = group.get("entries", [])
            for entry in entries:
                team = entry.get("team", {})
                name = team.get("displayName", team.get("name", "?"))
                stats = entry.get("stats", [])
                rank = int(_stat(stats, "rank") or len(rows) + 1)
                points = _stat(stats, "points")
                gp = _stat(stats, "gamesPlayed")
                wins = _stat(stats, "wins")
                losses = _stat(stats, "losses")
                ties = _stat(stats, "ties")
                gf = _stat(stats, "pointsFor") or _stat(stats, "goalsFor")
                gc = _stat(stats, "pointsAgainst") or _stat(stats, "goalsAgainst")
                diff = _stat(stats, "pointDifferential") or _stat(stats, "goalDifferential")
                form = _stat(stats, "streak", "")
                rows.append({
                    "rank": rank,
                    "name": name,
                    "pts": points,
                    "gp": gp,
                    "w": wins,
                    "d": ties,
                    "l": losses,
                    "gf": gf,
                    "gc": gc,
                    "diff": diff,
                    "form": form,
                })
    except (KeyError, TypeError, ValueError) as exc:
        _log("Parse error: {0}".format(exc), xbmc.LOGERROR)
    rows.sort(key=lambda x: x["rank"])
    return rows


def _zone_color(rank, total, sport):
    """Color de zona según posición."""
    if sport == "soccer":
        if rank <= 4:
            return "deepskyblue"   # Champions
        if rank <= 6:
            return "limegreen"     # Europa League / Conference
        if rank >= total - 2:
            return "red"           # Descenso
    elif sport == "basketball":
        if rank <= 8:
            return "limegreen"     # Playoff
        if rank >= total - 3:
            return "red"
    return "white"


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def clasificaciones_menu():
    h = int(sys.argv[1])
    for comp in _COMPETITIONS:
        label = "[B][COLOR {color}]{name}[/COLOR][/B]".format(**comp)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": comp["icon"]})
        li.setInfo("video", {"plot": comp["desc"], "title": comp["name"]})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="clasificacion_tabla", comp_id=comp["id"]),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def clasificacion_tabla(comp_id):
    h = int(sys.argv[1])
    comp = next((c for c in _COMPETITIONS if c["id"] == comp_id), None)
    if not comp:
        xbmcplugin.endOfDirectory(h)
        return

    xbmcgui.Dialog().notification(
        "EspaTV", "Cargando clasificación…",
        xbmcgui.NOTIFICATION_INFO, 1500,
    )

    data = _fetch(comp["sport"], comp["league"], comp_id)
    if not data:
        li = xbmcgui.ListItem(label="[COLOR red]Sin datos — comprueba la conexión[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    rows = _parse_standings(data)
    if not rows:
        li = xbmcgui.ListItem(
            label="[COLOR gray]Clasificación no disponible en este momento[/COLOR]"
        )
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    total = len(rows)
    sport = comp["sport"]

    for row in rows:
        rank = row["rank"]
        color = _zone_color(rank, total, sport)
        if sport == "soccer":
            label = (
                "[COLOR {col}][B]{r:>2}.[/B] {name:<28}[/COLOR]"
                "  [B]{pts}[/B] pts  "
                "{gp}J {w}G {d}E {l}P".format(
                    col=color,
                    r=rank,
                    name=row["name"],
                    pts=row["pts"],
                    gp=row["gp"],
                    w=row["w"],
                    d=row["d"],
                    l=row["l"],
                )
            )
            plot_parts = [
                "[B]{r}. {name}[/B]".format(r=rank, name=row["name"]),
                "",
                "Puntos: [B]{pts}[/B]   Partidos: {gp}".format(
                    pts=row["pts"], gp=row["gp"]
                ),
                "Victorias: {w}  Empates: {d}  Derrotas: {l}".format(
                    w=row["w"], d=row["d"], l=row["l"]
                ),
            ]
            if row["gf"] or row["gc"]:
                plot_parts.append(
                    "Goles: {gf} a favor / {gc} en contra  (dif: {diff:+d})".format(
                        gf=row["gf"], gc=row["gc"], diff=int(row["diff"] or 0)
                    )
                )
        else:  # basketball
            label = (
                "[COLOR {col}][B]{r:>2}.[/B] {name:<28}[/COLOR]"
                "  [B]{w}V-{l}D[/B]".format(
                    col=color, r=rank, name=row["name"], w=row["w"], l=row["l"]
                )
            )
            plot_parts = [
                "[B]{r}. {name}[/B]".format(r=rank, name=row["name"]),
                "",
                "Victorias: [B]{w}[/B]  Derrotas: {l}  Jugados: {gp}".format(
                    w=row["w"], l=row["l"], gp=row["gp"]
                ),
            ]

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultAddonPVRClient.png"})
        li.setInfo("video", {"plot": "\n".join(plot_parts), "title": row["name"]})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)

    # Leyenda de colores
    if sport == "soccer":
        li_leg = xbmcgui.ListItem(
            label="[COLOR gray]── Leyenda: Azul=Champions · Verde=Europa · Rojo=Descenso ──[/COLOR]"
        )
        li_leg.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li_leg, isFolder=False)

    # Refrescar
    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar clasificacion ][/COLOR]")
    li_r.setArt({"icon": "DefaultAddonService.png"})
    li_r.setInfo("video", {"plot": "Elimina la caché y recarga los datos."})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="clasificacion_refresh", comp_id=comp_id),
        listitem=li_r,
        isFolder=True,
    )
    xbmcplugin.endOfDirectory(h)


def clasificacion_refresh(comp_id):
    if not any(c["id"] == comp_id for c in _COMPETITIONS):
        return
    cache = _cache_path(comp_id)
    try:
        if os.path.exists(cache):
            os.remove(cache)
    except OSError:
        pass
    xbmcgui.Dialog().notification(
        "EspaTV", "Caché eliminada — recargando…",
        xbmcgui.NOTIFICATION_INFO, 1500,
    )
    xbmc.executebuiltin(
        "Container.Update({0})".format(_u(action="clasificacion_tabla", comp_id=comp_id))
    )


_ESPN_SCOREBOARD = (
    "https://site.api.espn.com/apis/site/v2/sports/{sport}/{league}/scoreboard"
)
_SCORE_TTL = 5 * 60          # TTL corto por posibles partidos en vivo
_SCORE_TTL_PAST = 24 * 3600  # resultados pasados ya fijos

_SFA_TOURNAMENT = {
    "laliga": 8,
    "segunda": 54,
    "champions": 7,
    # rfef: ID incierto, se omite
}
_SFA_URL = "https://api.sofascore.com/api/v1/sport/football/scheduled-events/{date}"
_SFA_HEADERS = _dh(accept=ACCEPT_JSON, referer="https://www.sofascore.com/")


def _load_json_cache(path, ttl):
    if not os.path.exists(path):
        return None
    if (time.time() - os.path.getmtime(path)) >= ttl:
        return None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        try:
            os.remove(path)
        except OSError:
            pass
        return None


def _save_json_cache(path, data):
    try:
        os.makedirs(_PROFILE_DIR, exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        pass


def _http_get_json(url, headers, timeout=15):
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _score_cache_path(comp_id, date_str=""):
    suffix = "_{0}".format(date_str) if date_str else ""
    return os.path.join(_PROFILE_DIR, "scores_{0}{1}.json".format(comp_id, suffix))


def _sfa_cache_path(comp_id, date_str):
    return os.path.join(_PROFILE_DIR, "sfa_{0}_{1}.json".format(comp_id, date_str))


def _fetch_scoreboard(sport, league, comp_id, date_str="", cache_only=False):
    cache = _score_cache_path(comp_id, date_str)
    today_str = datetime.date.today().strftime("%Y%m%d")
    ttl = _SCORE_TTL if (not date_str or date_str >= today_str) else _SCORE_TTL_PAST
    cached = _load_json_cache(cache, ttl)
    if cached is not None or cache_only:
        return cached
    url = _ESPN_SCOREBOARD.format(sport=sport, league=league)
    if date_str:
        url += "?dates={0}".format(date_str)
    try:
        data = _http_get_json(url, _JSON_HEADERS)
    except Exception as exc:
        _log("Error scoreboard {0}: {1}".format(comp_id, exc), xbmc.LOGERROR)
        return None
    _save_json_cache(cache, data)
    return data


def _get_espn_matches(comp, comp_id):
    today = datetime.date.today()
    matches = []
    seen = set()
    network_failed = False
    for days_back in range(5):
        d = today - datetime.timedelta(days=days_back)
        data = _fetch_scoreboard(
            comp["sport"], comp["league"], comp_id,
            d.strftime("%Y%m%d"),
            cache_only=network_failed,
        )
        if data is None:
            network_failed = True
            continue
        for m in _parse_scoreboard(data):
            key = (m["home"], m["away"])
            if key in seen:
                continue
            seen.add(key)
            matches.append(m)
    return matches


def _get_sfa_matches(comp_id):
    tournament_id = _SFA_TOURNAMENT.get(comp_id)
    if not tournament_id:
        return []

    today = datetime.date.today()
    all_events = []
    seen_keys = set()
    source_failed = False

    for days_back in range(5):
        d = today - datetime.timedelta(days=days_back)
        date_str = d.strftime("%Y%m%d")
        date_iso = d.isoformat()
        cache = _sfa_cache_path(comp_id, date_str)
        ttl = _SCORE_TTL if days_back == 0 else _SCORE_TTL_PAST

        events = _load_json_cache(cache, ttl)
        if events is None:
            if source_failed:
                continue
            try:
                data = _http_get_json(_SFA_URL.format(date=date_iso), _SFA_HEADERS)
            except Exception as exc:
                _log("SofaScore error {0} {1}: {2}".format(comp_id, date_iso, exc), xbmc.LOGERROR)
                source_failed = True
                continue
            events = [
                e for e in data.get("events", [])
                if (e.get("tournament") or {}).get("uniqueTournament", {}).get("id") == tournament_id
            ]
            _save_json_cache(cache, events)

        for e in events:
            home = (e.get("homeTeam") or {}).get("name", "")
            away = (e.get("awayTeam") or {}).get("name", "")
            key = (home, away)
            if key in seen_keys:
                continue
            seen_keys.add(key)
            all_events.append(e)

    return _parse_sfa_events(all_events)


def _parse_sfa_events(events):
    matches = []
    for e in events:
        try:
            status = e.get("status") or {}
            stype = status.get("type", "notstarted")
            if stype == "finished":
                state = "post"
            elif stype in ("inprogress", "halftime"):
                state = "in"
            else:
                state = "pre"

            home_t = e.get("homeTeam") or {}
            away_t = e.get("awayTeam") or {}
            home_sc = e.get("homeScore") or {}
            away_sc = e.get("awayScore") or {}

            hs = home_sc.get("current")
            aws = away_sc.get("current")

            clock = str(status.get("description") or "") if state == "in" else ""

            ts = e.get("startTimestamp")
            if ts and state == "pre":
                try:
                    dt = datetime.datetime.fromtimestamp(
                        int(ts), datetime.timezone.utc
                    )
                    date_iso = dt.strftime("%Y-%m-%dT%H:%M")
                except (ValueError, OSError):
                    date_iso = ""
            else:
                date_iso = ""

            matches.append({
                "home": home_t.get("shortName") or home_t.get("name", "?"),
                "away": away_t.get("shortName") or away_t.get("name", "?"),
                "home_score": str(hs) if hs is not None else "-",
                "away_score": str(aws) if aws is not None else "-",
                "state": state,
                "clock": clock,
                "date_iso": date_iso,
            })
        except Exception as exc:
            _log("SofaScore parse error: {0}".format(exc), xbmc.LOGWARNING)
    return matches


def _parse_scoreboard(data):
    matches = []
    for event in data.get("events", []):
        try:
            comps = event.get("competitions", [])
            if not comps:
                continue
            comp = comps[0]
            competitors = comp.get("competitors", [])
            home = next((c for c in competitors if c.get("homeAway") == "home"), None)
            away = next((c for c in competitors if c.get("homeAway") == "away"), None)
            if not home or not away:
                continue
            status = comp.get("status") or {}
            status_type = status.get("type") or {}
            state = status_type.get("state", "pre") if isinstance(status_type, dict) else "pre"
            clock = status.get("displayClock", "") if isinstance(status, dict) else ""

            def _team_name(competitor):
                team = competitor.get("team") or {}
                return (
                    team.get("shortDisplayName")
                    or team.get("displayName")
                    or team.get("name")
                    or "?"
                )

            home_raw = home.get("score")
            away_raw = away.get("score")
            matches.append({
                "home": _team_name(home),
                "away": _team_name(away),
                "home_score": str(home_raw) if home_raw is not None else "-",
                "away_score": str(away_raw) if away_raw is not None else "-",
                "state": state,
                "clock": clock,
                "date_iso": event.get("date", ""),
            })
        except Exception as exc:
            _log("Skipping event parse error: {0}".format(exc), xbmc.LOGWARNING)
            continue
    return matches


def _format_match_time(date_iso):
    try:
        dt = datetime.datetime.strptime(date_iso[:16], "%Y-%m-%dT%H:%M")
        return dt.strftime("%H:%M") + "h UTC"
    except (ValueError, TypeError):
        return ""


def resultados_detalle(title, plot):
    h = int(sys.argv[1])
    xbmcgui.Dialog().ok(title, plot)
    xbmcplugin.endOfDirectory(h, succeeded=False)


_RESULTADOS_COMPETITIONS = {"laliga", "segunda", "champions"}


def resultados_menu():
    h = int(sys.argv[1])
    for comp in _COMPETITIONS:
        if comp["id"] not in _RESULTADOS_COMPETITIONS:
            continue
        label = "[B][COLOR {color}]{name}[/COLOR][/B]".format(**comp)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": comp["icon"]})
        li.setInfo("video", {"plot": comp["desc"], "title": comp["name"]})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="resultados_liga", comp_id=comp["id"]),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def resultados_liga(comp_id):
    h = int(sys.argv[1])
    comp = next((c for c in _COMPETITIONS if c["id"] == comp_id), None)
    if not comp:
        xbmcplugin.endOfDirectory(h)
        return

    xbmcgui.Dialog().notification(
        "EspaTV", "Cargando resultados…",
        xbmcgui.NOTIFICATION_INFO, 1500,
    )

    try:
        _resultados_liga_body(h, comp, comp_id)
    except Exception as exc:
        _log("Error inesperado en resultados_liga: {0}".format(exc), xbmc.LOGERROR)
        li = xbmcgui.ListItem(label="[COLOR red]Error al cargar resultados[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)


def _build_multi_source_plot(best, sources):
    def _detail(m):
        if m["state"] == "post":
            return "[B]{0} - {1}[/B]  [FIN]".format(m["home_score"], m["away_score"])
        if m["state"] == "in":
            return "[B]{0} - {1}[/B]  [{2}]".format(
                m["home_score"], m["away_score"], m["clock"] or "En juego"
            )
        t = _format_match_time(m["date_iso"])
        return "vs  [{0}]".format(t or "Sin hora")

    seen = []
    for _, m in sources:
        d = _detail(m)
        if d not in seen:
            seen.append(d)

    lines = ["[B]{0}  vs  {1}[/B]".format(best["home"], best["away"]), ""]
    lines.extend(seen)
    return "\n".join(lines)


def _render_match_list(h, matches, section_label):
    li_hdr = xbmcgui.ListItem(
        label="[COLOR gray]── {0} ──[/COLOR]".format(section_label)
    )
    li_hdr.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li_hdr, isFolder=False)

    if not matches:
        li = xbmcgui.ListItem(label="[COLOR gray]Sin partidos[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        return

    for m in matches:
        state = m["state"]
        if state == "post":
            label = (
                "{home}  [B]{hs} - {aw}[/B]  {away}   [COLOR gray][FIN][/COLOR]"
            ).format(
                home=m["home"], hs=m["home_score"],
                aw=m["away_score"], away=m["away"],
            )
            plot = "[B]{home} {hs} - {aw} {away}[/B]\nFinalizado".format(
                home=m["home"], hs=m["home_score"],
                aw=m["away_score"], away=m["away"],
            )
        elif state == "in":
            label = (
                "[COLOR limegreen]{home}  [B]{hs} - {aw}[/B]  {away}"
                "   [{clock}][/COLOR]"
            ).format(
                home=m["home"], hs=m["home_score"],
                aw=m["away_score"], away=m["away"],
                clock=m["clock"] or "EN JUEGO",
            )
            plot = "[B]{home} {hs} - {aw} {away}[/B]\nEn juego: {clock}".format(
                home=m["home"], hs=m["home_score"],
                aw=m["away_score"], away=m["away"],
                clock=m["clock"] or "En curso",
            )
        else:  # pre
            t = _format_match_time(m["date_iso"])
            t_display = t or "Hora por confirmar"
            label = (
                "[COLOR silver]{home}  vs  {away}[/COLOR]"
                "   [COLOR gray][{t}][/COLOR]"
            ).format(home=m["home"], away=m["away"], t=t_display)
            plot = "{home} vs {away}\nHora: {t}".format(
                home=m["home"], away=m["away"], t=t_display,
            )

        title = "{0} - {1}".format(m["home"], m["away"])
        full_plot = m.get("_plot_override") or plot
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultAddonPVRClient.png"})
        li.setInfo("video", {"plot": full_plot, "title": title})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="resultados_detalle",
                   title=title,
                   plot=full_plot),
            listitem=li,
            isFolder=False,
        )


def _resultados_liga_body(h, comp, comp_id):
    _state_order = {"in": 0, "post": 1, "pre": 2}

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar resultados ][/COLOR]")
    li_r.setArt({"icon": "DefaultAddonService.png"})
    li_r.setInfo("video", {"plot": "Elimina la caché y recarga los resultados."})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="resultados_refresh", comp_id=comp_id),
        listitem=li_r, isFolder=True,
    )

    def _quality(m):
        return ({"post": 2, "in": 1, "pre": 0}.get(m["state"], 0),
                int(m["home_score"] != "-" and m["away_score"] != "-"))

    merged = {}

    def _merge(label, source_matches):
        for m in source_matches:
            key = (m["home"].lower().strip(), m["away"].lower().strip())
            if key not in merged:
                merged[key] = {"best": m, "sources": [(label, m)]}
            else:
                merged[key]["sources"].append((label, m))
                if _quality(m) > _quality(merged[key]["best"]):
                    merged[key]["best"] = m

    _merge("ESPN", _get_espn_matches(comp, comp_id))
    _merge("SofaScore", _get_sfa_matches(comp_id))

    all_matches = []
    for entry in merged.values():
        best = dict(entry["best"])
        best["_plot_override"] = _build_multi_source_plot(best, entry["sources"])
        all_matches.append(best)

    all_matches.sort(key=lambda m: _state_order.get(m["state"], 2))
    _render_match_list(h, all_matches, comp["name"])

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def resultados_refresh(comp_id):
    if not any(c["id"] == comp_id for c in _COMPETITIONS):
        return
    today = datetime.date.today()
    for days_back in range(5):
        d = today - datetime.timedelta(days=days_back)
        date_str = d.strftime("%Y%m%d")
        for path in (_score_cache_path(comp_id, date_str), _sfa_cache_path(comp_id, date_str)):
            try:
                if os.path.exists(path):
                    os.remove(path)
            except OSError:
                pass
    xbmcgui.Dialog().notification(
        "EspaTV", "Caché eliminada — recargando…",
        xbmcgui.NOTIFICATION_INFO, 1500,
    )
    xbmc.executebuiltin(
        "Container.Update({0})".format(_u(action="resultados_liga", comp_id=comp_id))
    )
