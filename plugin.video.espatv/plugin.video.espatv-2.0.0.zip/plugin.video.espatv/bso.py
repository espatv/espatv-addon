# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Reproductor de Bandas Sonoras de Películas Españolas (Dominio Público)."""
import hashlib
import json
import os
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG   = "[EspaTV-BSO]"
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_DIR = os.path.join(_PROFILE, "bso_cache")
_CACHE_TTL = 7 * 24 * 3600
_TIMEOUT   = 20
_ARCHIVE_META = "https://archive.org/metadata/{identifier}"

# URL base para los MP3 de la colección Sara Montiel (todos verificados).
_SMTT = "https://archive.org/download/SaraMontielTapameTapame/"

# Datos de películas y pistas. Cada pista es (nombre, fuente):
#   - fuente "https://..."         → URL directa
#   - fuente "iarchive:identifier" → se resuelve via metadata de Archive.org
_BSO_DATA = [
    {
        "id": "ultimo_cuple",
        "titulo": "El último cuplé (1957)",
        "desc": "Protagonizada por Sara Montiel. Un hito del cine español.",
        "pistas": [
            ("Ven y ven",        _SMTT + "sara%20montiel%20ven%20y%20ven.mp3"),
            ("Tápame, tápame",   _SMTT + "sara%20montiel%20tapame%20tapame.mp3"),
            ("La Madelón",       _SMTT + "sara%20montiel%20la%20madelon.mp3"),
            ("Volver",           _SMTT + "sara%20montiel%20volver.mp3"),
            ("Rosa de Madrid",   _SMTT + "sara%20montiel%20rosa%20de%20madrid.mp3"),
        ]
    },
    {
        "id": "balcon_luna",
        "titulo": "El balcón de la luna (1962)",
        "desc": "Protagonizada por Lola Flores, Paquita Rico y Carmen Sevilla.",
        "pistas": [
            ("A tu vera (Lola Flores)",        _SMTT + "lola%20flores%20a%20tu%20vera.mp3"),
            ("La Salvaora (Lola Flores)",      _SMTT + "lola%20flores%20la%20salvaora.mp3"),
        ]
    },
    {
        "id": "carmen_triana",
        "titulo": "Carmen la de Triana (1938)",
        "desc": "Protagonizada por Imperio Argentina. Rodada en los estudios de la UFA.",
        "pistas": [
            ("Antonio Vargas Heredia (Conchita Piquer)", "iarchive:78_7761-Antonio-Vargas-Heredia"),
            ("Los Piconeros (Conchita Piquer)",          "iarchive:78_7762-Los-Piconeros"),
        ]
    },
    {
        "id": "morena_clara",
        "titulo": "Morena Clara (1936)",
        "desc": "Protagonizada por Imperio Argentina y Miguel Ligero.",
        "pistas": [
            ("Échale guindas al pavo", "iarchive:78_echale-guindas-al-pavo_imperio-argentina-y-miguel-ligero-perello-y-mostazo_gbia0011504b"),
        ]
    },
    {
        "id": "imperio_argentina",
        "titulo": "Imperio Argentina — Cancionero del cine español (1930s-40s)",
        "desc": "Una de las grandes estrellas del cine español de los años 30. Sus canciones se popularizaron a través de películas como Nobleza Baturra y Morena Clara.",
        "pistas": [
            ("Dame un beso",          "iarchive:78_dame-un-beso-give-me-a-kiss_imperio-argentina-gran-orquesta-columbia-mtro-jose-l_gbia0021108a"),
            ("Para ti",               "iarchive:78_para-ti-for-you_imperio-argentina-gran-orquesta-columbia-mtro-andres-molto-m_gbia0021108b"),
            ("María del Mar",         "iarchive:78_maria-del-mar-maria-the-sailors-girl_imperio-argentina-gran-orquesta-columbia-m_gbia0021109b"),
            ("Crucecita de hierro",   "iarchive:78_crucecita-de-hierro-little-iron-cross_imperio-argentina-gran-orquesta-columbia-mt_gbia0021109a"),
            ("Carioca",               "iarchive:78_carioca_imperio-argentina-orq-casablanca-chappell-y-v-youmans_gbia0021248b"),
            ("Romanza Rusa",          "iarchive:78_romanza-rusa_imperio-argentina-orq-casablanca-r-martinez-f-rey-y-m-salina_gbia0021248a"),
            ("Noche de Reyes",        "iarchive:78_noche-de-reyes_por-imperio-argentina-jorge-curi-y-p-m-maffia_gbia0046734a"),
            ("Pena Gitana (1910)",    "iarchive:ImperioArgentinaPenaGitana"),
        ]
    },
    {
        "id": "concha_piquer",
        "titulo": "Conchita Piquer — Coplas del cine español",
        "desc": "Reina de la copla española. Sus canciones acompañaron a varias generaciones de películas musicales.",
        "pistas": [
            ("Vamos a dejarnos",        "iarchive:78_vamos-a-dejarnos_conchita-piquer-quintero-leon-quiroga_gbia0020142b"),
            ("Quiero un pañolito",      "iarchive:78_quiero-un-panolito_conchita-piquer-quintero-leon-quiroga_gbia0020142a"),
            ("Me caso mi madre",        "iarchive:78_me-caso-mi-madre_conchita-piquer-ochaita-valerio-solano-mtro-solano_gbia0021580a"),
            ("¿Pa quién será?",         "iarchive:78_pa-quien-sera_conchita-piquer-ochaita-valerio-solano-mtro-solano_gbia0021580b"),
            ("Antología (con órgano)",  "iarchive:lp_conchita-piquer_maestro-cisneros-conchita-piquer-con-organ"),
            ("Con el alma en los labios", _SMTT + "concha%20piquer%20con%20el%20alma%20en%20los%20labios.mp3"),
            ("La niña de la estación",  _SMTT + "concha%20piquer%20la%20nina%20de%20la%20estacion.mp3"),
            ("Tu nombre",               _SMTT + "concha%20piquer%20tu%20nombre.mp3"),
        ]
    },
    {
        "id": "marife_triana",
        "titulo": "Marifé de Triana — Cuplés y coplas (1950s-60s)",
        "desc": "Una de las voces más reconocibles del cine musical español de mediados del siglo XX.",
        "pistas": [
            ("La loba",          _SMTT + "marife%20de%20triana%20la%20loba.mp3"),
            ("Puente de plata",  _SMTT + "marife%20de%20triana%20puente%20de%20plata.mp3"),
        ]
    },
    {
        "id": "gracia_montes",
        "titulo": "Gracia Montes — Coplas (1950s-60s)",
        "desc": "Cantante y actriz sevillana, protagonizó varias películas musicales españolas.",
        "pistas": [
            ("Palito de ron",            _SMTT + "gracia%20montes%20palito%20de%20ron.mp3"),
            ("Quiéreme que tengo tela",  _SMTT + "gracia%20montes%20quiereme%20que%20tengo%20tela.mp3"),
            ("Una rosa colorá",          _SMTT + "gracia%20montes%20una%20rosa%20colora.mp3"),
        ]
    },
    {
        "id": "antonita_moreno",
        "titulo": "Antoñita Moreno — Cancionera del cine (1950s)",
        "desc": "Cantante folclórica y actriz, intervino en numerosas películas del cine musical español.",
        "pistas": [
            ("De España para Colombia", _SMTT + "antonita%20moreno%20de%20espana%20para%20colombia.mp3"),
            ("Quién pudiera",           _SMTT + "antonita%20moreno%20quien%20pudiera.mp3"),
            ("Sube que te sube",        _SMTT + "antonita%20moreno%20sube%20que%20te%20sube.mp3"),
        ]
    },
    {
        "id": "ana_maria",
        "titulo": "Ana María González — Cuplés del cine",
        "desc": "Cantante mexicana que popularizó coplas españolas a través del cine.",
        "pistas": [
            ("La baraja del amor",   _SMTT + "ana%20maria%20la%20baraja%20del%20amor.mp3"),
            ("La ley del querer",    _SMTT + "ana%20maria%20la%20ley%20del%20querer.mp3"),
        ]
    },
]


def _icon(name, fallback="DefaultAudio.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _cache_path(key):
    os.makedirs(_CACHE_DIR, exist_ok=True)
    return os.path.join(_CACHE_DIR, hashlib.md5(key.encode()).hexdigest() + ".json")


def _load_cache(key):
    fp = _cache_path(key)
    try:
        with open(fp, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if time.time() - obj.get("ts", 0) < _CACHE_TTL:
            return obj.get("data")
    except (OSError, ValueError):
        pass
    return None


def _save_cache(key, data):
    fp = _cache_path(key)
    try:
        with open(fp, "w", encoding="utf-8") as f:
            json.dump({"ts": time.time(), "data": data}, f, ensure_ascii=False)
    except OSError as e:
        xbmc.log("{0} Error cache: {1}".format(_LOG, e), xbmc.LOGWARNING)


def _resolve_archive_mp3(identifier):
    """Devuelve URL del primer MP3 disponible en un item Archive.org. Cacheado."""
    cache_key = "bso_meta_{0}".format(identifier)
    cached = _load_cache(cache_key)
    if cached is not None:
        return cached or None

    try:
        url = _ARCHIVE_META.format(identifier=urllib.parse.quote(identifier, safe=""))
        headers = {"User-Agent": "EspaTV/1.0"}
        resp = requests.get(url, headers=headers, timeout=_TIMEOUT)
        resp.raise_for_status()
        files = resp.json().get("files", [])
        # Preferir 64Kbps/128Kbps MP3 sobre VBR para compatibilidad Kodi
        for fmt in ("64Kbps MP3", "128Kbps MP3", "VBR MP3", "MP3"):
            for f in files:
                if f.get("format") == fmt and f.get("name", "").lower().endswith(".mp3"):
                    audio_url = "https://archive.org/download/{0}/{1}".format(
                        identifier, urllib.parse.quote(f["name"])
                    )
                    _save_cache(cache_key, audio_url)
                    return audio_url
        for f in files:
            if f.get("name", "").lower().endswith(".mp3"):
                audio_url = "https://archive.org/download/{0}/{1}".format(
                    identifier, urllib.parse.quote(f["name"])
                )
                _save_cache(cache_key, audio_url)
                return audio_url
        # Sin MP3 → cachear vacío para no reintentar constantemente
        _save_cache(cache_key, "")
    except Exception as e:
        xbmc.log("{0} Error resolviendo {1}: {2}".format(_LOG, identifier, e), xbmc.LOGERROR)
    return None


def bso_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_bso.png")

    xbmcplugin.setPluginCategory(h, "Bandas Sonoras Españolas")

    for movie in _BSO_DATA:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(movie["titulo"]))
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": movie["titulo"], "plot": movie["desc"]})
        li.setProperty("IsPlayable", "false")
        url = _u(action="bso_tracks", movie_id=movie["id"])
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def bso_tracks(movie_id):
    h = int(sys.argv[1])
    movie = next((m for m in _BSO_DATA if m["id"] == movie_id), None)
    if not movie:
        xbmcplugin.endOfDirectory(h)
        return

    xbmcplugin.setPluginCategory(h, movie["titulo"])
    icon = _icon("cat_bso.png")

    for nombre, src in movie["pistas"]:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(nombre))
        li.setArt({"icon": icon})
        li.setInfo("music", {"title": nombre, "album": movie["titulo"]})
        li.setProperty("IsPlayable", "true")
        li_url = _u(action="bso_play", nombre=nombre, src=src, movie=movie["titulo"])
        xbmcplugin.addDirectoryItem(handle=h, url=li_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def bso_play(nombre, src, movie):
    h = int(sys.argv[1])
    if not src:
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    # Resolver identificador Archive.org si procede
    if src.startswith("iarchive:"):
        identifier = src[len("iarchive:"):]
        xbmcgui.Dialog().notification("BSO", "Resolviendo audio…", xbmcgui.NOTIFICATION_INFO, 1200)
        audio_url = _resolve_archive_mp3(identifier)
        if not audio_url:
            xbmcgui.Dialog().ok("Bandas Sonoras", "No se encontró audio MP3 para esta pista.")
            xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
            return
        url = audio_url
    else:
        url = src

    xbmc.log("{0} Reproduciendo BSO: {1} ({2}) → {3}".format(_LOG, nombre, movie, url), xbmc.LOGINFO)
    li = xbmcgui.ListItem(nombre, path=url)
    li.setInfo("music", {"title": nombre, "album": movie})
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(h, True, li)
