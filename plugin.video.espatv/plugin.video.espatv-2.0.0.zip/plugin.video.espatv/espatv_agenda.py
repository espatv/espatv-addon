# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Agenda deportiva: parsing por regex de Marca, FutbolEnLaTV, FormulaTV, etc.

Sólo stdlib (sin requests) para que funcione también en builds de Kodi
de Android con dependencias mínimas.
"""
import calendar
import datetime
import gzip
import html as html_module
import json
import os
import re
import time
import unicodedata
import urllib.error
import urllib.request

import xbmc
from _user_agents import desktop_headers as _dh, ACCEPT_HTML
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG_TAG = "[EspaTV-Agenda]"
_CACHE_DIR = xbmcvfs.translatePath(
    "special://profile/addon_data/plugin.video.espatv/agenda_cache/"
)
try:
    os.makedirs(_CACHE_DIR, exist_ok=True)
except OSError:
    pass

_CACHE_FILE = os.path.join(_CACHE_DIR, "marca.html")
_CACHE_META = os.path.join(_CACHE_DIR, "marca.json")
_CACHE_TTL = 0  # sin TTL: siempre consulta el servidor

_MARCA_URL = "https://www.marca.com/programacion-tv.html"
_MARCA_ENCODING = "iso-8859-1"
_REQUEST_TIMEOUT = 15
_MAX_RESPONSE_SIZE = 10 * 1024 * 1024  # 10 MB; las paginas reales rondan ~150 KB
_MAX_RETRIES = 2
_RETRY_DELAYS = (1, 3)  # segundos entre reintentos ante error de red transitorio
_REQUEST_HEADERS = {**_dh(accept=ACCEPT_HTML), "Accept-Encoding": "gzip"}

_FUTBOLENLATV_URL = "https://www.futbolenlatv.es"
_FUTBOLENLATV_ENCODING = "utf-8"
_FUTBOLENLATV_CACHE = os.path.join(_CACHE_DIR, "futbolenlatv.html")
_FUTBOLENLATV_META = os.path.join(_CACHE_DIR, "futbolenlatv.json")

_FUTBOLHOY_URL = "https://www.futbolhoy.es/"
_FUTBOLHOY_ENCODING = "utf-8"
_FUTBOLHOY_CACHE = os.path.join(_CACHE_DIR, "futbolhoy.html")

_BALONCESTO_URL = "https://www.baloncestohoy.es/"
_BALONCESTO_ENCODING = "utf-8"
_BALONCESTO_CACHE = os.path.join(_CACHE_DIR, "baloncestohoy.html")

_TENIS_URL = "https://www.tenishoy.es/"
_TENIS_ENCODING = "utf-8"
_TENIS_CACHE = os.path.join(_CACHE_DIR, "tenishoy.html")

_FORMULATV_BASE = "https://www.formulatv.com/programacion/{slug}/"
_FORMULATV_CHANNELS = [
    # (slug, label, icon_key)
    ("teledeporte",     "Teledeporte",           "otros"),
    ("gol-television",  "Gol TV",                "futbol"),
    ("eurosport-2",     "Eurosport 2",           "otros"),
    ("dazn-1",          "DAZN 1",                "otros"),
    ("dazn-f1",         "DAZN F1",               "motor"),
    ("dazn-laliga",     "DAZN LaLiga",           "futbol"),
    ("movistar-laliga", "LaLiga TV (Movistar+)", "futbol"),
]
_FORMULATV_CACHES = {
    slug: os.path.join(_CACHE_DIR, "ftv_{0}.html".format(slug.replace("-", "_")))
    for slug, _, _ in _FORMULATV_CHANNELS
}
_FORMULATV_CACHES_MANANA = {
    slug: os.path.join(_CACHE_DIR, "ftv_{0}_manana.html".format(slug.replace("-", "_")))
    for slug, _, _ in _FORMULATV_CHANNELS
}
_FORMULATV_CACHES_AYER = {
    slug: os.path.join(_CACHE_DIR, "ftv_{0}_ayer.html".format(slug.replace("-", "_")))
    for slug, _, _ in _FORMULATV_CHANNELS
}

_CHANNEL_WEB_MAP = [
    (["dazn"],                                                          "https://www.dazn.com",              "Ver en DAZN",           "white"),
    (["movistar", "m+", "laliga tv"],                                   "https://www.movistarplus.es",        "Ver en Movistar+",      "cyan"),
    (["teledeporte", "tdp", "rtve", "tve", "la 1", "la 2", "clan"],    "https://www.rtve.es/play/",          "Ver en RTVE Play",      "tomato"),
    (["eurosport"],                                                     "https://www.eurosport.es",           "Ver en Eurosport",      "orange"),
    (["gol tv", "gol smart", "golsmartv", "gol"],                       "https://www.goltv.es",               "Ver en Gol TV",         "gold"),
    (["prime video", "amazon"],                                        "https://www.primevideo.com",          "Ver en Prime Video",    "dodgerblue"),
    (["disney"],                                                        "https://www.disneyplus.com",          "Ver en Disney+",        "blue"),
    (["bein"],                                                          "https://www.bein.com",                "Ver en beIN Sports",    "limegreen"),
    (["eleven"],                                                        "https://www.elevensports.com",        "Ver en Eleven Sports",  "white"),
    (["sky sport"],                                                     "https://www.skysports.com",           "Ver en Sky Sports",     "dodgerblue"),
    (["antena 3", "la sexta", "neox", "atresplayer"],                   "https://www.atresplayer.com",         "Ver en Atresplayer",    "orange"),
    (["telecinco", "cuatro", "mitele", "fdf", "be mad"],                "https://www.mitele.es",               "Ver en Mitele",         "limegreen"),
    (["hbo max", "hbo"],                                                "https://www.max.com",                 "Ver en Max",            "purple"),
    (["apple tv"],                                                      "https://tv.apple.com",                "Ver en Apple TV+",      "white"),
    (["paramount"],                                                     "https://www.paramountplus.com",        "Ver en Paramount+",     "dodgerblue"),
    (["footters"],                                                      "https://www.footters.com",             "Ver en Footters",       "limegreen"),
    (["f1 tv"],                                                         "https://f1tv.formula1.com",            "Ver en F1 TV",          "tomato"),
    (["ufc fight pass"],                                                "https://ufcfightpass.com",             "Ver en UFC Fight Pass", "tomato"),
    (["nba tv", "nba league"],                                          "https://www.nba.com",                 "Ver en NBA.com",         "dodgerblue"),
    (["espn"],                                                          "https://www.espn.com",                "Ver en ESPN",           "tomato"),
    (["vix"],                                                           "https://www.vix.com",                 "Ver en Vix",            "orange"),
    (["twitch"],                                                        "https://www.twitch.tv",               "Ver en Twitch",         "purple"),
    (["tnt sports", "bt sport"],                                        "https://www.tntsports.co.uk",         "Ver en TNT Sports",     "orange"),
    (["canal+", "canal plus"],                                          "https://www.canalplus.com",           "Ver en Canal+",         "white"),
    (["youtube"],                                                       "https://www.youtube.com",             "Ver en YouTube",        "tomato"),
]


def _kw_in(kw, text):
    if kw.isalpha():
        return bool(re.search(r'\b' + re.escape(kw) + r'\b', text))
    return kw in text


_FAVS_FILE = os.path.join(_CACHE_DIR, "favorites.json")
_SEARCH_HISTORY_FILE = os.path.join(_CACHE_DIR, "search_history.json")
_SEARCH_HISTORY_MAX = 5

_ICONS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "resources", "icons", "sports")

# Caché en memoria: evita round-trips repetidos al navegar rápido (TTL 30 s)
_MEM_CACHE = {}
_MEM_CACHE_TTL = 30

_LIVE_BEFORE = 15 * 60   # segundos antes del inicio que cuenta como "en directo"
_LIVE_AFTER  = 120 * 60  # segundos despues del inicio que cuenta como "en directo"

# Mapeo de deportes de Marca a categorias agrupadas.
# La clave es el texto exacto que aparece en <span class="dailyday"> del HTML.
_SPORT_GROUPS = {
    "Fútbol":       {"category": "futbol",      "label": "Fútbol",              "color": "limegreen"},
    "F. Sala":      {"category": "futbol",      "label": "Fútbol",              "color": "limegreen"},
    "Futsal":       {"category": "futbol",      "label": "Fútbol",              "color": "limegreen"},
    "NBA":          {"category": "baloncesto",  "label": "Baloncesto y NBA",    "color": "orange"},
    "Baloncesto":   {"category": "baloncesto",  "label": "Baloncesto y NBA",    "color": "orange"},
    "ACB":          {"category": "baloncesto",  "label": "Baloncesto y NBA",    "color": "orange"},
    "Euroliga":     {"category": "baloncesto",  "label": "Baloncesto y NBA",    "color": "orange"},
    "Fórmula 1":    {"category": "motor",       "label": "Motor",               "color": "red"},
    "MotoGP":       {"category": "motor",       "label": "Motor",               "color": "red"},
    "Motor":        {"category": "motor",       "label": "Motor",               "color": "red"},
    "Rally":        {"category": "motor",       "label": "Motor",               "color": "red"},
    "Tenis":        {"category": "tenis",       "label": "Tenis",               "color": "gold"},
    "Ciclismo":     {"category": "ciclismo",    "label": "Ciclismo",            "color": "deepskyblue"},
    "Golf":         {"category": "golf",        "label": "Golf",                "color": "mediumseagreen"},
    "Boxeo":        {"category": "boxeo",       "label": "Boxeo y MMA",         "color": "tomato"},
    "MMA":          {"category": "boxeo",       "label": "Boxeo y MMA",         "color": "tomato"},
    "Rugby":        {"category": "rugby",       "label": "Rugby",               "color": "peru"},
    "Natación":     {"category": "natacion",    "label": "Natación",            "color": "lightskyblue"},
    "Atletismo":    {"category": "atletismo",   "label": "Atletismo",           "color": "coral"},
    "Balonmano":    {"category": "balonmano",   "label": "Balonmano",           "color": "orchid"},
    "Waterpolo":    {"category": "waterpolo",   "label": "Waterpolo",           "color": "aquamarine"},
    "Voleibol":     {"category": "voleibol",    "label": "Voleibol",            "color": "khaki"},
    "Padel":        {"category": "padel",       "label": "Pádel",               "color": "springgreen"},
    "Pádel":        {"category": "padel",       "label": "Pádel",               "color": "springgreen"},
    "Hockey":       {"category": "hockey",      "label": "Hockey",              "color": "wheat"},
    "Vela":         {"category": "vela",        "label": "Vela",                "color": "cadetblue"},
    "Esgrima":      {"category": "otros",       "label": "Otros Deportes",      "color": "silver"},
    "Gimnasia":     {"category": "otros",       "label": "Otros Deportes",      "color": "silver"},
    "Judo":         {"category": "otros",       "label": "Otros Deportes",      "color": "silver"},
    "Piragüismo":   {"category": "otros",       "label": "Otros Deportes",      "color": "silver"},
    "Esquí":        {"category": "otros",       "label": "Otros Deportes",      "color": "silver"},
}

_DEFAULT_GROUP = {"category": "otros", "label": "Otros Deportes", "color": "silver"}

# Orden de presentacion en el menu de categorias.
_CATEGORY_ORDER = [
    "futbol", "baloncesto", "motor", "tenis", "ciclismo",
    "golf", "boxeo", "rugby", "natacion", "atletismo",
    "balonmano", "waterpolo", "voleibol", "padel",
    "hockey", "vela", "otros",
]


def _normalize(text):
    if not text:
        return ""
    nfkd = unicodedata.normalize("NFKD", text.lower())
    return "".join(c for c in nfkd if not unicodedata.combining(c))


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{tag} {msg}".format(tag=_LOG_TAG, msg=msg), level)


def _log_err(msg):
    _log(msg, xbmc.LOGERROR)


def _meta_path_for(cache_path):
    base, _ = os.path.splitext(cache_path)
    return base + ".json"


def _cache_valid(path):
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return False
    return (time.time() - mtime) < _CACHE_TTL


def _cache_read(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        return None


def _atomic_write(path, content):
    tmp_path = path + ".tmp"
    try:
        with open(tmp_path, "w", encoding="utf-8") as fh:
            fh.write(content)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass
        os.replace(tmp_path, path)
    except OSError as exc:
        _log_err("Error escribiendo cache {0}: {1}".format(path, exc))
        try:
            os.remove(tmp_path)
        except OSError:
            pass


def _meta_read(meta_path):
    try:
        with open(meta_path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _meta_write(meta_path, data):
    try:
        _atomic_write(meta_path, json.dumps(data, ensure_ascii=False))
    except (OSError, TypeError) as exc:
        _log_err("Error escribiendo metadata {0}: {1}".format(meta_path, exc))


def _touch(path):
    try:
        now = time.time()
        os.utime(path, (now, now))
    except OSError:
        pass


def _mem_get(key):
    entry = _MEM_CACHE.get(key)
    if entry and (time.time() - entry[0]) < _MEM_CACHE_TTL:
        return entry[1]
    return None


def _mem_set(key, value):
    _MEM_CACHE[key] = (time.time(), value)


def _fetch_url(url, encoding, cache_path, content_validator=None):
    """Descarga con TTL + GET condicional (ETag / If-Modified-Since). Devuelve HTML o None."""
    if _cache_valid(cache_path):
        cached = _cache_read(cache_path)
        if cached:
            _log("Cache valida: {0}".format(os.path.basename(cache_path)))
            return cached

    meta_path = _meta_path_for(cache_path)
    meta = _meta_read(meta_path)

    headers = dict(_REQUEST_HEADERS)
    if meta.get("etag") and os.path.exists(cache_path):
        headers["If-None-Match"] = meta["etag"]
    if meta.get("last_modified") and os.path.exists(cache_path):
        headers["If-Modified-Since"] = meta["last_modified"]

    for attempt in range(_MAX_RETRIES + 1):
        try:
            if attempt:
                _log("Reintento {0}/{1}: {2}".format(attempt, _MAX_RETRIES, url))
            else:
                _log("Descargando: {0}".format(url))
            req = urllib.request.Request(url, headers=headers)
            resp = urllib.request.urlopen(req, timeout=_REQUEST_TIMEOUT)

            ctype = (resp.headers.get("Content-Type") or "").lower()
            if ctype and not (ctype.startswith("text/html") or
                              ctype.startswith("application/xhtml")):
                raise ValueError("Content-Type inesperado: {0}".format(ctype))

            clen = resp.headers.get("Content-Length")
            if clen:
                try:
                    if int(clen) > _MAX_RESPONSE_SIZE:
                        raise ValueError(
                            "Content-Length {0} excede el limite".format(clen)
                        )
                except (TypeError, ValueError) as ve:
                    if "excede" in str(ve):
                        raise

            raw = resp.read(_MAX_RESPONSE_SIZE + 1)
            if len(raw) > _MAX_RESPONSE_SIZE:
                raise ValueError(
                    "Respuesta excede el tamaño maximo ({0} bytes)".format(_MAX_RESPONSE_SIZE)
                )

            enc_header = (resp.headers.get("Content-Encoding") or "").lower()
            if "gzip" in enc_header:
                try:
                    raw = gzip.decompress(raw)
                except (OSError, EOFError) as gz_exc:
                    raise ValueError("Error descomprimiendo gzip: {0}".format(gz_exc))

            html = raw.decode(encoding, errors="replace")

            if content_validator is not None and not content_validator(html):
                _log_err(
                    "Contenido descargado no valida ({0}); se conserva cache existente"
                    .format(os.path.basename(cache_path))
                )
                stale = _cache_read(cache_path)
                if stale:
                    return stale
                return None

            _atomic_write(cache_path, html)
            _meta_write(meta_path, {
                "etag": resp.headers.get("ETag"),
                "last_modified": resp.headers.get("Last-Modified"),
                "fetched_at": time.time(),
                "status": 200,
                "url": url,
            })
            return html
        except urllib.error.HTTPError as he:
            if he.code == 304:
                _log("304 Not Modified: {0}".format(os.path.basename(cache_path)))
                _touch(cache_path)
                meta["fetched_at"] = time.time()
                meta["status"] = 304
                _meta_write(meta_path, meta)
                cached = _cache_read(cache_path)
                if cached:
                    return cached
            else:
                _log_err("HTTP {0} descargando {1}".format(he.code, url))
            break
        except (urllib.error.URLError, ValueError, OSError) as exc:
            _log_err("Error descargando {0}: {1}".format(url, exc))
            if attempt < _MAX_RETRIES:
                time.sleep(_RETRY_DELAYS[attempt])

    stale = _cache_read(cache_path)
    if stale:
        _log("Usando cache expirada: {0}".format(os.path.basename(cache_path)))
        return stale

    return None


def _validate_marca_html(html):
    if not html or len(html) < 1000:
        return False
    lower = html.lower()
    if "dailyevent" in lower and "dailyhour" in lower:
        return lower.count('class="dailyevent"') >= 3
    return "programacion-tv" in lower


def _validate_futbolenlatv_html(html):
    if not html or len(html) < 1000:
        return False
    lower = html.lower()
    markers = sum([
        "tablaprincipal" in lower,
        "cabeceracompericion" in lower,
        "listacanales" in lower,
    ])
    return markers >= 2


def force_refresh():
    _MEM_CACHE.clear()
    paths = ([_CACHE_FILE, _FUTBOLENLATV_CACHE, _FUTBOLHOY_CACHE,
              _BALONCESTO_CACHE, _TENIS_CACHE]
             + list(_FORMULATV_CACHES.values())
             + list(_FORMULATV_CACHES_MANANA.values())
             + list(_FORMULATV_CACHES_AYER.values())
             + [_marca_cache_for(d)[1] for d in range(1, 8)])
    for path in paths:
        for p in (path, _meta_path_for(path)):
            try:
                os.remove(p)
            except OSError:
                pass
    _log("Refresco forzado: ETag y caché en memoria eliminados")


_RE_EVENT_BLOCK = re.compile(
    r'<li class="dailyevent">(.*?)</li>', re.DOTALL
)
_RE_SPORT = re.compile(
    r'<span class="dailyday">(.*?)</span>'
)
_RE_HOUR = re.compile(
    r'<strong class="dailyhour">(.*?)</strong>'
)
_RE_COMPETITION = re.compile(
    r'<span class="dailycompetition">(.*?)</span>'
)
_RE_TEAMS = re.compile(
    r'<h4 class="dailyteams">\s*(.*?)\s*</h4>', re.DOTALL
)
_RE_CHANNEL = re.compile(
    r'<span class="dailychannel[^"]*"[^>]*>(.*?)</span>', re.DOTALL
)
_RE_HTML_TAG = re.compile(r'<[^>]+>')


def _strip_tags(text):
    return _RE_HTML_TAG.sub("", text).strip()


def _parse_events(html):
    """Extrae eventos del HTML de Marca como dicts {sport, hour, competition, teams, channel, category, color, label}."""
    if not html:
        return []

    blocks = _RE_EVENT_BLOCK.findall(html)
    events = []

    for block in blocks:
        sport_m = _RE_SPORT.search(block)
        hour_m = _RE_HOUR.search(block)
        comp_m = _RE_COMPETITION.search(block)
        teams_m = _RE_TEAMS.search(block)
        chan_m = _RE_CHANNEL.search(block)

        sport = sport_m.group(1).strip() if sport_m else ""
        hour = hour_m.group(1).strip() if hour_m else ""
        competition = comp_m.group(1).strip() if comp_m else ""
        teams = _strip_tags(teams_m.group(1)) if teams_m else ""
        channel = _strip_tags(chan_m.group(1)) if chan_m else ""

        # Sin hora ni equipos no es un evento valido
        if not hour or not teams:
            continue
        group = _SPORT_GROUPS.get(sport, _DEFAULT_GROUP)

        events.append({
            "sport": sport,
            "hour": hour,
            "competition": competition,
            "teams": teams,
            "channel": channel,
            "category": group["category"],
            "label": group["label"],
            "color": group["color"],
        })

    return events


def _build_categories(events):
    """Devuelve sólo categorías con eventos, respetando _CATEGORY_ORDER."""
    seen = {}
    for ev in events:
        cat = ev["category"]
        if cat not in seen:
            seen[cat] = {"category": cat, "label": ev["label"], "color": ev["color"], "count": 0}
        seen[cat]["count"] += 1

    ordered = []
    for cat_key in _CATEGORY_ORDER:
        if cat_key in seen:
            ordered.append(seen.pop(cat_key))
    for cat_data in seen.values():
        ordered.append(cat_data)

    return ordered


def _filter_events(events, category):
    filtered = [ev for ev in events if ev["category"] == category]
    filtered.sort(key=lambda e: e["hour"])
    return filtered


def _spain_utc_offset():
    """UTC+1 (CET) o UTC+2 (CEST) calculando el último domingo de marzo/octubre sin pytz."""
    now_unix = time.time()
    y = time.gmtime(now_unix).tm_year

    def last_sunday(month):
        d = datetime.date(y, month, 31 if month in (1, 3, 5, 7, 8, 10, 12) else 30)
        while d.weekday() != 6:
            d -= datetime.timedelta(days=1)
        return d

    dst_start = last_sunday(3)   # último domingo de marzo
    dst_end   = last_sunday(10)  # último domingo de octubre
    approx = time.gmtime(now_unix + 3600)
    today_approx = datetime.date(approx.tm_year, approx.tm_mon, approx.tm_mday)
    return 2 if dst_start <= today_approx < dst_end else 1


def _parse_hour_today(hour_str):
    """Convierte 'HH:MM' (hora ES) a timestamp UTC. None si está mal formado."""
    try:
        h, m = hour_str.split(":")
        h, m = int(h), int(m)
        offset = _spain_utc_offset()
        spain_now = time.gmtime(time.time() + offset * 3600)
        spain_event = (
            spain_now.tm_year, spain_now.tm_mon, spain_now.tm_mday,
            h, m, 0, 0, 0, 0,
        )
        spain_event_as_utc = calendar.timegm(spain_event)
        return spain_event_as_utc - offset * 3600
    except (ValueError, TypeError):
        return None


def _filter_live(events):
    """Eventos en directo o que empiezan en las próximas 2 horas."""
    now = time.time()
    result = []
    for ev in events:
        ts = _parse_hour_today(ev.get("hour", ""))
        if ts is None:
            continue
        if ts < now - _LIVE_AFTER:
            ts += 86400
        if (now - _LIVE_BEFORE) <= ts <= (now + _LIVE_AFTER):
            result.append(ev)
    result.sort(key=lambda e: e["hour"])
    return result


def _time_hint(hour_str):
    """Texto relativo: 'en 45min', 'lleva 1h', 'ahora', '' si no aplica."""
    ts = _parse_hour_today(hour_str)
    if ts is None:
        return ""
    now = time.time()
    diff = ts - now
    if diff < -(4 * 3600):
        diff += 86400
    if diff > 4 * 3600 or diff < -(3 * 3600):
        return ""
    if -_LIVE_BEFORE <= diff <= 0:
        return "ahora"
    if diff > 0:
        mins = int(diff / 60)
        if mins < 60:
            return "en {0}min".format(mins)
        h, m = divmod(mins, 60)
        return "en {0}h {1}min".format(h, m) if m else "en {0}h".format(h)
    mins = int(-diff / 60)
    if mins < 60:
        return "lleva {0}min".format(mins)
    h, m = divmod(mins, 60)
    return "lleva {0}h {1}min".format(h, m) if m else "lleva {0}h".format(h)


def _load_favorites():
    try:
        with open(_FAVS_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            return {
                "teams":        list(data.get("teams", [])),
                "competitions": list(data.get("competitions", [])),
                "channels":     list(data.get("channels", [])),
            }
    except (OSError, ValueError):
        pass
    return {"teams": [], "competitions": [], "channels": []}


def _save_favorites(data):
    _atomic_write(_FAVS_FILE, json.dumps(data, ensure_ascii=False))


def toggle_favorite(category, value):
    if not value or not value.strip():
        return
    favs = _load_favorites()
    lst = favs.get(category, [])
    norm = _normalize(value)
    existing = [_normalize(x) for x in lst]
    if norm in existing:
        favs[category] = [x for x in lst if _normalize(x) != norm]
    else:
        favs[category] = lst + [value]
    _save_favorites(favs)


def is_favorite(category, value):
    favs = _load_favorites()
    norm = _normalize(value)
    return any(_normalize(x) == norm for x in favs.get(category, []))


def _event_matches_favorites(ev, favs):
    fields = [ev.get("teams", ""), ev.get("competition", ""), ev.get("channel", "")]
    norm_fields = [_normalize(f) for f in fields]
    for category in ("teams", "competitions", "channels"):
        for fav in favs.get(category, []):
            nf = _normalize(fav)
            if not nf:
                continue
            if any(nf in nfield for nfield in norm_fields):
                return True
    return False


def _fav_marker(ev, favs):
    return "[COLOR gold]* [/COLOR]" if _event_matches_favorites(ev, favs) else ""


def _sport_icon(category):
    path = os.path.join(_ICONS_DIR, "{0}.png".format(category or "otros"))
    return path if os.path.isfile(path) else "DefaultAddonPVRClient.png"


def _event_label(ev, favs, show_hint=True):
    marker = _fav_marker(ev, favs)
    hint_str = ""
    if show_hint:
        hint = _time_hint(ev.get("hour", ""))
        if hint:
            hint_str = "  [COLOR grey]{0}[/COLOR]".format(hint)
    return (
        "{marker}[COLOR gold]{hour}[/COLOR]{hint}  [COLOR {color}]{sport}[/COLOR]  {teams}"
        "  ·  [COLOR grey]{channel}[/COLOR]"
    ).format(
        marker=marker,
        hour=ev.get("hour", ""),
        hint=hint_str,
        color=ev.get("color", "white"),
        sport=ev.get("sport", ""),
        teams=ev.get("teams", ""),
        channel=ev.get("channel") or "Sin canal",
    )


def _load_search_history():
    try:
        with open(_SEARCH_HISTORY_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, list):
            return [str(x) for x in data if x][:_SEARCH_HISTORY_MAX]
    except (OSError, ValueError):
        pass
    return []


def _add_to_search_history(query):
    if not query or not query.strip():
        return
    q = query.strip()
    history = _load_search_history()
    history = [x for x in history if _normalize(x) != _normalize(q)]
    history.insert(0, q)
    _atomic_write(_SEARCH_HISTORY_FILE,
                  json.dumps(history[:_SEARCH_HISTORY_MAX], ensure_ascii=False))


def _build_channels(events):
    """Agrupa por canal. Un evento con varios canales cuenta en cada uno."""
    seen = {}
    for ev in events:
        raw = ev.get("channel", "") or ""
        canales = [c.strip() for c in raw.split(",") if c.strip()]
        if not canales:
            canales = ["Sin canal"]
        for c in canales:
            seen[c] = seen.get(c, 0) + 1
    return sorted(seen.items(), key=lambda x: (-x[1], x[0]))


def _filter_by_channel(events, channel):
    norm = _normalize(channel)
    result = []
    for ev in events:
        raw = ev.get("channel", "") or ""
        if channel == "Sin canal":
            if not raw.strip():
                result.append(ev)
        elif norm in _normalize(raw):
            result.append(ev)
    result.sort(key=lambda e: e["hour"])
    return result


def _build_competitions(events):
    seen = {}
    for ev in events:
        comp = ev.get("competition") or "Sin competicion"
        seen[comp] = seen.get(comp, 0) + 1
    return sorted(seen.items(), key=lambda x: (-x[1], x[0]))


def _filter_by_competition(events, competition):
    norm = _normalize(competition)
    result = [ev for ev in events if norm in _normalize(ev.get("competition") or "")]
    result.sort(key=lambda e: e["hour"])
    return result


def _search_events(events, query):
    nq = _normalize(query)
    result = []
    for ev in events:
        haystack = _normalize(
            " ".join([ev.get("sport") or "", ev.get("competition") or "",
                      ev.get("teams") or "", ev.get("channel") or ""])
        )
        if nq in haystack:
            result.append(ev)
    result.sort(key=lambda e: e["hour"])
    return result


def _marca_cache_for(day_offset):
    day_offset = int(day_offset)
    if day_offset == 0:
        return _MARCA_URL, _CACHE_FILE
    target = datetime.date.today() + datetime.timedelta(days=day_offset)
    url = "{0}?fecha={1}".format(_MARCA_URL, target.strftime("%Y-%m-%d"))
    cache = os.path.join(_CACHE_DIR, "marca_d{0}.html".format(day_offset))
    return url, cache


def fetch_agenda(day_offset=0):
    """Descarga + parsea eventos de Marca. day_offset: 0=hoy, 1=mañana, ..., 7=siguiente semana."""
    key = "agenda_{0}".format(day_offset)
    cached = _mem_get(key)
    if cached is not None:
        return cached
    url, cache_path = _marca_cache_for(day_offset)
    html = _fetch_url(url, _MARCA_ENCODING, cache_path,
                      content_validator=_validate_marca_html)
    events = _parse_events(html)
    if html is not None and not events:
        _log_err("HTML obtenido pero parser no extrajo eventos ({0})".format(
            os.path.basename(cache_path)))
    target = datetime.date.today() + datetime.timedelta(days=int(day_offset))
    date_str = target.strftime("%d/%m/%Y")
    for ev in events:
        ev["date"] = date_str
    _mem_set(key, events)
    return events


def _format_cache_time(cache_path):
    meta = _meta_read(_meta_path_for(cache_path))
    ts = meta.get("fetched_at")
    if not ts:
        try:
            ts = os.path.getmtime(cache_path)
        except OSError:
            return None
    try:
        return time.strftime("%d/%m/%Y  %H:%M", time.localtime(ts))
    except (TypeError, ValueError):
        return None


def show_agenda_menu(handle, build_url):
    events = fetch_agenda()

    updated_at = _format_cache_time(_CACHE_FILE)
    if updated_at:
        update_label = "[COLOR grey]Actualizado: {0}[/COLOR]".format(updated_at)
    else:
        update_label = "[COLOR grey]Datos no disponibles — pulsa para actualizar[/COLOR]"
    li_upd = xbmcgui.ListItem(label=update_label)
    li_upd.setArt({"icon": "DefaultIconInfo.png"})
    li_upd.setInfo("video", {"plot":
        "Última actualización: {0}\n"
        "Pulsa para forzar una descarga inmediata.".format(updated_at or "—")
    })
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_refresh"),
        listitem=li_upd, isFolder=False,
    )

    if not events:
        li = xbmcgui.ListItem(
            label="[COLOR grey]No se pudo cargar la agenda deportiva[/COLOR]"
        )
        li.setInfo("video", {"plot":
            "No se ha podido obtener la programación deportiva.\n"
            "Comprueba tu conexión a internet."
        })
        xbmcplugin.addDirectoryItem(
            handle=handle, url="", listitem=li, isFolder=False
        )
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    favs = _load_favorites()

    # Filtros
    live_count = len(_filter_live(events))
    live_hint = "  [COLOR red]({0} en directo)[/COLOR]".format(live_count) if live_count else ""
    li = xbmcgui.ListItem(label="[COLOR grey]Filtros[/COLOR]{0}".format(live_hint))
    li.setArt({"icon": "DefaultAddonsSearch.png"})
    li.setInfo("video", {"plot": "En directo, busqueda, mañana, pasado mañana, por canal."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_filters"),
        listitem=li, isFolder=True,
    )

    # Favoritos
    fav_events = [ev for ev in events if _event_matches_favorites(ev, favs)]
    has_favs = any(favs.get(k) for k in ("teams", "competitions", "channels"))
    if has_favs:
        label = "[COLOR gold][B]Mis favoritos ({0})[/B][/COLOR]".format(len(fav_events)) if fav_events \
                else "[COLOR grey]Mis favoritos (ninguno hoy)[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultAddonPVRClient.png"})
        li.setInfo("video", {"plot": "Eventos de hoy con equipos, competiciones o canales favoritos."})
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=build_url(action="agenda_events", sport="favorites"),
            listitem=li, isFolder=True,
        )

    # Agenda completa
    li = xbmcgui.ListItem(
        label="[COLOR gold][B]Agenda completa ({0} eventos)[/B][/COLOR]".format(len(events))
    )
    li.setArt({"icon": "DefaultAddonPVRClient.png"})
    li.setInfo("video", {"plot": "Programacion deportiva completa de hoy ordenada por hora."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_events", sport="all"),
        listitem=li, isFolder=True,
    )

    # Categorias dinamicas
    categories = _build_categories(events)
    for cat in categories:
        li = xbmcgui.ListItem(
            label="[COLOR {color}][B]{label}[/B][/COLOR]  [COLOR grey]({count})[/COLOR]".format(**cat)
        )
        li.setArt({"icon": _sport_icon(cat["category"])})
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=build_url(action="agenda_events", sport=cat["category"]),
            listitem=li, isFolder=True,
        )

    # Futbol en la TV
    li = xbmcgui.ListItem(label="[COLOR limegreen][B]Fútbol en la TV[/B][/COLOR]")
    li.setArt({"icon": _sport_icon("futbol")})
    li.setInfo("video", {"plot": "Partidos de fútbol televisados hoy con horarios y canales."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_futbolenlatv"),
        listitem=li, isFolder=True,
    )

    # Fútbol Hoy (por competición)
    li = xbmcgui.ListItem(label="[COLOR limegreen]Fútbol Hoy — Por competición[/COLOR]")
    li.setArt({"icon": _sport_icon("futbol")})
    li.setInfo("video", {"plot": "Todos los partidos de hoy ordenados por competición (futbolhoy.es)."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_futbolhoy"),
        listitem=li, isFolder=True,
    )

    # Baloncesto en la TV
    li = xbmcgui.ListItem(label="[COLOR orange][B]Baloncesto en la TV[/B][/COLOR]")
    li.setArt({"icon": _sport_icon("baloncesto")})
    li.setInfo("video", {"plot": "Partidos de baloncesto televisados hoy (NBA, Euroliga, ACB…)."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_baloncestohoy"),
        listitem=li, isFolder=True,
    )

    # Tenis en la TV
    li = xbmcgui.ListItem(label="[COLOR gold][B]Tenis en la TV[/B][/COLOR]")
    li.setArt({"icon": _sport_icon("tenis")})
    li.setInfo("video", {"plot": "Partidos de tenis televisados hoy (ATP, WTA, Grand Slams…)."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_tenishoy"),
        listitem=li, isFolder=True,
    )

    # Canales Deportivos TV
    li = xbmcgui.ListItem(label="[COLOR white][B]Canales Deportivos TV[/B][/COLOR]")
    li.setArt({"icon": _sport_icon("otros")})
    li.setInfo("video", {"plot": "Parrilla de hoy: Teledeporte, Gol TV, Eurosport 2, DAZN 1, DAZN F1, DAZN LaLiga, LaLiga TV (Movistar+)."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_sport_channels"),
        listitem=li, isFolder=True,
    )

    # Clasificaciones deportivas
    li = xbmcgui.ListItem(label="[COLOR limegreen][B]Clasificaciones[/B][/COLOR]")
    li.setArt({"icon": "DefaultAddonPVRClient.png"})
    li.setInfo("video", {"plot": "Tablas de LaLiga, Segunda División, Primera RFEF y Champions League."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="clasificaciones_menu"),
        listitem=li, isFolder=True,
    )

    # Resultados de partidos
    li = xbmcgui.ListItem(label="[COLOR deepskyblue][B]Resultados[/B][/COLOR]")
    li.setArt({"icon": "DefaultAddonPVRClient.png"})
    li.setInfo("video", {"plot": "Resultados de hoy y de ayer: LaLiga, Segunda División, Primera RFEF y Champions League."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="resultados_menu"),
        listitem=li, isFolder=True,
    )

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def _event_plot(ev):
    lines = []
    competition = ev.get("competition", "")
    teams = ev.get("teams", "")
    channel = ev.get("channel", "")
    hour = ev.get("hour", "")
    sport = ev.get("sport", "")
    if competition:
        lines.append("Competición: {0}".format(competition))
    if teams:
        lines.append("Evento: {0}".format(teams))
    if channel:
        lines.append("Canal: {0}".format(channel))
    if hour:
        lines.append("Hora: {0}".format(hour))
    date = ev.get("date", "")
    if date:
        lines.append("Fecha: {0}".format(date))
    if sport:
        lines.append("Deporte: {0}".format(sport))
    return "\n".join(lines)


def show_agenda_events(handle, build_url, sport_filter):
    events = fetch_agenda()

    if not events:
        li = xbmcgui.ListItem(
            label="[COLOR grey]No hay eventos disponibles[/COLOR]"
        )
        xbmcplugin.addDirectoryItem(
            handle=handle, url="", listitem=li, isFolder=False
        )
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    if sport_filter == "live":
        events = _filter_live(events)
    elif sport_filter == "favorites":
        favs = _load_favorites()
        events = [ev for ev in events if _event_matches_favorites(ev, favs)]
        events.sort(key=lambda e: e["hour"])
    elif sport_filter and sport_filter.startswith("channel:"):
        channel_name = sport_filter[len("channel:"):]
        events = _filter_by_channel(events, channel_name)
    elif sport_filter and sport_filter.startswith("competition:"):
        comp_name = sport_filter[len("competition:"):]
        events = _filter_by_competition(events, comp_name)
    elif sport_filter and sport_filter != "all":
        events = _filter_events(events, sport_filter)
    else:
        events = sorted(events, key=lambda e: e["hour"])

    empty_msgs = {
        "live":      "[COLOR grey]No hay eventos en directo ahora mismo[/COLOR]",
        "favorites": "[COLOR grey]Ninguno de tus favoritos emite hoy[/COLOR]",
    }
    if not events:
        if sport_filter and sport_filter.startswith("channel:"):
            msg = "[COLOR grey]No hay eventos en {0} hoy[/COLOR]".format(
                sport_filter[len("channel:"):]
            )
        elif sport_filter and sport_filter.startswith("competition:"):
            msg = "[COLOR grey]No hay eventos de {0} hoy[/COLOR]".format(
                sport_filter[len("competition:"):]
            )
        else:
            msg = empty_msgs.get(sport_filter, "[COLOR grey]No hay eventos de este deporte hoy[/COLOR]")
        li = xbmcgui.ListItem(label=msg)
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    favs = _load_favorites()
    for ev in events:
        label = _event_label(ev, favs)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": _sport_icon(ev.get("category"))})
        li.setInfo("video", {"plot": _event_plot(ev), "title": ev["teams"]})
        url = build_url(
            action="agenda_event_options",
            teams=ev["teams"],
            competition=ev["competition"],
            channel=ev["channel"],
            hour=ev["hour"],
            sport=ev["sport"],
        )
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def show_event_options(handle, build_url, params):
    teams = params.get("teams", "")
    competition = params.get("competition", "")
    channel = params.get("channel", "")
    hour = params.get("hour", "")
    sport = params.get("sport", "")

    # Construir query de busqueda razonable
    search_query = teams
    if competition:
        search_query = "{0} {1}".format(teams, competition)

    # 1. Ver informacion completa
    li = xbmcgui.ListItem(
        label="[COLOR lightskyblue][B]Ver información del evento[/B][/COLOR]"
    )
    li.setArt({"icon": "DefaultIconInfo.png"})
    li.setInfo("video", {"plot": _event_plot(params)})
    url = build_url(
        action="agenda_event_info",
        teams=teams, competition=competition,
        channel=channel, hour=hour, sport=sport,
    )
    xbmcplugin.addDirectoryItem(
        handle=handle, url=url, listitem=li, isFolder=False,
    )

    # 2. Buscar en YouTube
    li = xbmcgui.ListItem(
        label="[COLOR red][B]Buscar en YouTube[/B][/COLOR]"
    )
    li.setArt({"icon": "DefaultMusicVideos.png"})
    li.setInfo("video", {"plot":
        "Busca \"{0}\" en YouTube.".format(search_query)
    })
    url = build_url(action="yt_search_results", query=search_query)
    xbmcplugin.addDirectoryItem(
        handle=handle, url=url, listitem=li, isFolder=True,
    )

    # 3. Buscar en Dailymotion
    li = xbmcgui.ListItem(
        label="[COLOR dodgerblue][B]Buscar en Dailymotion[/B][/COLOR]"
    )
    li.setArt({"icon": "DefaultAddonWebSkin.png"})
    li.setInfo("video", {"plot":
        "Busca \"{0}\" en Dailymotion.".format(search_query)
    })
    url = build_url(action="lfr", q=search_query, ot="", nh=1)
    xbmcplugin.addDirectoryItem(
        handle=handle, url=url, listitem=li, isFolder=True,
    )

    channel_lower = (channel or "").lower()
    _shown_webs = set()
    for _kws, _web_url, _web_label, _web_color in _CHANNEL_WEB_MAP:
        if _web_url in _shown_webs:
            continue
        if any(_kw_in(kw, channel_lower) for kw in _kws):
            li = xbmcgui.ListItem(label="[COLOR {0}][B]{1}[/B][/COLOR]".format(_web_color, _web_label))
            li.setArt({"icon": "DefaultAddonWebSkin.png"})
            li.setInfo("video", {"plot": "Abre {0} en el navegador.".format(_web_label)})
            url = build_url(action="agenda_open_browser", url=_web_url)
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
            _shown_webs.add(_web_url)

    # 4. Favoritos — opciones de toggle
    fav_options = []
    if teams:
        in_fav = is_favorite("teams", teams)
        fav_options.append(("teams", teams,
            "[COLOR gold]Quitar equipos de favoritos[/COLOR]" if in_fav
            else "Añadir equipos a favoritos"))
    if competition:
        in_fav = is_favorite("competitions", competition)
        fav_options.append(("competitions", competition,
            "[COLOR gold]Quitar competicion de favoritos[/COLOR]" if in_fav
            else "Añadir competicion a favoritos"))
    if channel:
        in_fav = is_favorite("channels", channel)
        fav_options.append(("channels", channel,
            "[COLOR gold]Quitar canal de favoritos[/COLOR]" if in_fav
            else "Añadir canal a favoritos"))

    for fav_cat, fav_val, fav_label in fav_options:
        li = xbmcgui.ListItem(label=fav_label)
        li.setArt({"icon": "DefaultIconInfo.png"})
        li.setInfo("video", {"plot": fav_val})
        url = build_url(action="agenda_favorite_toggle",
                        category=fav_cat, value=fav_val)
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)

    # 5. Copiar informacion
    clipboard_text = "{0} - {1} - {2} ({3})".format(
        hour, teams, channel, competition
    )
    li = xbmcgui.ListItem(label="[COLOR grey]Copiar información[/COLOR]")
    li.setArt({"icon": "DefaultIconInfo.png"})
    li.setInfo("video", {"plot": clipboard_text})
    url = build_url(action="copy_url", url=clipboard_text)
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def show_event_info(params):
    teams = params.get("teams", "")
    competition = params.get("competition", "")
    channel = params.get("channel", "")
    hour = params.get("hour", "")
    sport = params.get("sport", "")

    lines = []
    lines.append("[B]{0}[/B]".format(teams))
    lines.append("")
    if competition:
        lines.append("Competición: {0}".format(competition))
    lines.append("Hora: {0}".format(hour))
    lines.append("Deporte: {0}".format(sport))
    if channel:
        lines.append("Canal: {0}".format(channel))

    text = "\n".join(lines)
    xbmcgui.Dialog().textviewer("Agenda Deportiva", text)


def show_agenda_day(handle, build_url, day_offset):
    events = fetch_agenda(day_offset=day_offset)

    if not events:
        li = xbmcgui.ListItem(label="[COLOR grey]No hay programacion disponible[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    events = sorted(events, key=lambda e: e["hour"])
    favs = _load_favorites()

    for ev in events:
        label = _event_label(ev, favs, show_hint=False)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": _sport_icon(ev.get("category"))})
        li.setInfo("video", {"plot": _event_plot(ev), "title": ev["teams"]})
        url = build_url(
            action="agenda_event_options",
            teams=ev["teams"], competition=ev["competition"],
            channel=ev["channel"], hour=ev["hour"], sport=ev["sport"],
        )
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


_WEEKDAY_ES = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]


def _all_sources_unified():
    """Combina eventos de todas las fuentes en dicts {hour, title, detail, category, source}.

    Memoizado (TTL 30s) para evitar disparar 11 descargas por cada navegación.
    """
    cached = _mem_get("unified_all")
    if cached is not None:
        return cached

    unified = []

    try:
        for ev in fetch_agenda():
            teams = ev.get("teams", "")
            comp = ev.get("competition", "")
            chan = ev.get("channel", "")
            detail_parts = [p for p in [comp, chan] if p]
            unified.append({
                "hour": ev.get("hour", ""),
                "title": teams,
                "detail": "  ·  ".join(detail_parts),
                "category": ev.get("category", "otros"),
                "source": "Marca",
            })
    except (OSError, ValueError):
        pass

    # 2. Fuentes de partidos por deporte (baloncestohoy, tenishoy, futbolenlatv, futbolhoy)
    _ext_sources = [
        (fetch_futbolenlatv,  "Fútbol en la TV",   "futbol"),
        (fetch_futbolhoy,     "Fútbol Hoy",        "futbol"),
        (fetch_baloncestohoy, "Baloncesto Hoy",    "baloncesto"),
        (fetch_tenishoy,      "Tenis Hoy",         "tenis"),
    ]
    for fetch_fn, src_label, cat in _ext_sources:
        try:
            for m in fetch_fn():
                teams = "{0} - {1}".format(m.get("local", ""), m.get("visitor", ""))
                comp = m.get("competition", "")
                chan = m.get("channel", "")
                detail_parts = [p for p in [comp, chan] if p]
                unified.append({
                    "hour": m.get("hour", ""),
                    "title": teams,
                    "detail": "  ·  ".join(detail_parts),
                    "category": cat,
                    "source": src_label,
                })
        except (OSError, ValueError):
            pass

    # 3. Canales FormulaTV (solo hoy)
    for slug, ch_label, icon_key in _FORMULATV_CHANNELS:
        try:
            items, _ = fetch_formulatv(slug)
            for item in items:
                title = item["title"]
                detail_parts = [p for p in [item.get("subtitle", ""), ch_label] if p]
                unified.append({
                    "hour": item["hour"],
                    "title": title,
                    "detail": "  ·  ".join(detail_parts),
                    "category": icon_key,
                    "source": ch_label,
                })
        except (OSError, ValueError):
            pass

    unified.sort(key=lambda u: u["hour"])
    _mem_set("unified_all", unified)
    return unified


def _filter_unified_live(unified):
    now = time.time()
    result = []
    for u in unified:
        ts = _parse_hour_today(u["hour"])
        if ts is None:
            continue
        if ts < now - _LIVE_AFTER:
            ts += 86400
        if (now - _LIVE_BEFORE) <= ts <= (now + _LIVE_AFTER):
            result.append(u)
    result.sort(key=lambda u: u["hour"])
    return result


def _search_unified(unified, query):
    nq = _normalize(query)
    return [u for u in unified if nq in _normalize(u["title"] + " " + u["detail"] + " " + u["source"])]


def _render_unified_list(handle, items, empty_msg):
    if not items:
        li = xbmcgui.ListItem(label="[COLOR grey]{0}[/COLOR]".format(empty_msg))
        li.setInfo("video", {"plot": empty_msg})
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    for u in items:
        hint = _time_hint(u["hour"])
        hint_str = "  [COLOR grey]{0}[/COLOR]".format(hint) if hint else ""
        src_str = "  [COLOR grey]({0})[/COLOR]".format(u["source"])
        lbl = "[COLOR gold]{0}[/COLOR]{1}  {2}{3}".format(
            u["hour"], hint_str, u["title"], src_str
        )
        li = xbmcgui.ListItem(label=lbl)
        li.setArt({"icon": _sport_icon(u["category"])})
        today_str = datetime.date.today().strftime("%d/%m/%Y")
        plot = "{0}\nHora: {1}\nFecha: {2}".format(u["title"], u["hour"], today_str)
        if u["detail"]:
            plot += "\n{0}".format(u["detail"])
        plot += "\nFuente: {0}".format(u["source"])
        li.setInfo("video", {"plot": plot, "title": u["title"]})
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def show_agenda_search_all(handle, build_url, prefilled_query=None):
    if prefilled_query:
        query = prefilled_query.strip()
    else:
        query = xbmcgui.Dialog().input(
            "Búsqueda unificada", type=xbmcgui.INPUT_ALPHANUM
        )
    if not query or not query.strip():
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    query = query.strip()
    _add_to_search_history(query)
    unified = _all_sources_unified()
    results = _search_unified(unified, query)
    _render_unified_list(
        handle, results,
        "Sin resultados para \"{0}\" en ninguna fuente".format(query)
    )


def show_agenda_live_all(handle, build_url):
    unified = _all_sources_unified()
    live = _filter_unified_live(unified)
    _render_unified_list(
        handle, live,
        "No hay eventos en directo o próximos en ninguna fuente ahora mismo"
    )


def show_agenda_filters(handle, build_url):
    events = fetch_agenda()
    live = _filter_live(events)
    channels = _build_channels(events)
    competitions = _build_competitions(events)

    # En directo / proximos
    if live:
        live_label = "[B]En directo / Próximos  [COLOR grey]({0})[/COLOR][/B]".format(len(live))
    else:
        live_label = "[B]En directo / Próximos  [COLOR grey](ninguno ahora)[/COLOR][/B]"
    li = xbmcgui.ListItem(label=live_label)
    li.setArt({"icon": "DefaultAddonPVRClient.png"})
    li.setInfo("video", {"plot": "Eventos en curso o que empiezan en las próximas 2 horas (agenda Marca)."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_events", sport="live"),
        listitem=li, isFolder=True,
    )

    # En directo ahora
    li = xbmcgui.ListItem(label="[B]En directo ahora[/B]")
    li.setArt({"icon": "DefaultAddonPVRClient.png"})
    li.setInfo("video", {"plot": "Partidos y programas en curso o que empiezan pronto."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_live_all"),
        listitem=li, isFolder=True,
    )

    # Buscar en AceStream
    li = xbmcgui.ListItem(label="[B]Buscar en AceStream[/B]")
    li.setArt({"icon": "DefaultAddonWebSkin.png"})
    li.setInfo("video", {"plot": "Buscador de identificadores AceStream. Util para descubrir qué canal retransmite un evento concreto.\n\nConsulta únicamente la API pública oficial de AceStream. No aloja, distribuye ni enlaza a ningún contenido concreto. Funciona igual que cualquier buscador web, ves lo que la propia red AceStream tiene indexado públicamente.\n\nLos desarrolladores no avalan su uso con contenido protegido por derechos de autor. La reproducción de cualquier contenido encontrado es responsabilidad exclusiva del usuario."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="search_acestream_prompt"),
        listitem=li, isFolder=True,
    )

    # Búsqueda unificada
    li = xbmcgui.ListItem(label="[B]Búsqueda unificada[/B]")
    li.setArt({"icon": "DefaultAddonsSearch.png"})
    li.setInfo("video", {"plot": "Busca por equipo, competición, canal o deporte."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_search_all"),
        listitem=li, isFolder=True,
    )

    # Búsqueda simple
    li = xbmcgui.ListItem(label="[B]Búsqueda simple[/B]")
    li.setArt({"icon": "DefaultAddonsSearch.png"})
    li.setInfo("video", {"plot": "Búsqueda rápida en la agenda de hoy."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_search"),
        listitem=li, isFolder=True,
    )

    # Vista semanal: próximos 7 días
    today = datetime.date.today()
    day_names = {1: "Mañana", 2: "Pasado mañana"}
    for offset in range(1, 8):
        target = today + datetime.timedelta(days=offset)
        day_name = day_names.get(offset, _WEEKDAY_ES[target.weekday()])
        li = xbmcgui.ListItem(
            label="[B]{0}[/B]  [COLOR grey]{1}[/COLOR]".format(day_name, target.strftime("%d/%m/%Y"))
        )
        li.setArt({"icon": "DefaultAddonPVRClient.png"})
        li.setInfo("video", {"plot": "Programación deportiva del {0}".format(target.strftime("%d/%m/%Y"))})
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=build_url(action="agenda_day", day=offset),
            listitem=li, isFolder=True,
        )

    # Por canal
    li = xbmcgui.ListItem(
        label="[B]Por canal[/B]  [COLOR grey]({0})[/COLOR]".format(len(channels))
    )
    li.setArt({"icon": "DefaultAddonPVRClient.png"})
    li.setInfo("video", {"plot": "Ver la programación agrupada por canal."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_channels"),
        listitem=li, isFolder=True,
    )

    # Por competición
    li = xbmcgui.ListItem(
        label="[B]Por competición[/B]  [COLOR grey]({0})[/COLOR]".format(len(competitions))
    )
    li.setArt({"icon": "DefaultAddonPVRClient.png"})
    li.setInfo("video", {"plot": "Ver la programación agrupada por competición."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_competitions"),
        listitem=li, isFolder=True,
    )

    # Historial de búsquedas
    history = _load_search_history()
    if history:
        for q in history:
            li = xbmcgui.ListItem(
                label="[COLOR grey]Búsqueda:[/COLOR]  {0}".format(q)
            )
            li.setArt({"icon": "DefaultAddonsSearch.png"})
            li.setInfo("video", {"plot": "Repetir búsqueda: {0}".format(q)})
            xbmcplugin.addDirectoryItem(
                handle=handle,
                url=build_url(action="agenda_search", query=q),
                listitem=li, isFolder=True,
            )

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def show_agenda_channels(handle, build_url):
    events = fetch_agenda()
    channels = _build_channels(events)

    if not channels:
        li = xbmcgui.ListItem(label="[COLOR grey]No hay canales disponibles[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    for name, count in channels:
        li = xbmcgui.ListItem(
            label="{name}  [COLOR grey]({count})[/COLOR]".format(name=name, count=count)
        )
        li.setArt({"icon": "DefaultAddonPVRClient.png"})
        li.setInfo("video", {"plot": "Eventos en {0} hoy: {1}".format(name, count)})
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=build_url(action="agenda_events", sport="channel:" + name),
            listitem=li, isFolder=True,
        )

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def show_agenda_competitions(handle, build_url):
    events = fetch_agenda()
    competitions = _build_competitions(events)

    if not competitions:
        li = xbmcgui.ListItem(label="[COLOR grey]No hay competiciones disponibles[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    for name, count in competitions:
        li = xbmcgui.ListItem(
            label="{name}  [COLOR grey]({count})[/COLOR]".format(name=name, count=count)
        )
        li.setArt({"icon": "DefaultAddonPVRClient.png"})
        li.setInfo("video", {"plot": "Eventos de {0} hoy: {1}".format(name, count)})
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=build_url(action="agenda_events", sport="competition:" + name),
            listitem=li, isFolder=True,
        )

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def show_agenda_search(handle, build_url, prefilled_query=None):
    if prefilled_query:
        query = prefilled_query.strip()
    else:
        query = xbmcgui.Dialog().input(
            "Buscar en la agenda", type=xbmcgui.INPUT_ALPHANUM
        )
    if not query or not query.strip():
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    query = query.strip()
    _add_to_search_history(query)
    events = fetch_agenda()
    results = _search_events(events, query)

    if not results:
        li = xbmcgui.ListItem(
            label="[COLOR grey]Sin resultados para \"{0}\"[/COLOR]".format(query)
        )
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    favs = _load_favorites()
    for ev in results:
        label = _event_label(ev, favs)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": _sport_icon(ev.get("category"))})
        li.setInfo("video", {"plot": _event_plot(ev), "title": ev["teams"]})
        url = build_url(
            action="agenda_event_options",
            teams=ev["teams"], competition=ev["competition"],
            channel=ev["channel"], hour=ev["hour"], sport=ev["sport"],
        )
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def _strip_html(text):
    return html_module.unescape(_RE_HTML_TAG.sub("", text)).strip()


def _render_sport_tv_guide(handle, build_url, matches, sport_label, sport_key, cache_path):
    updated_at = _format_cache_time(cache_path)
    if updated_at:
        update_label = "[COLOR grey]Actualizado: {0}[/COLOR]".format(updated_at)
    else:
        update_label = "[COLOR grey]Datos no disponibles — pulsa para actualizar[/COLOR]"
    li_upd = xbmcgui.ListItem(label=update_label)
    li_upd.setArt({"icon": "DefaultIconInfo.png"})
    li_upd.setInfo("video", {"plot": "Última actualización: {0}\nPulsa para forzar una descarga inmediata.".format(updated_at or "—")})
    xbmcplugin.addDirectoryItem(handle=handle, url=build_url(action="agenda_refresh"), listitem=li_upd, isFolder=False)

    if not matches:
        li = xbmcgui.ListItem(label="[COLOR grey]No hay partidos de {0} disponibles[/COLOR]".format(sport_label))
        li.setInfo("video", {"plot": "No se han podido obtener los partidos.\nComprueba tu conexión a internet."})
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    matches.sort(key=lambda m: m["hour"])
    current_comp = None
    icon = _sport_icon(sport_key)

    for m in matches:
        if m["competition"] and m["competition"] != current_comp:
            current_comp = m["competition"]
            sep = xbmcgui.ListItem(label="[COLOR lightskyblue][B]{0}[/B][/COLOR]".format(current_comp))
            sep.setInfo("video", {"plot": current_comp})
            xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=sep, isFolder=False)

        teams = "{0} - {1}".format(m["local"], m["visitor"])
        hint = _time_hint(m["hour"])
        hint_str = "  [COLOR grey]{0}[/COLOR]".format(hint) if hint else ""
        label = "[COLOR gold]{hour}[/COLOR]{hint}  {teams}  ·  [COLOR grey]{channel}[/COLOR]".format(
            hour=m["hour"], hint=hint_str, teams=teams,
            channel=m["channel"] or "Sin canal",
        )
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        today_str = datetime.date.today().strftime("%d/%m/%Y")
        plot = ""
        if m["competition"]:
            plot += "Competición: {0}\n".format(m["competition"])
        plot += "Partido: {0}\nHora: {1}\nFecha: {2}".format(teams, m["hour"], today_str)
        if m["channel"]:
            plot += "\nCanal: {0}".format(m["channel"])
        li.setInfo("video", {"plot": plot, "title": teams})
        url = build_url(action="agenda_event_options", teams=teams,
                        competition=m["competition"], channel=m["channel"],
                        hour=m["hour"], sport=sport_label)
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


# ─── Futbolenlatv.es — Parser y renderizado ───────────────────────────────────

_RE_FUTBOL_ROW = re.compile(r'(<tr[^>]*>.*?</tr>)', re.DOTALL)
_RE_FUTBOL_HOUR_FMT = re.compile(r'\d{1,2}:\d{2}$')
_RE_FUTBOL_COMP = re.compile(
    r'class="cabeceraCompericion".*?'
    r'<a[^>]*internalLink[^>]*>\s*(.*?)\s*</a>',
    re.DOTALL | re.IGNORECASE,
)
_RE_FUTBOL_HOUR = re.compile(
    r'<td class="hora[^"]*"[^>]*>\s*(.*?)\s*</td>', re.DOTALL
)
_RE_FUTBOL_LOCAL = re.compile(
    r'<td class="local"[^>]*>(.*?)</td>', re.DOTALL
)
_RE_FUTBOL_VISIT = re.compile(
    r'<td class="visitante"[^>]*>(.*?)</td>', re.DOTALL
)
_RE_FUTBOL_CHAN = re.compile(
    r'class="(?:canal-sin-enlace|internalLinkCanal)[^"]*"[^>]*>(.*?)<',
    re.DOTALL,
)


def _parse_futbolenlatv(html):
    """Devuelve lista de {competition, hour, local, visitor, channel}."""
    if not html:
        return []

    rows = _RE_FUTBOL_ROW.findall(html)
    current_comp = ""
    matches = []

    for row in rows:
        # Detectar fila de cabecera de competicion
        comp_m = _RE_FUTBOL_COMP.search(row)
        if comp_m:
            current_comp = html_module.unescape(
                _RE_HTML_TAG.sub("", comp_m.group(1))
            ).strip()
            continue

        # Detectar fila de partido
        hour_m = _RE_FUTBOL_HOUR.search(row)
        if not hour_m:
            continue
        hour = _strip_tags(hour_m.group(1))
        if not _RE_FUTBOL_HOUR_FMT.match(hour):
            continue
        if len(hour) == 4:
            hour = "0" + hour

        local_m = _RE_FUTBOL_LOCAL.search(row)
        visit_m = _RE_FUTBOL_VISIT.search(row)
        local = html_module.unescape(_strip_tags(local_m.group(1))) if local_m else ""
        visitor = html_module.unescape(_strip_tags(visit_m.group(1))) if visit_m else ""

        if not local and not visitor:
            continue

        canales = _RE_FUTBOL_CHAN.findall(row)
        canales = [c.strip() for c in canales if c.strip()]
        channel = ", ".join(canales)

        matches.append({
            "competition": current_comp,
            "hour": hour,
            "local": local,
            "visitor": visitor,
            "channel": channel,
        })

    return matches


def fetch_futbolenlatv():
    html = _fetch_url(_FUTBOLENLATV_URL, _FUTBOLENLATV_ENCODING,
                      _FUTBOLENLATV_CACHE,
                      content_validator=_validate_futbolenlatv_html)
    return _parse_futbolenlatv(html)


def show_futbolenlatv(handle, build_url):
    matches = fetch_futbolenlatv()

    updated_at = _format_cache_time(_FUTBOLENLATV_CACHE)
    if updated_at:
        update_label = "[COLOR grey]Actualizado: {0}[/COLOR]".format(updated_at)
    else:
        update_label = "[COLOR grey]Datos no disponibles — pulsa para actualizar[/COLOR]"
    li_upd = xbmcgui.ListItem(label=update_label)
    li_upd.setArt({"icon": "DefaultIconInfo.png"})
    li_upd.setInfo("video", {
        "plot": "Última actualización: {0}\n"
                "Pulsa para forzar una descarga inmediata.".format(updated_at or "—")
    })
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="agenda_refresh"),
        listitem=li_upd, isFolder=False,
    )

    if not matches:
        li = xbmcgui.ListItem(
            label="[COLOR grey]No hay partidos de fútbol disponibles[/COLOR]"
        )
        li.setInfo("video", {"plot":
            "No se han podido obtener los partidos.\n"
            "Comprueba tu conexión a internet."
        })
        xbmcplugin.addDirectoryItem(
            handle=handle, url="", listitem=li, isFolder=False
        )
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    matches.sort(key=lambda m: m["hour"])
    current_comp = None

    for m in matches:
        # Separador visual por competicion
        if m["competition"] and m["competition"] != current_comp:
            current_comp = m["competition"]
            li = xbmcgui.ListItem(
                label="[COLOR lightskyblue][B]{0}[/B][/COLOR]".format(current_comp)
            )
            li.setInfo("video", {"plot": current_comp})
            xbmcplugin.addDirectoryItem(
                handle=handle, url="", listitem=li, isFolder=False
            )

        teams = "{0} - {1}".format(m["local"], m["visitor"])
        hint = _time_hint(m["hour"])
        hint_str = "  [COLOR grey]{0}[/COLOR]".format(hint) if hint else ""
        label = (
            "[COLOR gold]{hour}[/COLOR]{hint}  {teams}"
            "  ·  [COLOR grey]{channel}[/COLOR]"
        ).format(
            hour=m["hour"],
            hint=hint_str,
            teams=teams,
            channel=m["channel"] or "Sin canal",
        )

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": _sport_icon("futbol")})

        today_str = datetime.date.today().strftime("%d/%m/%Y")
        plot = ""
        if m["competition"]:
            plot += "Competición: {0}\n".format(m["competition"])
        plot += "Partido: {0}\n".format(teams)
        if m["channel"]:
            plot += "Canal: {0}\n".format(m["channel"])
        plot += "Hora: {0}\nFecha: {1}".format(m["hour"], today_str)
        li.setInfo("video", {"plot": plot, "title": teams})

        url = build_url(
            action="agenda_event_options",
            teams=teams,
            competition=m["competition"],
            channel=m["channel"],
            hour=m["hour"],
            sport="Fútbol",
        )
        xbmcplugin.addDirectoryItem(
            handle=handle, url=url, listitem=li, isFolder=True,
        )

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


# ─── Baloncestohoy.es — Parser y renderizado ─────────────────────────────────

_RE_BALONC_COMP_HDR = re.compile(r'<div class="matchdayCompetitionHeader">\s*<h3>(.*?)</h3>', re.DOTALL)
_RE_BALONC_TEAMS    = re.compile(r'<span class="basicTeam">(.*?)</span>\s*-\s*<span class="basicTeam">(.*?)</span>', re.DOTALL)
_RE_BALONC_TIME     = re.compile(r'<span class="m_time">(\d{1,2}:\d{2})</span>')
_RE_BALONC_CHAN     = re.compile(r'<span class="channelLnk[^"]*"[^>]*>(.*?)</span>', re.DOTALL)
_RE_BALONC_PHASE    = re.compile(r'<div class="m_phase">\s*<span>(.*?)</span>', re.DOTALL)


def _validate_baloncestohoy_html(html):
    if not html or len(html) < 100:
        return False
    lower = html.lower()
    return "matchdaycompetitionheader" in lower and "basicteam" in lower


def _parse_baloncestohoy(html):
    if not html:
        return []

    matches = []
    current_comp = ""

    for section in re.split(r'<div class="matchdayCompetitionHeader">', html)[1:]:
        comp_m = _RE_BALONC_COMP_HDR.search("<div class=\"matchdayCompetitionHeader\">" + section)
        if comp_m:
            current_comp = _strip_html(comp_m.group(1))

        for block in re.split(r'<div class="match match_', section)[1:]:
            teams_m = _RE_BALONC_TEAMS.search(block)
            if not teams_m:
                continue
            local   = _strip_html(teams_m.group(1))
            visitor = _strip_html(teams_m.group(2))

            time_m = _RE_BALONC_TIME.search(block)
            if not time_m:
                continue
            hour = time_m.group(1)
            if len(hour) == 4:
                hour = "0" + hour

            channels = [_strip_html(c) for c in _RE_BALONC_CHAN.findall(block) if c.strip()]
            channel  = ", ".join(channels[:3])

            competition = current_comp
            phase_m = _RE_BALONC_PHASE.search(block)
            if phase_m:
                phase = _strip_html(phase_m.group(1))
                if phase:
                    competition = "{0} – {1}".format(current_comp, phase)

            matches.append({"competition": competition, "hour": hour,
                            "local": local, "visitor": visitor, "channel": channel})

    return matches


def fetch_baloncestohoy():
    html = _fetch_url(_BALONCESTO_URL, _BALONCESTO_ENCODING, _BALONCESTO_CACHE,
                      content_validator=_validate_baloncestohoy_html)
    return _parse_baloncestohoy(html)


def show_baloncestohoy(handle, build_url):
    _render_sport_tv_guide(handle, build_url, fetch_baloncestohoy(),
                           "Baloncesto", "baloncesto", _BALONCESTO_CACHE)


# ─── Tenishoy.es — Parser y renderizado ──────────────────────────────────────

_RE_TENIS_TOURNEY = re.compile(r'<div class="matchdayTournamentHeader">.*?<h3>(.*?)</h3>', re.DOTALL)
_RE_TENIS_ROUND   = re.compile(r'<div class="m_comm">(.*?)</div>', re.DOTALL)
_RE_TENIS_PLAYER  = re.compile(r'<div class="name">(.*?)</div>', re.DOTALL)
_RE_TENIS_TIME    = re.compile(r'<span class="m_time">(\d{1,2}:\d{2})</span>')
_RE_TENIS_CHAN    = re.compile(r'<span class="channelLnk[^"]*"[^>]*>(.*?)</span>', re.DOTALL)


def _validate_tenishoy_html(html):
    if not html or len(html) < 100:
        return False
    lower = html.lower()
    return "matchdaytournamentheader" in lower and "m_time" in lower


def _parse_tenishoy(html):
    if not html:
        return []

    matches = []
    current_tournament = ""

    for section in re.split(r'<div class="matchdayTournamentHeader">', html)[1:]:
        tourney_m = _RE_TENIS_TOURNEY.search("<div class=\"matchdayTournamentHeader\">" + section)
        if tourney_m:
            current_tournament = _strip_html(tourney_m.group(1))

        for block in re.split(r'<div class="match match_', section)[1:]:
            players = [_strip_html(p) for p in _RE_TENIS_PLAYER.findall(block) if p.strip()]
            if len(players) < 2:
                continue

            time_m = _RE_TENIS_TIME.search(block)
            if not time_m:
                continue
            hour = time_m.group(1)
            if len(hour) == 4:
                hour = "0" + hour

            channels = [_strip_html(c) for c in _RE_TENIS_CHAN.findall(block) if c.strip()]
            channel  = ", ".join(channels[:3])

            competition = current_tournament
            round_m = _RE_TENIS_ROUND.search(block)
            if round_m:
                rnd = _strip_html(round_m.group(1))
                if rnd:
                    competition = "{0} – {1}".format(current_tournament, rnd)

            matches.append({"competition": competition, "hour": hour,
                            "local": players[0], "visitor": players[1], "channel": channel})

    return matches


def fetch_tenishoy():
    html = _fetch_url(_TENIS_URL, _TENIS_ENCODING, _TENIS_CACHE,
                      content_validator=_validate_tenishoy_html)
    return _parse_tenishoy(html)


def show_tenishoy(handle, build_url):
    _render_sport_tv_guide(handle, build_url, fetch_tenishoy(),
                           "Tenis", "tenis", _TENIS_CACHE)


# ─── Futbolhoy.es — Fútbol por competición ───────────────────────────────────

_RE_FUTBOLHOY_TEAM = re.compile(
    r'<span class="(?:basicTeam|destTeam)[^"]*">([^<]+)</span>'
)


def _validate_futbolhoy_html(html):
    if not html or len(html) < 100:
        return False
    lower = html.lower()
    return "matchdaycompetitionheader" in lower and ("basicteam" in lower or "destteam" in lower)


def _parse_futbolhoy(html):
    """Extrae los partidos de futbolhoy.es (misma familia que baloncestohoy/tenishoy)."""
    if not html:
        return []
    matches = []
    sections = html.split('<div class="matchdayCompetitionHeader">')
    for section in sections[1:]:
        comp_m = re.search(r'<h3[^>]*>([^<]+)</h3>', section)
        competition = html_module.unescape(comp_m.group(1).strip()) if comp_m else ""
        blocks = section.split('<div class="match match_')
        for block in blocks[1:]:
            time_m = re.search(r'<span class="m_time">\s*(\d{1,2}):(\d{2})\s*</span>', block)
            teams = _RE_FUTBOLHOY_TEAM.findall(block)
            chan_m = re.search(r'<span class="channelLnk[^"]*">([^<]+)</span>', block)
            if not time_m or len(teams) < 2:
                continue
            hour = "{0:02d}:{1}".format(int(time_m.group(1)), time_m.group(2))
            matches.append({
                "competition": competition,
                "hour": hour,
                "local": html_module.unescape(teams[0].strip()),
                "visitor": html_module.unescape(teams[1].strip()),
                "channel": html_module.unescape(chan_m.group(1).strip()) if chan_m else "",
            })
    return matches


def fetch_futbolhoy():
    html = _fetch_url(_FUTBOLHOY_URL, _FUTBOLHOY_ENCODING, _FUTBOLHOY_CACHE,
                      content_validator=_validate_futbolhoy_html)
    return _parse_futbolhoy(html)


def show_futbolhoy(handle, build_url):
    _render_sport_tv_guide(handle, build_url, fetch_futbolhoy(),
                           "Fútbol", "futbol", _FUTBOLHOY_CACHE)


# ─── FormulaTV — Parrilla de canales deportivos ───────────────────────────────


def _validate_formulatv_html(html):
    if not html or len(html) < 100:
        return False
    return 'class="progi"' in html


def _parse_formulatv(html):
    """Extrae los programas de la parrilla de FormulaTV."""
    if not html:
        return []
    items = []
    parts = re.split(r'(?=<div class="progi(?:\s[^"]*)?">)', html)
    for part in parts:
        if 'class="progi"' not in part:
            continue
        time_m = re.search(r'<div class="time">(\d{1,2}:\d{2})</div>', part)
        tit_m = re.search(r'<div class="tit">(?:<a[^>]*>)?([^<]+)', part)
        stit_m = re.search(r'<div class="stit">(?:<a[^>]*>)?([^<]+)', part)
        if not time_m or not tit_m:
            continue
        items.append({
            "hour": time_m.group(1),
            "title": html_module.unescape(tit_m.group(1).strip()),
            "subtitle": html_module.unescape(stit_m.group(1).strip()) if stit_m else "",
        })
    return items


def fetch_formulatv(slug, day=""):
    """Descarga y parsea la parrilla de un canal en FormulaTV.

    day: "" = hoy, "manana" = mañana, "ayer" = ayer.
    Devuelve (items, cache_path).
    """
    suffix = "{0}/".format(day) if day else ""
    url = _FORMULATV_BASE.format(slug=slug) + suffix
    if day == "manana":
        caches = _FORMULATV_CACHES_MANANA
        fallback = "ftv_{0}_manana.html"
    elif day == "ayer":
        caches = _FORMULATV_CACHES_AYER
        fallback = "ftv_{0}_ayer.html"
    else:
        caches = _FORMULATV_CACHES
        fallback = "ftv_{0}.html"
    cache_path = caches.get(
        slug, os.path.join(_CACHE_DIR, fallback.format(slug.replace("-", "_")))
    )
    html = _fetch_url(url, "utf-8", cache_path, content_validator=_validate_formulatv_html)
    return _parse_formulatv(html), cache_path


def show_sport_channels_menu(handle, build_url):
    """Menú con la lista de canales deportivos disponibles."""
    for slug, label, icon_key in _FORMULATV_CHANNELS:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(label))
        li.setArt({"icon": _sport_icon(icon_key)})
        li.setInfo("video", {"plot": "Parrilla de hoy en {0}.".format(label)})
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=build_url(action="agenda_formulatv", slug=slug),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def show_formulatv_channel(handle, build_url, slug, day=""):
    """Renderiza la parrilla de un canal de FormulaTV.

    day: "" = hoy (por defecto), "manana" = mañana.
    """
    label = next((lbl for s, lbl, _ in _FORMULATV_CHANNELS if s == slug), slug)
    items, cache_path = fetch_formulatv(slug, day)

    updated_at = _format_cache_time(cache_path)
    update_label = (
        "[COLOR grey]Actualizado: {0}[/COLOR]".format(updated_at)
        if updated_at
        else "[COLOR grey]Datos no disponibles — pulsa para actualizar[/COLOR]"
    )
    li_upd = xbmcgui.ListItem(label=update_label)
    li_upd.setArt({"icon": "DefaultIconInfo.png"})
    li_upd.setInfo("video", {"plot": "Última actualización: {0}\nPulsa para forzar una descarga inmediata.".format(updated_at or "—")})
    xbmcplugin.addDirectoryItem(handle=handle, url=build_url(action="agenda_refresh"), listitem=li_upd, isFolder=False)

    # Navegación por días: Ayer / Hoy / Mañana
    _DAY_TABS = [("ayer", "← Ayer"), ("", "Hoy"), ("manana", "Mañana →")]
    for tab_day, tab_name in _DAY_TABS:
        is_active = (tab_day == day)
        tab_label = (
            "[COLOR white][B]{0}[/B][/COLOR]".format(tab_name)
            if is_active
            else "[COLOR deepskyblue]{0}[/COLOR]".format(tab_name)
        )
        li_tab = xbmcgui.ListItem(label=tab_label)
        li_tab.setArt({"icon": "DefaultAddonPVRClient.png"})
        li_tab.setInfo("video", {"plot": "Ver programación de {0}.".format(tab_name)})
        tab_url = build_url(action="agenda_formulatv", slug=slug, day=tab_day) if not is_active else ""
        xbmcplugin.addDirectoryItem(handle=handle, url=tab_url, listitem=li_tab, isFolder=not is_active)

    if not items:
        li = xbmcgui.ListItem(label="[COLOR grey]No hay programación disponible para {0}[/COLOR]".format(label))
        li.setInfo("video", {"plot": "No se ha podido obtener la parrilla.\nComprueba tu conexión a internet."})
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    icon_key = next((k for s, _, k in _FORMULATV_CHANNELS if s == slug), "otros")
    icon = _sport_icon(icon_key)

    _day_offset_map = {"ayer": -1, "": 0, "manana": 1}
    _ftv_date_str = (datetime.date.today() + datetime.timedelta(
        days=_day_offset_map.get(day, 0))).strftime("%d/%m/%Y")

    for item in items:
        hint = _time_hint(item["hour"])
        hint_str = "  [COLOR grey]{0}[/COLOR]".format(hint) if hint else ""
        title_part = (
            "{0} · {1}".format(item["title"], item["subtitle"])
            if item["subtitle"]
            else item["title"]
        )
        lbl = "[COLOR gold]{hour}[/COLOR]{hint}  {title}".format(
            hour=item["hour"], hint=hint_str, title=title_part,
        )
        li = xbmcgui.ListItem(label=lbl)
        li.setArt({"icon": icon})
        plot = "{0}\nHora: {1}\nFecha: {2}".format(item["title"], item["hour"], _ftv_date_str)
        if item["subtitle"]:
            plot += "\n{0}".format(item["subtitle"])
        li.setInfo("video", {"plot": plot, "title": item["title"]})
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)