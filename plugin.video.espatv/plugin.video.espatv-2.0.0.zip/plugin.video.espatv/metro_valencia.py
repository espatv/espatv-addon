# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Metrovalencia — Próximos trenes por trayecto (FGV / Metrovalencia)."""
import json
import os
import re
import sys
import time
import datetime
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG = "[EspaTV-MV]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_STATE_FILE = os.path.join(_PROFILE, "metrovalencia_state.json")
_CACHE_FILE = os.path.join(_PROFILE, "metrovalencia_cache.json")
_CACHE_TTL = 1800
_TIMEOUT = 25
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_URL = "https://www.metrovalencia.es/wp-admin/admin-ajax.php"
_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Android 11; Mobile; rv:109.0) Gecko/109.0 Firefox/109.0",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Referer": "https://www.metrovalencia.es/es/consulta-de-horarios-y-planificador/",
    "X-Requested-With": "XMLHttpRequest",
    "Origin": "https://www.metrovalencia.es",
}

# IDs verificados desde la API activa (GarriguesN/Metrovalencia-API, mayo 2026)
_STATIONS = {
    1: "Castelló",
    2: "Alberic",
    3: "Massalavés",
    4: "Montortal",
    5: "L'Alcúdia",
    6: "Benimodo",
    7: "Carlet",
    8: "Ausiàs March",
    9: "Alginet",
    10: "Font Almaguer",
    11: "Espioca",
    12: "Omet",
    13: "Picassent",
    14: "Sant Ramon",
    15: "Realón",
    16: "Col·legi El Vedat",
    17: "Torrent",
    18: "Picanya",
    19: "Paiporta",
    20: "València Sud",
    21: "Safranar",
    22: "Patraix",
    23: "Jesús",
    24: "Pl. Espanya",
    25: "Àngel Guimerà",
    26: "Túria",
    27: "Campanar",
    28: "Beniferri",
    29: "Empalme",
    30: "Burjassot",
    31: "Burjassot - Godella",
    32: "Godella",
    33: "Rocafort",
    34: "Massarrojos",
    35: "Moncada - Alfara",
    36: "Seminari - CEU",
    37: "Masies",
    38: "Horta Vella",
    39: "Bétera",
    40: "Cantereria",
    41: "Benimàmet",
    42: "Les Carolines - Fira",
    43: "Campament",
    44: "Paterna",
    45: "Fuente del Jarro",
    46: "La Canyada",
    47: "La Vallesa",
    48: "El Clot",
    49: "Montesol",
    50: "L'Eliana",
    51: "La Pobla de Vallbona",
    52: "Fondo de Benaguasil",
    53: "Benaguasil",
    54: "Llíria",
    55: "Palau de Congressos",
    56: "Alboraia Peris Aragó",
    57: "Almàssera",
    58: "Meliana",
    59: "Foios",
    60: "Albalat dels Sorells",
    61: "Museros",
    62: "Massamagrell",
    63: "La Pobla de Farnals",
    64: "Rafelbunyol",
    65: "Entrepins",
    66: "Machado",
    67: "Benimaclet",
    68: "Facultats - Manuel Broseta",
    69: "Alameda",
    70: "Colón",
    71: "Xàtiva",
    73: "Av. del Cid",
    74: "Nou d'Octubre",
    75: "Mislata",
    76: "Mislata Almassil",
    77: "Santa Rita",
    78: "Sant Isidre",
    79: "Alboraia Palmaret",
    80: "Florista",
    81: "Garbí",
    82: "Benicalap",
    83: "Trànsits",
    84: "Marxalenes",
    85: "Reus",
    86: "Sagunt",
    87: "Pont de Fusta",
    88: "Trinitat",
    90: "Vicente Zaragozá",
    91: "Universitat Politècnica",
    92: "La Carrasca",
    93: "Tarongers - Ernest Lluch",
    94: "Beteró",
    95: "La Cadena",
    96: "Platja Malva-rosa",
    97: "Platja les Arenes",
    98: "Dr. Lluch",
    99: "Cabanyal",
    100: "Fira València",
    102: "Vicent Andrés Estellés",
    103: "Campus",
    104: "Sant Joan",
    105: "La Granja",
    107: "Torrent Avinguda",
    108: "Bailén",
    110: "À Punt",
    111: "Parc Científic",
    112: "Tomás y Valiente",
    113: "La Coma",
    114: "Mas del Rosari",
    115: "Ll. Llarga - Terramelar",
    119: "Gallipont - Torre del Virrei",
    120: "Aragó",
    121: "Amistat",
    122: "Ayora",
    123: "Marítim",
    124: "Francesc Cubells",
    125: "Grau - La Marina",
    126: "Neptú",
    127: "Canyamelar",
    128: "Alfauir",
    129: "Orriols",
    130: "Estadi Ciutat de València",
    131: "Sant Miquel dels Reis",
    132: "Tossal del Rei",
    177: "Faitanar",
    178: "Quart de Poblet",
    179: "Salt de l'Aigua",
    180: "Manises",
    181: "Roses",
    182: "Aeroport",
    183: "La Cova",
    184: "La Presa",
    185: "Masia de Traver",
    186: "Riba-roja de Túria",
    188: "València la Vella",
    190: "Alacant",
    191: "Russafa",
    192: "Amado Granell - Montolivet",
    193: "Quatre Carreres",
    194: "Ciutat Arts i Ciències - Justícia",
    195: "Oceanogràfic",
    196: "Moreres",
    197: "Natzaret",
}

_STATIONS_SORTED = sorted(_STATIONS.items(), key=lambda x: x[1].lower())

_TIME_RE = re.compile(r'^\d{1,2}:\d{2}')


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _norm_time(t):
    """Normaliza HH:MM:SS o HH:MM a HH:MM."""
    if not t:
        return None
    t = str(t).strip()
    m = _TIME_RE.match(t)
    return m.group(0) if m else None


def _to_min(t):
    t = _norm_time(t)
    if not t:
        return None
    try:
        h, m = t.split(":")
        return int(h) * 60 + int(m)
    except Exception:
        return None


def _ensure_profile():
    if not xbmcvfs.exists(_PROFILE):
        xbmcvfs.mkdirs(_PROFILE)


def _load_state():
    try:
        with open(_STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save_state(state):
    _ensure_profile()
    try:
        with open(_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False)
    except OSError as e:
        xbmc.log("{0} Error guardando estado: {1}".format(_LOG, e), xbmc.LOGWARNING)


def _cache_key(origen_id, destino_id, fecha):
    return "ruta_{0}_{1}_{2}".format(origen_id, destino_id, fecha)


def _load_cache(key):
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        entry = obj.get(key, {})
        if time.time() - entry.get("ts", 0) < _CACHE_TTL:
            return entry.get("data")
    except (OSError, ValueError):
        pass
    return None


def _save_cache(key, data):
    _ensure_profile()
    try:
        try:
            with open(_CACHE_FILE, "r", encoding="utf-8") as f:
                obj = json.load(f)
        except (OSError, ValueError):
            obj = {}
        obj[key] = {"ts": time.time(), "data": data}
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except OSError as e:
        xbmc.log("{0} Error guardando caché: {1}".format(_LOG, e), xbmc.LOGWARNING)


def _fetch_ruta(origen_id, destino_id, fecha):
    inner = urllib.parse.urlencode({
        "action": "horarios-ruta",
        "origen": str(origen_id),
        "destino": str(destino_id),
        "dia": fecha,
        "horaDesde": "00:00",
        "horaHasta": "23:59",
    })
    body = urllib.parse.urlencode({
        "action": "formularios_ajax",
        "data": inner,
    })
    resp = requests.post(_URL, data=body, headers=_HEADERS, timeout=_TIMEOUT)
    resp.raise_for_status()
    return resp.json()


def _parse_trains(api_data, from_min):
    """Extrae lista de (dep, arr, dur_min, n_transbordos) desde la respuesta JSON.

    horas[i] = [departure_at_seg_start, train_id, real_departure(==scheduled)]
    La llegada se estima sumando la duracion de todos los segmentos.
    """
    trains = []
    if not isinstance(api_data, dict):
        return trains  # API devolvio [] / false cuando no hay ruta

    try:
        horarios = api_data.get("horarios") or []
        if not horarios or not isinstance(horarios, list):
            return trains

        total_dur_sec = sum(
            seg.get("duracion", 0) for seg in horarios if isinstance(seg, dict)
        )
        total_dur_min = total_dur_sec // 60
        n_transbordos = len(horarios) - 1

        first_seg = horarios[0]
        if not isinstance(first_seg, dict):
            return trains

        for entrada in (first_seg.get("horas") or []):
            if not isinstance(entrada, (list, tuple)) or len(entrada) < 2:
                continue
            dep = _norm_time(entrada[0])
            if not dep:
                continue
            dep_min = _to_min(dep)
            if dep_min is None or dep_min < from_min:
                continue
            arr_min_raw = dep_min + total_dur_min
            arr = "{:02d}:{:02d}".format((arr_min_raw % 1440) // 60, arr_min_raw % 60)
            trains.append((dep, arr, total_dur_min, n_transbordos))

    except Exception as e:
        xbmc.log("{0} Error parseando JSON: {1}".format(_LOG, e), xbmc.LOGWARNING)

    trains.sort(key=lambda x: _to_min(x[0]) or 9999)
    return trains


def metro_valencia_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_metro_valencia.png")
    state = _load_state()
    origen_id = state.get("origen_id")
    origen_name = state.get("origen_name", "—")
    destino_id = state.get("destino_id")
    destino_name = state.get("destino_name", "—")

    if origen_id and destino_id:
        li = xbmcgui.ListItem(
            label="[B][COLOR aqua]{0}  →  {1}[/COLOR][/B]".format(origen_name, destino_name)
        )
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Ver próximos trenes de {0} a {1}.".format(origen_name, destino_name)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="metro_valencia_trenes",
                   origen_id=origen_id, destino_id=destino_id,
                   origen_name=origen_name, destino_name=destino_name),
            listitem=li, isFolder=True,
        )

    li_o = xbmcgui.ListItem(label="[COLOR gold][ Cambiar origen: {0} ][/COLOR]".format(origen_name))
    li_o.setArt({"icon": "DefaultIconInfo.png"})
    li_o.setInfo("video", {"plot": "Selecciona la estación de origen."})
    li_o.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="metro_valencia_cambiar_origen"), listitem=li_o, isFolder=False)

    li_d = xbmcgui.ListItem(label="[COLOR gold][ Cambiar destino: {0} ][/COLOR]".format(destino_name))
    li_d.setArt({"icon": "DefaultIconInfo.png"})
    li_d.setInfo("video", {"plot": "Selecciona la estación de destino."})
    li_d.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="metro_valencia_cambiar_destino"), listitem=li_d, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def metro_valencia_cambiar_origen():
    names = [name for _, name in _STATIONS_SORTED]
    idx = xbmcgui.Dialog().select("Selecciona origen", names)
    if idx < 0:
        return
    st_id, st_name = _STATIONS_SORTED[idx]
    state = _load_state()
    state["origen_id"] = st_id
    state["origen_name"] = st_name
    _save_state(state)
    xbmc.executebuiltin("Container.Refresh")


def metro_valencia_cambiar_destino():
    names = [name for _, name in _STATIONS_SORTED]
    idx = xbmcgui.Dialog().select("Selecciona destino", names)
    if idx < 0:
        return
    st_id, st_name = _STATIONS_SORTED[idx]
    state = _load_state()
    state["destino_id"] = st_id
    state["destino_name"] = st_name
    _save_state(state)
    xbmc.executebuiltin("Container.Refresh")


def metro_valencia_trenes(origen_id, destino_id, origen_name, destino_name, **_):
    h = int(sys.argv[1])
    icon = _icon("cat_metro_valencia.png")
    origen_id = int(origen_id)
    destino_id = int(destino_id)

    now = datetime.datetime.now()
    fecha = now.strftime("%Y-%m-%d")
    from_min = now.hour * 60 + now.minute
    cache_key = _cache_key(origen_id, destino_id, now.strftime("%Y%m%d"))

    api_data = _load_cache(cache_key)
    if api_data is None:
        try:
            xbmcgui.Dialog().notification(
                "Metrovalencia", "Consultando horarios…",
                xbmcgui.NOTIFICATION_INFO, 1500
            )
            api_data = _fetch_ruta(origen_id, destino_id, fecha)
            _save_cache(cache_key, api_data)
        except requests.HTTPError as e:
            xbmc.log("{0} HTTP error: {1}".format(_LOG, e), xbmc.LOGERROR)
            _show_error(h, "Error del servidor ({0})".format(e.response.status_code if e.response else "?"))
            return
        except requests.ConnectionError:
            xbmc.log("{0} Sin conexión".format(_LOG), xbmc.LOGERROR)
            _show_error(h, "Sin conexión — comprueba la red")
            return
        except requests.Timeout:
            xbmc.log("{0} Timeout".format(_LOG), xbmc.LOGERROR)
            _show_error(h, "La web de Metrovalencia tardó demasiado — inténtalo de nuevo")
            return
        except Exception as e:
            xbmc.log("{0} Error inesperado: {1}".format(_LOG, e), xbmc.LOGERROR)
            _show_error(h, "Error inesperado — revisa el log de Kodi")
            return

    trains = _parse_trains(api_data, from_min)

    if not trains:
        msg = "[COLOR grey]No hay más trenes hoy entre {0} y {1}[/COLOR]".format(
            origen_name, destino_name
        )
        li = xbmcgui.ListItem(label=msg)
        li.setInfo("video", {"plot": "Mañana los horarios se actualizarán automáticamente."})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    else:
        for dep, arr, dur_min, n_transbordos in trains[:40]:
            dep_min = _to_min(dep) or 0
            mins_left = dep_min - from_min

            if mins_left <= 3:
                color_dep = "tomato"
            elif mins_left <= 10:
                color_dep = "gold"
            else:
                color_dep = "lightgreen"

            label = "[B][COLOR {0}]{1}[/COLOR][/B]  →  [COLOR white]{2}[/COLOR]  [COLOR grey]{3} min[/COLOR]".format(
                color_dep, dep, arr, dur_min
            )
            if n_transbordos > 0:
                label += "  [COLOR orange]+{0}C[/COLOR]".format(n_transbordos)

            plot_parts = [
                "[B]{0}  →  {1}[/B]".format(origen_name, destino_name),
                "",
                "  Sale:    [B]{0}[/B]".format(dep),
                "  Llega:   [B]{0}[/B]  (~{1} min)".format(arr, dur_min),
            ]
            if n_transbordos > 0:
                plot_parts.append("  [COLOR orange]{0} transbordo{1}[/COLOR]".format(
                    n_transbordos, "s" if n_transbordos > 1 else ""
                ))
            plot_parts.append("")
            if mins_left <= 0:
                plot_parts.append("[COLOR tomato]Ya ha salido[/COLOR]" if mins_left < 0 else "[COLOR tomato]¡Sale ahora![/COLOR]")
            elif mins_left == 1:
                plot_parts.append("[COLOR tomato]Sale en 1 minuto[/COLOR]")
            else:
                plot_parts.append("Sale en [B]{0}[/B] minutos".format(mins_left))

            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": icon})
            li.setInfo("video", {"title": "{0} → {1}".format(dep, arr), "plot": "\n".join(plot_parts)})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar horarios ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Elimina la caché y reconsulta los horarios de hoy."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="metro_valencia_refresh",
               origen_id=origen_id, destino_id=destino_id,
               origen_name=origen_name, destino_name=destino_name),
        listitem=li_r, isFolder=True,
    )
    xbmcplugin.endOfDirectory(h)


def metro_valencia_refresh(origen_id, destino_id, origen_name="", destino_name=""):
    origen_id_int = int(origen_id)
    destino_id_int = int(destino_id)
    now = datetime.datetime.now()
    cache_key = _cache_key(origen_id_int, destino_id_int, now.strftime("%Y%m%d"))
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        obj.pop(cache_key, None)
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except (OSError, ValueError):
        pass
    xbmc.executebuiltin("Container.Update({0},replace)".format(
        _u(action="metro_valencia_trenes",
           origen_id=origen_id, destino_id=destino_id,
           origen_name=origen_name, destino_name=destino_name)
    ))


def _show_error(h, msg):
    li = xbmcgui.ListItem(label="[COLOR red]{0}[/COLOR]".format(msg))
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)
