# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""
EspaTV - Buscador multimedia para Kodi.

Busca y reproduce contenido publico de Dailymotion y otras fuentes
legales.
Addon desarrollado por fullstackcurso, espatv y espakodi - RubénSDFA1laberot
Licencia: GPL-2.0-or-later (Si vas a usar este código, por favor, da crédito al desarrollador original e incluye esta licencia, 
ademas intenta contribuir al proyecto original si los cambios no son significativos para no fragmentar el desarrollo y la comunidad).

En el futuro habrán versiones para otros países hispanohablantes. Si quieres ayudar, ponte en contacto.

Este addon se ha hecho intentando que todo sea lo mas legal posible. Si crees que algo no lo es, ponte en contacto.

Es una adaptación para Kodi de una web y una app hechas por RubénSDFA1laberot que podrás encontrar en el repositorio de este proyecto próximamente.
"""
import sys
import os
import shutil
import time
import urllib.parse
from urllib.parse import urljoin, quote
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
import xbmcvfs
import json
import difflib
import re
import hashlib

# --- ACCESIBILIDAD ---
# Factory function (no herencia) porque xbmcgui.ListItem es tipo C++ nativo.

# Migración one-time desde force_white_text al nuevo acc_color_mode.
# Condición extra: no sobrescribir si el usuario ya configuró acc_color_mode.
try:
    _mig_addon = xbmcaddon.Addon()
    if _mig_addon.getSetting('acc_migrated_v1') != 'true':
        if (_mig_addon.getSetting('acc_color_mode') in ('', 'none')
                and _mig_addon.getSetting('force_white_text') == 'true'):
            _mig_addon.setSetting('acc_color_mode', 'white')
        _mig_addon.setSetting('acc_migrated_v1', 'true')
    del _mig_addon
except Exception:
    pass

_ACC_COLOR_MODE = 'none'
_ACC_FORCE_BOLD = False
_ACC_STRIP_SYMBOLS = False
try:
    _acc_addon = xbmcaddon.Addon()
    _ACC_COLOR_MODE = _acc_addon.getSetting('acc_color_mode') or 'none'
    _ACC_FORCE_BOLD = _acc_addon.getSetting('acc_force_bold') == 'true'
    _ACC_STRIP_SYMBOLS = _acc_addon.getSetting('acc_strip_symbols') == 'true'
    del _acc_addon
except Exception:
    pass

_ACC_ANY_ACTIVE = (_ACC_COLOR_MODE not in ('', 'none')) or _ACC_FORCE_BOLD or _ACC_STRIP_SYMBOLS

if _ACC_ANY_ACTIVE:
    # Tablas de remapeo para modos daltónicos
    _ACC_DRG_MAP = {  # daltonic_rg: deuteranopia/protanopia (sin rojo-verde)
        'red': 'orange', 'tomato': 'orange', 'crimson': 'orange',
        'maroon': 'orange', 'coral': 'orange', 'firebrick': 'orange',
        'green': 'cyan', 'lime': 'cyan', 'limegreen': 'cyan',
        'mediumseagreen': 'cyan', 'palegreen': 'cyan', 'springgreen': 'cyan',
        'darkgreen': 'cyan', 'forestgreen': 'cyan', 'seagreen': 'cyan',
        'aqua': 'cyan', 'cyan': 'cyan', 'deepskyblue': 'deepskyblue',
        'skyblue': 'skyblue', 'lightskyblue': 'lightskyblue',
        'royalblue': 'royalblue', 'cornflowerblue': 'cornflowerblue', 'blue': 'blue',
        'gold': 'yellow', 'khaki': 'yellow', 'yellow': 'yellow',
        # Neutros: preservar. gray/grey marcan items deshabilitados.
        'gray': 'gray', 'grey': 'grey', 'white': 'white',
        'darkgray': 'darkgray', 'darkgrey': 'darkgrey',
        'lightgray': 'lightgray', 'lightgrey': 'lightgrey',
        'black': 'black', 'silver': 'silver',
    }
    _ACC_DBY_MAP = {  # daltonic_by: tritanopia (sin azul-amarillo)
        'yellow': 'magenta', 'gold': 'magenta', 'khaki': 'magenta',
        'lemonchiffon': 'magenta', 'lightyellow': 'magenta',
        'blue': 'red', 'deepskyblue': 'red', 'royalblue': 'red',
        'cornflowerblue': 'red', 'lightskyblue': 'red', 'navy': 'red',
        'aqua': 'red', 'cyan': 'red', 'teal': 'red', 'turquoise': 'red',
        'skyblue': 'red', 'steelblue': 'red', 'cadetblue': 'red',
        # Neutros: preservar.
        'gray': 'gray', 'grey': 'grey', 'white': 'white',
        'darkgray': 'darkgray', 'darkgrey': 'darkgrey',
        'lightgray': 'lightgray', 'lightgrey': 'lightgrey',
        'black': 'black', 'silver': 'silver',
    }
    # Colores "destructivos" que el alto contraste preserva en rojo
    _ACC_HCD_KEEP_RED = frozenset({'red', 'tomato', 'crimson', 'maroon', 'coral', 'firebrick'})

    _ACC_COLOR_RE = re.compile(r'\[COLOR\s+([a-zA-Z]+)\]')
    _ACC_SYMBOL_TABLE = str.maketrans({'★': '*', '●': '*', '○': '-', '▲': '^', '▼': 'v', '◑': '~', '◐': '~'})

    def _acc_remap(match):
        c = match.group(1).lower()
        if _ACC_COLOR_MODE == 'white':
            return '[COLOR white]'
        elif _ACC_COLOR_MODE == 'daltonic_rg':
            return '[COLOR ' + _ACC_DRG_MAP.get(c, 'white') + ']'
        elif _ACC_COLOR_MODE == 'daltonic_by':
            return '[COLOR ' + _ACC_DBY_MAP.get(c, 'white') + ']'
        elif _ACC_COLOR_MODE == 'hc_dark':
            return '[COLOR ' + (c if c in _ACC_HCD_KEEP_RED else 'yellow') + ']'
        elif _ACC_COLOR_MODE == 'hc_light':
            return '[COLOR ' + (c if c in _ACC_HCD_KEEP_RED else 'black') + ']'
        return match.group(0)

    def _acc_transform(s):
        # El remap no es idempotente: cada label debe pasar una sola vez por esta función.
        if not isinstance(s, str) or not s:
            return s
        if _ACC_STRIP_SYMBOLS:
            s = s.translate(_ACC_SYMBOL_TABLE)
        if _ACC_FORCE_BOLD and '[B]' not in s:
            s = '[B]' + s + '[/B]'
        if _ACC_COLOR_MODE not in ('', 'none'):
            s = _ACC_COLOR_RE.sub(_acc_remap, s)
        return s

    def _ww(s):
        return _acc_transform(s)

    try:
        # Prevenir factory chaining si default.py se re-importa en el mismo proceso.
        _OrigListItem = getattr(xbmcgui, '_OrigListItemEspatv', None) or xbmcgui.ListItem
        xbmcgui._OrigListItemEspatv = _OrigListItem

        def _ListItemFactory(*args, **kwargs):
            if 'label' in kwargs:
                kwargs['label'] = _acc_transform(kwargs['label'])
            elif args:
                args = (_acc_transform(args[0]),) + args[1:]
            if 'label2' in kwargs:
                kwargs['label2'] = _acc_transform(kwargs['label2'])
            elif len(args) >= 2:
                args = (args[0], _acc_transform(args[1])) + args[2:]
            return _OrigListItem(*args, **kwargs)

        xbmcgui.ListItem = _ListItemFactory
        xbmc.log("[EspaTV] Accessibility patch installed (color={0} bold={1} symbols={2})".format(
            _ACC_COLOR_MODE, _ACC_FORCE_BOLD, _ACC_STRIP_SYMBOLS), xbmc.LOGINFO)
    except Exception as _e:
        xbmc.log("[EspaTV] Accessibility patch failed: {0}".format(_e), xbmc.LOGWARNING)

else:
    def _ww(s):
        return s
    # Restaurar ListItem original si la factory quedó instalada en un run previo del mismo proceso.
    try:
        _orig = getattr(xbmcgui, '_OrigListItemEspatv', None)
        if _orig is not None and xbmcgui.ListItem is not _orig:
            xbmcgui.ListItem = _orig
    except Exception:
        pass

import webcams as _webcams
import core_settings
import category_manager
import ytdlp_resolver
from _user_agents import UA_DESKTOP
import stats
import easter_egg_manager
import precio_luz
import librivox
import efemerides
import ibex
from install_helpers import (
    _install_espatv_repo,
    _flowfav_install,
    _loiolog_install,
)
from podcast_player import _podcast_menu, _podcast_feed, _play_podcast
from download_manager import _download_video
import yt_watched_tracker as _ywt
import watch_history as _wh
import log_manager as _lm
import yt_search as _yts
import search_history as _sh
import press_rss as _pr
import epg as _epg
import slyguy_installer as _slyguy
import top_movies as _tm
import yt_playlists as _ytp
import backups as _bk
import default_dispatch_extras as _extras

try:
    import requests
except ImportError:
    xbmc.log("[EspaTV] requests module not available", xbmc.LOGERROR)
    sys.exit(1)

# Firma de build original — no eliminar
_ORIGIN = "espakodi-rubensdfa1laberot-v1"

try:
    _home_win = xbmcgui.Window(10000)
    if not _home_win.getProperty("espatv_started"):
        _home_win.setProperty("espatv_started", "1")
        xbmc.log(
            "[EspaTV] Addon original por RubénSDFA1laberot — "
            "https://github.com/espakodi — GPL-2.0-or-later",
            xbmc.LOGINFO,
        )
except Exception:
    pass

_STATUS_URL = "https://raw.githubusercontent.com/espakodi/espatv/main/status.json"
_MESSAGES_URL = "https://raw.githubusercontent.com/espakodi/espatv/main/messages.json"

_DM_API_BASE = "https://api.dailymotion.com"
_DM_FIELDS = "id,title,thumbnail_720_url,thumbnail_360_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"


def _dm_search(query, extra_params=None):
    params = {
        "search": query, "limit": 30, "language": "es",
        "fields": _DM_FIELDS,
    }
    if extra_params:
        params.update(extra_params)
    try:
        resp = requests.get(_DM_API_BASE + "/videos", params=params, timeout=15)
        if resp.status_code == 200:
            return resp.json().get("list", [])
    except (requests.RequestException, ValueError) as exc:
        _log_error("DM search error: {0}".format(exc))
    return []


def _dm_resolve(vid):
    fields = _DM_FIELDS + ",qualities"
    try:
        resp = requests.get("{0}/video/{1}".format(_DM_API_BASE, vid),
                            params={"fields": fields}, timeout=15)
        if resp.status_code == 200:
            return resp.json()
    except (requests.RequestException, ValueError) as exc:
        _log_error("DM resolve error: {0}".format(exc))
    return None



_HEADERS_DM_DESKTOP = {
    "User-Agent": UA_DESKTOP,
    "Origin": "https://www.dailymotion.com",
    "Referer": "https://www.dailymotion.com/",
}


def _fetch_hls_variants(master_url, headers=None):
    """Devuelve las variantes del master playlist HLS, ordenadas de mayor a menor bitrate."""
    variants = []
    req_headers = headers if headers else {}
    try:
        r = requests.get(master_url, headers=req_headers, timeout=15)
        if r.status_code != 200:
            return variants

        lines = r.text.strip().splitlines()

        current_label = "unknown"
        current_bw = 0
        expecting_url = False

        for line in lines:
            line = line.strip()
            if not line:
                continue

            if line.startswith('#EXT-X-STREAM-INF'):
                res_match = re.search(r'RESOLUTION=(\d+x\d+)', line)
                bw_match = re.search(r'BANDWIDTH=(\d+)', line)
                current_label = res_match.group(1) if res_match else "unknown"
                current_bw = int(bw_match.group(1)) if bw_match else 0
                expecting_url = True
            elif expecting_url and not line.startswith('#'):
                stream_url = line
                if not stream_url.startswith('http'):
                    stream_url = urljoin(master_url, stream_url)
                variants.append({'label': current_label, 'url': stream_url, 'bandwidth': current_bw})
                expecting_url = False

        variants.sort(key=lambda x: x.get('bandwidth', 0), reverse=True)
    except (requests.RequestException, ValueError) as exc:
        _log_error("HLS variants lookup error: {0}".format(exc))
    return variants


def _dm_play_direct(vid, max_quality=1080):
    """Resolución directa via API de metadatos. Devuelve {url, mime, subs, headers} o None."""
    if not isinstance(vid, str) or not vid.strip():
        xbmc.log("[EspaTV] _dm_play_direct: ID de video invalido", xbmc.LOGWARNING)
        return None
        
    vid_safe = quote(vid.strip())
    
    try:
        meta_url = "https://www.dailymotion.com/player/metadata/video/{0}".format(vid_safe)
        r = requests.get(meta_url, headers=_HEADERS_DM_DESKTOP, timeout=15)
        
        if r.status_code != 200:
            xbmc.log("[EspaTV] _dm_play_direct error HTTP: {0}".format(r.status_code), xbmc.LOGWARNING)
            return None
            
        data = r.json()
        
        # Log GEO-Block/Errores específicos
        if data.get("error"):
            err_msg = data["error"].get("message", "Error API desconocido")
            xbmc.log("[EspaTV] Dailymotion API Error: {0}".format(err_msg), xbmc.LOGWARNING)
            return None

        qualities = data.get("qualities", {})
        subtitles = []
        subs_data = data.get("subtitles", {})
        
        # Extracción defensiva de subtítulos (la estructura varía entre vídeos)
        if isinstance(subs_data, dict):
            for lang, sub_list in subs_data.items():
                if isinstance(sub_list, list):
                    for sub in sub_list:
                        if isinstance(sub, dict) and sub.get("url"):
                            subtitles.append(sub.get("url"))

        # 1. Buscar MP4 directo (mejor compatibilidad en Android)
        best_mp4 = None
        best_res = 0
        for res_key, formats in qualities.items():
            if res_key == "auto":
                continue
            try:
                res_val = int(res_key)
            except (ValueError, TypeError):
                continue
                
            if res_val > max_quality:
                continue
                
            for fmt in formats:
                if isinstance(fmt, dict) and fmt.get("type") == "video/mp4" and res_val > best_res:
                    best_mp4 = fmt.get("url")
                    best_res = res_val
                    
        if best_mp4:
            xbmc.log("[EspaTV] _dm_play_direct: MP4 directo {0}p".format(best_res), xbmc.LOGINFO)
            return {"url": best_mp4, "mime": "video/mp4", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}

        # 2. Buscar HLS (fallback si no hay MP4 directo)
        hls_url = None
        if "auto" in qualities:
            for item in qualities["auto"]:
                if isinstance(item, dict) and item.get("type") == "application/x-mpegURL":
                    hls_url = item.get("url")
                    break
                    
        if hls_url:
            xbmc.log("[EspaTV] _dm_play_direct: parseando manifiesto HLS", xbmc.LOGINFO)
            # Pasar cabeceras al fetch del manifiesto para evitar 403 en CDN
            variants = _fetch_hls_variants(hls_url, headers=_HEADERS_DM_DESKTOP)
            
            if variants:
                filtered = []
                for v in variants:
                    label = v.get("label", "")
                    try:
                        height = int(label.split("x")[1].split(" ")[0]) if "x" in label else 0
                    except (ValueError, IndexError):
                        height = 0
                        
                    if height > 0 and height <= max_quality:
                        filtered.append(v)
                
                target = filtered[0] if filtered else variants[-1]
                xbmc.log("[EspaTV] _dm_play_direct: variante HLS seleccionada: {0}".format(target.get("label")), xbmc.LOGINFO)
                return {"url": target["url"], "mime": "application/x-mpegURL", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}

            # Sin variantes parseables, pasar la URL maestra directamente
            xbmc.log("[EspaTV] _dm_play_direct: sin variantes, usando master URL", xbmc.LOGWARNING)
            return {"url": hls_url, "mime": "application/x-mpegURL", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}

    except (requests.RequestException, ValueError) as exc:
        xbmc.log("[EspaTV] _dm_play_direct error: {0}".format(exc), xbmc.LOGERROR)
    return None


def _dm_play(vid, dm_level=0, max_quality=1080):
    """Cascada Dailymotion: dm_gujal (extreme/basic) → fallback directo MP4/HLS."""
    try:
        import dm_gujal

        if dm_level == 2:
            xbmc.log("[EspaTV] _dm_play: usando modo EXTREMO para {0}".format(vid), xbmc.LOGINFO)
            url, subs, mime = dm_gujal.play_dm_extreme(vid, max_quality=max_quality)
            if url:
                return {'url': url, 'subs': subs, 'mime': mime or 'application/x-mpegURL'}
        elif dm_level == 1:
            xbmc.log("[EspaTV] _dm_play: usando modo BASICO para {0}".format(vid), xbmc.LOGINFO)
            url, mime = dm_gujal.play_dm_basic(vid)
            if url:
                return {'url': url, 'mime': mime or 'application/x-mpegURL'}
        else:
            # Default (nivel 0): extreme primero, basic como fallback
            xbmc.log("[EspaTV] _dm_play: usando modo DEFAULT (extreme+fallback) para {0}".format(vid), xbmc.LOGINFO)
            url, subs, mime = dm_gujal.play_dm_extreme(vid, max_quality=max_quality)
            if url:
                xbmc.log("[EspaTV] _dm_play: extreme OK, mime={0}".format(mime), xbmc.LOGINFO)
                return {'url': url, 'subs': subs, 'mime': mime or 'application/x-mpegURL'}
            xbmc.log("[EspaTV] _dm_play: extreme falló, intentando basic...", xbmc.LOGINFO)
            url, mime = dm_gujal.play_dm_basic(vid)
            if url:
                xbmc.log("[EspaTV] _dm_play: basic OK, mime={0}".format(mime), xbmc.LOGINFO)
                return {'url': url, 'mime': mime or 'application/x-mpegURL'}
    except (ImportError, RuntimeError, AttributeError) as exc:
        _log_error("dm_gujal play error: {0}".format(exc))
        xbmc.log("[EspaTV] _dm_play EXCEPTION: {0}".format(exc), xbmc.LOGERROR)

    # Fallback directo: moderna extracción nativa
    xbmc.log("[EspaTV] _dm_play: intentando fallback directo para {0}".format(vid), xbmc.LOGINFO)
    result = _dm_play_direct(vid, max_quality=max_quality)
    if result:
        xbmc.log("[EspaTV] _dm_play: fallback directo OK", xbmc.LOGINFO)
        return result

    xbmc.log("[EspaTV] _dm_play: todos los métodos fallaron para {0}".format(vid), xbmc.LOGWARNING)
    return None


def _dm_play_android(vid, dm_level=0, max_quality=1080):
    """Variante para no-Windows: resolución directa primero, dm_gujal como fallback.

    El reproductor nativo de Android/Linux no aplica bien las cabeceras pipe que
    inyecta dm_gujal, así que probamos primero la resolución directa que devuelve
    URLs limpias.
    """
    result = None

    xbmc.log("[EspaTV] _dm_play_android: resolucion directa para {0}".format(vid), xbmc.LOGINFO)
    direct = _dm_play_direct(vid, max_quality=max_quality)
    if direct and direct.get('url'):
        xbmc.log("[EspaTV] _dm_play_android: resolucion directa OK", xbmc.LOGINFO)
        result = direct
    else:
        xbmc.log("[EspaTV] _dm_play_android: fallback dm_gujal para {0}".format(vid), xbmc.LOGINFO)
        gujal = _dm_play(vid, dm_level=dm_level, max_quality=max_quality)
        if gujal and gujal.get('url'):
            xbmc.log("[EspaTV] _dm_play_android: dm_gujal OK", xbmc.LOGINFO)
            result = gujal

    if result is None:
        xbmc.log("[EspaTV] _dm_play_android: sin resultados para {0}".format(vid), xbmc.LOGWARNING)
        return None

    # Descartar headers del dict para evitar que _pv() los inyecte
    # como pipe en la URL. En Android los headers pipe no se aplican
    # correctamente al reproductor nativo.
    result.pop('headers', None)
    return result


def _dm_search_channels(query):
    try:
        params = {"search": query, "limit": 20, "fields": "id,screenname,username,avatar_720_url"}
        resp = requests.get(_DM_API_BASE + "/users", params=params, timeout=15)
        if resp.status_code == 200:
            return resp.json().get("list", [])
    except (requests.RequestException, ValueError) as exc:
        _log_error("DM channel search error: {0}".format(exc))
    return []


def _dm_list_user_playlists(user):
    try:
        params = {"limit": 50, "fields": "id,name,description,videos_total"}
        resp = requests.get("{0}/user/{1}/playlists".format(_DM_API_BASE, user),
                           params=params, timeout=15)
        if resp.status_code == 200:
            results = resp.json().get("list", [])
            for r in results:
                r["count"] = r.pop("videos_total", 0)
            return results
    except (requests.RequestException, ValueError) as exc:
        _log_error("DM user playlists error: {0}".format(exc))
    return []


def _dm_view_playlist_api(pid):
    try:
        params = {"limit": 50, "fields": _DM_FIELDS}
        resp = requests.get("{0}/playlist/{1}/videos".format(_DM_API_BASE, pid),
                           params=params, timeout=15)
        if resp.status_code == 200:
            return resp.json().get("list", [])
    except (requests.RequestException, ValueError) as exc:
        _log_error("DM view playlist error: {0}".format(exc))
    return []


def _get_saved_playlists_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, 'saved_playlists.json')


def _load_saved_playlists():
    path = _get_saved_playlists_file()
    if not os.path.exists(path):
        return []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def _save_saved_playlists(data):
    path = _get_saved_playlists_file()
    with open(path, 'w', encoding='utf-8') as f:
        f.write(json.dumps(data, ensure_ascii=False, indent=2))


def _add_saved_playlist(pid, name, user, count=0):
    saved = _load_saved_playlists()
    for s in saved:
        if s.get('pid') == pid:
            return False
    saved.append({'pid': pid, 'name': name, 'user': user, 'count': count})
    _save_saved_playlists(saved)
    return True


def _remove_saved_playlist(pid):
    saved = _load_saved_playlists()
    saved = [s for s in saved if s.get('pid') != pid]
    _save_saved_playlists(saved)


def _dm_playlists_search_menu():
    kb = xbmc.Keyboard('', 'Buscar canal en Dailymotion')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText():
        return
    query = kb.getText()
    channels = _dm_search_channels(query)
    if not channels:
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron canales", xbmcgui.NOTIFICATION_WARNING)
        return
    h = int(sys.argv[1])
    for ch in channels:
        username = ch.get('username', '')
        screenname = ch.get('screenname', username)
        avatar = ch.get('avatar_720_url', '')
        li = xbmcgui.ListItem(label=screenname)
        li.setArt({'icon': avatar, 'thumb': avatar})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dm_user_playlists", user=username), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _dm_user_playlists_menu(user):
    playlists = _dm_list_user_playlists(user)
    if not playlists:
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron playlists", xbmcgui.NOTIFICATION_WARNING)
        return
    h = int(sys.argv[1])
    saved_pids = {s['pid'] for s in _load_saved_playlists()}
    for pl in playlists:
        pid = pl.get('id', '')
        name = pl.get('name', 'Sin nombre')
        count = pl.get('count', 0)
        is_saved = pid in saved_pids
        prefix = "[COLOR green]★[/COLOR] " if is_saved else ""
        li = xbmcgui.ListItem(label="{0}{1} ({2} vídeos)".format(prefix, name, count))
        # Menú contextual: guardar o quitar
        ctx = []
        if is_saved:
            ctx.append(("Quitar de guardados", "RunPlugin({0})".format(_u(action="dm_unsave_playlist", pid=pid))))
        else:
            ctx.append(("Guardar playlist", "RunPlugin({0})".format(_u(action="dm_save_playlist", pid=pid, name=name, user=user, count=count))))
        li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dm_view_playlist", pid=pid), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _dm_saved_playlists_menu():
    saved = _load_saved_playlists()
    h = int(sys.argv[1])
    if not saved:
        li = xbmcgui.ListItem(label="[COLOR grey]No tienes playlists guardadas[/COLOR]")
        li.setInfo('video', {'plot':
            "Para guardar una playlist:\n"
            "1. Ve a Catálogo → Playlists de Dailymotion\n"
            "2. Busca un canal (ej: antena3, telecinco...)\n"
            "3. Entra en el canal y verás sus playlists\n"
            "4. Mantén pulsado sobre una playlist → Guardar playlist\n\n"
            "Para borrar una playlist guardada:\n"
            "Mantén pulsado sobre ella → Quitar de guardados"})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    for s in saved:
        pid = s.get('pid', '')
        name = s.get('name', 'Sin nombre')
        user = s.get('user', '')
        count = s.get('count', 0)
        li = xbmcgui.ListItem(label="{0} ({1} vídeos) — {2}".format(name, count, user))
        ctx = [("Quitar de guardados", "RunPlugin({0})".format(_u(action="dm_unsave_playlist", pid=pid)))]
        li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dm_view_playlist", pid=pid), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _dm_view_playlist_menu(pid):
    items = _dm_view_playlist_api(pid)
    if not items:
        xbmcgui.Dialog().notification("EspaTV", "Playlist vacía o error", xbmcgui.NOTIFICATION_WARNING)
        return
    h = int(sys.argv[1])
    for v in items:
        vid = v.get('id', '')
        title = v.get('title', 'Sin título')
        thumb = v.get('thumbnail_720_url') or v.get('thumbnail_360_url') or v.get('thumbnail_url', '')
        duration = v.get('duration', 0)
        owner = v.get('owner.screenname', '')
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': thumb, 'icon': thumb})
        li.setInfo('video', {'title': title, 'duration': duration, 'plot': "Canal: {0}".format(owner)})
        li.setProperty('IsPlayable', 'true')
        cm = []
        cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action='download_video', vid=vid, title=title))))
        cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action='dm_open_browser', url=vid))))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vid)))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vid), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def _l(m): xbmc.log("[EspaTV] {0}".format(m), xbmc.LOGINFO)
def _u(**k): return sys.argv[0] + "?" + urllib.parse.urlencode(k)
def _fix_img(t):
    return t

def _load_spanish_channels():
    data = {}
    try:
        addon_path = xbmcaddon.Addon().getAddonInfo('path')
        main_path = os.path.join(addon_path, 'canales_espana.json')
        if os.path.exists(main_path):
            with open(main_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        meme_path = os.path.join(addon_path, 'museo_meme.json')
        if os.path.exists(meme_path):
            with open(meme_path, 'r', encoding='utf-8') as f:
                data.update(json.load(f))
    except (OSError, ValueError) as e:
        xbmc.log("[EspaTV] Error cargando canales: {0}".format(e), xbmc.LOGWARNING)
    return data


def _spanish_section_menu(section):
    data = _load_spanish_channels()
    sec = data.get(section)
    if not sec:
        xbmcgui.Dialog().notification("EspaTV", "Sección no encontrada", xbmcgui.NOTIFICATION_WARNING)
        return
    h = int(sys.argv[1])
    channels = sec.get('channels', [])
    url_channels = [ch for ch in channels if ch.get('url', '')]
    if url_channels and section == 'museo_meme':
        li_all = xbmcgui.ListItem(label="[B][COLOR gold]Reproducir todo ({0} vídeos)[/COLOR][/B]".format(len(url_channels)))
        _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
        _icon = os.path.join(_mp, sec.get('icon', ''))
        li_all.setArt({'icon': _icon, 'thumb': _icon})
        _full_plot = sec.get('plot', '')
        _warning = _full_plot.split('\n\n', 1)[-1] if '\n\n' in _full_plot else _full_plot
        li_all.setInfo('video', {'title': 'Reproducir todo', 'plot': _warning})
        li_all.setProperty('SpecialSort', 'top')
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="spanish_section_play_all", section=section), listitem=li_all, isFolder=False)
    watched = _ywt.load()
    for ch in channels:
        direct_url = ch.get('url', '')
        name = ch.get('name', '')
        if direct_url:
            m = re.search(r'[?&]v=([^&]+)', direct_url)
            yt_id = m.group(1) if m else ''
            is_watched = yt_id in watched
            label = "[COLOR gray](Visto) {0}[/COLOR]".format(name) if is_watched else "[COLOR lime]{0}[/COLOR]".format(name)
            thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id) if yt_id else 'DefaultVideo.png'
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': thumb, 'thumb': thumb})
            _desc = ch.get('description', '')
            _year = ch.get('year', '')
            _chan = ch.get('channel', '')
            _views = ch.get('views', 0)
            _plot_parts = []
            if _chan:
                _plot_parts.append('Canal: {0}'.format(_chan))
            if _year:
                _plot_parts.append('Año: {0}'.format(_year))
            if _views:
                _plot_parts.append('Vistas: {0:,}'.format(_views).replace(',', '.'))
            if _desc:
                _plot_parts.append(_desc)
            li.setInfo('video', {'title': name, 'plot': '\n'.join(_plot_parts), 'year': int(_year) if _year.isdigit() else 0})
            fav_params = json.dumps({"yt_id": yt_id, "name": name, "ctype": "video", "burl": direct_url})
            cm = []
            if yt_id:
                if is_watched:
                    cm.append(("Desmarcar como visto", "RunPlugin({0})".format(_u(action='yt_toggle_watched', yt_id=yt_id))))
                else:
                    cm.append(("Marcar como visto", "RunPlugin({0})".format(_u(action='yt_toggle_watched', yt_id=yt_id))))
                cm.append(("Añadir a cola de reproducción", "RunPlugin({0})".format(_u(action='yt_queue_add', yt_id=yt_id, name=name))))
            cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(
                _u(action='add_favorite', title=name, fav_url='yt_{0}'.format(yt_id),
                   icon=thumb, platform='youtube', fav_action='felicidad_play', params=fav_params))))
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_play", yt_id=yt_id, name=name, ctype="video", burl=direct_url), listitem=li, isFolder=True)
            continue
        username = ch.get('username', '')
        if not name:
            name = username
        li = xbmcgui.ListItem(label=name)
        try:
            r = requests.get("{0}/user/{1}".format(_DM_API_BASE, username),
                           params={"fields": "avatar_720_url,screenname"}, timeout=5)
            if r.status_code == 200:
                info = r.json()
                avatar = info.get('avatar_720_url', '')
                if avatar:
                    li.setArt({'icon': avatar, 'thumb': avatar})
                real_name = info.get('screenname', name)
                li.setLabel(real_name)
            else:
                li.setArt({'icon': 'DefaultActor.png'})
                li.setLabel(_ww("{0} [COLOR grey](no disponible)[/COLOR]".format(name)))
        except (requests.RequestException, ValueError):
            li.setArt({'icon': 'DefaultActor.png'})
        ctx = []
        ctx.append(("Ver playlists del canal", "Container.Update({0})".format(_u(action="dm_user_playlists", user=username))))
        fav_params = json.dumps({"user": username, "name": name})
        ctx.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(_u(action='add_favorite', title=name, fav_url='spanish_channel_videos_{0}'.format(username), icon=li.getArt('icon'), platform='catalogo', fav_action='spanish_channel_videos', params=fav_params))))
        li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="spanish_channel_videos", user=username, name=name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _play_ytdlp_by_id(yt_id, name=""):
    h = int(sys.argv[1])
    stream_url = None
    try:
        stream_url = ytdlp_resolver.resolve("https://www.youtube.com/watch?v={0}".format(yt_id))
    except Exception as exc:
        xbmc.log("[EspaTV] _play_ytdlp_by_id resolve error ({0}): {1}".format(yt_id, exc), xbmc.LOGWARNING)
    if stream_url:
        thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
        li = xbmcgui.ListItem(label=name or yt_id, path=stream_url)
        li.setArt({"icon": thumb, "thumb": thumb})
        li.setInfo("video", {"title": name or yt_id})
        li.setProperty("IsPlayable", "true")
        li.setContentLookup(False)
        try:
            _wh.add(yt_id, name or yt_id, thumb=thumb, duration=0)
        except (OSError, ValueError):
            pass
        xbmcplugin.setResolvedUrl(h, True, li)
    else:
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem(label=name or yt_id))


def _spanish_section_play_all(section):
    data = _load_spanish_channels()
    sec = data.get(section)
    if not sec:
        return
    videos = [ch for ch in sec.get('channels', []) if ch.get('url', '')]
    if not videos:
        xbmcgui.Dialog().notification("EspaTV", "No hay vídeos en esta sección", xbmcgui.NOTIFICATION_WARNING)
        return
    has_yt = xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)")
    has_ytdlp = ytdlp_resolver.is_available()
    if not has_yt and not has_ytdlp:
        xbmcgui.Dialog().ok("EspaTV", "Se necesita el addon YouTube o yt-dlp para reproducir toda la lista.")
        return
    try:
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        added = 0
        for ch in videos:
            url = ch.get('url', '')
            name = ch.get('name', '')
            m = re.search(r'[?&]v=([^&]+)', url)
            yt_id = m.group(1) if m else ''
            if not yt_id:
                continue
            thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
            li = xbmcgui.ListItem(label=name)
            li.setArt({'icon': thumb, 'thumb': thumb})
            li.setInfo('video', {'title': name})
            li.setProperty('IsPlayable', 'true')
            if has_yt:
                plugin_url = "plugin://plugin.video.youtube/play/?video_id={0}".format(yt_id)
            else:
                plugin_url = _u(action="play_ytdlp_by_id", yt_id=yt_id, name=name)
            pl.add(plugin_url, li)
            added += 1
        if added == 0:
            xbmcgui.Dialog().notification("EspaTV", "No se encontraron vídeos válidos", xbmcgui.NOTIFICATION_WARNING)
            return
        xbmcgui.Dialog().notification("EspaTV", "Reproduciendo {0} vídeos...".format(added), xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.Player().play(pl)
    except Exception as exc:
        xbmc.log("[EspaTV] _spanish_section_play_all error: {0}".format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("EspaTV", "Error al iniciar la reproducción", xbmcgui.NOTIFICATION_ERROR)


def _spanish_channel_videos(user, name=""):
    """Vídeos recientes de un canal DM español. Empieza el menú con un acceso a sus playlists."""
    try:
        params = {"limit": 50, "fields": _DM_FIELDS, "sort": "recent"}
        resp = requests.get("{0}/user/{1}/videos".format(_DM_API_BASE, user),
                           params=params, timeout=15)
        if resp.status_code != 200:
            xbmcgui.Dialog().notification("EspaTV", "Canal no disponible", xbmcgui.NOTIFICATION_WARNING)
            return
        items = resp.json().get("list", [])
    except (requests.RequestException, ValueError) as exc:
        xbmcgui.Dialog().notification("EspaTV", "Error: {0}".format(exc), xbmcgui.NOTIFICATION_ERROR)
        return
    if not items:
        xbmcgui.Dialog().notification("EspaTV", "Sin vídeos recientes", xbmcgui.NOTIFICATION_INFO)
        return
    h = int(sys.argv[1])
    # Añadir opción para ver playlists al inicio
    li_pl = xbmcgui.ListItem(label="[COLOR yellow]Ver playlists de {0}[/COLOR]".format(name or user))
    li_pl.setArt({'icon': 'DefaultVideoPlaylists.png'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dm_user_playlists", user=user), listitem=li_pl, isFolder=True)
    for v in items:
        vid = v.get('id', '')
        title = v.get('title', 'Sin título')
        thumb = v.get('thumbnail_720_url') or v.get('thumbnail_360_url') or v.get('thumbnail_url', '')
        duration = v.get('duration', 0)
        owner = v.get('owner.screenname', name)
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': thumb, 'icon': thumb})
        li.setInfo('video', {'title': title, 'duration': duration, 'plot': "Canal: {0}".format(owner)})
        li.setProperty('IsPlayable', 'true')
        cm = []
        cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action='download_video', vid=vid, title=title))))
        cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action='dm_open_browser', url=vid))))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vid)))))
        fav_params = json.dumps({"q": title, "ot": thumb})
        cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(_u(action='add_favorite', title=title, fav_url='lfr_{0}'.format(vid), icon=thumb, platform='dailymotion', fav_action='lfr', params=fav_params))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vid), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def _catalog_menu():
    h = int(sys.argv[1])
    data = _load_spanish_channels()
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ri(name, fallback='DefaultFolder.png'):
        if name and not name.startswith('Default'):
            p = os.path.join(_mp, name)
            return p if os.path.isfile(p) else fallback
        return name or fallback

    # 1. Verano
    fv_count = sum(len(v) for v in _FELICIDAD_VERANIEGA_YT.values())
    li = xbmcgui.ListItem(label="[B][COLOR khaki]Verano[/COLOR][/B] ({0})".format(fv_count))
    li.setArt({'icon': _ri('cat_felicidad.png', 'DefaultMusicVideos.png')})
    li.setInfo('video', {'plot': "Contenido para el buen rollo veraniego.\nGrand Prix, Humor Amarillo, summer mixes y buenas vibraciones.\nRequiere addon YouTube."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_menu"), listitem=li, isFolder=True)

    # Educación y Divulgación
    edu_count = sum(len(v) for v in _EDUCACION_DIVULGACION_YT.values())
    li = xbmcgui.ListItem(label="[B][COLOR cornflowerblue]Educación y Divulgación[/COLOR][/B] ({0})".format(edu_count))
    li.setArt({'icon': _ri('cat_educacion.png', 'DefaultAddonHelper.png')})
    li.setInfo('video', {'plot': "Canales de divulgación científica, historia, matemáticas y tecnología en español.\nRequiere addon YouTube."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="educacion_menu"), listitem=li, isFolder=True)

    # 2. Cocina Española
    cc_count = sum(len(v) for v in _COCINA_ESPANOLA_YT.values())
    if cc_count > 0:
        li = xbmcgui.ListItem(label="[B][COLOR peru]Cocina Española[/COLOR][/B] ({0})".format(cc_count))
        li.setArt({'icon': _ri('cat_cocina.png', 'DefaultMusicVideos.png')})
        li.setInfo('video', {'plot': "Recetas y cocina española en YouTube.\nTortillas, paellas, tapas y mucho más."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cocina_menu"), listitem=li, isFolder=True)

    # 4. DGT — Tráfico
    li = xbmcgui.ListItem(label="[B][COLOR mediumpurple]DGT — Estado del tráfico[/COLOR][/B]")
    li.setArt({'icon': _ri('dgt_coche.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Incidencias en carretera en tiempo real: retenciones, accidentes, obras, niebla, nieve."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dgt_menu"), listitem=li, isFolder=True)

    # 5. Playlists de YouTube
    yt_pl_saved = _ytp._load_yt_playlists()
    yt_pl_count = len(yt_pl_saved)
    yt_pl_label = "Playlists de YouTube ({0})".format(yt_pl_count) if yt_pl_count else "Playlists de YouTube"
    li = xbmcgui.ListItem(label="[B][COLOR tomato]{0}[/COLOR][/B]".format(yt_pl_label))
    li.setArt({'icon': 'DefaultVideoPlaylists.png'})
    li.setInfo('video', {'plot': "Gestiona tus playlists de YouTube.\nPega la URL de una playlist y accede a ella desde aquí.\nPuedes pegar desde el mando o desde tu móvil/PC."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_playlists_menu"), listitem=li, isFolder=True)

    # 6. Último Boletín de Noticias
    li = xbmcgui.ListItem(label="[B][COLOR goldenrod]Último Boletín de Noticias[/COLOR][/B]")
    li.setArt({'icon': _ri('radio_blanca.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Reproduce el audio del último informativo nacional de radio (Cadena SER / RNE / COPE).\nSe reproduce en segundo plano."})
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_latest_news"), listitem=li, isFolder=False)

    # Tendencias
    li = xbmcgui.ListItem(label="[B][COLOR limegreen]Tendencias[/COLOR][/B]")
    li.setArt({'icon': 'DefaultMusicTop100.png'})
    li.setInfo('video', {'plot': "Vídeos trending en español de la última semana."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trending"), listitem=li, isFolder=True)

    # Buscar en Dailymotion
    li = xbmcgui.ListItem(label="[B][COLOR steelblue]Buscar canales y playlists[/COLOR][/B]")
    li.setArt({'icon': 'DefaultAddonsSearch.png'})
    li.setInfo('video', {'plot': "Busca cualquier canal de Dailymotion por nombre.\nPuedes explorar sus vídeos, ver sus playlists y guardarlas en tu colección."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dm_playlists_search"), listitem=li, isFolder=True)

    # Mis Playlists guardadas
    saved = _load_saved_playlists()
    count = len(saved)
    label_saved = "[B][COLOR plum]Mis Playlists guardadas ({0})[/COLOR][/B]".format(count) if count else "[B][COLOR plum]Mis Playlists guardadas[/COLOR][/B]"
    li = xbmcgui.ListItem(label=label_saved)
    li.setArt({'icon': 'DefaultPlaylist.png'})
    li.setInfo('video', {'plot': "Playlists de Dailymotion que has guardado.\nPuedes guardar playlists desde la búsqueda y borrarlas desde aquí."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dm_saved_playlists"), listitem=li, isFolder=True)

    # Cámaras de España en Directo
    li = xbmcgui.ListItem(label="[B][COLOR turquoise]España en Vivo[/COLOR][/B]")
    li.setArt({'icon': _ri('webcam_blanca.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Cámaras web en directo de playas, ciudades y montañas de España."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="webcams_menu"), listitem=li, isFolder=True)

    # Reloj Mundial
    li = xbmcgui.ListItem(label="[B][COLOR deepskyblue]Reloj Mundial[/COLOR][/B]")
    li.setArt({'icon': _ri('reloj_mundial.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Hora actual en las principales ciudades del mundo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="reloj_mundial_menu"), listitem=li, isFolder=True)

    # Lotería Nacional
    li = xbmcgui.ListItem(label="[B][COLOR royalblue]Lotería Nacional[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_loteria.png', 'DefaultAddonGame.png')})
    li.setInfo('video', {'plot': "Últimos resultados de Primitiva, Euromillones, Bonoloto, El Gordo, ONCE y más."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="loteria_menu"), listitem=li, isFolder=True)

    # Precio de la Luz
    li = xbmcgui.ListItem(label="[B][COLOR gold]Precio de la Luz por Horas[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_luz.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Precio PVPC de la electricidad en España, hora a hora.\nFuente: API oficial de Red Eléctrica de España (apidatos.ree.es)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="precio_luz_menu"), listitem=li, isFolder=True)

    # Audiolibros LibriVox
    li = xbmcgui.ListItem(label="[B][COLOR khaki]Audiolibros[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_audiolibros.png', 'DefaultAudio.png')})
    li.setInfo('video', {'plot': "Audiolibros gratuitos de dominio público.\nObras en español e inglés."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="librivox_menu"), listitem=li, isFolder=True)

    # Documentales en español (Archive.org)
    li = xbmcgui.ListItem(label="[B][COLOR mediumseagreen]Documentales en español[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_documentales.png', 'DefaultMovies.png')})
    li.setInfo('video', {'plot': "Documentales en español del archivo público de Internet Archive.\nHistoria, naturaleza, ciencia, cultura y más.\n\nLos documentales se obtienen mediante búsqueda en directo cada vez que entras. No hay enlaces fijos: el catálogo puede variar en cada consulta."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="archive_documentales_es"), listitem=li, isFolder=True)

    # Efemérides España
    li = xbmcgui.ListItem(label="[B][COLOR lightblue]Un día como hoy en la Historia de España[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_efemerides.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Efemérides relevantes para España según Wikipedia.\nAcontecimientos, nacimientos y fallecimientos del día."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="efemerides_menu"), listitem=li, isFolder=True)

    # IBEX 35
    li = xbmcgui.ListItem(label="[B][COLOR orange]IBEX 35 — Mercados[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_ibex.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Cotización del IBEX 35, histórico mensual y precios de los 35 valores del índice."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="ibex_menu"), listitem=li, isFolder=True)

    # Estado de Embalses
    li = xbmcgui.ListItem(label="[B][COLOR deepskyblue]Estado de Embalses[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_embalses.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Nivel de llenado de los embalses españoles por cuenca hidrográfica.\nDatos semanales del MITECO."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="embalses_menu"), listitem=li, isFolder=True)

    # Calidad del Aire
    li = xbmcgui.ListItem(label="[B][COLOR lightblue]Calidad del Aire[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_aire.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Calidad del aire en tiempo real en 12 ciudades españolas.\nMúltiples estaciones por ciudad. Niveles de NO₂, PM₁₀ y otros contaminantes."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="aire_menu"), listitem=li, isFolder=True)

    # Polen y Alergias
    li = xbmcgui.ListItem(label="[B][COLOR palegreen]Nivel de Polen y Alergias[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_polen.png', 'DefaultAddonHealth.png')})
    li.setInfo('video', {'plot': "Niveles aerobiológicos por tipo de polen (Gramíneas, Olivo, etc.)\nNiveles de concentración actuales y prevención de alergias."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="polen_menu"), listitem=li, isFolder=True)

    # Festivos
    li = xbmcgui.ListItem(label="[B][COLOR tomato]Festivos Nacionales y Autonómicos[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_festivos.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Calendario de festivos nacionales y de tu Comunidad Autónoma para 2025 y 2026.\nConfigura tu CCAA en Ajustes."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="festivos_menu"), listitem=li, isFolder=True)

    # BOE
    li = xbmcgui.ListItem(label="[B][COLOR royalblue]BOE — Boletín Oficial del Estado[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_boe.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Últimas disposiciones del BOE: leyes, oposiciones, subvenciones y anuncios oficiales."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="boe_menu"), listitem=li, isFolder=True)

    # SEPE / Empleo
    li = xbmcgui.ListItem(label="[B][COLOR mediumseagreen]Empleo SEPE y Oposiciones[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_sepe.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Convocatorias del SEPE, oposiciones a la Administración Pública y subvenciones al empleo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="sepe_menu"), listitem=li, isFolder=True)

    # Gasolineras Baratas
    li = xbmcgui.ListItem(label="[B][COLOR gold]Gasolineras Baratas[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_gasolineras.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Precios de carburantes en tiempo real ordenados de más barato a más caro.\nAPI oficial del Ministerio de Industria."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="gasolineras_menu"), listitem=li, isFolder=True)

    # Horarios de Transporte (submenú)
    li = xbmcgui.ListItem(label="[B][COLOR deepskyblue]Horarios de Transporte[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_transporte.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Próximos trenes de metro y cercanías de varias ciudades españolas.\nDatos en tiempo real y horarios GTFS estáticos según la red."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="submenu_transporte"), listitem=li, isFolder=True)

    # Alquiler — Evolución del precio del alquiler por provincia (IPC, INE)
    li = xbmcgui.ListItem(label="[B][COLOR coral]Evolución del Precio del Alquiler[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_alquiler.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Variación del alquiler vs. el mismo mes del año anterior, por provincia.\nOrdenado de mayor a menor subida, con serie histórica mensual.\nFuente: INE — IPC subgrupo Alquiler de vivienda."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="alquiler_menu"), listitem=li, isFolder=True)

    # Galería de Obras de Arte
    li = xbmcgui.ListItem(label="[B][COLOR plum]Galería de Obras de Arte[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_galeria_arte.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Obras de Goya, Velázquez, El Greco, Dalí y otros maestros en el Metropolitan Museum.\nColección pública de dominio público (CC0)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="galeria_menu"), listitem=li, isFolder=True)

    # Himnos
    li = xbmcgui.ListItem(label="[B][COLOR orange]Himnos de España y CCAA[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_himnos.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Himno nacional de España, himnos de las 17 Comunidades Autónomas y el himno de la UE.\nArchivos de audio en dominio público de Wikimedia Commons."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="himnos_menu"), listitem=li, isFolder=True)

    # Astronomía y Cielos (SUBMENÚ)
    li = xbmcgui.ListItem(label="[B][COLOR deepskyblue]Astronomía y Cielos[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_astronomia.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Fases Lunares y Calendario Astronómico Anual.\nCálculos locales sin necesidad de conexión."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="submenu_astronomia"), listitem=li, isFolder=True)

    # Música Libre
    li = xbmcgui.ListItem(label="[B][COLOR lightgreen]Música Libre[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_musica_libre.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Música con licencia Creative Commons y radios online libres. Sin registro."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="musica_libre_menu"), listitem=li, isFolder=True)



    # Horóscopo
    li = xbmcgui.ListItem(label="[B][COLOR khaki]Horóscopo Diario[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_horoscopo.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Predicción del día para los 12 signos del zodiaco.\nConfigura tu signo en Ajustes."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="horoscopo_menu"), listitem=li, isFolder=True)

    # Agenda Cultural
    li = xbmcgui.ListItem(label="[B][COLOR sandybrown]Agenda Cultural Nacional[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_agenda_cultural.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Fiestas de Interés Turístico Internacional y Nacional.\nNoticias del Ministerio de Cultura."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="agenda_cultural_menu"), listitem=li, isFolder=True)

    # Separador
    li_sep = xbmcgui.ListItem(label="[COLOR gray]────────────────────────────────────────[/COLOR]")
    li_sep.setArt({'icon': _ri('sep_line.png', 'DefaultAddonNone.png')})
    li_sep.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trololo"), listitem=li_sep, isFolder=False)

    # Secciones españolas dinámicas desde JSON
    section_order = ['museo_meme', 'tv_nacional', 'noticias', 'deportes', 'motor', 'cine',
                     'series', 'infantil', 'musica', 'lifestyle', 'gaming',
                     'cultura', 'internacional_es']
    for key in section_order:
        sec = data.get(key)
        if sec:
            name = sec.get('name', key)
            icon = _ri(sec.get('icon', 'DefaultFolder.png'))
            plot = sec.get('plot', '')
            count = len(sec.get('channels', []))
            li = xbmcgui.ListItem(label="[B]{0}[/B] ({1})".format(name, count))
            li.setArt({'icon': icon})
            li.setInfo('video', {'plot': plot})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="spanish_section", section=key), listitem=li, isFolder=True)
        if key == 'cultura':
            am_count = sum(len(v) for v in _ARTE_MUSEOS_YT.values())
            if am_count > 0:
                li = xbmcgui.ListItem(label="[B][COLOR orchid]Arte y Museos[/COLOR][/B] ({0})".format(am_count))
                li.setArt({'icon': _ri('cat_arte.png', 'DefaultPicture.png')})
                li.setInfo('video', {'plot': "Canales y vídeos de los grandes museos españoles en YouTube.\nPrado, Reina Sofía, Guggenheim, Patrimonio Nacional, flamenco y más."})
                xbmcplugin.addDirectoryItem(handle=h, url=_u(action="arte_museos_menu"), listitem=li, isFolder=True)

    # Filmoteca / NO-DO (tras secciones dinámicas, antes de YouTube)
    li = xbmcgui.ListItem(label="[B][COLOR sandybrown]Filmoteca y NO-DO[/COLOR][/B]")
    li.setArt({'icon': _ri('cat_filmoteca.png', 'DefaultMovies.png')})
    li.setInfo('video', {'plot': "Archivo histórico de RTVE: NO-DO, Filmoteca Española, Memoria de España y más."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="filmoteca_menu"), listitem=li, isFolder=True)

    # YouTube en directo
    li = xbmcgui.ListItem(label="[B][COLOR crimson]YouTube[/COLOR][/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales de YouTube en directo en español.\n24h noticias, música, documentales y más."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="youtube_live_menu"), listitem=li, isFolder=True)

    # Nota informativa
    li = xbmcgui.ListItem(label="[COLOR gray][I]Nota: La mayoría del contenido se obtiene automáticamente. Algunos videos se han añadido manualmente para dar coherencia a cada sección.[/I][/COLOR]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    li.setInfo('video', {'plot': "La mayoría del contenido mostrado se obtiene mediante búsquedas automáticas por categoría.\nAlgunos canales y videos han sido añadidos manualmente para dar sentido y coherencia a cada sección.\nSu presencia no implica afinidad, preferencia ni promoción por parte de los desarrolladores."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="info_note"), listitem=li, isFolder=False)

    # --- Anuncios de otros addons ---
    li = xbmcgui.ListItem(label="[B][COLOR cornflowerblue]EspaDaily[/COLOR][/B] — Explorador de TV Española")
    li.setArt({'icon': 'DefaultAddonVideo.png'})
    li.setInfo('video', {'plot': "EspaDaily, el puente entre Kodi y las principales plataformas de TV española.\n\nNo elude muros de pago ni DRM — funciona con contenido en abierto."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="open_espadaily"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _my_recordings_menu():
    h = int(sys.argv[1])
    rec_path = xbmcaddon.Addon().getSetting("record_path")
    if not rec_path:
        xbmcgui.Dialog().notification("EspaTV", "Carpeta no configurada", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(h)
        return

    # Las grabaciones PVR se guardan en la subcarpeta dedicada
    pvr_dir = os.path.join(rec_path, "Grabaciones_PVR")
    if not os.path.isdir(pvr_dir):
        li = xbmcgui.ListItem(label="No hay grabaciones guardadas actualmente")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    try:
        dirs, files = xbmcvfs.listdir(pvr_dir)
    except (OSError, RuntimeError):
        files = []

    xbmcplugin.setContent(h, "videos")
    has_videos = False

    # Solo archivos .ts (formato nativo del grabador PVR)
    for f in sorted(files, reverse=True):
        # Compatibilidad: xbmcvfs.listdir puede devolver bytes en algunas plataformas
        if isinstance(f, bytes):
            f = f.decode('utf-8', errors='ignore')
        if not f.lower().endswith('.ts'):
            continue
        has_videos = True
        file_path = os.path.join(pvr_dir, f)
        try:
            size = os.path.getsize(file_path) if os.path.exists(file_path) else 0
            s_str = "{0:.1f} MB".format(size / 1024.0 / 1024.0)
        except OSError:
            s_str = "Desconocido"

        li = xbmcgui.ListItem(label=f)
        li.setArt({'icon': 'DefaultVideo.png'})
        li.setInfo('video', {'plot': "Grabación PVR:\n{0}\n\nTamaño: {1}".format(f, s_str)})

        cm = [("Borrar grabación", "RunPlugin({0})".format(_u(action="delete_recording", file=file_path)))]
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=h, url=file_path, listitem=li, isFolder=False)

    if not has_videos:
        li = xbmcgui.ListItem(label="No hay grabaciones guardadas actualmente")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

# --- REMOTE CHECKS ---

def _check_validity():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    sf = os.path.join(p, 'status_check.json')

    now = time.time()
    st = {'last_check': 0, 'disabled': False}
    if os.path.exists(sf):
        try:
            with open(sf, 'r', encoding='utf-8') as f:
                st = json.load(f)
        except (OSError, ValueError):
            pass

    if st.get('disabled', False):
        return False

    if now - st.get('last_check', 0) > 604800:
        data = None
        try:
            r = requests.get(_STATUS_URL, timeout=10)
            if r.status_code == 200:
                data = r.json()
        except (requests.RequestException, ValueError):
            pass

        if data:
            if not data.get('allowed', True):
                st['disabled'] = True
                with open(sf, 'w', encoding='utf-8') as f:
                    json.dump(st, f)
                return False

            min_v = data.get('min_version', '0.0.0')
            cur_v = xbmcaddon.Addon().getAddonInfo('version')
            def pv(v): return [int(x) for x in v.replace('v','').split('.') if x.isdigit()]

            if pv(cur_v) < pv(min_v):
                st['disabled'] = True
                with open(sf, 'w', encoding='utf-8') as f:
                    json.dump(st, f)
                return False

            st['last_check'] = now
            st['disabled'] = False
            with open(sf, 'w', encoding='utf-8') as f:
                json.dump(st, f)

    return True


def _check_messages():
    data = None
    try:
        r = requests.get(_MESSAGES_URL, timeout=5)
        if r.status_code == 200:
            data = r.json()
    except (requests.RequestException, ValueError):
        pass

    if not data:
        return

    # Soporte para formato plano {"id":..} y formato array {"messages":[..]}
    if isinstance(data, dict) and "messages" in data:
        msgs = data["messages"]
        if not isinstance(msgs, list) or not msgs: return
        msg = msgs[0]  # Mostrar solo el ultimo/primer mensaje
    elif isinstance(data, dict) and "id" in data:
        msg = data  # Formato plano legacy
    else:
        return

    mid = msg.get("id")
    if not mid: return

    # repeat: cuantas veces mostrar. -1=siempre, 0=nunca, N=N veces. Default=1 (una vez)
    mrep = msg.get("repeat", 1)
    if mrep == 0: return

    # Cargar estado local de mensajes vistos
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    mf = os.path.join(p, 'messages_state.json')
    st = {}
    if os.path.exists(mf):
        try:
            with open(mf, 'r', encoding='utf-8') as f:
                st = json.load(f)
        except (OSError, ValueError):
            pass

    views = st.get(str(mid), 0)
    show_it = False
    if mrep == -1:
        show_it = True
    elif views < mrep:
        show_it = True

    if show_it:
        title = msg.get("title", msg.get("titulo", "Aviso EspaTV"))
        body = msg.get("text", msg.get("message", ""))
        xbmcgui.Dialog().ok(title, body)
        st[str(mid)] = views + 1
        with open(mf, 'w', encoding='utf-8') as f:
            json.dump(st, f)


def main_menu():
    try:
        _check_messages()
    except (requests.RequestException, ValueError, OSError):
        pass  # No bloquear el menu si falla la comprobacion de mensajes

    def _bg_download_ascii():
        import time as _t
        _t.sleep(5)
        _profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if not os.path.exists(_profile):
            os.makedirs(_profile)
        _dst = os.path.join(_profile, 'ascii.jpg')
        if os.path.exists(_dst):
            return
        try:
            _url = 'https://raw.githubusercontent.com/fullstackcurso/Ruta-Fullstack/main/ascii.jpg'
            r = requests.get(_url, timeout=10)
            if r.status_code == 200 and len(r.content) > 1000:
                with open(_dst, 'wb') as f:
                    f.write(r.content)
                xbmc.log("[EspaTV] ascii.jpg downloaded OK", xbmc.LOGINFO)
        except (requests.RequestException, OSError):
            pass
    import threading
    threading.Thread(target=_bg_download_ascii, daemon=True).start()

    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    # Agenda Deportiva
    li = xbmcgui.ListItem(label="[B][COLOR limegreen]Agenda Deportiva TV[/COLOR][/B]")
    li.setArt({'icon': _ico('agenda.png', 'DefaultAddonPVRClient.png')})
    li.setInfo('video', {'plot': "Programación deportiva de hoy en la TV española.\nFútbol, baloncesto, F1, tenis y más."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="agenda_menu"), listitem=li, isFolder=True)

    # 4. TV y Radio en Directo
    li = xbmcgui.ListItem(label="[COLOR orange][B]TV y Radio en Directo[/B][/COLOR]")
    li.setArt({'icon': _ico('directo.png', 'DefaultAddonPVRClient.png')})
    li.setInfo('video', {'plot': "Canales de televisión y radio en directo, listas IPTV y más."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="live_tv_menu"), listitem=li, isFolder=True)

    # Top Películas y Series
    li = xbmcgui.ListItem(label="[B][COLOR coral]Top Películas y Series[/COLOR][/B]")
    li.setArt({'icon': _ico('peliculas.png', 'DefaultVideoPlaylists.png')})
    li.setInfo('video', {'plot': "Cartelera, estrenos y tops de FilmAffinity, SensaCine, Cinemeta y Trakt.tv."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="top_pelis_series_menu"), listitem=li, isFolder=True)

    # 2a. Buscar en YouTube
    li = xbmcgui.ListItem(label="[B][COLOR red]Buscar en YouTube[/COLOR][/B]")
    li.setArt({'icon': _ico('youtube.png', 'DefaultMusicVideos.png')})
    li.setInfo('video', {'plot': "Busca vídeos directamente en YouTube.\nLos resultados se reproducen aquí o se abren en el navegador."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="yt_search"), listitem=li, isFolder=True)

    # 2b. Buscar en Dailymotion
    li = xbmcgui.ListItem(label="[B][COLOR dodgerblue]Buscar en Dailymotion[/COLOR][/B]")
    li.setArt({'icon': _ico('dailymotion.png', 'DefaultAddonWebSkin.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="manual_search"), listitem=li, isFolder=True)

    # El Tiempo
    li = xbmcgui.ListItem(label="[B][COLOR lightskyblue]El Tiempo[/COLOR][/B]")
    li.setArt({'icon': _ico('tiempo.png', 'DefaultAddonWeather.png')})
    li.setInfo('video', {'plot': "Pronóstico meteorológico oficial de España (AEMET).\nAñade tus ubicaciones y consulta el tiempo de los próximos 7 días."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="aemet_menu"), listitem=li, isFolder=True)

    # 3. Historial
    li = xbmcgui.ListItem(label="[B][COLOR aqua]Historial[/COLOR][/B]")
    li.setArt({'icon': _ico('historial.png', 'DefaultAddonRepository.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="history_menu"), listitem=li, isFolder=True)

    # 4.5. Prensa (Titulares RSS)
    li = xbmcgui.ListItem(label="[B][COLOR pink]Prensa[/COLOR][/B]")
    li.setArt({'icon': _ico('prensa.png', 'DefaultPlaylist.png')})
    li.setInfo('video', {'plot': "Lee los titulares de última hora de los principales diarios y portales de noticias nacionales."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="press_menu"), listitem=li, isFolder=True)

    # Podcast
    li = xbmcgui.ListItem(label="[B][COLOR coral]Podcast[/COLOR][/B]")
    li.setArt({'icon': _ico('podcast.png', 'DefaultMusicSongs.png')})
    li.setInfo('video', {'plot': "Podcasts populares en español.\nEscucha los últimos episodios directamente."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="podcast_menu"), listitem=li, isFolder=True)

    # 7. Abrir URL
    li = xbmcgui.ListItem(label="[B][COLOR mediumpurple]Abrir URL[/COLOR][/B]")
    li.setArt({'icon': _ico('url.png', 'DefaultAddSource.png')})
    li.setInfo('video', {'plot': "Reproduce una URL pegada: Dailymotion, YouTube, m3u8, mp4, mpd..."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_url"), listitem=li, isFolder=True)

    # 5. Mis Favoritos
    li = xbmcgui.ListItem(label="[B][COLOR khaki]Mis Favoritos[/COLOR][/B]")
    li.setArt({'icon': _ico('favoritos.png', 'DefaultSets.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="show_favorites"), listitem=li, isFolder=True)

    # 6. Mis Descargas
    li = xbmcgui.ListItem(label="[B][COLOR lightblue]Mis Descargas[/COLOR][/B]")
    li.setArt({'icon': _ico('descargas.png', 'DefaultHardDisk.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="show_downloads"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B][COLOR springgreen]Más[/COLOR][/B]")
    li.setArt({'icon': _ico('catalogo.png', 'DefaultFolder.png')})
    li.setInfo('video', {'plot': "Listas de películas, series populares y tendencias."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="catalog_menu"), listitem=li, isFolder=True)

    # 10. OPCIONES
    li = xbmcgui.ListItem(label="[B][COLOR thistle]Opciones, mantenimiento y anti-errores[/COLOR][/B]")
    li.setArt({'icon': _ico('opciones.png', 'DefaultAddonService.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="advanced_menu"), listitem=li, isFolder=True)

    # 8. Información
    cm_legal = []
    li = xbmcgui.ListItem(label="[B]Información[/B]")
    li.setArt({'icon': _ico('info.png', 'DefaultIconInfo.png')})
    li.addContextMenuItems(cm_legal)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="info_menu"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def info_menu():
    h = int(sys.argv[1])

    # Universo EspaKodi
    li = xbmcgui.ListItem(label="[COLOR skyblue]Universo EspaKodi[/COLOR]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="show_universo"), listitem=li, isFolder=False)

    # Versión (sin acción)
    if _is_debug_active():
        li = xbmcgui.ListItem(label="Hecho por RubénSDFA1laberot")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="sanitized_info"), listitem=li, isFolder=False)
    else:
        try:
            ver = xbmcaddon.Addon().getAddonInfo("version") or "?.?.?"
        except RuntimeError:
            ver = "?.?.?"
        li = xbmcgui.ListItem(label="Versión {0}".format(ver))
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.addContextMenuItems([("Créditos", "RunPlugin({0})".format(_u(action="caramelldansen")))])
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    # Actualizaciones / Repositorio
    _repo_id = "repository.espatv"
    is_installed = xbmc.getCondVisibility("System.HasAddon({0})".format(_repo_id))
    status_tag = "[COLOR lime]● INSTALADO[/COLOR]" if is_installed else "[COLOR orange]○ NO DETECTADO[/COLOR]"
    li = xbmcgui.ListItem(label="Actualizaciones: {0}".format(status_tag))
    li.setArt({'icon': 'DefaultAddonRepository.png'})
    li.setInfo('video', {'plot': "Verifica que el repositorio oficial está instalado para que el addon se mantenga actualizado solo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="check_repo_status"), listitem=li, isFolder=False)

    # Aviso VPN
    li = xbmcgui.ListItem(label="[B][COLOR yellow]La VPN puede causar fallos o ser necesaria[/COLOR][/B] — Algunos servidores bloquean VPNs (desactívala si un vídeo no carga). En otros casos puede ser necesaria.")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    li.setInfo('video', {'plot': "Algunos servidores bloquean conexiones VPN. Si un vídeo no carga, prueba desactivando la VPN. En otros casos puede ser necesaria para que el contenido cargue correctamente."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="vpn_info"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _check_repo_status_espatv():
    _repo_id = "repository.espatv"
    installed = xbmc.getCondVisibility("System.HasAddon({0})".format(_repo_id))

    if not installed:
        try:
            import xml.etree.ElementTree as ET
            addons_path = xbmcvfs.translatePath("special://home/addons/")
            dirs, _ = xbmcvfs.listdir(addons_path)
            for d in dirs:
                if "repository" not in d.lower() and "espatv" not in d.lower():
                    continue
                xml_vfs = "special://home/addons/{0}/addon.xml".format(d)
                if not xbmcvfs.exists(xml_vfs):
                    continue
                try:
                    vf = xbmcvfs.File(xml_vfs)
                    content = vf.read()
                    vf.close()
                    root = ET.fromstring(content)
                    if root.attrib.get('id', '') == _repo_id:
                        installed = True
                        break
                except (OSError, ET.ParseError, AttributeError, TypeError):
                    continue
        except Exception as e:
            xbmc.log("[EspaTV] Deep scan repo: {0}".format(e), xbmc.LOGWARNING)

    if installed:
        xbmcgui.Dialog().ok(
            "Estado del Repositorio",
            "[COLOR green][B]● INSTALADO Y ACTIVO[/B][/COLOR]\n\n"
            "El repositorio oficial está configurado correctamente.\n\n"
            "El addon se actualizará automáticamente cuando haya nuevas versiones disponibles."
        )
    else:
        if xbmcgui.Dialog().yesno(
            "Repositorio No Detectado",
            "Para recibir mejoras y actualizaciones automáticas, es necesario\n"
            "instalar el repositorio oficial de EspaTV.\n\n"
            "¿Deseas instalarlo ahora mismo?"
        ):
            _install_espatv_repo()


def _yt_pc_info():
    xbmcgui.Dialog().textviewer(
        "¿YouTube no funciona?",
        "YouTube bloquea peticiones desde IPs residenciales sin sesión activa "
        "(error: 'Sign in to confirm you're not a bot'). "
        "Afecta tanto al addon de YouTube como a yt-dlp.\n\n"
        "[B]Solución 1 — VPN[/B]\n"
        "Activa una VPN. Funciona con cualquier método de reproducción.\n\n"
        "[B]Solución 2 — Fallback automático con curl_cffi (solo yt-dlp)[/B]\n"
        "Si usas 'Reproducir con yt-dlp', EspaTV reintenta automáticamente "
        "imitando el fingerprint TLS de Chrome si tienes instalado curl_cffi:\n"
        "   pip install curl_cffi\n\n"
        "Con curl_cffi instalado el reintento ocurre solo, sin que tengas que hacer nada."
    )


def _vpn_info():
    xbmcgui.Dialog().ok(
        "VPN y compatibilidad",
        "Algunos servidores bloquean conexiones VPN.\n\n"
        "Si un vídeo no carga, prueba [B]desactivando la VPN[/B].\n\n"
        "En otros casos, algunos servidores pueden requerir VPN "
        "para funcionar correctamente."
    )


def _history_menu():
    # Enlace a Historial de Visionado dentro del historial
    li = xbmcgui.ListItem(label="[B][COLOR mediumpurple]Historial de Visionado[/COLOR][/B]")
    li.setArt({'icon': 'DefaultRecentlyAddedEpisodes.png'})
    li.setInfo('video', {'plot': "Vídeos reproducidos recientemente desde Dailymotion."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="watch_history"), listitem=li, isFolder=True)

    # Mostrar directamente el historial de búsquedas (como hacía antes _show_history)
    _sh.menu(skip_end=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def advanced_menu():
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    # Accesibilidad (submenú)
    li = xbmcgui.ListItem(label="[B]Accesibilidad[/B]")
    li.setArt({'icon': _ico('adv_skin.png', 'DefaultAddonSkin.png')})
    li.setInfo('video', {'plot': "Opciones para daltónicos, baja visión y otros problemas visuales.\nModo de color, texto en negrita, sustitución de símbolos."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="accessibility_menu"), listitem=li, isFolder=True)

    # Texto blanco (acceso directo)
    _cur_acc_mode = xbmcaddon.Addon().getSetting('acc_color_mode') or 'none'
    if _cur_acc_mode == 'white':
        wt_label = "   Texto blanco (acceso rápido): [COLOR green]ACTIVADO[/COLOR]"
        wt_plot = "Pulsa para desactivar y volver a los colores originales."
    elif _cur_acc_mode in ('', 'none'):
        wt_label = "   Texto blanco (acceso rápido): [COLOR grey]DESACTIVADO[/COLOR]"
        wt_plot = "Pulsa para forzar todos los textos a blanco.\nPara más opciones de color y accesibilidad, entra en el submenú Accesibilidad de arriba."
    else:
        _cur_name = _ACC_COLOR_NAMES.get(_cur_acc_mode, _cur_acc_mode)
        wt_label = "   Texto blanco (acceso rápido): [COLOR orange]Otro modo activo[/COLOR]"
        wt_plot = "Hay otro modo de Accesibilidad activo: {0}.\n\nPulsar aquí lo SOBRESCRIBIRÁ con 'Texto blanco'. Para configurar otros modos, usa el submenú Accesibilidad.".format(_cur_name)
    li = xbmcgui.ListItem(label=wt_label)
    li.setArt({'icon': _ico('adv_skin.png', 'DefaultAddonSkin.png')})
    li.setInfo('video', {'plot': wt_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_force_white_text"), listitem=li, isFolder=False)

    # 1. Búsqueda Avanzada
    if core_settings.is_advanced_search_active():
        label = "Búsqueda DM: [COLOR green]AVANZADO (Submenú)[/COLOR]"
        plot = "Al pulsar 'Buscar manualmente', se abrirá un menú intermedio con opciones de búsqueda especializada (Cine, Exacta, etc.).\n\n[COLOR blue][I]Pulsa para volver a Búsqueda Directa[/I][/COLOR]"
    else:
        label = "Búsqueda DM: [COLOR grey]SIMPLE (Directa)[/COLOR]"
        plot = "Al pulsar 'Buscar manualmente', se abrirá directamente el teclado para escribir.\n\n[COLOR blue][I]Pulsa para activar el Menú Avanzado[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _ico('adv_busqueda.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_advanced_search"), listitem=li, isFolder=False)





    # 2. Debug
    if _is_debug_active():
        li = xbmcgui.ListItem(label="Modo Debug: [COLOR green]ACTIVADO[/COLOR]")
    else:
        li = xbmcgui.ListItem(label="Modo Debug: [COLOR red]DESACTIVADO[/COLOR]")
    li.setArt({'icon': _ico('adv_debug.png')})
    li.setInfo('video', {'plot': "Activa el registro detallado de errores.\n\nPuedes generar un archivo de log interno para solucionar problemas. Puede ralentizar el addon."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_debug"), listitem=li, isFolder=False)

    # 2b. Dev Mode (solo visible con Debug activo)
    if _is_debug_active():
        dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
        is_dev = os.path.exists(dev_flag)
        if is_dev:
            dev_label = "   Modo Desarrollo: [COLOR green]ACTIVO[/COLOR]"
        else:
            dev_label = "   Modo Desarrollo: [COLOR grey]DESACTIVADO[/COLOR]"
        li = xbmcgui.ListItem(label=dev_label)
        li.setArt({'icon': _ico('adv_dev.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Protege los modulos internos del addon.\nCuando esta ACTIVO, el addon no se actualiza desde internet.\n\nDesactivar para recibir actualizaciones normales."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_dev_mode"), listitem=li, isFolder=False)

    # 2c. Log y Diagnóstico
    li = xbmcgui.ListItem(label="Log y Diagnóstico")
    li.setArt({'icon': _ico('adv_log.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Herramientas para ver y analizar el log de Kodi y del addon.\nFiltrar errores, buscar entradas, ver tamaño, etc."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="log_menu"), listitem=li, isFolder=True)


        

    # 5. Priorizar por Ajuste (Match) vs Duración
    if core_settings.is_prioritize_match_active():
        label = "Priorizar DM: [COLOR green]AJUSTE AL CONTEXTO[/COLOR]"
        plot = "MODO PRECISIÓN: Los resultados se ordenan según cuánto se parecen las palabras clave al título buscado.\n\nIdeal si te aparecen vídeos largos que no tienen nada que ver con lo que buscas.\n\n[COLOR blue][I]Pulsa para priorizar por DURACIÓN (Estándar)[/I][/COLOR]"
    else:
        label = "Priorizar DM: [COLOR grey]DURACIÓN (ESTÁNDAR)[/COLOR]"
        plot = "MODO CLÁSICO: Se da mucha importancia a la duración del vídeo para encontrar capítulos completos.\n\nPuede causar que aparezcan vídeos largos que no coinciden bien con el nombre.\n\n[COLOR blue][I]Pulsa para priorizar por PRECISIÓN[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _ico('adv_priorizar.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_prioritize_match"), listitem=li, isFolder=False)

    # 6. Priorizar Contenido Reciente
    if core_settings.is_recent_active():
        label = "Filtro Temporal DM: [COLOR green]RECIENTES PRIMERO[/COLOR]"
        plot = "MODO NOTICIAS: Los vídeos se ordenan por FECHA DE SUBIDA.\n\nIdeal para ver informativos de hoy o programas diarios.\n\n[COLOR blue][I]Pulsa para desactivar[/I][/COLOR]"
    else:
        label = "Filtro Temporal DM: [COLOR grey]RELEVANCIA (POR DEFECTO)[/COLOR]"
        plot = "MODO MIXTO: El orden depende de cuánto se parezca el título, sin importar si el vídeo es de ayer o de hace meses.\n\n[COLOR blue][I]Pulsa para activar orden RECIENTE[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _ico('adv_filtro_tiempo.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_recent"), listitem=li, isFolder=False)

    # 7. Filtro Anti-Trailers (Minutos)
    min_m = core_settings.get_min_duration()
    if min_m > 0:
        label = f"Anti-Trailers DM: [COLOR green]SOLO +{min_m} MIN[/COLOR]"
        plot = f"MODO CAPÍTULO: Oculta automáticamente cualquier vídeo de menos de {min_m} minutos.\n\nIdeal para limpiar trailers, clips y avances de los resultados de búsqueda.\n\n[COLOR blue][I]Pulsa para cambiar o desactivar[/I][/COLOR]"
    else:
        label = "Anti-Trailers DM: [COLOR grey]DESACTIVADO[/COLOR]"
        plot = "MODO TODOS: Muestra todos los resultados encontrados, sin importar su duración.\n\n[COLOR blue][I]Pulsa para filtrar por duración mínima[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _ico('adv_antitrailers.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_min_duration"), listitem=li, isFolder=False)

    # 8b. Copias de Seguridad
    li = xbmcgui.ListItem(label="Copias de Seguridad")
    li.setArt({'icon': _ico('adv_backup.png', 'DefaultAddonRepository.png')})
    li.setInfo('video', {'plot': "Crea, restaura e importa copias ZIP de todos los datos del addon.\nHistorial, favoritos, categorías, configuración y más."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="backups_menu"), listitem=li, isFolder=True)

    # 8b2. Almacenamiento (cachés del addon)
    li = xbmcgui.ListItem(label="Almacenamiento y Cachés")
    li.setArt({'icon': _ico('adv_cache.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Ver y liberar espacio ocupado por las cachés del addon.\nBorra por categoría o limpia todo de una vez.\nNunca borra favoritos, historial ni tu configuración."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="storage_menu"), listitem=li, isFolder=True)

    # 8c. Ruta de Descargas
    cfg = _load_dm_settings()
    d_path = cfg.get('download_path', '')
    dl_label = "Ruta de Descargas: [COLOR green]{0}[/COLOR]".format(d_path) if d_path else "Ruta de Descargas: [COLOR grey]NO CONFIGURADA[/COLOR]"
    li = xbmcgui.ListItem(label=dl_label)
    li.setArt({'icon': _ico('adv_ruta_dl.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Selecciona la carpeta donde se guardarán los vídeos descargados."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_download_path"), listitem=li, isFolder=False)
    
    # 8d. Modo Anti-Errores Dailymotion (4 niveles)
    dm_level = cfg.get('dm_safe_level', 0)
    if dm_level == 0:
        dm_label = "Modo Anti-Errores DM: [COLOR grey]DESACTIVADO[/COLOR]"
    elif dm_level == 1:
        dm_label = "Modo Anti-Errores DM: [COLOR green]BÁSICO[/COLOR]"
    elif dm_level == 2:
        dm_label = "Modo Anti-Errores DM: [COLOR gold]EXTREMO[/COLOR]"
    else:
        dm_label = "Modo Anti-Errores DM: [COLOR cyan]YT-DLP[/COLOR]"
    dm_plot = (
        "MODO ANTI-ERRORES DAILYMOTION:\n\n"
        "[B]DESACTIVADO:[/B] Conexión normal de EspaTV.\n"
        "[B]BÁSICO:[/B] Simula teléfono móvil Android.\n"
        "[B]EXTREMO:[/B] Técnicas avanzadas (Subtítulos, Verificación de enlaces, etc).\n"
        "[B]YT-DLP:[/B] Usa yt-dlp. Recomendado en Windows donde el CDN bloquea Kodi.\n\n"
        "[I]Pulsa para cambiar el nivel.[/I]"
    )
    li = xbmcgui.ListItem(label=dm_label)
    li.setArt({'icon': _ico('adv_anti_errores.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': dm_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_dm_safe_level"), listitem=li, isFolder=False)

    # 8e. Modo de Descarga
    dl_mode = cfg.get('dl_mode', 0)
    if dl_mode == 0:
        d_mode_txt = "[COLOR grey]DIRECTO (Normal)[/COLOR]"
    elif dl_mode == 1:
        d_mode_txt = "[COLOR green]SAFE MODE (Gujal)[/COLOR]"
    elif dl_mode == 2:
        d_mode_txt = "[COLOR gold]MODO EspaTV (HLS Process)[/COLOR]"
    elif dl_mode == 3:
        d_mode_txt = "[COLOR cyan]YT-DLP (Externo)[/COLOR]"
    else:
        d_mode_txt = "[COLOR magenta]ULTRA (Multi-hilo HLS+)[/COLOR]"
        
    dl_s_label = f"Modo de Descarga: {d_mode_txt}"
    dl_s_plot = (
        "MODO DE DESCARGA:\n\n"
        "[B]DIRECTO:[/B] Muestra menú para elegir calidad.\n"
        "[B]SAFE MODE:[/B] Descarga el mejor MP4 directo.\n"
        "[B]EspaTV:[/B] Descarga por segmentos HLS.\n"
        "[B]YT-DLP:[/B] Usa yt-dlp (mejor calidad). Requiere Python 3.10+.\n"
        "[B]ULTRA:[/B] Igual que YT-DLP (mejor calidad). Recomendado en PC."
    )
    li = xbmcgui.ListItem(label=dl_s_label)
    li.setArt({'icon': _ico('adv_modo_dl.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': dl_s_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_dl_mode"), listitem=li, isFolder=False)

    # 8f. Mantenimiento yt-dlp (Solo PC)
    if xbmc.getCondVisibility("System.Platform.Windows | System.Platform.Linux | System.Platform.OSX"):
        li = xbmcgui.ListItem(label="Mantenimiento PC (yt-dlp)")
        li.setArt({'icon': _ico('adv_ytdlp.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Muestra las instrucciones paso a paso para instalar yt-dlp en tu PC, o ejecuta un diagnóstico para comprobar si ya está instalado y funcionando correctamente."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ytdlp_menu"), listitem=li, isFolder=False)

    # --- Caché IPTV ---
    iptv_cache_on = core_settings.is_iptv_cache_active()
    ttl_val = core_settings.get_iptv_cache_ttl()
    # buscar nombre legible del TTL actual
    ttl_name = "Desactivada"
    for v, n in core_settings._IPTV_CACHE_TTL_OPTIONS:
        if v == ttl_val: ttl_name = n; break

    if iptv_cache_on:
        c_label = "Caché IPTV/TDT: [COLOR green]ACTIVA ({0})[/COLOR]".format(ttl_name)
    else:
        c_label = "Caché IPTV/TDT: [COLOR grey]DESACTIVADA[/COLOR]"
    c_plot = (
        "CACHÉ IPTV / TDT:\n\n"
        "Guarda en disco los canales (M3U, TDT, etc) para que "
        "al pulsar ATRÁS se carguen al instante.\n\n"
        "[B]Estado:[/B] {0}\n"
        "[B]Duración:[/B] {1}\n\n"
        "[I]Pulsa para activar o desactivar.[/I]"
    ).format("Activa" if iptv_cache_on else "Desactivada", ttl_name)
    li = xbmcgui.ListItem(label=c_label)
    li.setArt({'icon': _ico('adv_cache.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': c_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_iptv_cache"), listitem=li, isFolder=False)

    if iptv_cache_on:
        ttl_label = "   Duración de caché IPTV: [COLOR green]{0}[/COLOR]".format(ttl_name)
        li = xbmcgui.ListItem(label=ttl_label)
        li.setArt({'icon': _ico('adv_filtro_tiempo.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Selecciona cuánto tiempo se mantienen guardados los canales.\n\n1 hora: Se actualizan rápido.\n12 horas: Equilibrio.\n1 día: Menos internet.\n1 semana: Ultra rápido.\n\n[I]Pulsa para cambiar.[/I]"})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_iptv_cache_ttl"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="   [COLOR orange]Restaurar caché por defecto[/COLOR]")
        li.setArt({'icon': _ico('adv_borrar.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Desactiva la caché IPTV y elimina todos los archivos cacheados.\nEl addon volverá a descargar los datos en cada entrada, como venía de fábrica."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="reset_iptv_cache"), listitem=li, isFolder=False)

    # PVR Integracion Nativa
    import pvr_manager
    if pvr_manager.is_pvr_installed():
        li = xbmcgui.ListItem(label="Abrir Guía de Televisión Nativa (PVR)")
        li.setArt({'icon': _ico('adv_pvr.png', 'DefaultAddonPVRClient.png')})
        li.setInfo('video', {'plot': "Salta instantáneamente a la sección 'TV' de Kodi para ver la parrilla de horarios."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_pvr"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="Forzar Auto-Configuración PVR")
        li.setArt({'icon': _ico('adv_pvr.png', 'DefaultAddonPVRClient.png')})
        li.setInfo('video', {'plot': "Utiliza esto para forzar que EspaTV reinstale y sobreescriba tu guía si falla."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="setup_pvr"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="Auto-Configurar Guía de TV Nativa (PVR Grid)")
        li.setArt({'icon': _ico('adv_pvr.png', 'DefaultAddonPVRClient.png')})
        li.setInfo('video', {'plot': "Esta opción vinculará la programación TDT con la sección nativa 'TV' del menú principal de Kodi.\n\nTe proporcionará una cuadrícula de horarios por horas (Grid) súper fluida. Reemplazará configuraciones PVR anteriores."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="setup_pvr"), listitem=li, isFolder=False)

    # 8. Reproductor TDT (InputStream)
    use_ia = xbmcaddon.Addon().getSetting('use_inputstream') == 'true'
    if use_ia:
        ia_label = "Motor TDT (En Directo): [COLOR green]INPUTSTREAM ADAPTIVE[/COLOR]"
        ia_plot = "REPRODUCTOR AVANZADO: Forzando Kodi a usar el motor InputStream para M3U8.\n\nMejora la reconexión de red y permite pausar el directo (TimeShift).\n\n[COLOR blue][I]Pulsa para desactivar y volver al Reproductor Nativo de Kodi.[/I][/COLOR]"
    else:
        ia_label = "Motor TDT (En Directo): [COLOR grey]NATIVO (Por defecto)[/COLOR]"
        ia_plot = "REPRODUCTOR ESTÁNDAR: Usando el motor de vídeo nativo interno de Kodi.\n\nEl directo no se puede pausar, pero es compatible con todos los sistemas operativos.\n\n[COLOR blue][I]Pulsa para activar InputStream (Requiere addon instalado).[/I][/COLOR]"
    li = xbmcgui.ListItem(label=ia_label)
    li.setArt({'icon': _ico('adv_motor_tdt.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': ia_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_inputstream"), listitem=li, isFolder=False)

    # 8b. Modo Anti-Errores IPTV
    anti_err = xbmcaddon.Addon().getSetting('iptv_anti_errors') == 'true'
    if anti_err:
        ae_label = "Modo Anti-Errores IPTV: [COLOR green]ACTIVADO[/COLOR]"
    else:
        ae_label = "Modo Anti-Errores IPTV: [COLOR grey]DESACTIVADO[/COLOR]"
    ae_plot = "Si un canal te da 'Playback failed', activa este modo para solucionarlo."
    li = xbmcgui.ListItem(label=ae_label)
    li.setArt({'icon': _ico('adv_anti_errores.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': ae_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_iptv_anti_errors"), listitem=li, isFolder=False)

    # Ajustes PVR y Generales
    li = xbmcgui.ListItem(label="Ajustes de Grabaciones")
    li.setArt({'icon': _ico('adv_grabaciones.png', 'DefaultAddonProgram.png')})
    li.setInfo('video', {'plot': "Configura la carpeta de destino para las grabaciones PVR de IPTV y TDT."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_settings"), listitem=li, isFolder=False)

    # Puerto del servidor remoto
    _cur_port = xbmcaddon.Addon().getSetting('remote_port') or '8089'
    li = xbmcgui.ListItem(label="Puerto servidor remoto: [COLOR deepskyblue]{0}[/COLOR]".format(_cur_port))
    li.setArt({'icon': _ico('adv_puerto.png', 'DefaultNetwork.png')})
    li.setInfo('video', {'plot': "Puerto inicial del servidor HTTP local para enviar URLs o texto desde el móvil o PC.\nSi el puerto está ocupado, se prueban los 10 siguientes.\nPuerto actual: {0}".format(_cur_port)})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="config_remote_port"), listitem=li, isFolder=False)

    # 9. Borrar Cache
    li = xbmcgui.ListItem(label="[COLOR red]¡BORRAR TODA LA CACHÉ![/COLOR]")
    li.setArt({'icon': _ico('adv_borrar.png', 'DefaultIconError.png')})
    li.setInfo('video', {'plot': "Elimina todos los datos temporales e imágenes guardadas.\nSOLUCIONA PROBLEMAS.\n\nÚtil si los menús muestran información antigua, imágenes rotas o comportamientos extraños."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="clear_cache"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _toggle_inputstream():
    cur = xbmcaddon.Addon().getSetting('use_inputstream') == 'true'
    xbmcaddon.Addon().setSetting('use_inputstream', "false" if cur else "true")
    if not cur:
        try:
            xbmcaddon.Addon('inputstream.adaptive')
            xbmcgui.Dialog().notification("Reproductor", "InputStream Adaptive ACTIVADO", xbmcgui.NOTIFICATION_INFO)
        except RuntimeError:
            xbmcgui.Dialog().ok("Aviso Importante", "Has activado usar InputStream Adaptive, pero parece que el componente oficial no está instalado.\n\nVe al repositorio oficial de Kodi -> Addons de Vídeo InputStream e instala InputStream Adaptive para que funcione, o vuelve a desactivar esta opción.")
    else:
        xbmcgui.Dialog().notification("Reproductor", "InputStream Adaptive DESACTIVADO", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_iptv_anti_errors():
    cur = xbmcaddon.Addon().getSetting('iptv_anti_errors') == 'true'
    xbmcaddon.Addon().setSetting('iptv_anti_errors', "false" if cur else "true")
    if not cur:
        xbmcgui.Dialog().notification("Anti-Errores", "Modo Anti-Errores ACTIVADO", xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("Anti-Errores", "Modo Anti-Errores DESACTIVADO", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_force_white_text():
    cur = xbmcaddon.Addon().getSetting('acc_color_mode') == 'white'
    xbmcaddon.Addon().setSetting('acc_color_mode', 'none' if cur else 'white')
    if not cur:
        xbmcgui.Dialog().notification("EspaTV", "Texto blanco ACTIVADO", xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("EspaTV", "Texto blanco DESACTIVADO", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


# ---------------------------------------------------------------------------
# ACCESIBILIDAD — submenú y acciones de toggle
# ---------------------------------------------------------------------------

_ACC_COLOR_NAMES = {
    'none':       'Sin modificar (colores originales)',
    'white':      'Texto blanco (todos los colores → blanco)',
    'daltonic_rg':'Daltónico rojo-verde (deuteranopia/protanopia)',
    'daltonic_by':'Daltónico azul-amarillo (tritanopia)',
    'hc_dark':    'Alto contraste — fondo oscuro (amarillo)',
    'hc_light':   'Alto contraste — fondo claro (negro)',
}
_ACC_COLOR_KEYS = list(_ACC_COLOR_NAMES.keys())
_ACC_COLOR_LABELS = list(_ACC_COLOR_NAMES.values())

_ACC_COLOR_PLOTS = {
    'none': "Los textos aparecen con los colores originales del addon.\n\nLos colores se usan para localizar elementos a simple vista (gris = desactivado, verde = activo, rojo = borrar, etc.).",
    'white': "Todos los textos de color se muestran en blanco.\n\nÚtil si tu skin tiene fondo claro o si los colores del addon no se ven bien.",
    'daltonic_rg': "Optimizado para personas con daltonismo rojo-verde (deuteranopia o protanopia, ~6% de varones).\n\nLos rojos se convierten en naranja. Los verdes se convierten en cyan. Los azules se preservan.",
    'daltonic_by': "Optimizado para personas con daltonismo azul-amarillo (tritanopia, ~0.5%).\n\nLos amarillos se convierten en magenta. Los azules y cyans se convierten en rojo.",
    'hc_dark': "Alto contraste para skins con fondo oscuro (la más común en Kodi).\n\nTodos los textos en amarillo brillante. Solo el rojo se preserva en items destructivos (BORRAR, ERROR).",
    'hc_light': "Alto contraste para skins con fondo claro.\n\nTodos los textos en negro. Solo el rojo se preserva en items destructivos.",
}

def accessibility_menu():
    h = int(sys.argv[1])

    _cur_mode = xbmcaddon.Addon().getSetting('acc_color_mode') or 'none'
    _bold_on = xbmcaddon.Addon().getSetting('acc_force_bold') == 'true'
    _sym_on = xbmcaddon.Addon().getSetting('acc_strip_symbols') == 'true'

    mode_name = _ACC_COLOR_NAMES.get(_cur_mode, _ACC_COLOR_NAMES['none'])

    # 1. Modo de color
    li = xbmcgui.ListItem(label="Modo de color: [COLOR deepskyblue]{0}[/COLOR]".format(mode_name))
    li.setArt({'icon': 'DefaultAddonSkin.png'})
    plot_base = "Selecciona cómo se muestran los colores en todos los menús del addon.\n\n"
    plot_base += _ACC_COLOR_PLOTS.get(_cur_mode, '')
    plot_base += "\n\n[I]Cierra y vuelve a abrir el addon para que el cambio se aplique a todos los menús.[/I]"
    li.setInfo('video', {'plot': plot_base})
    xbmcplugin.addDirectoryItem(h, url=_u(action="acc_set_color_mode"), listitem=li, isFolder=False)

    # 2. Forzar negrita
    bold_label = "Forzar negrita en todas las etiquetas: [COLOR green]ACTIVADO[/COLOR]" if _bold_on else "Forzar negrita en todas las etiquetas: [COLOR grey]DESACTIVADO[/COLOR]"
    li = xbmcgui.ListItem(label=bold_label)
    li.setArt({'icon': 'DefaultAddonSkin.png'})
    li.setInfo('video', {'plot': "Muestra todas las etiquetas de los menús en negrita.\n\nÚtil para personas con baja visión o dificultad para leer texto fino.\n\n[I]Cierra y vuelve a abrir el addon para que el cambio se aplique a todos los menús.[/I]"})
    xbmcplugin.addDirectoryItem(h, url=_u(action="acc_toggle_bold"), listitem=li, isFolder=False)

    # 3. Quitar símbolos
    sym_label = "Reemplazar símbolos (★●▲▼ → *-^v): [COLOR green]ACTIVADO[/COLOR]" if _sym_on else "Reemplazar símbolos (★●▲▼ → *-^v): [COLOR grey]DESACTIVADO[/COLOR]"
    li = xbmcgui.ListItem(label=sym_label)
    li.setArt({'icon': 'DefaultAddonSkin.png'})
    li.setInfo('video', {'plot': "Sustituye los símbolos Unicode (★ ● ○ ▲ ▼ ◑ ◐) por equivalentes de texto (* - ^ v ~).\n\nÚtil para lectores de pantalla o fuentes que no incluyen estos caracteres.\n\n[I]Cierra y vuelve a abrir el addon para que el cambio se aplique a todos los menús.[/I]"})
    xbmcplugin.addDirectoryItem(h, url=_u(action="acc_toggle_symbols"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _acc_set_color_mode():
    cur = xbmcaddon.Addon().getSetting('acc_color_mode') or 'none'
    try:
        cur_idx = _ACC_COLOR_KEYS.index(cur)
    except ValueError:
        cur_idx = 0
    sel = xbmcgui.Dialog().select("Modo de color — Accesibilidad", _ACC_COLOR_LABELS, preselect=cur_idx)
    if sel < 0:
        return
    new_mode = _ACC_COLOR_KEYS[sel]
    xbmcaddon.Addon().setSetting('acc_color_mode', new_mode)
    name = _ACC_COLOR_LABELS[sel]
    xbmcgui.Dialog().notification("Accesibilidad", "Color: {0}".format(name[:40]), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _acc_toggle_bold():
    cur = xbmcaddon.Addon().getSetting('acc_force_bold') == 'true'
    xbmcaddon.Addon().setSetting('acc_force_bold', 'false' if cur else 'true')
    xbmcgui.Dialog().notification("Accesibilidad", "Negrita " + ("DESACTIVADA" if cur else "ACTIVADA"), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _acc_toggle_symbols():
    cur = xbmcaddon.Addon().getSetting('acc_strip_symbols') == 'true'
    xbmcaddon.Addon().setSetting('acc_strip_symbols', 'false' if cur else 'true')
    xbmcgui.Dialog().notification("Accesibilidad", "Reemplazo de símbolos " + ("DESACTIVADO" if cur else "ACTIVADO"), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_dev_mode():
    dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
    if os.path.exists(dev_flag):
        try:
            os.remove(dev_flag)
            xbmcgui.Dialog().notification("EspaTV", "Modo Desarrollo DESACTIVADO", xbmcgui.NOTIFICATION_INFO)
        except OSError as e:
            xbmcgui.Dialog().ok("Error", "No se pudo desactivar: {0}".format(e))
    else:
        try:
            with open(dev_flag, 'w') as f:
                f.write('dev')
            xbmcgui.Dialog().notification("EspaTV", "Modo Desarrollo ACTIVO", xbmcgui.NOTIFICATION_WARNING)
        except OSError as e:
            xbmcgui.Dialog().ok("Error", "No se pudo activar: {0}".format(e))
    xbmc.executebuiltin("Container.Refresh")


def _get_debug_state_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, 'debug_state.json')


def _is_debug_active():
    f = _get_debug_state_file()
    if not os.path.exists(f):
        return False
    try:
        with open(f, 'r', encoding='utf-8') as o:
            return json.load(o).get('active', False)
    except (OSError, ValueError):
        return False

def _toggle_debug():
    new_state = not _is_debug_active()
    
    # Advertencia de seguridad SIEMPRE (tanto al activar como al desactivar)
    action_str = "activar" if new_state else "desactivar"
    if not xbmcgui.Dialog().yesno("ADVERTENCIA DE SEGURIDAD", 
        f"[COLOR red]ALERTA:[/COLOR] Vas a {action_str} el Modo Debug.\n\n"
        "Si no sabes lo que estás haciendo, esto podría causar errores o inestabilidad en el addon.\n"
        "¿Estás seguro de continuar?"):
        return


    log_to_file = False
    if new_state:
        if xbmcgui.Dialog().yesno("Generar Log de Errores", 
            "¿Quieres generar un archivo LOG en la raíz del addon con los errores del addon?\n\n"
            "Esto creará 'EspaTV_errors.log' en la carpeta del plugin."):
            log_to_file = True
            try:
                base_dir = os.path.dirname(os.path.abspath(__file__))
                log_file = os.path.join(base_dir, 'EspaTV_errors.log')
                ts = time.strftime('%Y-%m-%d %H:%M:%S')
                with open(log_file, 'a', encoding='utf-8') as lf:
                    lf.write(f"[{ts}] --- INICIO DE SESIÓN DE DEBUG ---\n")
            except OSError:
                pass
    else:
        try:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            log_file = os.path.join(base_dir, 'EspaTV_errors.log')
            if os.path.exists(log_file):
                os.remove(log_file)
        except OSError:
            pass

    with open(_get_debug_state_file(), 'w', encoding='utf-8') as o: json.dump({'active': new_state, 'log_to_file': log_to_file}, o)
    
    msg = "ACTIVADO" if new_state else "DESACTIVADO"
    if log_to_file: msg += " (Con Log Propio)"
    xbmcgui.Dialog().notification("EspaTV", f"Modo Debug {msg}", xbmcgui.NOTIFICATION_INFO)
    # Forzamos viaje al menu principal rompiendo la cache con un timestamp
    xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?reload={int(time.time())}, replace)")

def _log_error(msg):
    xbmc.log(f"[EspaTV ERROR] {msg}", xbmc.LOGERROR)
    try:
        f = _get_debug_state_file()
        if os.path.exists(f):
            with open(f, 'r', encoding='utf-8') as fh:
                st = json.load(fh)
            if st.get('active') and st.get('log_to_file'):
                base_dir = os.path.dirname(os.path.abspath(__file__))
                log_file = os.path.join(base_dir, 'EspaTV_errors.log')
                ts = time.strftime('%Y-%m-%d %H:%M:%S')
                with open(log_file, 'a', encoding='utf-8') as lf:
                    lf.write(f"[{ts}] {msg}\n")
    except (OSError, ValueError):
        pass

def _view_error_log():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    log_file = os.path.join(base_dir, 'EspaTV_errors.log')
    
    if not os.path.exists(log_file):
        xbmcgui.Dialog().ok("Error", "No existe el archivo de log.\nActiva el Modo Debug y genera errores primero.")
        return

    opts = ["Ver archivo completo", "Últimas 50 líneas", "Últimas 20 líneas", "Últimas 10 líneas"]
    sel = xbmcgui.Dialog().select("¿Qué deseas ver?", opts)
    if sel < 0: return
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except OSError as e:
        xbmcgui.Dialog().ok("Error Leyendo Log", str(e))
        return

    if not lines:
        content = "[El archivo está vacío]"
    elif sel == 0:
        content = "".join(lines)
    elif sel == 1:
        content = "".join(lines[-50:])
    elif sel == 2:
        content = "".join(lines[-20:])
    elif sel == 3:
        content = "".join(lines[-10:])
    else:
        content = ""

    xbmcgui.Dialog().textviewer("Log de Errores - EspaTV", content)



def _toggle_prioritize_match():
    new_state = not core_settings.is_prioritize_match_active()
    core_settings.set_prioritize_match(new_state)
    msg = "MODO PRECISIÓN ACTIVADO" if new_state else "MODO DURACIÓN (ESTÁNDAR)"
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_recent():
    new_state = not core_settings.is_recent_active()
    core_settings.set_recent_active(new_state)
    msg = "ORDEN RECIENTE ACTIVADO" if new_state else "ORDEN RELEVANCIA REINSTAURADO"
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _set_min_duration_filter():
    opts = ["Desactivado", "Más de 2 min", "Más de 5 min", "Más de 10 min", "Más de 20 min (Solo Full)"]
    vals = [0, 2, 5, 10, 20]
    sel = xbmcgui.Dialog().select("Ocultar vídeos más cortos que...", opts)
    if sel < 0: return
    core_settings.set_min_duration(vals[sel])
    xbmc.executebuiltin("Container.Refresh")





def _get_cache_dir():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    cd = os.path.join(p, 'api_cache')
    if not os.path.exists(cd):
        os.makedirs(cd)
    return cd


def _save_cache(key, data):
    try:
        f = os.path.join(_get_cache_dir(), "{0}.json".format(key))
        with open(f, 'w', encoding='utf-8') as o:
            json.dump(data, o)
    except OSError:
        pass


def _load_cache(key):
    f = os.path.join(_get_cache_dir(), "{0}.json".format(key))
    if not os.path.exists(f):
        return None
    try:
        with open(f, 'r', encoding='utf-8') as o:
            return json.load(o)
    except (OSError, ValueError):
        return None


def _cached_http_get(url, timeout=15):
    """GET con caché opcional basada en TTL de IPTV. Si activa y vigente, sirve desde disco."""
    import hashlib
    ttl = core_settings.get_iptv_cache_ttl()

    cache_file = None
    if ttl > 0:
        cache_dir = core_settings.get_iptv_cache_dir()
        cache_key = hashlib.md5(url.encode('utf-8')).hexdigest()
        cache_file = os.path.join(cache_dir, "{0}.json".format(cache_key))
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    cached = json.load(f)
                if (time.time() - cached.get("ts", 0)) < ttl:
                    return cached.get("content", "")
            except (OSError, ValueError):
                pass

    r = requests.get(url, timeout=timeout)
    if r.status_code != 200:
        raise RuntimeError("Error HTTP {0}".format(r.status_code))
    content = r.text

    if cache_file:
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump({"ts": time.time(), "url": url, "content": content}, f, ensure_ascii=False)
        except OSError:
            pass

    return content


def _sanitized_info():
    t = (
        "[B]EspaTV[/B]\nContacto: t.me/rubensdfa1laberot\n"
        "GitHub: https://github.com/espakodi\n"
        "Telegram: https://t.me/espadaily\n"
        "Contacto: fullstackcurso.github.io/donaciones/#mensaje\n\n"
        
        "[B]AVISO LEGAL:[/B]\n\n"
        
        "[B]1. No Afiliación:[/B]\n"
        "Este proyecto es independiente. NO tiene ninguna afiliación ni vinculación con ninguna cadena de televisión ni entidad oficial.\n\n"
        
        "[B]2. Naturaleza Técnica:[/B]\n"
        "Este software actúa como un agregador de búsqueda. NO contiene, aloja ni sube contenido protegido. Muestra resultados que ya son accesibles públicamente en internet.\n\n"
        
        "[B]3. Responsabilidad del Usuario:[/B]\n"
        "El usuario es el único responsable de verificar la legalidad del acceso a los contenidos según las leyes de su país. Este addon se proporciona \"tal cual\", sin garantías de ningún tipo.\n"
        "EspaTV no se hace responsable del contenido alojado en servidores de terceros.\n\n"
        
        "[B]4. Naturaleza del proyecto:[/B]\n"
        "Es GRATUITO y sin ánimo de lucro.\n\n"
        
        "[B]5. Telemetría Anónima:[/B]\n"
        "Para mejorar el addon, se envía de forma anónima la plataforma, versión del addon y de Kodi. No se recopilan datos personales, IPs ni hábitos de uso.\n\n"
        
        "[B]Contacto y Retirada:[/B]\n"
        "Si es titular de derechos y considera que este software le perjudica, puede solicitar cambios a través de Telegram o GitHub."
    )
    xbmcgui.Dialog().textviewer("Información de EspaTV", t)

def _info():
    t = (
        "[B]EspaTV[/B]\n"
        "GitHub: https://github.com/espakodi\n"
        "Contacto: t.me/rubensdfa1laberot\n"
        "Canal de Telegram: https://t.me/espadaily\n"
        "Chat de Telegram: https://t.me/espakodi\n"
        "Contacto 2: fullstackcurso.github.io/donaciones/#mensaje\n\n"
        
        "[B]AVISO LEGAL:[/B]\n\n"
        
        "[B]1. No Afiliación:[/B]\n"
        "Este proyecto es independiente. NO tiene ninguna afiliación ni vinculación con ninguna cadena de televisión ni entidad oficial.\n\n"
        
        "[B]2. Naturaleza Técnica:[/B]\n"
        "Este software actúa como un agregador de búsqueda. NO contiene, aloja ni sube contenido protegido. Muestra resultados que ya son accesibles públicamente en internet.\n\n"
        
        "[B]3. Responsabilidad del Usuario:[/B]\n"
        "El usuario es el único responsable de verificar la legalidad del acceso a los contenidos según las leyes de su país. Este addon se proporciona \"tal cual\", sin garantías de ningún tipo.\n"
        "EspaTV no se hace responsable del contenido alojado en servidores de terceros.\n\n"
        
        "[B]4. Naturaleza del proyecto:[/B]\n"
        "Es GRATUITO y sin ánimo de lucro.\n\n"
        
        "[B]5. Telemetría Anónima:[/B]\n"
        "Para mejorar el addon, se envía de forma anónima la plataforma, versión del addon y de Kodi. No se recopilan datos personales, IPs ni hábitos de uso.\n\n"
        
        "[B]Contacto y Retirada:[/B]\n"
        "Si es titular de derechos y considera que este software le perjudica, puede solicitar cambios a través de Telegram o GitHub."
    )
    xbmcgui.Dialog().textviewer("Información de EspaTV", t)

def _web_info():
    t = (
        "https://github.com/espakodi\n\n"
        "------------------------------------------------\n\n"
        "[B]Visita mi GitHub para más proyectos como este.[/B]\n\n"
        "Allí encontrarás mis otros trabajos y actualizaciones.\n"
        "Cualquier apoyo o difusión de mis proyectos se agradece enormemente.\n\n"
    )
    xbmcgui.Dialog().textviewer("Más en...", t)

def _version_notes():
    t = (
        "[B]GUÍA DE USUARIO DE ESPATV[/B]\n\n"
        "------------------------------------------------\n"
        "[B]¿CÓMO FUNCIONA?[/B]\n"
        "EspaTV es un centro multimedia con TV en directo (TDT, IPTV, RTVE Play), catálogo de canales de Dailymotion, búsqueda en YouTube, radio y más. Al elegir un contenido, el addon [B]busca automáticamente[/B] enlaces públicos en internet que coincidan.\n\n"
        "------------------------------------------------\n"
        "[B]HERRAMIENTAS PRINCIPALES[/B]\n\n"
        "• [B]Mis Favoritos:[/B] Guarda programas o series para acceder rápido. Pulsa clic derecho en cualquier ítem y elige 'Añadir a Favoritos'.\n"
        "• [B]Historial:[/B] Guarda tus últimas 50 búsquedas automáticamente.\n"
        "• [B]Mis Descargas:[/B] Gestiona los vídeos que hayas guardado localmente.\n"
        "• [B]Backup:[/B] Exporta tu historial y favoritos a un archivo ZIP para llevarlos a otro Kodi.\n\n"
        "------------------------------------------------\n"
        "[B]GUÍA DE OPCIONES AVANZADAS[/B]\n\n"
        "• [B]Contexto Completo:[/B] Es la opción más importante. Define qué texto se busca en internet.\n"
        "   - [I]Desactivado:[/I] Busca solo el título del capítulo (Ej: 'Capítulo 1').\n"
        "   - [I]Nivel 1 (Recomendado):[/I] Busca Serie + Capítulo (Ej: 'Cuéntame Capítulo 1').\n"
        "   - [I]Nivel 2/MAX:[/I] Añade más datos de la ruta para búsquedas muy específicas.\n\n"
        "• [B]Priorizar Ajuste vs Duración:[/B]\n"
        "   - [I]Duración:[/I] Prefiere vídeos largos (evita clips cortos).\n"
        "   - [I]Ajuste:[/I] Prefiere títulos que coincidan exactamente, aunque sean cortos.\n\n"
        "• [B]Filtro Anti-Trailers:[/B] Oculta automáticamente vídeos de menos de X minutos.\n\n"
        "• [B]Filtro Temporal:[/B] Decide si prefieres ver primero los resultados más nuevos (Reciente) o los que mejor coinciden (Relevancia).\n\n"
        "• [B]Control de Caché:[/B]\n"
        "   - [I]Apagado:[/I] Siempre carga de internet (más lento, menos espacio).\n"
        "   - [I]Híbrido:[/I] Guarda los menús en disco para que navegar sea instantáneo.\n\n"
        "• [B]Otras Utilidades:[/B]\n"
        "   - [I]Refrescar:[/I] Recarga el addon si notas que algún menú no se actualiza.\n"
        "   - [I]Modo Debug:[/I] Actívalo solo si tienes problemas graves para generar un registro de errores.\n"
        "   - [I]Borrar Caché:[/I] Elimina datos temporales. Úsalo si tienes problemas de espacio o errores visuales.\n\n"
        "------------------------------------------------\n"
        "¡Que disfrutes de EspaTV!"
    )
    xbmcgui.Dialog().textviewer("Guía de EspaTV", t)
def _version_notes_v1():
    t = (
        "[B]NOTAS DE LA VERSIÓN 1.0[/B]\n\n"
        "Versión inicial de EspaTV.\n\n"
        "[B]Funciones incluidas:[/B]\n"
        "• TV en directo (TDT, IPTV, RTVE Play)\n"
        "• Catálogo de canales de Dailymotion\n"
        "• Búsqueda en YouTube\n"
        "• Radio y podcasts\n"
        "• Favoritos, historial y descargas\n"
        "• Búsqueda avanzada con filtros de calidad\n"
        "• Integración con Elementum para torrents\n"
    )
    xbmcgui.Dialog().textviewer("Notas v1.0", t)
def _manual_search():
    if core_settings.is_advanced_search_active():
        _advanced_search_menu()
        return

    kb = xbmc.Keyboard('', 'Introduce el nombre a buscar')
    kb.doModal()
    if kb.isConfirmed():
        q = kb.getText()
        if q:
            _sh.add(q)
            _lfd(q, "", nh=True)

def _show_watch_providers(title, tmdb_id):
    import metadata_enricher as me

    if not tmdb_id and title:
        meta = me.enrich(title=title, media_type='movie')
        tmdb_id = str((meta.get('ids') or {}).get('tmdb', '')) if meta else ''

    if not tmdb_id:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo identificar la película en TMDB", xbmcgui.NOTIFICATION_WARNING)
        return

    providers = me.fetch_watch_providers(tmdb_id, media_type='movie')
    lines = []
    if providers.get('flatrate'):
        lines.append("Suscripción: " + ", ".join(providers['flatrate']))
    if providers.get('free'):
        lines.append("Gratis: " + ", ".join(providers['free']))
    if providers.get('rent'):
        lines.append("Alquiler: " + ", ".join(providers['rent']))
    if providers.get('buy'):
        lines.append("Compra: " + ", ".join(providers['buy']))

    if lines:
        xbmcgui.Dialog().textviewer(
            "¿Dónde ver '{0}' en España?".format(title),
            "\n".join(lines),
        )
    else:
        xbmcgui.Dialog().ok(
            "¿Dónde ver '{0}'?".format(title),
            "No disponible en ninguna plataforma de streaming en España según TMDB.\n\n"
            "Puede que aún esté en cines o que TMDB no tenga datos de España.",
        )


def _search_movie_multi(q):
    if not q:
        return
    archive_q = 'mediatype:movies AND title:({0})'.format(re.sub(r'[()[\]{}]', '', q))
    opciones = [
        "[COLOR red]YouTube[/COLOR]",
        "[COLOR dodgerblue]Dailymotion (EspaTV)[/COLOR]",
        "[COLOR peru]Internet Archive[/COLOR]",
        "[COLOR peru]Torrents P2P (Elementum)[/COLOR]",
    ]
    sel = xbmcgui.Dialog().select(u"Buscar '{0}' en:".format(q), opciones)
    if sel < 0:
        return
    if sel == 0:
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='yt_search_results', query=q)))
    elif sel == 1:
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='lfr', q=q, ot='')))
    elif sel == 2:
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='archive_category', q=archive_q, page=1)))
    elif sel == 3:
        _search_elementum(q)


def _top_pelis_series_menu():
    h = int(sys.argv[1])

    li = xbmcgui.ListItem(label="[B]Mejores Películas[/B]")
    li.setArt({'icon': 'DefaultVideoPlaylists.png'})
    li.setInfo('video', {'plot': "Top películas y series por género.\nAcción, Drama, Comedia, Terror, Ciencia Ficción, Series TV y más."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="filmaffinity_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]FilmAffinity[/B]")
    li.setArt({'icon': 'DefaultVideoPlaylists.png'})
    li.setInfo('video', {'plot': "En Cines España: cartelera actual.\nTop Valoradas: mejores películas de la historia."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="filmaffinity_submenu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]SensaCine[/B]")
    li.setArt({'icon': 'DefaultVideoPlaylists.png'})
    li.setInfo('video', {'plot': "Cartelera actual en cines de España y próximos estrenos."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="sensacine_submenu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Cinemeta - Top Películas[/B]")
    li.setArt({'icon': 'DefaultVideoPlaylists.png'})
    li.setInfo('video', {'plot': "Top películas más valoradas a nivel mundial.\nActualizado cada 6 horas."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cinemeta_top"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Listas de Trakt.tv[/B]")
    li.setArt({'icon': 'DefaultVideoPlaylists.png'})
    li.setInfo('video', {'plot': "Listas curadas de películas y series, disponibles sin configuración adicional."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trakt_root"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Películas (Top Historia/Populares)[/B]")
    li.setArt({'icon': 'DefaultVideoPlaylists.png'})
    li.setInfo('video', {'plot': "Lista curada de más de 130 películas legendarias y populares de todos los tiempos."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="top_movies", page=1), listitem=li, isFolder=True)

    # tmdb no se va a poner en espadaily y atresdaily (de momento)
    li = xbmcgui.ListItem(label="[B]TMDB — Listas oficiales[/B]")
    li.setArt({'icon': 'DefaultVideoPlaylists.png'})
    li.setInfo('video', {'plot': "Listas de películas y series: top valoradas, populares, tendencias, próximos estrenos y mejores series."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tmdb_lists_menu"), listitem=li, isFolder=True)

    # Letterboxd deshabilitado hasta integrar API key oficial
    # li = xbmcgui.ListItem(label="[B]Letterboxd — Listas curadas[/B]")
    # xbmcplugin.addDirectoryItem(handle=h, url=_u(action="letterboxd_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]RTVE — Cine[/B]")
    li.setArt({'icon': 'DefaultMovies.png'})
    li.setInfo('video', {'plot': "Películas disponibles gratuitamente en RTVE Play."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="rtve_category", cat_id="866", cat_name="Cine"), listitem=li, isFolder=True)

    _archive_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'archive.png')
    li = xbmcgui.ListItem(label="[B]Internet Archive — Dominio Público[/B]")
    li.setArt({'icon': _archive_icon if os.path.exists(_archive_icon) else 'DefaultMovies.png'})
    li.setInfo('video', {'plot': "Biblioteca digital sin ánimo de lucro que preserva millones de obras culturales.\n\nContiene películas, documentales y cine clásico de dominio público reproducibles directamente y de forma completamente legal.\n\nFundada en 1996, alberga más de 40 millones de recursos digitalizados.\n\n[COLOR orange]La búsqueda se realiza al pulsar el botón correspondiente. Los resultados provienen directamente de Internet Archive y no están controlados ni filtrados por este addon.[/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="archive_menu"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def _ls(cid, page=0):
    items = _dm_search(cid, page=page)
    if not items:
        if page == 0:
            xbmcgui.Dialog().ok("Error", "No se pudo obtener la lista de contenidos.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return

    _process_atres_items(items, cid, page=page)

def _process_atres_items(items, cid, page=0):
    addon = xbmcaddon.Addon(); ai = addon.getAddonInfo('icon'); af = addon.getAddonInfo('fanart')
    for i in items:
        try:
            tt = i.get("title", "Sin título"); im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr)
            if not th:
                try:
                    dr = _sr(tt)
                    th = dr[0].get("thumbnail_720_url") or dr[0].get("thumbnail_360_url") if dr else ai
                except (requests.RequestException, ValueError, KeyError, IndexError):
                    th = ai
            if not th: th = ai
            fa = th if th != ai else af
            lk = i.get("link", {}); au = lk.get("href")
            if not au: continue
            li = xbmcgui.ListItem(label=tt); li.setArt({'thumb': th, 'icon': th, 'fanart': fa})
            li.setInfo('video', {'title': tt, 'plot': i.get('description', '')})
            

            _add_fav_cm(li, tt, "atresplayer", "fs", {"au": au, "st": tt, "sth": th})
            

            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=au, st=tt, sth=th), listitem=li, isFolder=True)

        except (KeyError, AttributeError, TypeError) as e:
            _log_error(f"Error al procesar item del catálogo: {e}")
            continue

    # Paginacion: si hay items suficientes, probablemente hay mas paginas
    if len(items) >= 10:
        next_page = page + 1
        li = xbmcgui.ListItem(label="[COLOR cyan][B]>> Página Siguiente ({0})[/B][/COLOR]".format(next_page))
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls", cid=cid, page=next_page), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)

def _clear_cache():
    if not xbmcgui.Dialog().yesno("EspaTV",
"¿Borrar TODA la caché?\n\nEsto eliminará datos temporales de canales y el historial de red. NO borrará tus listas ni tu configuración.\n¿Estás seguro?"):
        return

    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if os.path.exists(p):
        _protected = [
            "favorites.json",
            "custom_categories.json",
            "custom_iptv.json",
            "iptv_cache_settings.json",
            "dm_settings.json",
            "trakt_settings.json",
            "advanced_search_state.json",
            "downloads_history.json",
            "min_duration.json",
            "priority_state.json",
            "saved_playlists.json",
            "yt_playlists.json",
            "url_bookmarks.json",
        ]
        for f in os.listdir(p):
            if f.endswith(".json") and f not in _protected:
                try:
                    os.remove(os.path.join(p, f))
                except OSError:
                    pass
    
    # Vaciar cache de discos
    import core_settings
    core_settings.clear_iptv_cache_files()
    
    xbmcgui.Dialog().notification("EspaTV", "Caché borrada", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _fs(au, st, sth="", pu=""):
    if pu and au == pu: _fb(st, sth); return
    d = _dm_search(au)
    if not d: _fb(st, sth); return
    ss = d.get("seasons", []); rw = d.get("rows", []); id_ = d.get("items", [])
    erh = None
    for ro in rw:
        if ro.get("type") == "EPISODE": erh = ro.get("href"); break
    if erh: _lfr(erh, st, sth); return
    if id_: _rel(id_, st, sth); return
    if len(ss) > 1:
        for s in ss:
            t = s.get("title", "Temporada"); sh = s.get("link", {}).get("href")
            if sh and sh != au:
                li = xbmcgui.ListItem(label=t); li.setArt({'thumb': sth, 'icon': sth})
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=sh, st=st, sth=sth, pu=au), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1])); return
    elif len(ss) == 1:
        sh = ss[0].get("link", {}).get("href")
        if sh and sh != au: _fs(sh, st, sth, pu=au); return
    _fb(st, sth)

def _fb(st, sth):
    li = xbmcgui.ListItem(label=f"Buscar '{st}' en Internet..."); li.setArt({'thumb': sth, 'icon': sth})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=st, ot=sth), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _lfr(ru, st, sth=""):
    items = _dm_search(ru)
    if items: _rel(items, st, sth)

def _rel(items, st, sth=""):
    for i in items:
        tt = i.get("title", "Capítulo"); en = i.get("name", ""); dt = f"{en} - {tt}" if en else tt

        sq = f"{tt} {en}".strip() if en else tt
        im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr) or sth
        li = xbmcgui.ListItem(label=dt); li.setArt({'thumb': th, 'icon': th, 'fanart': th})
        li.setInfo('video', {'title': dt, 'plot': i.get('description', '')})

        # Menú contextual: añadir a favoritos (episodio individual)
        _add_fav_cm(li, dt, "atresplayer", "lfr", {"q": sq, "ot": th})

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=sq, ot=th), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _clean_title(t):
    # Si hay dos partes separadas por " : ", quedarse con la segunda (suele ser el titulo real)
    if " : " in t: parts = t.split(" : "); t = parts[1] if len(parts[1]) > len(parts[0]) else parts[0]
    return t.strip() # Devolver limpio

def _lfd(q, ot, mode="", extra_params=None, nh=None):
    cq = _clean_title(q)
    rs = []
    
    if mode == "movie":
        # Intentar varias combinaciones para encontrar contenido en español
        variations = [
            f"{cq} pelicula completa castellano",
            f"{cq} pelicula completa español",
            f"{cq} pelicula completa",
            f"{cq} completa español",
            f"{cq} castellano",
            cq # Como ultimo recurso, el titulo limpio a secas
        ]
        
        for v in variations:
            rs = _sr(v, extra_params)
            if rs: break # Si encontramos algo, nos quedamos con ello
            
    elif mode == "exact":
        # Busca exactamente lo que el usuario escribió
        rs = _sr(q, extra_params)

    elif mode == "keywords":
        # Busca solo por palabras clave de más de 3 letras
        kw = " ".join([w for w in re.findall(r'\w+', q) if len(w) > 3])
        if kw: rs = _sr(kw, extra_params)

    else:
        # Logica estandar para series/programas (o User, Long, Short)
        # Si es modo User/Long/Short, el 'q' puede ser el termino de busqueda normal, y 'extra_params' lleva el filtro.
        # Intentamos con titulo limpio primero
        rs = _sr(cq, extra_params) 
        if not rs and cq != q: rs = _sr(q, extra_params) # Intentar con el original si el limpio falla
    
    if not rs and mode not in ["exact", "keywords"]: 
        # Ultimo intento: buscar solo palabras clave (mayores de 3 letras)
        kw = " ".join([w for w in re.findall(r'\w+', q) if len(w) > 3])
        if kw: rs = _sr(kw, extra_params)
    
    # Botón de alternativas de búsqueda al inicio de resultados
    _has_alt_addons = (
        xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)") or
        xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)") or
        xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)")
    )
    if _has_alt_addons:
        _alt_label = "[COLOR yellow][B]¿No es lo que buscas?[/B][/COLOR]"
    else:
        _alt_label = "[COLOR yellow][B]Editar búsqueda y reintentar[/B][/COLOR]"
    li_alt = xbmcgui.ListItem(label=_alt_label)
    li_alt.setArt({'icon': 'DefaultAddonsSearch.png', 'thumb': 'DefaultAddonsSearch.png'})
    li_alt.setInfo('video', {'plot': "Busca en otros addons instalados o edita tu búsqueda."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_alt_prompt", q=cq, ot=ot), listitem=li_alt, isFolder=False)

    if not rs: 
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron resultados", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    sr = _gsr(cq, rs, mode)[:25] # Aumentamos un poco el limite para tener mas donde ordenar
    
    if not sr: 

        if xbmcgui.Dialog().yesno("EspaTV", "No se encontraron coincidencias relevantes.\n\n¿Quieres editar las palabras clave y probar otra vez?"):
             kb = xbmc.Keyboard(q, 'Editar Búsqueda')
             kb.doModal()
             if kb.isConfirmed():
                 nq = kb.getText()
                 if nq:
                     xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=nq, ot=ot)})")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    

    
    min_dur = core_settings.get_min_duration() * 60
    for sc, v in sr:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        
        # FILTRO ESTRICTO DE DURACIÓN
        if min_dur > 0 and du < min_dur: continue
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ot
        
        # En modo pelicula mostramos el titulo completo del video encontrado
        if mode == "movie":
             lb = vt
        else:
             lb = f"{vt} ({int(sc*100)}% match)"

        li = xbmcgui.ListItem(label=lb); li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Subido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        
        # MENU CONTEXTUAL PARA DESCARGAR Y ABRIR EN NAVEGADOR
        cm = []
        cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=vt)})"))
        cm.append(("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"))
        cm.append(("Abrir en navegador", f"RunPlugin({_u(action='dm_open_browser', url=vi)})"))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vi)))))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _pv(vid):
    """Reproductor principal Dailymotion. Cascada según plataforma + nivel de seguridad configurado."""
    try:
        dm_cfg = _load_dm_settings()
        dm_level = dm_cfg.get('dm_safe_level', 0)
        max_quality = dm_cfg.get('dm_max_quality', 1080)

        # Metadata opcional (no bloquea la reproducción si falla)
        d = _dm_resolve(vid)
        v_title = d.get('title', vid) if d else vid
        v_thumb = (d.get('thumbnail_url') or d.get('thumbnail_360_url', '')) if d else ''
        v_duration = d.get('duration', 0) if d else 0

        def _record_history():
            try:
                _wh.add(vid, v_title, thumb=v_thumb, duration=v_duration)
            except (OSError, ValueError):
                pass

        _is_windows = xbmc.getCondVisibility("System.Platform.Windows")
        
        # Solo usar YT-DLP si el usuario lo seleccionó explícitamente (Nivel 3)
        use_ytdlp = (dm_level == 3)

        if not _is_windows and not use_ytdlp:
            # No-Windows: resolucion directa (API) con fallback a dm_gujal
            result = _dm_play_android(vid, dm_level=dm_level, max_quality=max_quality)
            if result and result.get('url'):
                _record_history()
                stream_url = result['url']
                mime_type = result.get('mime', '')
                is_hls = 'mpegURL' in mime_type

                # Codificar headers si presentes (salvaguarda defensiva)
                headers_dict = result.get('headers')
                header_str = ""
                if headers_dict:
                    header_str = "&".join(
                        "{0}={1}".format(k, urllib.parse.quote(str(v)))
                        for k, v in headers_dict.items()
                    )

                if not is_hls and header_str:
                    stream_url = "{0}|{1}".format(stream_url, header_str)

                li = xbmcgui.ListItem(path=stream_url)
                if mime_type:
                    li.setMimeType(mime_type)
                if is_hls and header_str:
                    li.setProperty("inputstream", "inputstream.adaptive")
                    li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                    li.setProperty("inputstream.adaptive.stream_headers", header_str)
                li.setContentLookup(False)
                subs = result.get('subs')
                if subs and isinstance(subs, list):
                    li.setSubtitles(subs)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
                return

            # Fallback para no-Windows: plugin.video.dailymotion_com
            if xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
                xbmc.log("[EspaTV] _pv: Intentando plugin.video.dailymotion_com...", xbmc.LOGINFO)
                dm_plugin_url = "plugin://plugin.video.dailymotion_com/?url={0}&mode=playVideo".format(vid)
                xbmc.executebuiltin('PlayMedia("{0}")'.format(dm_plugin_url))
                try:
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                except RuntimeError:
                    pass
                return

            xbmcgui.Dialog().notification("EspaTV", "No se encontró stream válido", xbmcgui.NOTIFICATION_ERROR)
            try:
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            except RuntimeError:
                pass

        else:
            _dm_ok = False
            dm_web_url = f"https://www.dailymotion.com/video/{vid}"

            _ytdlp_present = ytdlp_resolver.is_installed()
            if _ytdlp_present:
                xbmcgui.Dialog().notification("EspaTV", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
                stream_url = ytdlp_resolver.resolve(dm_web_url)
                if stream_url:
                    _record_history()
                    li = xbmcgui.ListItem(path=stream_url)
                    li.setProperty('IsPlayable', 'true')
                    li.setContentLookup(False)
                    try:
                        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
                    except RuntimeError:
                        xbmc.Player().play(stream_url, li)
                    _dm_ok = True

            if not _dm_ok:
                if _ytdlp_present:
                    _err_body = (
                        "El CDN de Dailymotion bloqueó la petición con error 403 HTTP. "
                        "yt-dlp lo intentó pero también fue bloqueado: sin VPN el bloqueo "
                        "es por IP, no solo por cliente.\n\n"
                        "[B]Prueba estas soluciones:[/B]\n"
                        "• Activa una VPN y vuelve a intentar la reproducción\n"
                        "• Abre el vídeo en el Navegador Web (botón abajo)\n"
                        "• Pulsa 'Forzar Kodi' para intentar métodos alternativos"
                    )
                else:
                    _err_body = (
                        "El CDN de Dailymotion bloquea Kodi en Windows con error 403 HTTP.\n"
                        "yt-dlp no está instalado en el Python del sistema, "
                        "por lo que no se pudo usar como alternativa.\n\n"
                        "[B]Prueba estas soluciones:[/B]\n"
                        "• Activa una VPN y vuelve a intentar la reproducción\n"
                        "• Abre el vídeo en el Navegador Web (botón abajo)\n"
                        "• Instala yt-dlp: Opciones → Mantenimiento PC (yt-dlp)\n"
                        "• Pulsa 'Forzar Kodi' para intentar métodos alternativos"
                    )
                if xbmcgui.Dialog().yesno(
                    "Error Kodi/Windows",
                    _err_body,
                    yeslabel="Navegador Web", nolabel="Forzar Kodi"
                ):
                    try:
                        import webbrowser
                        webbrowser.open(dm_web_url)
                        xbmcgui.Dialog().notification("EspaTV", "Enlace enviado al navegador", xbmcgui.NOTIFICATION_INFO)
                    except (OSError, webbrowser.Error):
                        xbmcgui.Dialog().ok("EspaTV", f"Abre la siguiente URL en tu navegador de internet:\n\n{dm_web_url}")
                    _record_history()
                    _dm_ok = True

            if not _dm_ok:
                try:
                    result = _dm_play(vid, dm_level=dm_level, max_quality=max_quality)
                    if result and result.get('url'):
                        _record_history()
                        stream_url = result['url']
                        mime_type = result.get('mime', '')
                        is_hls = 'mpegURL' in mime_type

                        headers_dict = result.get('headers')
                        header_str = ""
                        if headers_dict:
                            header_str = "&".join(
                                "{0}={1}".format(k, urllib.parse.quote(str(v)))
                                for k, v in headers_dict.items()
                            )

                        if not is_hls and header_str:
                            stream_url = "{0}|{1}".format(stream_url, header_str)

                        li = xbmcgui.ListItem(path=stream_url)
                        if mime_type: li.setMimeType(mime_type)
                        if is_hls and header_str:
                            li.setProperty("inputstream", "inputstream.adaptive")
                            li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                            li.setProperty("inputstream.adaptive.stream_headers", header_str)
                        li.setContentLookup(False)
                        subs = result.get('subs')
                        if subs and isinstance(subs, list): li.setSubtitles(subs)
                        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
                        
                        import time as _t; _t.sleep(2)
                        if xbmc.Player().isPlaying(): _dm_ok = True
                except (RuntimeError, OSError, ValueError):
                    pass

            if not _dm_ok and xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
                try:
                    dm_plugin_url = "plugin://plugin.video.dailymotion_com/?url={0}&mode=playVideo".format(vid)
                    xbmc.executebuiltin('PlayMedia("{0}")'.format(dm_plugin_url))
                    import time as _t; _t.sleep(3)
                    if xbmc.Player().isPlaying():
                        _record_history()
                        _dm_ok = True
                except RuntimeError:
                    pass

            if not _dm_ok:
                try:
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                except RuntimeError:
                    pass

    except (requests.RequestException, ValueError, RuntimeError, KeyError) as e:
        _l(f"Play Error: {e}")
        xbmcgui.Dialog().ok("Error", str(e))


def _sr(q, extra_params=None):
    p = {}
    if core_settings.is_recent_active():
        p["sort"] = "recent"
    if extra_params:
        p.update(extra_params)
    return _dm_search(q, p if p else None)

def _gsr(q, rs, mode=""):
    if not rs: return []
    sc = []; ql = q.lower().strip(); qn = re.findall(r'(\d+)', ql)
    for r in rs:
        t = r.get("title", "").strip(); tl = t.lower()
        if not t: continue
        

        rt = difflib.SequenceMatcher(None, ql, tl).ratio(); s = rt
        
        # FILTRO ESTRICTO: Si no contiene las palabras clave de la busqueda, penalizar fuertemente
        # (Esto evita que salgan resultados random como 'La Monja' buscando 'Top Gun')
        q_words = [w for w in ql.split() if len(w) > 3] # Palabras importantes (>3 letras)
        if q_words:
            matches = sum(1 for w in q_words if w in tl)
            if matches == 0: 
                s -= 1.0 # Penalizacion masiva si no coincide ninguna palabra clave
            elif matches < len(q_words):
                s -= 0.1 # Pequeña penalizacion si faltan palabras

        if ql in tl: s += 0.35 # Match contenido exacto
        

        words_q = set(ql.split())
        words_t = set(tl.split())
        common = words_q.intersection(words_t)
        if len(common) > 0: s += (len(common) / len(words_q)) * 0.2
        

        tn = re.findall(r'(\d+)', tl)
        if qn and tn:
            if qn[-1] in tn: s += 0.4
            if set(qn).issubset(set(tn)): s += 0.1
            

        # IMPORTANTE: Solo aplicamos bonus de duracion si el titulo coincide razonablemente bien (s > 0.3)
        # Esto evita que 'La Monja' (larga) gane a 'Iron Man 3' (corto) si el titulo no se parece.
        du = r.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        
        if s > 0.3: # Solo si hay match de titulo decente
            if not core_settings.is_prioritize_match_active():
                # Modo ESTÁNDAR: Fuerte bonus por duración
                if du > 600: s += 0.6    # Gran bonus si coincide titulo y es larga
                elif du > 300: s += 0.2
            else:
                # Modo PRECISIÓN: Bonus por duración mínimo
                if du > 600: s += 0.05
            
            if du < 180: s -= 0.1  # Penalizacion leve por ser muy corto (trailer)
        else:
            # Si el titulo no coincide bien, la duracion NO ayuda.
            pass
        

        if any(w in tl for w in ["español", "castellano", "spanish"]):
            s += 0.15

        # Filtrado especifico de peliculas
        if mode == "movie":
            # Penalizar contenido que no sea pelicula
            if any(w in tl for w in ["trailer", "avance", "entrevista", "making", "detras", "clip", "promo"]):
                s -= 0.5
            # Bonus por indicadores de pelicula
            if any(w in tl for w in ["pelicula", "completa", "movie", "film"]):
                s += 0.2

        s = min(s, 1.0)
        sc.append((s, r))
    sc.sort(key=lambda x: x[0], reverse=True); return sc


def _show_yt_fav_news():
    favs = core_settings.get_favorites()
    channels = []
    for f in favs:
        if f.get('action') != 'felicidad_play':
            continue
        params = f.get('params', {})
        if isinstance(params, str):
            try:
                params = json.loads(params)
            except (json.JSONDecodeError, TypeError):
                continue
        if params.get('ctype') == 'channel' and params.get('yt_id'):
            channels.append({'yt_id': params['yt_id'], 'name': params.get('name', 'Canal')})

    if not channels:
        xbmcgui.Dialog().ok("EspaTV", "No tienes canales de YouTube en favoritos.\n\nAñade canales desde las secciones de YouTube.")
        return

    pdp = xbmcgui.DialogProgress()
    pdp.create("Novedades YouTube", "Buscando vídeos recientes...")

    all_videos = []
    total = len(channels)
    for i, ch in enumerate(channels):
        if pdp.iscanceled():
            break
        pdp.update(int((i / max(total, 1)) * 100), "Analizando: [B]{0}[/B]".format(ch['name']))
        try:
            url = "https://www.youtube.com/channel/{0}/videos".format(ch['yt_id'])
            r = requests.get(url, headers={"Accept-Language": "es"}, timeout=12)
            if r.status_code != 200:
                continue
            data = _yts._yt_parse_initial_data(r.text)
            if not data:
                continue
            # Extraer de la pestaña de vídeos del canal
            vids = []
            try:
                tabs = data.get("contents", {}).get("twoColumnBrowseResultsRenderer", {}).get("tabs", [])
                for tab in tabs:
                    tr = tab.get("tabRenderer", {})
                    if tr.get("selected"):
                        contents = tr.get("content", {}).get("richGridRenderer", {}).get("contents", [])
                        for item in contents:
                            ri = item.get("richItemRenderer", {}).get("content", {}).get("videoRenderer")
                            if not ri:
                                continue
                            vid = ri.get("videoId", "")
                            if not vid:
                                continue
                            title = ""
                            runs = ri.get("title", {}).get("runs", [])
                            if runs:
                                title = runs[0].get("text", "")
                            dur = ri.get("lengthText", {}).get("simpleText", "")
                            views = ri.get("viewCountText", {}).get("simpleText", "")
                            if not views:
                                views = ri.get("shortViewCountText", {}).get("simpleText", "")
                            published = ri.get("publishedTimeText", {}).get("simpleText", "")
                            if title and vid:
                                vids.append({
                                    "vid": vid, "title": title, "duration": dur,
                                    "channel": ch['name'], "views": views,
                                    "published": published
                                })
                            if len(vids) >= 5:
                                break
                        break
            except (KeyError, TypeError):
                pass
            all_videos.extend(vids)
        except (requests.RequestException, ValueError, KeyError):
            continue

    pdp.close()

    if not all_videos:
        xbmcgui.Dialog().ok("Novedades YouTube", "No se encontraron vídeos recientes en tus canales favoritos.")
        return

    h = int(sys.argv[1])
    xbmcplugin.setContent(h, 'videos')
    for v in all_videos:
        vid = v["vid"]
        title = v["title"]
        li = xbmcgui.ListItem(label="[COLOR cyan][{0}][/COLOR] {1}".format(v["channel"], title))
        thumb = 'https://i.ytimg.com/vi/{0}/hqdefault.jpg'.format(vid)
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb})
        plot_lines = []
        if v.get("channel"):
            plot_lines.append("Canal: {0}".format(v["channel"]))
        if v.get("duration"):
            plot_lines.append("Duración: {0}".format(v["duration"]))
        if v.get("views"):
            plot_lines.append("Vistas: {0}".format(v["views"]))
        if v.get("published"):
            plot_lines.append("Subido: {0}".format(v["published"]))
        plot = "\n".join(plot_lines) if plot_lines else title
        li.setInfo('video', {'plot': plot, 'title': title})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_play", yt_id=vid, name=title, ctype="video"), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _show_fav_news():
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaTV", "No tienes favoritos guardados", xbmcgui.NOTIFICATION_WARNING)
        return
        
    # 1. Preguntar margen
    opts = [
        "Últimas 24 horas",
        "Últimas 48 horas (Recomendado)",
        "Última semana (7 días)",
        "Último mes (30 días - Lento)"
    ]
    sel = xbmcgui.Dialog().select("Margen de búsqueda de Novedades", opts)
    if sel < 0: return # Cancelado
    
    margins = [86400, 172800, 604800, 2592000]
    time_limit = int(time.time()) - margins[sel]
    sel_label = opts[sel]

    pdp = xbmcgui.DialogProgress()
    pdp.create("Novedades Favoritos DM", "Buscando: {0}...".format(sel_label))
    
    all_results = []
    
    queries = []
    seen = set()
    for f in favs:
        q = None
        if f.get('action') == 'lfr':
            q = f.get('params', {}).get('q')
        
        if q and q.lower() not in seen:
            queries.append(q)
            seen.add(q.lower())
            
    if not queries:
        pdp.close()
        xbmcgui.Dialog().ok("Mi Periódico", "No hay series o búsquedas en favoritos para analizar.")
        return

    total = len(queries)
    for i, q in enumerate(queries):
        if pdp.iscanceled(): break
        pdp.update(int((i / max(total, 1)) * 100), f"Analizando: [B]{q}[/B]")
        
        rs = _sr(q, {"created_after": time_limit})
        if rs:
            sr = _gsr(q, rs, mode="keywords") 
            for score, v in sr:
                if score > 0.35: # Filtro de calidad para evitar basura
                    vid = v.get("id")
                    if not any(r[1].get("id") == vid for r in all_results):
                        all_results.append((score, v, q))

    pdp.close()
    
    if not all_results:
        xbmcgui.Dialog().ok("Novedades Favoritos DM", "No se han encontrado novedades en '{0}' para tus favoritos.".format(sel_label))
        return

    # Mostrar resultados consolidados
    h = int(sys.argv[1])
    all_results.sort(key=lambda x: x[0], reverse=True)
    xbmcplugin.setContent(h, 'videos')
    
    for score, v, origin in all_results:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url")
        
        label = f"[COLOR yellow][{origin}][/COLOR] {vt}"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Favorito: {origin}\nSubido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        
        cm = []
        cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=vt)})"))
        cm.append(("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"))
        cm.append(("Abrir en navegador", f"RunPlugin({_u(action='dm_open_browser', url=vi)})"))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vi)))))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(h)

def _show_favorites():
    favs = core_settings.get_favorites()
    

    _FLOWFAV_REPO_ID = 'repository.flowfavmanager'
    _FLOWFAV_ADDON_ID = 'plugin.program.flowfavmanager'
    try:
        xbmcaddon.Addon(_FLOWFAV_ADDON_ID)
        li_flow = xbmcgui.ListItem(label="[COLOR violet][B]Flow FavManager[/B][/COLOR]")
        li_flow.setArt({'icon': 'DefaultAddonProgram.png'})
        li_flow.setInfo('video', {'plot': 'Abre el editor avanzado de favoritos de Kodi.\nOrganiza, personaliza colores, iconos, formatos, crea secciones, perfiles y copias de seguridad.'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_flowfav"), listitem=li_flow, isFolder=False)
    except RuntimeError:
        li_flow = xbmcgui.ListItem(label="[COLOR gray]Flow FavManager (No instalado)[/COLOR]")
        li_flow.setArt({'icon': 'DefaultAddonProgram.png'})
        li_flow.setInfo('video', {'plot': 'Gestor avanzado de favoritos para Kodi.\nPulsa para instalar o ver instrucciones.'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="flowfav_install"), listitem=li_flow, isFolder=False)


    cats = category_manager.load_cats()
    if cats:
         li_c = xbmcgui.ListItem(label=f"[COLOR yellow][B]Mis Categorías ({len(cats)})[/B][/COLOR]")
         li_c.setArt({'icon': 'DefaultAddonService.png'})
         li_c.setInfo('video', {'plot': "Accede a tus carpetas y listas ('Infantil', 'Noticias', etc).\n\nPuedes crear nuevas categorías desde el menú principal."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cat_menu"), listitem=li_c, isFolder=True)
    

    if favs:
         li_n = xbmcgui.ListItem(label="[COLOR yellow][B]Novedades Favoritos DM[/B][/COLOR]")
         li_n.setArt({'icon': 'DefaultAddonService.png'})
         li_n.setInfo('video', {'plot': "Analiza automáticamente tus favoritos y busca contenido subido recientemente.\n\nPodrás elegir el margen de tiempo (24h, 48h, 7 días...).\n\nIdeal para ver qué hay de nuevo sin ir sección por sección."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_news"), listitem=li_n, isFolder=True)

         li_yt = xbmcgui.ListItem(label="[COLOR cyan][B]Novedades YouTube de Favoritos[/B][/COLOR]")
         li_yt.setArt({'icon': 'DefaultMusicVideos.png'})
         li_yt.setInfo('video', {'plot': "Busca vídeos recientes en los canales de YouTube que tengas en favoritos.\n\nMuestra los 5 últimos vídeos de cada canal."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="yt_fav_news"), listitem=li_yt, isFolder=True)


    if not favs:
        if not cats: # Only show 'empty' if no cats either
             li = xbmcgui.ListItem(label="No tienes favoritos guardados")
             li.setArt({'icon': 'DefaultIconInfo.png'})
             li.setInfo('video', {'plot': "Haz clic derecho en cualquier programa o serie y selecciona 'Añadir a Mis Favoritos' para guardarlo aquí."})
             xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="nyan_cat"), listitem=li, isFolder=False)
    else:
        for f in favs:
            li = xbmcgui.ListItem(label=f['title'])
            li.setArt({'icon': f['icon'], 'thumb': f['icon']})
        
            cm = []
            cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=f['title'])})"))



            cm.append(("Editar nombre y buscar", f"RunPlugin({_u(action='edit_and_search', q=f['title'], ot=f['icon'])})"))

            cm.append(("Renombrar...", f"RunPlugin({_u(action='fav_rename', fav_url=f['url'], old_title=f['title'])})"))
            cm.append(("Mover arriba", f"RunPlugin({_u(action='fav_move_up', fav_url=f['url'])})"))
            cm.append(("Mover abajo", f"RunPlugin({_u(action='fav_move_down', fav_url=f['url'])})"))
            

            # Usar 'cat_move_from_favs' para MOVER (borra de favs y añade a cat) en lugar de solo añadir.
            cm.append(("Mover a Categoría...", f"RunPlugin({_u(action='cat_move_from_favs', fav_url=f['url'], q=f['title'])})"))
            

            cm.append(("Eliminar de Favoritos", f"RunPlugin({_u(action='remove_favorite', fav_url=f['url'])})"))
            
            li.addContextMenuItems(cm)
            
            # Reconstruir la URL con la acción y parámetros guardados
            # URL que se abre al hacer clic en el favorito:
            u_params = f"action={f['action']}"
            for k,v in f.get('params', {}).items():
                u_params += f"&{k}={urllib.parse.quote(str(v))}"
            

            if f['action'] == 'lfr' and '&nh=' not in u_params:
                u_params += "&nh=1"
            
            non_folder_actions = ('play_podcast', 'play_tdt', 'pv')
            is_folder = f['action'] not in non_folder_actions
            if f['action'] == 'felicidad_play':
                fav_ctype = f.get('params', {}).get('ctype', 'channel')
                is_folder = (fav_ctype == 'video')
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?"+u_params, listitem=li, isFolder=is_folder)


    li = xbmcgui.ListItem(label="[COLOR cyan]Exportar Favoritos...[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Guarda tus favoritos principales en un archivo JSON para compartirlos."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_export"), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="[COLOR cyan]Importar Favoritos...[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Carga favoritos desde un archivo JSON."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_import"), listitem=li, isFolder=False)



    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _show_downloads():
    _p2p_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'p2p.png')
    li = xbmcgui.ListItem(label="[COLOR peru][B]Torrents (P2P)[/B][/COLOR]")
    li.setArt({'icon': _p2p_icon if os.path.exists(_p2p_icon) else 'DefaultAddonProgram.png'})
    li.setInfo('video', {'plot': "Acceso a redes P2P (peer-to-peer) mediante Elementum.\n\nLas redes P2P permiten compartir archivos directamente entre nodos sin servidor central. BitTorrent es el protocolo P2P más utilizado.\n\nRequiere tener Elementum instalado.\n\nEste addon no aloja ni distribuye contenido. El usuario asume toda responsabilidad sobre el uso que haga de Elementum. Elementum es un addon de terceros independiente de EspaTV."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="elementum_search_prompt"), listitem=li, isFolder=False)

    # Acceso directo a descargas de Elementum (solo si está instalado)
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
        li = xbmcgui.ListItem(label="[B][COLOR cyan]Ver Descargas de Elementum (Torrents)[/COLOR][/B]")
        li.setArt({'icon': 'DefaultAddonProgram.png'})
        li.setInfo('video', {'plot': "Abre la sección de descargas/torrents de Elementum para ver el progreso y archivos descargados."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="plugin://plugin.video.elementum/torrents/", listitem=li, isFolder=True)
    else:
        li = xbmcgui.ListItem(label="[COLOR grey]Elementum no instalado[/COLOR]")
        li.setArt({'icon': 'DefaultIconWarning.png'})
        li.setInfo('video', {'plot': "Para ver descargas de torrents, instala el addon Elementum desde su repositorio oficial.\n\nElementum permite buscar y descargar torrents directamente desde Kodi."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)


    dls = core_settings.get_downloads()
    if not dls:
        li = xbmcgui.ListItem(label="No hay historial de descargas")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'plot': "Cuando descargues un vídeo con éxito, aparecerá aquí.\nPuedes descargar vídeos desde los resultados de búsqueda pulsando clic derecho."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    else:
        for d in dls:
            path = d['path']
            if not os.path.exists(path):
                label = f"[COLOR grey][ELIMINADO][/COLOR] {d['title']}"
                is_valid = False
            else:
                label = f"{d['title']} ({d['date']})"
                is_valid = True
                
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': 'DefaultVideo.png'})
            li.setInfo('video', {'title': d['title'], 'plot': f"Archivo: {path}\nDescargado el: {d['date']}"})
            
            cm = [("Quitar del historial", f"RunPlugin({_u(action='remove_download', dl_path=path)})")]
            if is_valid:
                 li.setProperty("IsPlayable", "true")
                 cm.append(("[COLOR red]ELIMINAR ARCHIVO DEL DISCO[/COLOR]", f"RunPlugin({_u(action='delete_download_file', dl_path=path, title=d['title'])})"))
             
                 u = path
            else:
                 u = ""
                 
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=False if is_valid else True)
        
    # Nota legal de descargas
    li = xbmcgui.ListItem(label="[COLOR grey][I]Aviso: Descargar vídeos puede infringir los Términos de Servicio de las plataformas y las leyes de propiedad intelectual. No se incluye descarga de YouTube por restricciones legales y por la agresividad de Google contra estas prácticas. El usuario es el único responsable del uso que haga de esta función.[/I][/COLOR]")
    li.setArt({'icon': 'DefaultIconWarning.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _add_fav_cm(li, title, platform, action, params):
    # Prepare URL for favorites (re-entrant call)
    # Mejorar la unicidad del ID para evitar duplicados falsos
    id_val = params.get('cid') or params.get('pid') or params.get('url') or params.get('au') or params.get('q')
    if not id_val:
        # Fallback critico: Usar hash de params si no hay ID claro
        id_val = str(hash(json.dumps(params, sort_keys=True)))
    fav_url = f"{action}_{id_val}"
    params_json = json.dumps(params)
    li.addContextMenuItems([
        ("Añadir a Mis Favoritos", f"RunPlugin({_u(action='add_favorite', title=title, fav_url=fav_url, icon=li.getArt('icon'), platform=platform, fav_action=action, params=params_json)})")
    ])

def _delete_download_file(path, title):
    if xbmcgui.Dialog().yesno("Eliminar Archivo", f"¿Estás seguro de que quieres eliminar físicamente el archivo?\n\n[B]{title}[/B]\n\nEsta acción eliminará el archivo de tu disco duro para siempre."):
        try:
            if os.path.exists(path):
                os.remove(path)
                core_settings.remove_download(path)
                xbmcgui.Dialog().notification("EspaTV", "Archivo eliminado satisfactoriamente", xbmcgui.NOTIFICATION_INFO)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("EspaTV", "El archivo ya no existe en esa ruta.")
                core_settings.remove_download(path)
                xbmc.executebuiltin("Container.Refresh")
        except OSError as e:
            xbmcgui.Dialog().ok("EspaTV Error", f"No se pudo eliminar: {str(e)}")








def _toggle_advanced_search():
    new_state = not core_settings.is_advanced_search_active()
    core_settings.set_advanced_search_active(new_state)
    msg = "MENÚ AVANZADO ACTIVADO" if new_state else "BÚSQUEDA DIRECTA (SIMPLE)"
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _advanced_search_menu():
    # === BÚSQUEDAS BÁSICAS ===
    li = xbmcgui.ListItem(label="[B]— BÚSQUEDAS BÁSICAS —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda Estándar (Por Título)")
    li.setArt({'icon': 'DefaultAddonWebSkin.png'})
    _add_fav_cm(li, "Búsqueda Estándar", "search", "execute_adv_search", {"mode": ""})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode=""), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda de Películas (Modo Cine)")
    li.setArt({'icon': 'DefaultMovies.png'})
    li.setInfo('video', {'plot': "Optimiza la búsqueda para encontrar películas completas en castellano.\nPrueba variantes como 'pelicula completa', 'castellano', etc."})
    _add_fav_cm(li, "Búsqueda de Películas", "search", "execute_adv_search", {"mode": "movie"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="movie"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda de Series (Temporada + Capítulo)")
    li.setArt({'icon': 'DefaultTVShows.png'})
    li.setInfo('video', {'plot': "Introduce el nombre de la serie y el addon te pedirá número de temporada y capítulo.\nConstruye automáticamente la mejor query posible."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="series"), listitem=li, isFolder=True)

    # === FILTROS DE DURACIÓN ===
    li = xbmcgui.ListItem(label="[B]— FILTROS DE DURACIÓN —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda de Vídeos Largos (+20 min)")
    li.setArt({'icon': 'DefaultVideo.png'})
    li.setInfo('video', {'plot': "Filtra los resultados para mostrar solo vídeos de más de 20 minutos.\nIdeal para encontrar episodios completos o películas."})
    _add_fav_cm(li, "Vídeos Largos (+20 min)", "search", "execute_adv_search", {"mode": "long"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="long"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda de Vídeos Cortos (-10 min)")
    li.setArt({'icon': 'DefaultVideo.png'})
    li.setInfo('video', {'plot': "Filtra los resultados para mostrar solo vídeos de menos de 10 minutos.\nIdeal para buscar clips, canciones o sketches."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="short"), listitem=li, isFolder=True)

    # === FILTROS TEMPORALES ===
    li = xbmcgui.ListItem(label="[B]— FILTROS TEMPORALES —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Contenido de Hoy (Últimas 24h)")
    li.setArt({'icon': 'DefaultFolder.png'})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en las últimas 24 horas.\nPerfecto para informativos y programas diarios."})
    _add_fav_cm(li, "Contenido de Hoy (24h)", "search", "execute_adv_search", {"mode": "recent_24h"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_24h"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Contenido de Esta Semana")
    li.setArt({'icon': 'DefaultFolder.png'})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en los últimos 7 días."})
    _add_fav_cm(li, "Contenido de esta Semana", "search", "execute_adv_search", {"mode": "recent_week"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_week"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Contenido de Este Mes")
    li.setArt({'icon': 'DefaultFolder.png'})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en los últimos 30 días."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_month"), listitem=li, isFolder=True)

    # === FILTROS DE CALIDAD E IDIOMA ===
    li = xbmcgui.ListItem(label="[B]— CALIDAD E IDIOMA —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Solo HD (Alta Definición)")
    li.setArt({'icon': 'DefaultVideo.png'})
    li.setInfo('video', {'plot': "Filtra para mostrar únicamente vídeos en HD (720p o superior)."})
    _add_fav_cm(li, "Solo HD", "search", "execute_adv_search", {"mode": "hd"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="hd"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Solo Contenido en Español")
    li.setArt({'icon': 'DefaultFolder.png'})
    li.setInfo('video', {'plot': "Filtra para mostrar solo vídeos con idioma español configurado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="spanish"), listitem=li, isFolder=True)

    # === FILTROS AVANZADOS ===
    li = xbmcgui.ListItem(label="[B]— FILTROS AVANZADOS —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda por Usuario / Canal")
    li.setArt({'icon': 'DefaultFolder.png'})
    li.setInfo('video', {'plot': "Busca contenido subido ÚNICAMENTE por un usuario específico (ej: 'rtve', 'atresplayer').\n\nPuedes filtrar por texto dentro del canal."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="user"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda Inversa (Excluir palabras)")
    li.setArt({'icon': 'DefaultIconError.png'})
    li.setInfo('video', {'plot': "Busca X pero EXCLUYENDO resultados que contengan ciertas palabras.\nÚtil para evitar 'trailer', 'making of', 'clip', etc."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="exclude"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda Exacta (Sin limpieza)")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Busca EXACTAMENTE lo que escribas, sin intentar limpiar el título ni quitar paréntesis."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="exact"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda por Palabras Clave")
    li.setArt({'icon': 'DefaultAddonWebSkin.png'})
    li.setInfo('video', {'plot': "Extrae solo las palabras importantes (más de 3 letras) y busca por ellas. Útil si el título oficial es muy largo o complejo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="keywords"), listitem=li, isFolder=True)

    # === UTILIDADES ===
    li = xbmcgui.ListItem(label="[B]— UTILIDADES —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Repetir Última Búsqueda (con filtros)")
    li.setArt({'icon': 'DefaultAddonRepository.png'})
    li.setInfo('video', {'plot': "Toma la última búsqueda de tu historial y te permite ejecutarla con cualquiera de los filtros anteriores."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="repeat_last"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Búsqueda Múltiple (varios términos)")
    li.setArt({'icon': 'DefaultAddonWebSkin.png'})
    li.setInfo('video', {'plot': "Busca varios términos separados por comas en Dailymotion.\nEjemplo: 'saber y ganar, pasapalabra, el hormiguero'"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="multi_search"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _execute_adv_search(mode):
    ep = None
    exclude_words = None
    q = ""

    if mode == "user":
        kb = xbmc.Keyboard('', 'Introduce el ID de Usuario/Canal')
        kb.doModal()
        if not kb.isConfirmed(): return
        user = kb.getText()
        if not user: return
        ep = {"owner": user}

        kb = xbmc.Keyboard('', 'Buscar en canal de {0} (Opcional, vacío = últimos vídeos)'.format(user))
        kb.doModal()
        if kb.isConfirmed():
            q = kb.getText()
        if q: _sh.add(q)
        _lfd(q if q else " ", "", mode=mode, extra_params=ep, nh=True)
        return

    if mode == "series":
        kb = xbmc.Keyboard('', 'Nombre de la Serie')
        kb.doModal()
        if not kb.isConfirmed(): return
        series_name = kb.getText()
        if not series_name: return

        kb = xbmc.Keyboard('', 'Número de Temporada (vacío = cualquiera)')
        kb.doModal()
        if not kb.isConfirmed(): return
        season = kb.getText()

        kb = xbmc.Keyboard('', 'Número de Capítulo (vacío = cualquiera)')
        kb.doModal()
        if not kb.isConfirmed(): return
        episode = kb.getText()

        q = series_name
        if season:
            q += " T{0}".format(season)
        if episode:
            q += " Capitulo {0}".format(episode)

        _sh.add(q)
        _lfd(q, "", mode="", extra_params=None, nh=True)
        return

    if mode == "exclude":
        kb = xbmc.Keyboard('', '¿Qué quieres buscar?')
        kb.doModal()
        if not kb.isConfirmed(): return
        q = kb.getText()
        if not q: return

        kb = xbmc.Keyboard('trailer, clip, making of', 'Palabras a EXCLUIR (separadas por coma)')
        kb.doModal()
        if not kb.isConfirmed(): return
        exclude_text = kb.getText()
        if exclude_text:
            exclude_words = [w.strip().lower() for w in exclude_text.split(",") if w.strip()]

        _sh.add(q)
        _lfd_with_exclusions(q, "", exclude_words)
        return

    if mode == "repeat_last":
        h = _sh.load()
        if not h:
            xbmcgui.Dialog().notification("EspaTV", "No hay historial", xbmcgui.NOTIFICATION_WARNING)
            return

        filters = [
            ("Sin filtros (Estándar)", "", None),
            ("Modo Cine (Películas)", "movie", None),
            ("Solo +20 min", "", {"longer_than": 20}),
            ("Solo -10 min", "", {"shorter_than": 10}),
            ("Solo HD", "", {"hd": 1}),
            ("Solo Español", "", {"language": "es"}),
            ("Últimas 24h", "", {"created_after": int(time.time()) - 86400}),
            ("Última Semana", "", {"created_after": int(time.time()) - 604800}),
        ]

        opts = [f[0] for f in filters]
        sel = xbmcgui.Dialog().select("Repetir: '{0}' con filtro...".format(h[0]), opts)
        if sel < 0: return

        chosen_mode, chosen_ep = filters[sel][1], filters[sel][2]
        _lfd(h[0], "", mode=chosen_mode, extra_params=chosen_ep, nh=True)
        return

    kb = xbmc.Keyboard('', 'Búsqueda Avanzada')
    kb.doModal()
    if not kb.isConfirmed(): return
    q = kb.getText()
    if not q: return

    _sh.add(q)

    if mode == "long":
        ep = {"longer_than": 20}
    elif mode == "short":
        ep = {"shorter_than": 10}
    elif mode == "recent_24h":
        ep = {"created_after": int(time.time()) - 86400, "sort": "recent"}
    elif mode == "recent_week":
        ep = {"created_after": int(time.time()) - 604800, "sort": "recent"}
    elif mode == "recent_month":
        ep = {"created_after": int(time.time()) - 2592000, "sort": "recent"}
    elif mode == "hd":
        ep = {"hd": 1}
    elif mode == "spanish":
        ep = {"language": "es"}

    ep = {} if ep is None else ep
    _lfd(q, "", mode=mode, extra_params=ep, nh=True)

def _lfd_with_exclusions(q, ot, exclude_words):
    cq = _clean_title(q)
    rs = _sr(cq)
    if not rs and cq != q: rs = _sr(q)
    
    if not rs:
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron resultados", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    # Filtrar resultados que contienen palabras excluidas
    if exclude_words:
        filtered = []
        for r in rs:
            title_lower = r.get("title", "").lower()
            if not any(ex in title_lower for ex in exclude_words):
                filtered.append(r)
        rs = filtered
    
    if not rs:
        xbmcgui.Dialog().notification("EspaTV", "Todos los resultados fueron excluidos", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    sr = _gsr(cq, rs, "")[:25]
    
    if not sr:
        xbmcgui.Dialog().notification("EspaTV", "Sin coincidencias relevantes", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    min_dur = core_settings.get_min_duration() * 60
    for sc, v in sr:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        
        if min_dur > 0 and du < min_dur: continue
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ot
        
        lb = f"{vt} ({int(sc*100)}% match)"

        li = xbmcgui.ListItem(label=lb); li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Subido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        cm = []
        cm.append(("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"))
        cm.append(("Abrir en navegador", f"RunPlugin({_u(action='dm_open_browser', url=vi)})"))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vi)))))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))





_TDT_JSON_URL = "https://www.tdtchannels.com/lists/tv.json"
_TDT_M3U_URL = "https://www.tdtchannels.com/lists/tv.m3u8"
_CUSTOM_IPTV_FILE = "custom_iptv.json"
_tdt_json_cache = {"data": None}

def _load_custom_iptv():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    fp = os.path.join(p, _CUSTOM_IPTV_FILE)
    if not os.path.exists(fp):
        return []
    try:
        with open(fp, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def _save_custom_iptv(lists):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    fp = os.path.join(p, _CUSTOM_IPTV_FILE)
    try:
        with open(fp, 'w', encoding='utf-8') as f:
            json.dump(lists, f, ensure_ascii=False)
    except OSError:
        pass

def _parse_m3u_content(text):
    lines = text.splitlines()
    channels = []
    cur_name, cur_logo, cur_group = "", "", ""
    cur_ua, cur_ref = "", ""
    cur_tvg_id = ""
    for line in lines:
        line = line.strip()
        if line.startswith("#EXTINF:"):
            cur_name = line.split(",", 1)[-1].strip() if "," in line else "Canal"
            m = re.search(r'tvg-logo="([^"]*)"', line)
            cur_logo = m.group(1) if m else ""
            m_id = re.search(r'tvg-id="([^"]*)"', line)
            cur_tvg_id = m_id.group(1) if m_id else ""
            m2 = re.search(r'group-title="([^"]*)"', line)
            cur_group = m2.group(1) if m2 else ""
        elif line.upper().startswith("#EXTVLCOPT:HTTP-USER-AGENT="):
            cur_ua = line.split("=", 1)[1].strip()
        elif line.upper().startswith("#EXTVLCOPT:HTTP-REFERRER="):
            cur_ref = line.split("=", 1)[1].strip()
        elif line.upper().startswith("#EXTVLCOPT:HTTP-REFERER="):
            cur_ref = line.split("=", 1)[1].strip()
        elif line and not line.startswith("#"):
            entry = {"name": cur_name or "Canal", "url": line, "logo": cur_logo, "group": cur_group}
            if cur_tvg_id: entry["tvg_id"] = cur_tvg_id
            if cur_ua: entry["ua"] = cur_ua
            if cur_ref: entry["ref"] = cur_ref
            channels.append(entry)
            cur_name, cur_logo, cur_group = "", "", ""
            cur_ua, cur_ref = "", ""
            cur_tvg_id = ""
    return channels

def _render_m3u_channels(channels):
    h = int(sys.argv[1])
    xbmcplugin.setContent(h, 'videos')
    epg = _epg.fetch() if any(ch.get("tvg_id") for ch in channels) else {}
    for ch in channels:
        label = ch["name"]
        tvg_id = ch.get("tvg_id", "")
        epg_info = epg.get(tvg_id) if tvg_id else None
        if epg_info and epg_info.get("title"):
            epg_label = epg_info["title"]
            t1 = _epg.format_time(epg_info.get("start", ""))
            t2 = _epg.format_time(epg_info.get("stop", ""))
            time_str = "  ({0}-{1})".format(t1, t2) if t1 and t2 else ""
            label += "  [COLOR skyblue]Ahora: {0}{1}[/COLOR]".format(epg_label, time_str)
        if ch["group"]:
            label = "[COLOR gray][{0}][/COLOR] {1}".format(ch["group"], label)
        li = xbmcgui.ListItem(label=label)
        thumb = ch["logo"] or "DefaultAddonPVRClient.png"
        li.setArt({'icon': thumb, 'thumb': thumb})
        plot = "Canal: {0}".format(ch["name"])
        if epg_info and epg_info.get("title"):
            plot += "\n\nAhora: {0}".format(epg_info["title"])
            if epg_info.get("desc"): plot += "\n{0}".format(epg_info["desc"])
        if ch["group"]: plot += "\nGrupo: {0}".format(ch["group"])
        li.setInfo('video', {'title': ch["name"], 'plot': plot})
        li.setProperty("IsPlayable", "true")
        cm = [
            ("Añadir a Favoritos", "RunPlugin({0})".format(
                _u(action="add_favorite", title=ch["name"], fav_url=ch["url"], icon=thumb, platform="tdt", fav_action="play_tdt", params=json.dumps({}))
            )),
            ("[COLOR red]Grabar este canal[/COLOR]", "RunPlugin({0})".format(
                _u(action="record_stream", url=ch["url"], name=ch["name"])
            ))
        ]
        li.addContextMenuItems(cm)
        play_args = {"action": "play_tdt", "url": ch["url"], "title": ch["name"]}
        if ch.get("ua"): play_args["ua"] = ch["ua"]
        if ch.get("ref"): play_args["ref"] = ch["ref"]
        xbmcplugin.addDirectoryItem(handle=h, url=_u(**play_args), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.is_iptv_cache_active())

def _open_atresdaily():
    try:
        xbmcaddon.Addon("plugin.video.atresdaily")
        xbmc.executebuiltin("RunAddon(plugin.video.atresdaily)")
        return
    except RuntimeError:
        pass
    choice = xbmcgui.Dialog().yesno("EspaTV",
        "AtresDaily no está instalado.\n\n"
        "Es un addon especializado centrado en Atresplayer.\n"
        "Disponible en:\nhttps://github.com/fullstackcurso\n\n"
        "¿Ver instrucciones de instalación?")
    if choice:
        xbmcgui.Dialog().textviewer("Instalar AtresDaily",
            "[B]Cómo instalar AtresDaily[/B]\n\n"
            "1. Descarga el ZIP desde:\n"
            "   [B]https://github.com/fullstackcurso[/B]\n\n"
            "2. En Kodi, ve a:\n"
            "   [B]Addons → Instalar desde ZIP[/B]\n\n"
            "3. Selecciona el archivo ZIP descargado\n\n"
            "4. Vuelve al Catálogo de EspaTV y pulsa AtresDaily")

def _search_acestream_prompt():
    kb = xbmc.Keyboard('', 'Buscar en AceStream')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    query = kb.getText().strip()
    _search_acestream_results(query)


def _search_acestream_results(query):
    h = int(sys.argv[1])
    if not query:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    encoded_q = urllib.parse.quote_plus(query)
    api_urls = [
        ("motor local", "http://127.0.0.1:6878/server/api?method=search&query={0}&page=0".format(encoded_q)),
        ("servidor publico", "https://search.acestream.net/?method=search&api_key=test_api_key&api_version=1&query={0}&page=0".format(encoded_q)),
    ]

    progress = xbmcgui.DialogProgressBG()
    try:
        progress.create("AceStream", "Buscando: {0}".format(query))
    except RuntimeError:
        progress = None

    data = None
    last_error = None
    used_endpoint = ""

    from urllib.request import urlopen as _urlopen, Request as _Request
    for label, api_url in api_urls:
        try:
            xbmc.log("[espatv] AceStream search via {0}: {1}".format(label, api_url), xbmc.LOGINFO)
            req = _Request(api_url, headers={"User-Agent": "Mozilla/5.0 (Kodi)"})
            resp = _urlopen(req, timeout=10)
            raw = resp.read().decode("utf-8", errors="replace")
            xbmc.log("[espatv] AceStream {0} response ({1} chars): {2}".format(label, len(raw), raw[:300]), xbmc.LOGINFO)
            try:
                parsed = json.loads(raw)
            except Exception as je:
                last_error = "Respuesta no es JSON ({0}): {1}".format(label, str(je))
                continue
            if isinstance(parsed, dict) and parsed.get("error"):
                last_error = "{0}: {1}".format(label, parsed.get("error"))
                continue
            data = parsed
            used_endpoint = label
            break
        except Exception as e:
            last_error = "{0}: {1}".format(label, str(e))
            xbmc.log("[espatv] AceStream {0} failed: {1}".format(label, e), xbmc.LOGWARNING)
            continue

    if progress:
        try:
            progress.close()
        except RuntimeError:
            pass

    if data is None:
        xbmcgui.Dialog().ok("Buscar en AceStream",
            "No se pudo realizar la busqueda.\n\n"
            "Detalle: {0}".format(last_error or "error desconocido"))
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    results = []
    if isinstance(data, list):
        results = data
    elif isinstance(data, dict):
        result_obj = data.get("result") or {}
        results = result_obj.get("results") or data.get("results") or []
    if not isinstance(results, list):
        results = []

    xbmc.log("[espatv] AceStream search returned {0} results from {1}".format(len(results), used_endpoint), xbmc.LOGINFO)

    if not results:
        xbmcgui.Dialog().ok("AceStream", "Sin resultados para: {0}".format(query))
        xbmcplugin.endOfDirectory(h, succeeded=True)
        return

    xbmcplugin.setPluginCategory(h, "AceStream: {0}".format(query))
    xbmcplugin.setContent(h, "videos")

    for item in results:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or item.get("title") or "Sin nombre")
        infohash = str(item.get("infohash") or item.get("id") or "").strip()
        if not infohash:
            continue

        categories = item.get("categories") or []
        if not isinstance(categories, list):
            categories = [categories] if categories else []
        categories = [str(c) for c in categories if c]

        availability = item.get("availability") or 0
        try:
            availability = float(availability)
            if availability > 1:
                availability = availability / 100.0
        except (TypeError, ValueError):
            availability = 0

        plot_lines = []
        if categories:
            plot_lines.append("Categoria: {0}".format(", ".join(categories)))
        desc = str(item.get("description") or "").strip()
        if desc:
            plot_lines.append(desc)
        if availability > 0:
            plot_lines.append("Disponibilidad: {0:.0f}%".format(availability * 100))
        plot = "\n".join(plot_lines) if plot_lines else name

        li = xbmcgui.ListItem(label=name)
        li.setInfo("video", {"title": name, "plot": plot})
        li.setArt({"icon": "DefaultAddonTvInfo.png"})
        li.setProperty("IsPlayable", "true")
        _add_fav_cm(li, name, "acestream", "play_ace_result", {"infohash": infohash, "name": name})
        play_url = _u(action="play_ace_result", infohash=infohash, name=name)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _play_ace_result(infohash, name):
    xbmc.log("[espatv] _play_ace_result called: infohash={0} name={1}".format(infohash, name), xbmc.LOGINFO)
    if not infohash:
        xbmc.log("[espatv] _play_ace_result aborted: empty infohash", xbmc.LOGWARNING)
        return
    try:
        _wh.add("acestream://" + infohash, name or infohash[:12])
    except Exception as e:
        xbmc.log("[espatv] _play_ace_result: _wh.add failed: {0}".format(e), xbmc.LOGERROR)
    import url_player
    url_player.play_url_action("acestream://" + infohash)


def live_tv_menu():
    h = int(sys.argv[1])

    li = xbmcgui.ListItem(label="[B][COLOR white]TV Autonómicas en Directo[/COLOR][/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Señal en directo de las principales televisiones autonómicas españolas.\nTV3, ETB, TVG, Canal Sur, Aragón TV, À Punt, TPA, TV Canaria, IB3 y más."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tv_autonomicas_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]TDT Channels España[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Lista completa de canales TDT españoles.\nIncluye nacionales, autonómicos, temáticos y más."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tdt_channels_json"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]TDT Channels España (M3U)[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Lista M3U alternativa."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tdt_channels"), listitem=li, isFolder=True)


    li = xbmcgui.ListItem(label="[B][COLOR skyblue]Radio en Directo[/COLOR][/B]")
    li.setArt({'icon': 'DefaultMusicSongs.png'})
    li.setInfo('video', {'plot': "Emisoras de radio españolas en directo.\nPopulares, musicales, deportivas, autonómicas y más."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="radio_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B][COLOR red]RTVE Play[/COLOR][/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales de RTVE en directo (La 1, La 2, 24h, Teledeporte, Clan).\nCatálogo de programas, series y documentales de RTVE Play."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="rtve_menu"), listitem=li, isFolder=True)
    
    # Mostrar carpeta de grabaciones si existen archivos
    rec_path = xbmcaddon.Addon().getSetting("record_path")
    if rec_path and xbmcvfs.exists(rec_path):
        try:
            dirs, files = xbmcvfs.listdir(rec_path)
            if any(f.endswith('.ts') or f.endswith('.mp4') for f in files):
                li = xbmcgui.ListItem(label="[B][COLOR gold]Mis Grabaciones[/COLOR][/B]")
                li.setArt({'icon': 'DefaultVideo.png'})
                li.setInfo('video', {'plot': "Archivo de grabaciones de TV en directo.\nProgramas descargados localmente."})
                xbmcplugin.addDirectoryItem(handle=h, url=_u(action="my_recordings_menu"), listitem=li, isFolder=True)
        except (OSError, RuntimeError):
            pass

    # --- Listas IPTV gratuitas y legales ---
    li = xbmcgui.ListItem(label="[B]España — IPTV Abierta[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Directorio comunitario con 300+ canales españoles verificados.\nIncluye nacionales, autonómicos, temáticos, deportes, música y más."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://iptv-org.github.io/iptv/countries/es.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Cine y Películas FAST[/B]")
    li.setArt({'icon': 'DefaultMovies.png'})
    li.setInfo('video', {'plot': "Canales FAST gratuitos de cine y películas.\nIncluye Rakuten TV, Pluto TV, Atrescine, Cine Western y más.\nContenido con publicidad."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://iptv-org.github.io/iptv/categories/movies.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Canales Internacionales en Español[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales internacionales disponibles en España.\nFrance 24, DW, euronews, RT y más en español."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://iptv-org.github.io/iptv/languages/spa.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Free-TV IPTV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Lista IPTV gratuita con canales de todo el mundo.\nIncluye canales en abierto verificados."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="freetv_menu"), listitem=li, isFolder=True)

    # --- Pluto TV y Samsung TV Plus (SlyGuy) ---
    li = xbmcgui.ListItem(label="[B]Pluto TV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "TV gratuita con canales temáticos (cine, series, noticias...).\nRequiere addon SlyGuy (se instala automáticamente)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="slyguy_install", addon_id="slyguy.pluto.tv.provider", title="Pluto TV"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]Samsung TV Plus[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales de TV gratuitos de Samsung.\nRequiere addon SlyGuy (se instala automáticamente)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="slyguy_install", addon_id="slyguy.samsung.tv.plus", title="Samsung TV Plus"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]Roku Channel[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales de TV gratuitos de Roku.\nPelículas, series y TV en vivo sin suscripción.\nRequiere addon SlyGuy (se instala automáticamente)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="slyguy_install", addon_id="slyguy.roku", title="Roku Channel"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]Plex Live TV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Decenas de canales lineales gratuitos de cine, noticias y entretenimiento.\nRequiere el módulo de SlyGuy (se instala automáticamente)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="slyguy_install", addon_id="slyguy.plex.live", title="Plex Live TV"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]Rakuten TV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Más de 90 canales gratuitos con películas, series y documentales (FAST)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://raw.githubusercontent.com/iptv-org/iptv/master/streams/es_rakuten.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B][COLOR lightcyan]Programación TV (EPG en texto)[/COLOR][/B]")
    _mp_epg = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'cat_epg_texto.png')
    li.setArt({'icon': _mp_epg if os.path.isfile(_mp_epg) else 'DefaultIconInfo.png'})
    li.setInfo('video', {'plot': "Parrilla de programación de los canales TDT en formato texto."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="epg_texto_menu"), listitem=li, isFolder=True)

    import pvr_manager
    if pvr_manager.is_pvr_installed():
        li_p = xbmcgui.ListItem(label="[B]Abrir Guía de Televisión Nativa (PVR)[/B]")
        li_p.setArt({'icon': 'DefaultAddonPVRClient.png'})
        li_p.setInfo('video', {'plot': "Salta instantáneamente a la sección 'TV' de Kodi para ver la parrilla de horarios interactiva de TDT."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="open_pvr"), listitem=li_p, isFolder=False)

    # --- Listas IPTV ---
    custom_lists = _load_custom_iptv()
    for lst in custom_lists:
        name = lst.get("name", "Lista")
        url = lst.get("url", "")
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(name))
        li.setArt({'icon': 'DefaultAddonPVRClient.png'})
        li.setInfo('video', {'plot': "Lista personalizada\nURL: {0}".format(url)})
        cm = [("Eliminar esta lista", "RunPlugin({0})".format(_u(action="delete_custom_iptv", url=url)))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url=url), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Añadir IPTV M3U[/B]")
    li.setArt({'icon': 'DefaultAddSource.png'})
    li.setInfo('video', {'plot': "Pega la URL de una nueva fuente de canales (M3U/M3U8) para añadirla."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="add_custom_iptv"), listitem=li, isFolder=False)
    
    xbmcplugin.endOfDirectory(h)

def tdt_channels_json():
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Canales TDT", "Descargando lista actualizada...")
    try:
        dp.update(30, "Conectando...")
        content = _cached_http_get(_TDT_JSON_URL, timeout=15)
        dp.update(70, "Procesando canales...")
        data = json.loads(content)
        dp.close()
        countries = data.get("countries", [])
        if not countries:
            xbmcgui.Dialog().ok("TDT Channels", "No se encontraron datos.")
            xbmcplugin.endOfDirectory(h); return
        _tdt_json_cache["data"] = countries[0].get("ambits", [])
        
        # Boton PVR rapido
        import pvr_manager
        if pvr_manager.is_pvr_installed():
            li_pvr = xbmcgui.ListItem(label="Abrir la Parrilla Completa (PVR)")
            li_pvr.setArt({'icon': 'DefaultAddonPVRClient.png'})
            li_pvr.setInfo('video', {'plot': "Salta automáticamente a la cuadrícula de televisión de Kodi."})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="open_pvr"), listitem=li_pvr, isFolder=False)
        else:
            li_pvr = xbmcgui.ListItem(label="Ver en Parrilla Nativa Completa (PVR)")
            li_pvr.setArt({'icon': 'DefaultAddonPVRClient.png'})
            li_pvr.setInfo('video', {'plot': "Auto-configura Kodi para mostrar estos canales en una cuadrícula horaria visual."})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="setup_pvr"), listitem=li_pvr, isFolder=False)

        for ambit in _tdt_json_cache["data"]:
            name = ambit.get("name", "Sin nombre")
            num = len(ambit.get("channels", []))
            li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(name, num))
            li.setArt({'icon': 'DefaultAddonPVRClient.png'})
            li.setInfo('video', {'plot': "Categoría: {0}\nCanales: {1}".format(name, num)})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tdt_json_ambit", url=name), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
    except (requests.RequestException, ValueError, RuntimeError, KeyError) as e:
        dp.close()
        _log_error("Error TDT JSON: {0}".format(e))
        xbmcgui.Dialog().ok("TDT Channels", "No se pudo cargar:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h)
        except RuntimeError:
            pass

def tdt_json_ambit(ambit_name):
    h = int(sys.argv[1])
    ambits = _tdt_json_cache.get("data")
    if not ambits:
        try:
            content = _cached_http_get(_TDT_JSON_URL, timeout=15)
            data = json.loads(content)
            countries = data.get("countries", [])
            if countries:
                ambits = countries[0].get("ambits", [])
                _tdt_json_cache["data"] = ambits
        except (requests.RequestException, ValueError, RuntimeError):
            xbmcgui.Dialog().ok("TDT Channels", "No se pudo cargar la lista.")
            xbmcplugin.endOfDirectory(h); return
    if not ambits:
        xbmcplugin.endOfDirectory(h); return
    target = None
    for a in ambits:
        if a.get("name") == ambit_name:
            target = a; break
    if not target:
        xbmcplugin.endOfDirectory(h); return
    channels = []
    for ch in target.get("channels", []):
        name = ch.get("name", "Canal")
        opts = ch.get("options", [])
        logo = ch.get("logo", "")
        for opt in opts:
            fmt = opt.get("format", "")
            url = opt.get("url", "")
            if url and fmt.lower() in ("m3u8", "mp4", ""):
                channels.append({"name": name, "url": url, "logo": logo, "group": ambit_name})
                break
    if channels:
        _render_m3u_channels(channels)
    else:
        xbmcgui.Dialog().ok("TDT Channels", "No se encontraron streams para {0}.".format(ambit_name))
        xbmcplugin.endOfDirectory(h)

def tdt_channels():
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Canales TDT", "Descargando lista M3U...")
    try:
        dp.update(30, "Conectando...")
        content = _cached_http_get(_TDT_M3U_URL, timeout=15)
        dp.update(70, "Procesando canales...")
        channels = _parse_m3u_content(content)
        dp.close()
        if not channels:
            xbmcgui.Dialog().ok("TDT Channels", "No se encontraron canales.")
            xbmcplugin.endOfDirectory(h); return
        _render_m3u_channels(channels)
    except (requests.RequestException, RuntimeError, OSError) as e:
        dp.close()
        _log_error("Error TDT M3U: {0}".format(e))
        xbmcgui.Dialog().ok("TDT Channels", "No se pudo cargar:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h)
        except RuntimeError:
            pass

def play_tdt(url, title="", ua="", ref=""):
    h = int(sys.argv[1])
    try:
        play_url = url
        is_m3u8 = '.m3u8' in url.lower()

        # Comprobar si el usuario quiere usar InputStream Adaptive
        use_ia = False
        if is_m3u8:
            import xbmcaddon
            if xbmcaddon.Addon().getSetting('use_inputstream') == 'true':
                # Verificar que el addon esta realmente instalado
                try:
                    xbmcaddon.Addon('inputstream.adaptive')
                    use_ia = True
                except RuntimeError:
                    xbmc.log("[EspaTV] InputStream Adaptive activado en ajustes pero no instalado. Usando reproductor normal.", xbmc.LOGWARNING)

        # Modo Anti-Errores: inyectar UA de navegador si no hay uno propio
        import xbmcaddon as _xa
        anti_err = _xa.Addon().getSetting('iptv_anti_errors') == 'true'
        if anti_err and not ua:
            ua = UA_DESKTOP

        # Construir URL con headers en formato pipe si no se usa InputStream Adaptive
        # InputStream Adaptive NO soporta el formato pipe (|User-Agent=...)
        if (ua or ref) and not use_ia:
            parts = []
            if ua: parts.append("User-Agent={0}".format(requests.utils.quote(ua)))
            if ref: parts.append("Referer={0}".format(requests.utils.quote(ref)))
            play_url = "{0}|{1}".format(url, "&".join(parts))

        li = xbmcgui.ListItem(path=play_url)
        if title: li.setInfo('video', {'title': title})
        
        if is_m3u8:
            li.setMimeType('application/x-mpegURL')

        if use_ia:
            xbmc.log("[EspaTV] Reproduciendo {0} con InputStream Adaptive".format(title), xbmc.LOGINFO)
            # Kodi 19+ / Kodi 18
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstreamaddon', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            
            # Pasar headers a InputStream Adaptive por su via nativa
            hdr_parts = []
            if ua:
                hdr_parts.append("User-Agent={0}".format(ua))
            if ref: 
                hdr_parts.append("Referer={0}".format(ref))
            if hdr_parts:
                li.setProperty('inputstream.adaptive.stream_headers', "&".join(hdr_parts))

        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(h, True, li)
    except (RuntimeError, AttributeError, ValueError) as e:
        _log_error("Error TDT play: {0}".format(e))
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())


def add_custom_iptv():
    kb = xbmc.Keyboard('', 'URL de la lista M3U/M3U8')
    kb.doModal()
    if not kb.isConfirmed(): return
    url = kb.getText().strip()
    if not url: return
    if not url.startswith(('http://', 'https://')):
        xbmcgui.Dialog().ok("EspaTV", "La URL debe empezar por http:// o https://"); return
    try:
        r = requests.get(url, timeout=10)
        if r.status_code != 200:
            xbmcgui.Dialog().ok("EspaTV", "No se pudo acceder a la URL.\nError HTTP {0}".format(r.status_code)); return
        channels = _parse_m3u_content(r.text)
        if not channels:
            xbmcgui.Dialog().ok("EspaTV", "La URL no contiene canales válidos en formato M3U."); return
    except (requests.RequestException, ValueError) as e:
        xbmcgui.Dialog().ok("EspaTV", "Error al verificar la URL:\n{0}".format(e)); return
    kb2 = xbmc.Keyboard('', 'Nombre para la lista ({0} canales encontrados)'.format(len(channels)))
    kb2.doModal()
    if not kb2.isConfirmed() or not kb2.getText().strip(): return
    name = kb2.getText().strip()
    lists = _load_custom_iptv()
    if any(l.get("url") == url for l in lists):
        xbmcgui.Dialog().notification("EspaTV", "Esta lista ya está añadida", xbmcgui.NOTIFICATION_WARNING); return
    lists.append({"name": name, "url": url})
    _save_custom_iptv(lists)
    xbmcgui.Dialog().notification("EspaTV", "Lista '{0}' añadida".format(name), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def view_custom_iptv(url):
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Lista IPTV", "Cargando canales...")
    try:
        dp.update(30, "Descargando...")
        content = _cached_http_get(url, timeout=15)
        dp.update(70, "Procesando canales...")
        channels = _parse_m3u_content(content)
        dp.close()
        if not channels:
            xbmcgui.Dialog().ok("Lista IPTV", "No se encontraron canales.")
            xbmcplugin.endOfDirectory(h); return
        _render_m3u_channels(channels)
    except (requests.RequestException, RuntimeError, OSError) as e:
        dp.close()
        _log_error("Error lista IPTV: {0}".format(e))
        xbmcgui.Dialog().ok("Lista IPTV", "No se pudo cargar:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h)
        except RuntimeError:
            pass

def freetv_menu():
    h = int(sys.argv[1])
    li = xbmcgui.ListItem(label="[B]Free-TV IPTV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Lista IPTV gratuita con canales de todo el mundo.\nIncluye canales en abierto verificados."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]España[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales españoles."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://raw.githubusercontent.com/iptv-org/iptv/master/streams/es.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]España Regional[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales regionales españoles."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://raw.githubusercontent.com/iptv-org/iptv/master/streams/es_45.95.78.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Pluto TV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales Pluto TV España."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://raw.githubusercontent.com/iptv-org/iptv/master/streams/es_pluto.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Samsung TV Plus[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales Samsung TV Plus España."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://raw.githubusercontent.com/iptv-org/iptv/master/streams/es_samsung.m3u"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)

def delete_custom_iptv(url):
    lists = _load_custom_iptv()
    name = next((l.get("name", "Lista") for l in lists if l.get("url") == url), "Lista")
    if xbmcgui.Dialog().yesno("EspaTV", "¿Eliminar la lista '{0}'?".format(name)):
        new_lists = [l for l in lists if l.get("url") != url]
        _save_custom_iptv(new_lists)
        xbmcgui.Dialog().notification("EspaTV", "Lista eliminada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")


# --- YOUTUBE EN DIRECTO ---
# --- FELICIDAD VERANIEGA (YouTube) ---
from youtube_data import FELICIDAD_VERANIEGA_YT as _FELICIDAD_VERANIEGA_YT
from youtube_data import COCINA_ESPANOLA_YT as _COCINA_ESPANOLA_YT
from youtube_data import ARTE_MUSEOS_YT as _ARTE_MUSEOS_YT
from youtube_data import EDUCACION_DIVULGACION_YT as _EDUCACION_DIVULGACION_YT
import loteria as _loteria_mod
import clasificaciones as _clasif_mod
import dgt as _dgt_mod
import tv_autonomicas as _tvaut_mod
import rtve_catalog as _rtve_mod
import archive_org



def _yt_queue_add(yt_id, name=""):
    if not yt_id:
        return
    if not _check_youtube_addon():
        _youtube_install_prompt()
        return
    url = "plugin://plugin.video.youtube/play/?video_id={0}".format(yt_id)
    li = xbmcgui.ListItem(name or yt_id)
    li.setArt({"thumb": "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)})
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    if not xbmc.Player().isPlaying():
        playlist.clear()
        playlist.add(url, li)
        xbmc.Player().play(playlist)
        xbmcgui.Dialog().notification(
            "EspaTV", "Reproduciendo — pulsa Atrás para añadir más",
            xbmcgui.NOTIFICATION_INFO, 3000,
        )
    else:
        playlist.add(url, li)
        xbmcgui.Dialog().notification(
            "EspaTV",
            "Añadido a la cola ({0} vídeos)".format(playlist.size()),
            xbmcgui.NOTIFICATION_INFO, 2000,
        )

def _felicidad_menu():
    h = int(sys.argv[1])
    if not _check_youtube_addon():
        li = xbmcgui.ListItem(label="[COLOR red][B]Instalar addon YouTube (necesario)[/B][/COLOR]")
        li.setArt({'icon': 'DefaultAddonHelper.png'})
        li.setInfo('video', {'plot': "El addon YouTube de Kodi es necesario para ver este contenido.\nPulsa aqui para ver las instrucciones."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="youtube_install"), listitem=li, isFolder=False)
    for cat_name, channels in _FELICIDAD_VERANIEGA_YT.items():
        li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(cat_name, len(channels)))
        li.setArt({'icon': 'DefaultMusicVideos.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_list", cat=cat_name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)

def _felicidad_list(cat_name):
    h = int(sys.argv[1])
    channels = _FELICIDAD_VERANIEGA_YT.get(cat_name, [])
    if not channels:
        xbmcplugin.endOfDirectory(h); return
    watched = _ywt.load()
    for ch in channels:
        name = ch.get("name", "Canal")
        ctype = ch.get("type", "channel")
        desc = ch.get("desc", "")
        yt_id = ch.get("yt_id", "")
        burl = ch.get("url", "")
        is_watched = ctype == "video" and yt_id in watched
        if ctype == "browser":
            label = "[COLOR orange]{0}[/COLOR]".format(name)
            plot = "{0}\nSe abre en el navegador.".format(desc)
        elif ctype == "video":
            if is_watched:
                label = "[COLOR gray](Visto) {0}[/COLOR]".format(name)
            else:
                label = "[COLOR lime]{0}[/COLOR]".format(name)
            plot = "{0}\nVideo individual.".format(desc)
        elif ctype == "playlist":
            label = "[COLOR skyblue]{0}[/COLOR]".format(name)
            plot = "{0}\nPlaylist de YouTube.".format(desc)
        else:
            label = "[B]{0}[/B]".format(name)
            plot = "{0}\nCanal de YouTube.".format(desc)
        li = xbmcgui.ListItem(label=label)
        art = {'icon': 'DefaultMusicVideos.png'}
        if ctype == "video" and yt_id:
            thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
            art['thumb'] = thumb
            art['icon'] = thumb
        li.setArt(art)
        li.setInfo('video', {'title': name, 'plot': plot})
        fav_params = json.dumps({"yt_id": yt_id, "name": name, "ctype": ctype, "burl": burl})
        cm = []
        if ctype == "video" and yt_id:
            if is_watched:
                cm.append(("Desmarcar como visto", "RunPlugin({0})".format(
                    _u(action='yt_toggle_watched', yt_id=yt_id))))
            else:
                cm.append(("Marcar como visto", "RunPlugin({0})".format(
                    _u(action='yt_toggle_watched', yt_id=yt_id))))
            cm.append(("Añadir a cola de reproducción", "RunPlugin({0})".format(
                _u(action='yt_queue_add', yt_id=yt_id, name=name))))
        cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(
            _u(action='add_favorite', title=name, fav_url='yt_{0}'.format(yt_id),
               icon='DefaultMusicVideos.png', platform='youtube',
               fav_action='felicidad_play', params=fav_params))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_play", yt_id=yt_id, name=name, ctype=ctype, burl=burl), listitem=li, isFolder=(ctype == "video"))
    xbmcplugin.endOfDirectory(h)

def _felicidad_open_browser(url, name=""):
    url = url.replace('"', '').replace("'", '') if url else ""
    try:
        if xbmc.getCondVisibility("System.Platform.Android"):
            xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","text/html","{0}")'.format(url))
        else:
            import webbrowser
            webbrowser.open(url)
        xbmcgui.Dialog().notification("EspaTV", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
    except (ImportError, OSError):
        xbmcgui.Dialog().ok("Abrir en navegador", "No se pudo abrir automaticamente.\n\nAbre esta URL:\n{0}".format(url))


def _felicidad_open_yt_app(url, name=""):
    url = url.replace('"', '').replace("'", '') if url else ""
    try:
        xbmc.executebuiltin('StartAndroidActivity("com.google.android.youtube","android.intent.action.VIEW","","{0}")'.format(url))
        xbmcgui.Dialog().notification("EspaTV", "Abriendo app YouTube...", xbmcgui.NOTIFICATION_INFO, 2000)
    except (RuntimeError, OSError):
        xbmcgui.Dialog().ok("App YouTube", "No se pudo abrir la app YouTube.\nAsegurate de que esta instalada.")

# Buscar en YouTube

def _felicidad_play(yt_id="", name="", ctype="channel", burl=""):
    if ctype == "browser":
        if xbmc.getCondVisibility("System.Platform.Android"):
            opts = ["Abrir en la app YouTube", "Abrir en el navegador"]
            sel = xbmcgui.Dialog().select("{0}".format(name or "YouTube"), opts)
            if sel < 0: return
            if sel == 0:
                _felicidad_open_yt_app(burl or "https://www.youtube.com", name)
            else:
                _felicidad_open_browser(burl or "https://www.youtube.com", name)
        else:
            _felicidad_open_browser(burl or "https://www.youtube.com", name)
        return
    if ctype == "video":
        h = int(sys.argv[1])
        yt_thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
        is_android = xbmc.getCondVisibility("System.Platform.Android")
        is_pc = not is_android
        li = xbmcgui.ListItem(label="[COLOR limegreen][B]Reproducir aquí[/B][/COLOR]")
        li.setArt({"icon": "DefaultVideo.png", "thumb": yt_thumb})
        li.setInfo("video", {"plot": "Reproduce con el addon YouTube de Kodi."})
        xbmcplugin.addDirectoryItem(handle=h,
            url=_u(action="felicidad_play_exec", yt_id=yt_id, name=name, method="addon"),
            listitem=li, isFolder=False)
        if is_android:
            li = xbmcgui.ListItem(label="[COLOR lightskyblue]Abrir en la app YouTube[/COLOR]")
            li.setArt({"icon": "DefaultAddonProgram.png", "thumb": yt_thumb})
            li.setInfo("video", {"plot": "Abre en la aplicación YouTube de Android."})
            xbmcplugin.addDirectoryItem(handle=h,
                url=_u(action="felicidad_play_exec", yt_id=yt_id, name=name, method="yt_app"),
                listitem=li, isFolder=False)
        li = xbmcgui.ListItem(label="[COLOR orange]Abrir en el navegador[/COLOR]")
        li.setArt({"icon": "DefaultNetwork.png", "thumb": yt_thumb})
        li.setInfo("video", {"plot": "Abre la página de YouTube en el navegador."})
        xbmcplugin.addDirectoryItem(handle=h,
            url=_u(action="felicidad_play_exec", yt_id=yt_id, name=name, method="browser"),
            listitem=li, isFolder=False)
        if is_pc:
            li = xbmcgui.ListItem(label="[COLOR mediumpurple]Reproducir con yt-dlp[/COLOR]")
            li.setArt({"icon": "DefaultAddonVideo.png", "thumb": yt_thumb})
            li.setInfo("video", {"plot": "Resuelve el vídeo con yt-dlp y lo reproduce."})
            xbmcplugin.addDirectoryItem(handle=h,
                url=_u(action="felicidad_play_exec", yt_id=yt_id, name=name, method="ytdlp"),
                listitem=li, isFolder=False)
            li = xbmcgui.ListItem(label="[COLOR gray]¿YouTube no funciona? Lee esto[/COLOR]")
            li.setArt({"icon": "DefaultIconInfo.png", "thumb": yt_thumb})
            li.setInfo("video", {"plot": (
                "YouTube bloquea peticiones desde IPs residenciales sin sesión activa "
                "(error: 'Sign in to confirm you’re not a bot'). "
                "Afecta tanto al addon de YouTube como a yt-dlp.\n\n"
                "[B]Solución 1 — VPN[/B]\n"
                "Activa una VPN. Funciona con cualquier método de reproducción.\n\n"
                "[B]Solución 2 — Fallback automático con curl_cffi (solo yt-dlp)[/B]\n"
                "Si usas 'Reproducir con yt-dlp', EspaTV reintenta automáticamente "
                "imitando el fingerprint TLS de Chrome si tienes instalado curl_cffi:\n"
                "   pip install curl_cffi\n\n"
                "Con curl_cffi instalado el reintento ocurre solo, sin que tengas que hacer nada."
            )})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h,
                url=_u(action="yt_pc_info"),
                listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    # --- Canales y playlists: mantener diálogo ---
    yt_url_map = {
        "channel": ("plugin://plugin.video.youtube/channel/{0}/", "https://www.youtube.com/channel/{0}"),
        "playlist": ("plugin://plugin.video.youtube/playlist/{0}/", "https://www.youtube.com/playlist?list={0}"),
    }
    addon_tpl, web_tpl = yt_url_map.get(ctype, yt_url_map["channel"])
    is_android = xbmc.getCondVisibility("System.Platform.Android")
    if is_android:
        opts = ["Abrir aquí", "Abrir en la app YouTube", "Abrir en el navegador"]
    else:
        opts = ["Abrir aquí", "Abrir en el navegador"]
    sel = xbmcgui.Dialog().select("{0}".format(name or "YouTube"), opts)
    if sel < 0:
        return
    if sel == 0:
        if not _check_youtube_addon():
            if not _youtube_install_prompt():
                return
        xbmc.executebuiltin("ActivateWindow(Videos,{0})".format(addon_tpl.format(yt_id)))
    elif is_android and sel == 1:
        _felicidad_open_yt_app(web_tpl.format(yt_id), name)
    else:
        _felicidad_open_browser(web_tpl.format(yt_id), name)


def _felicidad_play_exec(yt_id="", name="", method="addon"):
    if not yt_id:
        return
    yt_web = "https://www.youtube.com/watch?v={0}".format(yt_id)
    if method == "addon":
        if not _check_youtube_addon():
            if not _youtube_install_prompt():
                return
        yt_thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
        try:
            _wh.add(yt_id, name or yt_id, thumb=yt_thumb, duration=0)
        except (OSError, ValueError):
            pass
        plugin_url = "plugin://plugin.video.youtube/play/?video_id={0}".format(yt_id)
        xbmc.executebuiltin("PlayMedia({0})".format(plugin_url))
    elif method == "yt_app":
        _felicidad_open_yt_app(yt_web, name)
    elif method == "browser":
        _felicidad_open_browser(yt_web, name)
    elif method == "ytdlp":
        _felicidad_play_ytdlp(yt_id, name)


def _felicidad_play_ytdlp(yt_id, name=""):
    yt_web = "https://www.youtube.com/watch?v={0}".format(yt_id)
    xbmcgui.Dialog().notification(
        "EspaTV", "Resolviendo con yt-dlp...",
        xbmcgui.NOTIFICATION_INFO, 2000,
    )
    stream_url = ytdlp_resolver.resolve(yt_web)
    if stream_url:
        li = xbmcgui.ListItem(path=stream_url)
        li.setProperty("IsPlayable", "true")
        li.setContentLookup(False)
        xbmc.Player().play(stream_url, li)
        yt_thumb = 'https://i.ytimg.com/vi/{0}/hqdefault.jpg'.format(yt_id)
        try:
            _wh.add(yt_id, name or yt_id, thumb=yt_thumb, duration=0)
        except (OSError, ValueError):
            pass
        return
    xbmcgui.Dialog().ok(
        "EspaTV",
        "yt-dlp no pudo resolver el vídeo.\n\n"
        "Asegúrate de tener yt-dlp instalado:\npip install yt-dlp",
    )

# --- COCINA ESPAÑOLA ---
def _cocina_menu():
    h = int(sys.argv[1])
    if not _COCINA_ESPANOLA_YT:
        xbmcgui.Dialog().ok("Cocina Española", "Aún no hay contenido. ¡Próximamente!")
        return
    for cat_name, channels in _COCINA_ESPANOLA_YT.items():
        li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(cat_name, len(channels)))
        li.setArt({'icon': 'DefaultMusicVideos.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cocina_list", cat=cat_name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)

def _cocina_list(cat_name):
    h = int(sys.argv[1])
    channels = _COCINA_ESPANOLA_YT.get(cat_name, [])
    if not channels:
        xbmcplugin.endOfDirectory(h); return
    watched = _ywt.load()
    for ch in channels:
        name = ch.get("name", "Canal")
        ctype = ch.get("type", "channel")
        desc = ch.get("desc", "")
        yt_id = ch.get("yt_id", "")
        burl = ch.get("url", "")
        is_watched = ctype == "video" and yt_id in watched
        if ctype == "browser":
            label = "[COLOR orange]{0}[/COLOR]".format(name)
            plot = "{0}\nSe abre en el navegador.".format(desc)
        elif ctype == "video":
            if is_watched:
                label = "[COLOR gray](Visto) {0}[/COLOR]".format(name)
            else:
                label = "[COLOR lime]{0}[/COLOR]".format(name)
            plot = "{0}\nVideo individual.".format(desc)
        elif ctype == "playlist":
            label = "[COLOR skyblue]{0}[/COLOR]".format(name)
            plot = "{0}\nPlaylist de YouTube.".format(desc)
        else:
            label = "[B]{0}[/B]".format(name)
            plot = "{0}\nCanal de YouTube.".format(desc)
        li = xbmcgui.ListItem(label=label)
        art = {'icon': 'DefaultMusicVideos.png'}
        if ctype == "video" and yt_id:
            thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
            art['thumb'] = thumb
            art['icon'] = thumb
        li.setArt(art)
        li.setInfo('video', {'title': name, 'plot': plot})
        fav_params = json.dumps({"yt_id": yt_id, "name": name, "ctype": ctype, "burl": burl})
        cm = []
        if ctype == "video" and yt_id:
            if is_watched:
                cm.append(("Desmarcar como visto", "RunPlugin({0})".format(
                    _u(action='yt_toggle_watched', yt_id=yt_id))))
            else:
                cm.append(("Marcar como visto", "RunPlugin({0})".format(
                    _u(action='yt_toggle_watched', yt_id=yt_id))))
            cm.append(("Añadir a cola de reproducción", "RunPlugin({0})".format(
                _u(action='yt_queue_add', yt_id=yt_id, name=name))))
        cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(
            _u(action='add_favorite', title=name, fav_url='yt_{0}'.format(yt_id),
               icon='DefaultMusicVideos.png', platform='cocina',
               fav_action='felicidad_play', params=fav_params))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_play", yt_id=yt_id, name=name, ctype=ctype, burl=burl), listitem=li, isFolder=(ctype == "video"))
    xbmcplugin.endOfDirectory(h)

# --- EDUCACIÓN Y DIVULGACIÓN ---
def _educacion_menu():
    h = int(sys.argv[1])
    if not _EDUCACION_DIVULGACION_YT:
        xbmcgui.Dialog().ok("Educación y Divulgación", "Aún no hay contenido. ¡Próximamente!")
        return
    edu_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'cat_educacion.png')
    if not os.path.isfile(edu_icon):
        edu_icon = 'DefaultFolder.png'
    li_wip = xbmcgui.ListItem(label="[COLOR orange][ ℹ  Sección en construcción — los vídeos aún no se abren en Kodi ][/COLOR]")
    li_wip.setArt({'icon': edu_icon})
    li_wip.setInfo('video', {'plot': (
        "Esta sección está en desarrollo.\n"
        "Los canales y listas de reproducción ya se pueden explorar,\n"
        "pero los vídeos individuales aún no se reproducen directamente en Kodi.\n"
        "Próximamente se añadirá soporte completo de reproducción."
    )})
    li_wip.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li_wip, isFolder=False)

    for cat_name, channels in _EDUCACION_DIVULGACION_YT.items():
        li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(cat_name, len(channels)))
        li.setArt({'icon': edu_icon})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="educacion_list", cat=cat_name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)

def _educacion_list(cat_name):
    h = int(sys.argv[1])
    channels = _EDUCACION_DIVULGACION_YT.get(cat_name, [])
    if not channels:
        xbmcplugin.endOfDirectory(h); return
    edu_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'cat_educacion.png')
    if not os.path.isfile(edu_icon):
        edu_icon = 'DefaultFolder.png'
    watched = _ywt.load()
    for ch in channels:
        name = ch.get("name", "Canal")
        ctype = ch.get("type", "channel")
        desc = ch.get("desc", "")
        yt_id = ch.get("yt_id", "")
        burl = ch.get("url", "")
        is_watched = ctype == "video" and yt_id in watched
        if ctype == "browser":
            label = "[COLOR orange]{0}[/COLOR]".format(name)
            plot = "{0}\nSe abre en el navegador.".format(desc)
        elif ctype == "video":
            label = "[COLOR gray](Visto) {0}[/COLOR]".format(name) if is_watched else "[COLOR lime]{0}[/COLOR]".format(name)
            plot = "{0}\nVideo individual.".format(desc)
        elif ctype == "playlist":
            label = "[COLOR skyblue]{0}[/COLOR]".format(name)
            plot = "{0}\nPlaylist de YouTube.".format(desc)
        else:
            label = "[B]{0}[/B]".format(name)
            plot = "{0}\nCanal de YouTube.".format(desc)
        li = xbmcgui.ListItem(label=label)
        art = {'icon': edu_icon}
        if ctype == "video" and yt_id:
            thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
            art['thumb'] = thumb
            art['icon'] = thumb
        li.setArt(art)
        li.setInfo('video', {'title': name, 'plot': plot})
        fav_params = json.dumps({"yt_id": yt_id, "name": name, "ctype": ctype, "burl": burl})
        cm = []
        if ctype == "video" and yt_id:
            if is_watched:
                cm.append(("Desmarcar como visto", "RunPlugin({0})".format(_u(action='yt_toggle_watched', yt_id=yt_id))))
            else:
                cm.append(("Marcar como visto", "RunPlugin({0})".format(_u(action='yt_toggle_watched', yt_id=yt_id))))
            cm.append(("Añadir a cola de reproducción", "RunPlugin({0})".format(_u(action='yt_queue_add', yt_id=yt_id, name=name))))
        cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(
            _u(action='add_favorite', title=name, fav_url='yt_{0}'.format(yt_id),
               icon=edu_icon, platform='educacion',
               fav_action='felicidad_play', params=fav_params))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_play", yt_id=yt_id, name=name, ctype=ctype, burl=burl), listitem=li, isFolder=(ctype == "video"))
    xbmcplugin.endOfDirectory(h)

# --- ARTE Y MUSEOS ---
def _arte_museos_menu():
    h = int(sys.argv[1])
    if not _ARTE_MUSEOS_YT:
        xbmcgui.Dialog().ok("Arte y Museos", "Aún no hay contenido. ¡Próximamente!")
        return
    for cat_name, items in _ARTE_MUSEOS_YT.items():
        li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(cat_name, len(items)))
        li.setArt({'icon': 'DefaultPicture.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="arte_museos_list", cat=cat_name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _arte_museos_list(cat_name):
    h = int(sys.argv[1])
    items = _ARTE_MUSEOS_YT.get(cat_name, [])
    if not items:
        xbmcplugin.endOfDirectory(h)
        return
    watched = _ywt.load()
    for ch in items:
        name = ch.get("name", "")
        ctype = ch.get("type", "browser")
        desc = ch.get("desc", "")
        yt_id = ch.get("yt_id", "")
        burl = ch.get("url", "")
        is_watched = ctype == "video" and yt_id in watched
        if ctype == "info":
            li = xbmcgui.ListItem(label="[COLOR gray][I]Pendiente de actualizar[/I][/COLOR]")
            li.setArt({'icon': 'DefaultIconInfo.png'})
            li.setInfo('video', {'title': "Pendiente de actualizar", 'plot': desc})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="arte_info_dialog", title=cat_name, msg=desc),
                listitem=li, isFolder=False,
            )
            continue
        if ctype == "browser":
            label = "[COLOR orange]{0}[/COLOR]".format(name)
            plot = "{0}\nSe abre en el navegador.".format(desc)
        elif ctype == "video":
            label = "[COLOR gray](Visto) {0}[/COLOR]".format(name) if is_watched else "[COLOR lime]{0}[/COLOR]".format(name)
            plot = "{0}\nVideo individual.".format(desc)
        elif ctype == "playlist":
            label = "[COLOR skyblue]{0}[/COLOR]".format(name)
            plot = "{0}\nPlaylist de YouTube.".format(desc)
        else:
            label = "[B]{0}[/B]".format(name)
            plot = "{0}\nCanal de YouTube.".format(desc)
        li = xbmcgui.ListItem(label=label)
        art = {'icon': 'DefaultPicture.png'}
        if ctype == "video" and yt_id:
            thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
            art['thumb'] = thumb
            art['icon'] = thumb
        li.setArt(art)
        li.setInfo('video', {'title': name, 'plot': plot})
        cm = []
        if ctype == "video" and yt_id:
            toggle_label = "Desmarcar como visto" if is_watched else "Marcar como visto"
            cm.append((toggle_label, "RunPlugin({0})".format(_u(action='yt_toggle_watched', yt_id=yt_id))))
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="felicidad_play", yt_id=yt_id, name=name, ctype=ctype, burl=burl),
            listitem=li,
            isFolder=(ctype != "video"),
        )
    xbmcplugin.endOfDirectory(h)


_YT_LIVE_CHANNELS = {
    "Noticias 24h": [
        {"name": "RTVE 24h", "yt_id": "UCfHptOfCGvKbHdFhfjJnWpA"},
        {"name": "euronews en español", "yt_id": "UCjwHpMgZoLPasxBswgFshKg"},
        {"name": "France 24 Español", "yt_id": "UCUdOoVWuWmgo1wByzcsyKDQ"},
        {"name": "DW Español", "yt_id": "UCT2VMLy-aMTdfnCjTmYgUbg"},
        {"name": "Televisión de Galicia", "yt_id": "UC7dxTqnuQI6IxCZMmJG_MOw"},
    ],
    "Música": [
        {"name": "Lo-fi Girl", "yt_id": "UCSJ4gkVC6NrvII8umztf0A"},
        {"name": "Steezy Beats", "yt_id": "UCwNw0w-CorPkMNy5vRxatZg"},
        {"name": "Chillhop Music", "yt_id": "UCOxqgCwgOqC2lMqC5PYz_Dg"},
    ],
    "Naturaleza y Documentales": [
        {"name": "Explore.org Live Cams", "yt_id": "UCOhMiSLNDD0D7xTuHCYgEhw"},
    ],
}

def _check_youtube_addon():
    try:
        xbmcaddon.Addon("plugin.video.youtube")
        return True
    except RuntimeError:
        return False



def _youtube_install_prompt():
    """Pide confirmación y llama a InstallAddon(plugin.video.youtube). Devuelve siempre False (la instalación es asíncrona)."""
    import xbmc, xbmcgui
    import traceback
    

    dialog = xbmcgui.Dialog()
    
    try:
        # Peticion imperativa de interaccion del usuario
        if dialog.yesno("Dependencia Requerida en EspaTV", 
                        "Motor oficial de YouTube detectado ausente.\n\n"
                        "¿Autorizas la instalación automatizada nativa en este momento?",
                        nolabel="Cancelar", yeslabel="Sí, Instalar"):
            
            xbmc.log("[EspaTV] Dependencies: Aprobacion concedida. Lanzando Builtin Event.", xbmc.LOGINFO)
            
            # Ejecucion protegida del Sandbox de C++ Kodi
            xbmc.executebuiltin("InstallAddon(plugin.video.youtube)")
            
            # Notificacion asíncrona sutil
            dialog.notification("EspaTV", "Instalando módulo central por defecto...", xbmcgui.NOTIFICATION_INFO, 2500)
            

            return False
        else:
            xbmc.log("[EspaTV] Dependencies: Evaluacion completada, instalador denegado.", xbmc.LOGINFO)
            dialog.notification("EspaTV", "Instalación manual requerida (YouTube cancelado).", xbmcgui.NOTIFICATION_WARNING)
            return False
            
    except (RuntimeError, AttributeError) as script_error:
        tb = traceback.format_exc()
        xbmc.log("[EspaTV] EXCEPCION CRITICA en Dependency Installer: {0}\n\t{1}".format(str(script_error), str(tb)), xbmc.LOGERROR)
        dialog.notification("EspaTV Error", "Fallo al llamar la API del sistema", xbmcgui.NOTIFICATION_ERROR)
        return False




def _play_dash(stream_url, title=""):
    h = int(sys.argv[1])
    if not stream_url:
        xbmcgui.Dialog().notification("EspaTV", "Streaming DASH no disponible.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    xbmc.log("[EspaTV] Reproduciendo flujo DASH: {0}".format(stream_url), xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=stream_url)
    li.setInfo('video', {'title': title})
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    li.setMimeType('application/dash+xml')
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(h, True, li)


def _youtube_live_menu():
    h = int(sys.argv[1])
    if not _check_youtube_addon():
        li = xbmcgui.ListItem(label="[COLOR red][B]Instalar addon YouTube (necesario)[/B][/COLOR]")
        li.setArt({'icon': 'DefaultAddonHelper.png'})
        li.setInfo('video', {'plot': "El addon YouTube de Kodi es necesario para reproducir estos canales.\nPulsa aquí para ver las instrucciones de instalación."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="youtube_install"), listitem=li, isFolder=False)
    for cat_name, channels in _YT_LIVE_CHANNELS.items():
        li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(cat_name, len(channels)))
        li.setArt({'icon': 'DefaultAddonPVRClient.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="youtube_live_list", cat=cat_name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)

def _youtube_live_list(cat_name):
    h = int(sys.argv[1])
    channels = _YT_LIVE_CHANNELS.get(cat_name, [])
    if not channels:
        xbmcplugin.endOfDirectory(h); return
    has_yt = _check_youtube_addon()
    for ch in channels:
        name = ch.get("name", "Canal")
        yt_id = ch.get("yt_id", "")
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(name))
        li.setArt({'icon': 'DefaultAddonPVRClient.png', 'thumb': 'DefaultAddonPVRClient.png'})
        if has_yt:
            li.setInfo('video', {'title': name, 'plot': "YouTube Live: {0}\nPulsa para ver en directo.".format(name)})
        else:
            li.setInfo('video', {'title': name, 'plot': "YouTube Live: {0}\n[COLOR red]Necesitas instalar el addon YouTube.[/COLOR]".format(name)})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_youtube_live", yt_id=yt_id, title=name), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def _play_youtube_live(yt_id, title=""):
    h = int(sys.argv[1])
    if not _check_youtube_addon():
        _youtube_install_prompt()
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    yt_url = "plugin://plugin.video.youtube/play/?channel_id={0}&live=1".format(yt_id)
    xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
    xbmc.executebuiltin("PlayMedia({0})".format(yt_url))

def _play_latest_news():
    h = int(sys.argv[1])
    url = "https://fapi-top.prisasd.com/podcast/playser/hora_14/itunestfp/podcast.xml"
    try:
        import xml.etree.ElementTree as ET
        r = requests.get(url, timeout=8)
        r.raise_for_status()
        r.encoding = 'utf-8'
        root = ET.fromstring(r.text)
        item = root.find('.//item')
        if item is None:
            xbmcgui.Dialog().notification("EspaTV", "No hay boletines disponibles.", xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
            return
        enclosure = item.find('enclosure')
        if enclosure is None or not enclosure.get('url'):
            xbmcgui.Dialog().notification("EspaTV", "Boletín sin audio disponible.", xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
            return
        audio_url = enclosure.get('url')
        title_el = item.find('title')
        title = title_el.text if title_el is not None and title_el.text else "Boletín Informativo"
        xbmc.log("[EspaTV] Reproduciendo RSS Noticias: {0}".format(audio_url), xbmc.LOGINFO)
        xbmcgui.Dialog().notification("EspaTV", "Reproduciendo: {0}".format(title), xbmcgui.NOTIFICATION_INFO, 3000)
        li = xbmcgui.ListItem(path=audio_url)
        li.setInfo(type="Music", infoLabels={"Title": title, "Artist": "SER Noticias"})
        xbmcplugin.setResolvedUrl(h, True, li)
        return
    except (requests.RequestException, ValueError, ImportError) as exc:
        _log_error("Error obteniendo boletín de noticias: {0}".format(exc))
        xbmcgui.Dialog().notification("EspaTV", "Error obteniendo el boletín de noticias.", xbmcgui.NOTIFICATION_ERROR)
    xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())

# --- LO MÁS VISTO ---
def _most_watched():
    h = int(sys.argv[1])
    history = _wh._load()
    if not history:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay historial aún. Reproduce vídeos para ver tus más vistos.[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h); return

    # Collect entries to show (top 20)
    entries_to_show = []
    for entry in history:
        if len(entries_to_show) >= 20: break
        vid = entry.get('vid', '')
        if not vid: continue
        entries_to_show.append(entry)

    # Detect entries with DM IDs as titles and batch-resolve from API
    ids_to_resolve = []
    for entry in entries_to_show:
        vt = entry.get('title', '')
        vid = entry.get('vid', '')
        if not vt or vt == vid or (len(vt) < 12 and ' ' not in vt):
            ids_to_resolve.append(vid)

    resolved = {}
    if ids_to_resolve:
        try:
            batch_ids = ",".join(ids_to_resolve[:20])
            r = requests.get("https://api.dailymotion.com/videos",
                params={"ids": batch_ids, "fields": "id,title,thumbnail_720_url,thumbnail_url,duration"},
                timeout=10)
            if r.status_code == 200:
                for v in r.json().get("list", []):
                    resolved[v.get("id", "")] = v
        except (requests.RequestException, ValueError):
            pass

    # Actualizar el historial con títulos reales obtenidos de la API (mejora las entradas con IDs como título)
    if resolved:
        updated = False
        for entry in history:
            vid = entry.get('vid', '')
            if vid in resolved:
                info = resolved[vid]
                real_title = info.get("title", "")
                real_thumb = info.get("thumbnail_720_url") or info.get("thumbnail_url", "")
                real_dur = info.get("duration", 0)
                if real_title and (not entry.get('title') or entry['title'] == vid or (len(entry['title']) < 12 and ' ' not in entry['title'])):
                    entry['title'] = real_title
                    updated = True
                if real_thumb and not entry.get('thumb'):
                    entry['thumb'] = real_thumb
                    updated = True
                if real_dur and not entry.get('duration'):
                    entry['duration'] = real_dur
                    updated = True
        if updated:
            _wh._save(history)

    xbmcplugin.setContent(h, 'videos')
    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    for idx, entry in enumerate(entries_to_show):
        vid = entry.get('vid', '')
        vt = entry.get('title', 'Video')
        dth = entry.get('thumb', '') or ai
        du = entry.get('duration', 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0

        # Si la API devolvió datos reales para este vídeo, sobreescribir los del historial
        if vid in resolved:
            info = resolved[vid]
            vt = info.get("title", vt) or vt
            dth = info.get("thumbnail_720_url") or info.get("thumbnail_url", "") or dth
            try: du = int(info.get("duration", du))
            except (ValueError, TypeError): pass

        label = "[COLOR gold]{0}.[/COLOR] {1}".format(idx + 1, vt)
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': dth, 'icon': dth})
        plot = "Acceso rápido a tus vídeos recientes."
        if du: plot += "\nDuración: {0}m {1}s".format(du // 60, du % 60)
        li.setInfo('video', {'title': vt, 'plot': plot, 'duration': du})
        li.setProperty("IsPlayable", "true")
        cm = []
        cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action='download_video', vid=vid, title=vt))))
        cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action='dm_open_browser', url=vid))))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vid)))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vid), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR red][B]Limpiar lista de lo más visto[/B][/COLOR]")
    li.setArt({'icon': 'DefaultIconError.png'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="clear_most_watched"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)






def _show_trending():
    h = int(sys.argv[1])
    try:
        time_limit = int(time.time()) - 604800
        params = {
            "sort": "trending", "language": "es", "created_after": time_limit,
            "limit": 50,
            "fields": "id,title,thumbnail_720_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"
        }
        resp = requests.get("https://api.dailymotion.com/videos", params=params, timeout=15)
        rs = resp.json().get("list", [])
        if not rs:
            xbmcgui.Dialog().ok("Tendencias", "No se han encontrado vídeos en tendencia.")
            xbmcplugin.endOfDirectory(h); return
        xbmcplugin.setContent(h, 'videos')
        watched_ids = _wh.get_watched_ids()
        addon = xbmcaddon.Addon()
        ai = addon.getAddonInfo('icon')
        for i, v in enumerate(rs):
            vt = v.get("title", "Video")
            vi = v.get("id")
            ow = v.get("owner.screenname") or v.get("owner.username", "")
            du = 0
            try: du = int(v.get("duration", 0))
            except (ValueError, TypeError): pass
            vw = 0
            try: vw = int(v.get("views_total", 0))
            except (ValueError, TypeError): pass
            dth = v.get("thumbnail_720_url") or v.get("thumbnail_url") or ai
            is_watched = vi in watched_ids if vi else False
            watched_mark = "[COLOR lime][V][/COLOR] " if is_watched else ""
            label = "[COLOR orange]{0}.[/COLOR] {1}{2}".format(i + 1, watched_mark, vt)
            li = xbmcgui.ListItem(label=label)
            li.setArt({'thumb': dth, 'icon': dth})
            li.setInfo('video', {'title': vt, 'plot': "Canal: {0}\nVistas: {1:,}\nDuración: {2}m {3}s".format(ow, vw, du // 60, du % 60), 'duration': du})
            li.setProperty("IsPlayable", "true")
            cm = []
            if vi:
                cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action="download_video", vid=vi, title=vt))))
                cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action="dm_open_browser", url=vi))))
                cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vi)))))
                fav_params = json.dumps({"q": vt, "ot": dth})
                cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(_u(action='add_favorite', title=vt, fav_url='lfr_{0}'.format(vi), icon=dth, platform='tendencias', fav_action='lfr', params=fav_params))))
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
    except (requests.RequestException, ValueError) as e:
        xbmcgui.Dialog().ok("Error", "Error al cargar tendencias:\n{0}".format(str(e)))
        try:
            xbmcplugin.endOfDirectory(h)
        except RuntimeError:
            pass




def _multi_search():
    kb = xbmc.Keyboard('', 'Términos separados por comas')
    kb.doModal()
    if not kb.isConfirmed(): return
    raw = kb.getText().strip()
    if not raw: return
    terms = [t.strip() for t in raw.split(',') if t.strip()]
    if not terms:
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron términos válidos", xbmcgui.NOTIFICATION_WARNING)
        return
    if len(terms) > 10:
        terms = terms[:10]
        xbmcgui.Dialog().notification("EspaTV", "Limitado a 10 términos", xbmcgui.NOTIFICATION_INFO)
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Búsqueda Múltiple", "Buscando {0} términos...".format(len(terms)))
    all_results = []
    seen_ids = set()
    try:
        for idx, term in enumerate(terms):
            if dp.iscanceled(): break
            dp.update(int((idx / len(terms)) * 100), "Buscando: {0}".format(term))
            try:
                params = {"search": term, "sort": "relevance", "language": "es", "limit": 10,
                          "fields": "id,title,thumbnail_720_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"}
                resp = requests.get("https://api.dailymotion.com/videos", params=params, timeout=15)
                for item in resp.json().get("list", []):
                    vid = item.get("id", "")
                    if vid and vid not in seen_ids:
                        seen_ids.add(vid)
                        all_results.append((term, item))
            except (requests.RequestException, ValueError):
                pass
    finally:
        dp.close()
    if not all_results:
        xbmcgui.Dialog().ok("Búsqueda Múltiple", "No se encontraron resultados para ningún término.")
        xbmcplugin.endOfDirectory(h); return
    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    for term, item in all_results:
        vid = item.get("id", "")
        title = item.get("title", "Sin título")
        thumb = item.get("thumbnail_720_url") or item.get("thumbnail_url", "") or ai
        dur = 0
        try: dur = int(item.get("duration", 0))
        except (ValueError, TypeError): pass
        owner = item.get("owner.screenname") or item.get("owner.username", "")
        views = 0
        try: views = int(item.get("views_total", 0))
        except (ValueError, TypeError): pass
        dur_min = dur // 60 if dur else 0
        label = "[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(title, term)
        if dur_min: label += " [COLOR cyan]{0}min[/COLOR]".format(dur_min)
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb, 'thumb': thumb})
        li.setInfo('video', {'plot': "Canal: {0}\nBúsqueda: {1}\nDuración: {2}min\nVisitas: {3:,}".format(owner, term, dur_min, views), 'duration': dur})
        li.setProperty("IsPlayable", "true")
        cm = []
        cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action='download_video', vid=vid, title=title))))
        cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action='dm_open_browser', url=vid))))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vid)))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vid), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)
    xbmcgui.Dialog().notification("Búsqueda Múltiple", "{0} resultados de {1} términos".format(len(all_results), len(terms)))




def _dm_open_browser(vid):
    vid = str(vid).replace('"', '').replace("'", '').strip() if vid else ""
    if not vid: return
    url = "https://www.dailymotion.com/video/{0}".format(vid)
    try:
        if xbmc.getCondVisibility("System.Platform.Android"):
            xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","","{0}")'.format(url))
        else:
            import webbrowser
            webbrowser.open(url)
        xbmcgui.Dialog().notification("EspaTV", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
    except (ImportError, OSError):
        xbmcgui.Dialog().ok("Abrir en navegador", "No se pudo abrir automáticamente.\n\nAbre esta URL:\n{0}".format(url))


def _copy_url(url):
    url = str(url).strip() if url else ""
    if not url:
        return
    try:
        xbmcgui.Window(10000).setProperty("espatv.clipboard.url", url)
    except (RuntimeError, AttributeError):
        xbmc.log("EspaTV: Fallo al escribir en portapapeles (Window 10000 unavailable).", xbmc.LOGWARNING)
        return
    display = (url[:60] + "...") if len(url) > 60 else url
    xbmcgui.Dialog().notification(
        "EspaTV", "URL copiada: {0}".format(display),
        xbmcgui.NOTIFICATION_INFO, 2500
    )


def _open_flowfav():
    if xbmc.getCondVisibility("System.HasAddon(plugin.program.flowfavmanager)"):
        xbmc.executebuiltin("RunAddon(plugin.program.flowfavmanager)")
    else:
        xbmcgui.Dialog().ok("EspaTV",
            "Flow FavManager no está instalado.\n\n"
            "Descárgalo desde:\nhttps://github.com/loioloio/flowfav")

def _open_loiolog():
    if xbmc.getCondVisibility("System.HasAddon(plugin.program.loiolog)"):
        xbmc.executebuiltin("RunAddon(plugin.program.loiolog)")
    else:
        xbmcgui.Dialog().ok("EspaTV",
            "LoioLog no está instalado.\n\n"
            "Descárgalo desde:\nhttps://github.com/loioloio/loiolog")

def _open_atresdaily():
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.atresdaily)"):
        xbmc.executebuiltin("RunAddon(plugin.video.atresdaily)")
    else:
        xbmcgui.Dialog().ok("AtresDaily",
            "AtresDaily no está instalado.\n\n"
            "Para instalarlo:\n"
            "1. Ajustes > Explorador de archivos > Añadir fuente\n"
            "2. Escribe: https://fullstackcurso.github.io/atresdaily/\n"
            "3. Instalar desde ZIP > atresdaily > repository.atresdaily-1.0.1.zip\n"
            "4. Instalar desde repositorio > AtresDaily Repository")

def _open_espadaily():
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.espadaily)"):
        xbmc.executebuiltin("RunAddon(plugin.video.espadaily)")
    else:
        xbmcgui.Dialog().ok("EspaDaily",
            "EspaDaily no está instalado.\n\n"
            "Para instalarlo:\n"
            "1. Ajustes > Explorador de archivos > Añadir fuente\n"
            "2. Escribe: https://fullstackcurso.github.io/espadaily/\n"
            "3. Instalar desde ZIP > espadaily > repository.espadaily-1.0.2.zip\n"
            "4. Instalar desde repositorio > EspaDaily Repository")

def _set_cache_config():
    cfg = _load_dm_settings()
    current = cfg.get('cache_expiry', 0)
    options = [
        "Apagado" + (" [ACTIVO]" if current == 0 else ""),
        "1 día" + (" [ACTIVO]" if current == 86400 else ""),
        "1 semana" + (" [ACTIVO]" if current == 604800 else ""),
        "1 mes" + (" [ACTIVO]" if current == 2592000 else ""),
        "Indefinido" + (" [ACTIVO]" if current == -1 else ""),
    ]
    vals = [0, 86400, 604800, 2592000, -1]
    sel = xbmcgui.Dialog().select("Duración de la caché", options)
    if sel < 0: return
    cfg['cache_expiry'] = vals[sel]
    _save_dm_settings(cfg)
    xbmcgui.Dialog().notification("EspaTV", "Caché: {0}".format(options[sel].replace(" [ACTIVO]", "")), xbmcgui.NOTIFICATION_INFO)

def _toggle_iptv_cache():
    current = core_settings.is_iptv_cache_active()
    new_state = not current
    core_settings.set_iptv_cache_active(new_state)
    if new_state:
        xbmcgui.Dialog().notification("EspaTV", "Caché IPTV ACTIVADA", xbmcgui.NOTIFICATION_INFO)
    else:
        core_settings.clear_iptv_cache_files()
        xbmcgui.Dialog().notification("EspaTV", "Caché IPTV DESACTIVADA", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _set_iptv_cache_ttl_dialog():
    options = []
    current_ttl = core_settings.get_iptv_cache_ttl()
    for val, name in core_settings._IPTV_CACHE_TTL_OPTIONS:
        if val == 0:
            continue  # no mostrar "Desactivada", para eso está el toggle
        label = name
        if val == current_ttl:
            label += " [ACTIVO]"
        options.append((val, label))
    sel = xbmcgui.Dialog().select("Duración de caché IPTV", [o[1] for o in options])
    if sel < 0:
        return
    core_settings.set_iptv_cache_ttl(options[sel][0])
    core_settings.clear_iptv_cache_files()  # limpiar al cambiar TTL
    xbmcgui.Dialog().notification("EspaTV", "Caché: {0}".format(options[sel][1].replace(" [ACTIVO]", "")), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _reset_iptv_cache():
    if not xbmcgui.Dialog().yesno("EspaTV",
        "¿Restaurar la caché IPTV por defecto?\n\n"
        "Se desactivará la caché y se borrarán "
        "todos los archivos guardados.\n"
        "Los canales se descargarán de internet cada vez que entres, como venía de fábrica."):
        return
    core_settings.reset_iptv_cache_defaults()
    xbmcgui.Dialog().notification("EspaTV", "Caché restaurada por defecto", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _set_download_path():
    path = xbmcgui.Dialog().browse(0, 'Seleccionar carpeta de descargas', 'files')
    if not path: return
    cfg = _load_dm_settings()
    cfg['download_path'] = path
    _save_dm_settings(cfg)
    xbmcgui.Dialog().notification("EspaTV", "Ruta configurada", xbmcgui.NOTIFICATION_INFO)














def _load_dm_settings():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    sp = os.path.join(p, 'dm_settings.json')
    if not os.path.exists(sp):
        return {}
    try:
        with open(sp, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}

def _save_dm_settings(cfg):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    sp = os.path.join(p, 'dm_settings.json')
    try:
        with open(sp, 'w', encoding='utf-8') as f:
            json.dump(cfg, f, ensure_ascii=False)
    except IOError:
        pass

def _set_dm_safe_level():
    options = [
        "Desactivado (Conexión Normal)",
        "Básico (Móvil + Cookies)",
        "Extremo (Todas las técnicas de Gujal00)",
        "YT-DLP (TLS Spoofing - Recomendado en PC)"
    ]
    cfg = _load_dm_settings()
    current = cfg.get('dm_safe_level', 0)
    
    sel = xbmcgui.Dialog().select("Modo Anti-Errores Dailymotion", options, preselect=current)
    if sel >= 0:
        if sel == 3:
            try:
                import yt_dlp
                xbmc.log(f"[EspaTV] yt-dlp v{yt_dlp.version.__version__} disponible", xbmc.LOGINFO)
            except ImportError:
                xbmcgui.Dialog().ok("EspaTV", "yt-dlp no está instalado.\n\nInstálalo con:\npip install yt-dlp curl-cffi")
                return
        cfg['dm_safe_level'] = sel
        _save_dm_settings(cfg)
        xbmcgui.Dialog().notification("EspaTV", f"Modo Anti-Errores DM: {options[sel].split(' (')[0]}")
        xbmc.executebuiltin("Container.Refresh")

def _set_dl_mode():
    opts = [
        "Nivel 1: DIRECTO (Elegir calidad)", 
        "Nivel 2: SAFE MODE (Mejor MP4 directo)", 
        "Nivel 3: EspaTV (Descargar por HLS)",
        "Nivel 4: YT-DLP (Mejor calidad, Python 3.10+)",
        "Nivel 5: ULTRA (Mejor calidad, Python 3.10+)"
    ]
    cfg = _load_dm_settings()
    current = cfg.get('dl_mode', 0)
    idx = xbmcgui.Dialog().select("Modo de Descarga", opts, preselect=current)
    if idx >= 0:
        cfg['dl_mode'] = idx
        _save_dm_settings(cfg)
        xbmcgui.Dialog().notification("EspaTV", f"Modo descarga: Nivel {idx+1} guardado")
        xbmc.executebuiltin("Container.Refresh")

def _dm_playlists_search():
    kb = xbmc.Keyboard("", "Buscar canal de Dailymotion")
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return
    channels = _dm_search_channels(query)
    if not channels:
        xbmcgui.Dialog().ok("EspaTV", "No se encontraron canales para: " + query)
        return
    h = int(sys.argv[1])
    for ch in channels:
        name = ch.get("screenname") or ch.get("username", "Canal")
        user = ch.get("username", "")
        li = xbmcgui.ListItem(label=name)
        li.setArt({'icon': 'DefaultActor.png'})
        li.setInfo('video', {'plot': "Usuario: " + user})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="dm_user_playlists", user=user),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)

def _dm_user_playlists(user):
    if not user:
        return
    playlists = _dm_list_user_playlists(user)
    if not playlists:
        xbmcgui.Dialog().ok("EspaTV", "Este canal no tiene playlists.")
        return
    h = int(sys.argv[1])
    for pl in playlists:
        name = pl.get("name", "Playlist")
        count = pl.get("count", 0)
        label = "{0} ({1} videos)".format(name, count) if count else name
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultVideoPlaylists.png'})
        desc = pl.get("description", "")
        if desc:
            li.setInfo('video', {'plot': desc})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="dm_view_playlist", pid=pl.get("id")),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)

def _dm_view_playlist(pid):
    if not pid:
        return
    videos = _dm_view_playlist_api(pid)
    if not videos:
        xbmcgui.Dialog().ok("EspaTV", "No se encontraron videos en esta playlist.")
        return
    h = int(sys.argv[1])
    for v in videos:
        vid = v.get("id")
        if not vid:
            continue
        tt = v.get("title", "Video")
        th = v.get("thumbnail_720_url", "")
        dur = v.get("duration", 0)
        owner = v.get("owner.screenname", "")
        li = xbmcgui.ListItem(label=tt)
        li.setArt({'thumb': th, 'icon': th})
        info = {'title': tt, 'duration': dur}
        if owner:
            info['plot'] = "Canal: " + owner
        li.setInfo('video', info)
        li.setProperty("IsPlayable", "true")
        cm = []
        cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action='download_video', vid=vid, title=tt))))
        cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action='dm_open_browser', url=vid))))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vid)))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="pv", vid=vid),
            listitem=li, isFolder=False,
        )
    xbmcplugin.endOfDirectory(h)

def _search_external_prompt(query):
    if not query:
        return
    options = []
    actions = []


    if xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        options.append("Buscar en addon Dailymotion (Gujal)")
        actions.append(("dm_gujal_search", query))

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        options.append("Buscar en YouTube")
        actions.append(("youtube_search", query))

    if not options:
        xbmcgui.Dialog().ok(
            "EspaTV",
            "No hay addons de terceros instalados.\n\n"
            "Addons compatibles:\n"
            u"  • Dailymotion (Gujal)\n"
            u"  • YouTube",
        )
        return

    sel = xbmcgui.Dialog().select(
        u"¿Dónde quieres buscar '{0}'?".format(query), options
    )
    if sel < 0:
        return

    action_name, q = actions[sel]
    if action_name == "dm_gujal_search":
        _search_dailymotion_gujal(q)
    elif action_name == "youtube_search":
        yt_url = "plugin://plugin.video.youtube/kodion/search/query/?q=" + urllib.parse.quote(q)
        xbmc.executebuiltin('Container.Update("{0}")'.format(yt_url))

def _search_dailymotion_gujal(query):
    if not query:
        return
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        xbmcgui.Dialog().ok("EspaTV", "El addon Dailymotion de Gujal no está instalado.")
        return
    url = "plugin://plugin.video.dailymotion_com/?action=search&query=" + urllib.parse.quote(query)
    xbmc.executebuiltin('Container.Update("{0}")'.format(url))

def _get_system_clipboard_text():
    try:
        import ctypes, ctypes.wintypes
        CF_UNICODETEXT = 13
        _gcd = ctypes.windll.user32.GetClipboardData
        _gcd.restype = ctypes.c_void_p
        _gcd.argtypes = [ctypes.wintypes.UINT]
        _gl = ctypes.windll.kernel32.GlobalLock
        _gl.restype = ctypes.c_void_p
        _gl.argtypes = [ctypes.c_void_p]
        _gu = ctypes.windll.kernel32.GlobalUnlock
        _gu.argtypes = [ctypes.c_void_p]
        if not ctypes.windll.user32.OpenClipboard(None):
            return ""
        try:
            handle = _gcd(CF_UNICODETEXT)
            if not handle:
                return ""
            ptr = _gl(handle)
            if not ptr:
                return ""
            try:
                return ctypes.wstring_at(ptr).strip()
            finally:
                _gu(handle)
        finally:
            ctypes.windll.user32.CloseClipboard()
    except Exception:
        return ""


def _elementum_search_prompt():
    opciones = ["Escribir búsqueda", "Pegar desde portapapeles"]
    eleccion = xbmcgui.Dialog().select("Buscar torrents", opciones)
    if eleccion == 0:
        kb = xbmc.Keyboard("", "Buscar torrents en Elementum")
        kb.doModal()
        if kb.isConfirmed() and kb.getText().strip():
            _search_elementum(kb.getText().strip())
    elif eleccion == 1:
        texto = _get_system_clipboard_text()
        if not texto:
            xbmcgui.Dialog().ok("Portapapeles vacío",
                "El portapapeles no contiene texto.\n\n"
                "Copia primero el título que quieres buscar.")
            return
        kb = xbmc.Keyboard(texto, "Buscar torrents en Elementum")
        kb.doModal()
        if kb.isConfirmed() and kb.getText().strip():
            _search_elementum(kb.getText().strip())


def _search_elementum(query):
    if not query:
        return
    
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
        xbmcgui.Dialog().ok("EspaTV", 
            "El addon Elementum no está instalado.\n\n"
            "Esta función requiere Elementum para buscar torrents en webs como 1337x, RARBG, etc.\n\n"
            "Puedes instalarlo desde el repositorio oficial de Kodi o desde GitHub.")
        return
    
    # Abrir búsqueda en Elementum
    elementum_url = "plugin://plugin.video.elementum/search?q={0}".format(urllib.parse.quote(query))
    xbmc.executebuiltin("Container.Update({0})".format(elementum_url))

def _search_youtube_from_results(query):
    if not query:
        return
    kb = xbmc.Keyboard(query, 'Buscar en YouTube')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        q = kb.getText().strip()
        if q:
            _yts._add_yt_to_history(q)
            xbmc.executebuiltin(f"Container.Update({_u(action='yt_search_results', query=q)})")


def _search_alternatives_prompt(query, ot=''):
    opciones = []
    acciones = []

    opciones.append("[COLOR cyan]¿Dónde ver en España?[/COLOR]")
    acciones.append("watch_providers")

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        opciones.append("[COLOR deepskyblue]Buscar en Dailymotion (Gujal)[/COLOR]")
        acciones.append("dm_gujal")

    opciones.append("[COLOR dodgerblue]Buscar en Dailymotion (EspaTV)[/COLOR]")
    acciones.append("dm_espatv")

    opciones.append("[COLOR red]Buscar en YouTube[/COLOR]")
    acciones.append("youtube")

    opciones.append("[COLOR orange]Editar búsqueda y reintentar[/COLOR]")
    acciones.append("edit")

    opciones.append("[COLOR limegreen]Copiar título al portapapeles[/COLOR]")
    acciones.append("clipboard")

    opciones.append("[COLOR gold]Internet Archive[/COLOR]")
    acciones.append("archive")

    opciones.append("[COLOR tomato]Torrents P2P (Elementum)[/COLOR]")
    acciones.append("elementum")

    sel = xbmcgui.Dialog().select(
        f"¿Dónde quieres buscar '{query}'?", opciones)
    if sel < 0:
        return
    accion = acciones[sel]
    if accion == "watch_providers":
        _show_watch_providers(query, '')
    elif accion == "dm_gujal":
        _search_dailymotion_gujal(query)
    elif accion == "dm_espatv":
        xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=query, ot=ot)})")
    elif accion == "youtube":
        _search_youtube_from_results(query)
    elif accion == "edit":
        kb = xbmc.Keyboard(query, 'Editar Búsqueda')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=kb.getText(), ot=ot)})")
    elif accion == "clipboard":
        if _copy_to_clipboard(query):
            xbmcgui.Dialog().notification("EspaTV", u"'{0}' copiado al portapapeles".format(query), xbmcgui.NOTIFICATION_INFO, 2500)
        else:
            xbmcgui.Dialog().notification("EspaTV", "No se pudo copiar al portapapeles", xbmcgui.NOTIFICATION_WARNING, 2000)
    elif accion == "archive":
        archive_q = 'mediatype:movies AND title:({0})'.format(re.sub(r'[()[\]{}]', '', query))
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='archive_category', q=archive_q, page=1)))
    elif accion == "elementum":
        _search_elementum(query)


def _setup_pvr():
    import pvr_manager
    if not xbmcgui.Dialog().yesno(
        "Auto-Configuración PVR",
        "EspaTV va a vincular la lista TDT y la Guía (EPG) con la sección nativa de TV de Kodi para que puedas ver el Timeline de horas.\n\nAtención: Se sobrescribirán tus ajustes de 'PVR IPTV Simple Client'. ¿Continuar?"
    ):
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Configurando la Guía de Televisión...")
    dp.update(30, "Ajustando reproductor...")

    m3u_url = "https://www.tdtchannels.com/lists/tv.m3u8"
    epg_url = "https://www.tdtchannels.com/epg/TV.xml.gz"

    success = pvr_manager.check_and_setup_pvr(m3u_url, epg_url)

    dp.update(100, "¡Hecho!")
    dp.close()

    if success:
        if xbmcgui.Dialog().yesno("¡Éxito!", "Guía nativa configurada con éxito.\n\nNota: Si se queda al 0% un momento, es normal. Está procesando los datos por primera vez.\n\nVe a la pantalla principal de Kodi y busca la sección 'TV'.\n¿Saltar a la Parrilla ahora?"):
            xbmc.executebuiltin("ActivateWindow(TVGuide)")

def _show_ytdlp_instructions():
    text = (
        "Para ver videos de YouTube, Dailymotion y otras webs\n"
        "necesitas instalar dos programas gratuitos en tu PC.\n"
        "No te preocupes, es facil. Sigue estos pasos:\n\n"

        "============================================\n"
        "  PRIMERO: ABRIR LA TERMINAL\n"
        "============================================\n\n"
        "La terminal es una ventana donde escribes\n"
        "comandos. Para abrirla:\n\n"
        "  Windows:\n"
        "    1. Pulsa la tecla Windows del teclado\n"
        "       (la que tiene el logo de Windows)\n"
        "    2. Escribe:  cmd\n"
        "    3. Haz clic en 'Simbolo del sistema'\n"
        "    Se abrira una ventana negra. Ahi es donde\n"
        "    vas a escribir los comandos.\n\n"
        "    TRUCO: Para pegar un comando en esa ventana,\n"
        "    haz CLIC DERECHO con el raton (no Ctrl+V).\n\n"
        "  Mac:\n"
        "    1. Pulsa Cmd + Espacio a la vez\n"
        "    2. Escribe:  Terminal\n"
        "    3. Pulsa Enter\n\n"
        "  Linux:\n"
        "    Pulsa Ctrl + Alt + T a la vez\n\n"

        "============================================\n"
        "  PASO 1: INSTALAR PYTHON\n"
        "============================================\n\n"
        "Puede que ya lo tengas. Para comprobarlo,\n"
        "escribe en la terminal:\n\n"
        "   python --version\n\n"
        "Si aparece algo como 'Python 3.12.0', perfecto,\n"
        "ya lo tienes. Salta al Paso 2.\n\n"
        "Si da error, prueba con:\n"
        "   py --version\n\n"
        "Si tambien falla, necesitas instalarlo:\n\n"
        "   1. Ve a: https://www.python.org/downloads/\n"
        "   2. Descarga la version para tu sistema\n"
        "   3. Ejecuta el instalador\n\n"
        "   >>> MUY IMPORTANTE en Windows: <<<\n"
        "   En la primera pantalla del instalador,\n"
        "   MARCA la casilla que dice:\n"
        "       'Add Python to PATH'\n"
        "   Si no la marcas, nada funcionara.\n\n"
        "   4. Cierra la terminal y vuelve a abrirla\n"
        "      (para que detecte el Python nuevo)\n\n"

        "============================================\n"
        "  PASO 2: INSTALAR YT-DLP\n"
        "============================================\n\n"
        "Escribe (o pega) este comando en la terminal:\n\n"
        '   pip install -U "yt-dlp[default]"\n\n'
        ">>> IMPORTANTE: Escribe el comando TAL CUAL, <<<\n"
        ">>> con las comillas y el [default].          <<<\n"
        ">>> Sin eso, YouTube no funcionara.           <<<\n\n"
        "Si 'pip' da error, prueba con este otro:\n\n"
        '   python -m pip install -U "yt-dlp[default]"\n\n'
        "Espera a que termine (puede tardar un minuto).\n"
        "Cuando vuelva a aparecer el cursor parpadeante,\n"
        "ya esta listo.\n\n"

        "============================================\n"
        "  PASO 3: INSTALAR DENO (para YouTube)\n"
        "============================================\n\n"
        "YouTube necesita este programa adicional.\n"
        "Sin el, los videos de YouTube no funcionaran.\n\n"
        "  Windows:\n"
        "    Escribe en la terminal:\n"
        "    winget install DenoLand.Deno\n\n"
        "    Si 'winget' da error o no lo reconoce:\n"
        "    1. Ve a: https://github.com/denoland/deno/\n"
        "       releases/latest\n"
        "    2. Descarga el archivo que diga:\n"
        "       deno-x86_64-pc-windows-msvc.zip\n"
        "    3. Descomprime el ZIP\n"
        "    4. Mueve deno.exe a C:\\Windows\\\n"
        "       (o a cualquier carpeta que este en PATH)\n\n"
        "  Mac:\n"
        "    Escribe en la terminal:\n"
        "    curl -fsSL https://deno.land/install.sh | sh\n\n"
        "  Linux:\n"
        "    Escribe en la terminal:\n"
        "    curl -fsSL https://deno.land/install.sh | sh\n\n"
        "  Nota: Si ya tienes Node.js version 20 o\n"
        "  superior, tambien vale y no necesitas Deno.\n\n"
        "  Tras instalar Deno, CIERRA la terminal\n"
        "  y vuelve a abrirla para que lo detecte.\n\n"

        "============================================\n"
        "  PASO 4: COMPROBAR QUE TODO FUNCIONA\n"
        "============================================\n\n"
        "Escribe en la terminal:\n\n"
        "   python -m yt_dlp --version\n\n"
        "Si aparece una fecha (ej: 2026.03.13),\n"
        "todo esta correcto.\n\n"
        "Si da error, revisa los pasos anteriores.\n\n"
        ">>> ULTIMO PASO: Cierra Kodi completamente <<<\n"
        ">>> y vuelve a abrirlo.                    <<<\n\n"

        "============================================\n"
        "  PARA ACTUALIZAR EN EL FUTURO\n"
        "============================================\n\n"
        "Si YouTube deja de funcionar, abre la\n"
        "terminal y repite el comando del Paso 2:\n\n"
        '   pip install -U "yt-dlp[default]"\n\n'
        "Despues, cierra y abre Kodi.\n\n"
        "Se recomienda actualizar cada pocas semanas.\n\n"

        "============================================\n"
        "  AYUDA RAPIDA\n"
        "============================================\n\n"
        "Tambien puedes pulsar 'Comprobar estado'\n"
        "en los Ajustes de EspaTV para ver que\n"
        "tienes instalado y que te falta."
    )
    xbmcgui.Dialog().textviewer("EspaTV \u2014 Instalar yt-dlp", text)


def _check_ytdlp_status():
    import subprocess
    lines = []
    creation_flags = 0x08000000 if xbmc.getCondVisibility("System.Platform.Windows") else 0

    # 1. Comprobar yt-dlp
    try:
        proc = subprocess.run(
            ["python", "-m", "yt_dlp", "--version"],
            capture_output=True, text=True, timeout=15,
            creationflags=creation_flags,
        )
        if proc.returncode == 0:
            ver = proc.stdout.strip()
            lines.append("[OK] yt-dlp instalado: v{0}".format(ver))
        else:
            lines.append("[ERROR] yt-dlp encontrado pero devolvió error")
    except FileNotFoundError:
        lines.append("[ERROR] Python no encontrado en PATH")
    except subprocess.TimeoutExpired:
        lines.append("[AVISO] yt-dlp tardó demasiado en responder")
    except OSError as exc:
        lines.append("[ERROR] Error de sistema: {0}".format(exc))

    # 2. Comprobar Deno
    try:
        proc = subprocess.run(
            ["deno", "--version"],
            capture_output=True, text=True, timeout=10,
            creationflags=creation_flags,
        )
        if proc.returncode == 0:
            deno_ver = proc.stdout.strip().split("\n")[0]
            lines.append("[OK] Deno instalado: {0}".format(deno_ver))
        else:
            lines.append("[NO] Deno no disponible")
    except (FileNotFoundError, OSError):
        lines.append("[NO] Deno no encontrado en PATH")
    except subprocess.TimeoutExpired:
        lines.append("[AVISO] Deno tardó demasiado")

    # 3. Comprobar Node.js
    try:
        proc = subprocess.run(
            ["node", "--version"],
            capture_output=True, text=True, timeout=10,
            creationflags=creation_flags,
        )
        if proc.returncode == 0:
            node_ver = proc.stdout.strip()
            lines.append("[OK] Node.js instalado: {0}".format(node_ver))
        else:
            lines.append("[NO] Node.js no disponible")
    except (FileNotFoundError, OSError):
        lines.append("[NO] Node.js no encontrado en PATH")
    except subprocess.TimeoutExpired:
        lines.append("[AVISO] Node.js tardó demasiado")

    # 4. Comprobar yt-dlp-ejs
    try:
        proc = subprocess.run(
            ["python", "-c", "import yt_dlp_ejs"],
            capture_output=True, text=True, timeout=10,
            creationflags=creation_flags,
        )
        if proc.returncode == 0:
            lines.append("[OK] yt-dlp-ejs instalado")
        else:
            lines.append("[NO] yt-dlp-ejs no instalado")
            lines.append("     Instálalo: pip install -U \"yt-dlp[default]\"")
    except (FileNotFoundError, OSError):
        lines.append("[NO] No se pudo comprobar yt-dlp-ejs")
    except subprocess.TimeoutExpired:
        pass

    # Resumen
    has_ytdlp = any("[OK] yt-dlp instalado:" in l for l in lines)
    has_js = any("[OK] Deno" in l or "[OK] Node" in l for l in lines)
    has_ejs = any("[OK] yt-dlp-ejs" in l for l in lines)
    lines.append("")
    lines.append("===== RESUMEN =====")
    if has_ytdlp and has_js and has_ejs:
        lines.append("Todo OK. YouTube debería funcionar correctamente.")
    elif has_ytdlp and has_js and not has_ejs:
        lines.append("Falta yt-dlp-ejs. Ejecuta:")
        lines.append('   pip install -U "yt-dlp[default]"')
    elif has_ytdlp and not has_js:
        lines.append("Falta un runtime JS (Deno o Node.js).")
        lines.append("YouTube podría fallar sin él.")
        lines.append("Pulsa 'Instrucciones' en Ajustes para más info.")
    else:
        lines.append("yt-dlp no detectado. Pulsa 'Instrucciones' en Ajustes.")

    xbmcgui.Dialog().textviewer("EspaTV — Estado de yt-dlp", "\n".join(lines))


def _ytdlp_proactive_check():
    """Devuelve True si yt-dlp parece estar disponible. Si no, ofrece instrucciones al usuario."""
    if xbmc.getCondVisibility("System.Platform.Android"):
        return False

    import subprocess
    creation_flags = 0x08000000 if xbmc.getCondVisibility("System.Platform.Windows") else 0
    try:
        proc = subprocess.run(
            ["python", "-m", "yt_dlp", "--version"],
            capture_output=True, text=True, timeout=10,
            creationflags=creation_flags,
        )
        if proc.returncode == 0:
            return True
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass

    if xbmcgui.Dialog().yesno(
        "EspaTV",
        "No se encuentra yt-dlp en tu sistema, o no está en el PATH.\n"
        "Es necesario para reproducir este vídeo.\n\n"
        "¿Quieres ver las instrucciones de instalación?",
    ):
        _show_ytdlp_instructions()
    return False


def _copy_to_clipboard(text):
    import subprocess
    import shutil
    try:
        if xbmc.getCondVisibility("System.Platform.Windows"):
            import ctypes, ctypes.wintypes
            CF_UNICODETEXT = 13
            GMEM_MOVEABLE  = 0x0002
            _ga = ctypes.windll.kernel32.GlobalAlloc
            _ga.restype = ctypes.c_void_p
            _ga.argtypes = [ctypes.wintypes.UINT, ctypes.c_size_t]
            _gl = ctypes.windll.kernel32.GlobalLock
            _gl.restype = ctypes.c_void_p
            _gl.argtypes = [ctypes.c_void_p]
            _gu = ctypes.windll.kernel32.GlobalUnlock
            _gu.argtypes = [ctypes.c_void_p]
            _scd = ctypes.windll.user32.SetClipboardData
            _scd.restype = ctypes.c_void_p
            _scd.argtypes = [ctypes.wintypes.UINT, ctypes.c_void_p]
            text_bytes = (text + '\0').encode('utf-16-le')
            h_mem = _ga(GMEM_MOVEABLE, len(text_bytes))
            if not h_mem:
                return False
            ptr = _gl(h_mem)
            if not ptr:
                return False
            ctypes.memmove(ptr, text_bytes, len(text_bytes))
            _gu(h_mem)
            if not ctypes.windll.user32.OpenClipboard(None):
                return False
            ctypes.windll.user32.EmptyClipboard()
            _scd(CF_UNICODETEXT, h_mem)
            ctypes.windll.user32.CloseClipboard()
            return True
        elif xbmc.getCondVisibility("System.Platform.OSX"):
            p = subprocess.Popen(['pbcopy'], stdin=subprocess.PIPE, text=True, encoding='utf-8')
            p.communicate(input=text)
            return True
        elif xbmc.getCondVisibility("System.Platform.Linux"):
            if shutil.which("xclip"):
                p = subprocess.Popen(['xclip', '-selection', 'clipboard'], stdin=subprocess.PIPE, text=True, encoding='utf-8')
                p.communicate(input=text)
                return True
            elif shutil.which("xsel"):
                p = subprocess.Popen(['xsel', '--clipboard', '--input'], stdin=subprocess.PIPE, text=True, encoding='utf-8')
                p.communicate(input=text)
                return True
    except (OSError, subprocess.SubprocessError):
        pass

    try:
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        r.clipboard_clear()
        r.clipboard_append(text)
        r.update()
        r.destroy()
        return True
    except (ImportError, RuntimeError):
        pass
    return False


def _ytdlp_menu():
    opts = [
        "Instrucciones: Instalar / Actualizar yt-dlp",
        "Comprobar estado de yt-dlp",
        "Copiar comando de instalación al Portapapeles"
    ]
    sel = xbmcgui.Dialog().select("Mantenimiento yt-dlp", opts)
    if sel == 0:
        _show_ytdlp_instructions()
    elif sel == 1:
        _check_ytdlp_status()
    elif sel == 2:
        cmd_ytdlp = 'pip install -U "yt-dlp[default]"'
        if xbmc.getCondVisibility("System.Platform.Windows"):
            cmd_deno = 'winget install DenoLand.Deno'
        else:
            cmd_deno = 'curl -fsSL https://deno.land/install.sh | sh'
            
        full_text = cmd_ytdlp + "\n" + cmd_deno
        
        if _copy_to_clipboard(full_text):
            xbmcgui.Dialog().ok("Portapapeles", "Los comandos se han copiado con exito.\nAhora puedes pegarlos (clic derecho o Ctrl+V) en tu terminal.")
        else:
            xbmcgui.Dialog().ok("Error", "No se pudo copiar al portapapeles. Tendras que escribirlo a mano copiando las instrucciones.")


def router(ps):
    p = dict(urllib.parse.parse_qsl(ps)); a = p.get("action")

    if _extras.dispatch(a, p):
        return

    if a == "ls": _ls(p.get("cid"), page=int(p.get("page", 0)))
    elif a == "fs": _fs(p.get("au"), p.get("st"), p.get("sth", ""), p.get("pu", ""))
    elif a == "lfr":
        ep_str = p.get("ep") or ""
        ep = json.loads(ep_str) if ep_str else None
        _lfd(p.get("q"), p.get("ot"), p.get("mode", ""), extra_params=ep, nh=p.get("nh"))
    elif a == "lfd_exclude":
        exc = p.get("exclude") or ""
        words = [w.strip() for w in exc.split(",") if w.strip()] if exc else None
        _lfd_with_exclusions(p.get("q", ""), p.get("ot", ""), words)
    elif a == "pv": _pv(p.get("vid"))
    elif a == "catalog_menu": _catalog_menu()
    elif a == "youtube_live_menu": _youtube_live_menu()
    elif a == "webcams_menu": _webcams.menu()
    elif a == "webcams_list": _webcams.lista(p.get("cat", ""), p.get("subcat", ""))
    elif a == "play_webcam": _webcams.play()
    elif a == "skyline_menu": _webcams.sky_menu()
    elif a == "skyline_paises": _webcams.sky_paises()
    elif a == "skyline_regiones": _webcams.sky_regiones()
    elif a == "skyline_categorias": _webcams.sky_categorias()
    elif a == "skyline_camaras": _webcams.sky_camaras()
    elif a == "skyline_open_browser": _webcams.sky_open_browser()
    elif a == "play_dash": _play_dash(p.get("stream_url", ""), p.get("title", ""))
    elif a == "play_latest_news": _play_latest_news()
    elif a == "press_menu": _pr.menu()
    elif a == "press_list": _pr.show_list(p.get("raw_url", ""), p.get("name", ""))
    elif a == "press_read": _pr.read(p.get("title", ""), p.get("desc", ""))
    elif a == "felicidad_menu": _felicidad_menu()
    elif a == "felicidad_list": _felicidad_list(p.get("cat", ""))
    elif a == "yt_search": _yts.search()
    elif a == "yt_search_results": _yts.search_results(p.get("query", ""))
    elif a == "remove_yt_history_item": _yts.remove_yt_history_item(p.get("q", ""))
    elif a == "clear_yt_history": _yts.clear_yt_history()
    elif a == "yt_toggle_watched": _ywt.toggle(p.get("yt_id", ""))
    elif a == "yt_queue_add": _yt_queue_add(p.get("yt_id", ""), p.get("name", ""))
    elif a == "felicidad_play": _felicidad_play(p.get("yt_id", ""), p.get("name", ""), p.get("ctype", "channel"), p.get("burl", ""))
    elif a == "felicidad_play_exec": _felicidad_play_exec(p.get("yt_id", ""), p.get("name", ""), p.get("method", "addon"))
    elif a == "cocina_menu": _cocina_menu()
    elif a == "cocina_list": _cocina_list(p.get("cat", ""))
    elif a == "educacion_menu": _educacion_menu()
    elif a == "educacion_list": _educacion_list(p.get("cat", ""))
    elif a == "arte_museos_menu": _arte_museos_menu()
    elif a == "arte_museos_list": _arte_museos_list(p.get("cat", ""))
    elif a == "arte_info_dialog":
        xbmcgui.Dialog().ok(p.get("title", "Info"), p.get("msg", ""))
    elif a == "loteria_menu": _loteria_mod.loteria_menu()
    elif a == "loteria_result": _loteria_mod.loteria_result(p.get("game_id", ""))
    elif a == "loteria_refresh": _loteria_mod.loteria_refresh(p.get("game_id", ""))
    elif a == "precio_luz_menu": precio_luz.precio_luz_menu()
    elif a == "precio_luz_refresh": precio_luz.precio_luz_refresh()
    elif a == "librivox_menu": librivox.librivox_menu()
    elif a == "librivox_list": librivox.librivox_list(
        page=p.get("page", 1),
        title_search=p.get("title_search", ""),
        author_search=p.get("author_search", ""),
        language=p.get("language", "Spanish"))
    elif a == "librivox_book": librivox.librivox_book(p.get("book_id", ""), p.get("title", ""))
    elif a == "librivox_search": librivox.librivox_search()
    elif a == "archive_documentales_es":      archive_org.show_documentales_es_menu()
    elif a == "archive_documentales_archive": archive_org.show_documentales_archive_submenu()
    elif a == "archive_felix":                archive_org.show_felix_menu()
    elif a == "archive_felix_archive":        archive_org.show_felix_archive_submenu()
    elif a == "archive_felix_rtve":           _rtve_mod.show_felix_rtve(int(p.get("page", 1)), p.get("prog_id", ""))
    elif a == "archive_felix_yt":             archive_org.show_felix_yt()
    elif a == "archive_punset":               archive_org.show_punset_menu()
    elif a == "archive_punset_rtve":          _rtve_mod.show_punset_rtve(int(p.get("page", 1)), p.get("prog_id", ""))
    elif a == "play_raw_url":                 import url_player; url_player.play_url_action(p.get("url", ""))
    elif a == "archive_audiobooks_es":     archive_org.show_audiobooks_es_menu()
    elif a == "archive_audiobooks_category": archive_org.show_audiobooks_category(p.get("q",""), p.get("page",1))
    elif a == "archive_play_audio":        archive_org.play_audio(p.get("archive_id",""), p.get("title",""))
    elif a == "efemerides_menu": efemerides.efemerides_menu()
    elif a == "ibex_menu":       ibex.ibex_menu()
    elif a == "ibex_historico":  ibex.ibex_historico()
    elif a == "ibex_empresas":   ibex.ibex_empresas()
    elif a == "ibex_refresh":    ibex.ibex_refresh()
    elif a == "sp500_menu":      ibex.sp500_menu()
    elif a == "sp500_historico": ibex.sp500_historico()
    elif a == "sp500_empresas":  ibex.sp500_empresas()
    elif a == "sp500_refresh":   ibex.sp500_refresh()
    elif a == "crypto_menu":     ibex.crypto_menu()
    elif a == "crypto_historico":ibex.crypto_historico()
    elif a == "crypto_empresas": ibex.crypto_empresas()
    elif a == "crypto_refresh":  ibex.crypto_refresh()
    elif a == "market_detail":   ibex.market_detail(p.get("ticker", ""), p.get("symbol", ""), p.get("name", ""))
    elif a == "stock_historico": ibex.stock_historico(p.get("symbol", ""), p.get("name", ""))
    elif a == "filmoteca_menu": _rtve_mod.show_filmoteca_menu()
    elif a == "filmoteca_seccion": _rtve_mod.show_filmoteca_seccion(p.get("q", ""), p.get("name", ""))
    elif a == "filmoteca_search": _rtve_mod.filmoteca_search()
    elif a == "dgt_menu": _dgt_mod.dgt_menu()
    elif a == "dgt_provincias": _dgt_mod.dgt_provincias()
    elif a == "dgt_lista": _dgt_mod.dgt_lista(p.get("filtro", ""), p.get("provincia", ""))
    elif a == "dgt_refresh": _dgt_mod.dgt_refresh()
    elif a == "dgt_camaras_provincia": _dgt_mod.dgt_camaras_provincia(p.get("provincia", ""))
    elif a == "dgt_camaras_refresh": _dgt_mod.dgt_camaras_refresh()
    elif a == "tv_autonomicas_menu": _tvaut_mod.tv_autonomicas_menu()
    elif a == "tv_autonomicas_refresh": _tvaut_mod.tv_autonomicas_refresh()
    elif a == "clasificaciones_menu": _clasif_mod.clasificaciones_menu()
    elif a == "clasificacion_tabla": _clasif_mod.clasificacion_tabla(p.get("comp_id", ""))
    elif a == "clasificacion_refresh": _clasif_mod.clasificacion_refresh(p.get("comp_id", ""))
    elif a == "resultados_menu": _clasif_mod.resultados_menu()
    elif a == "resultados_liga": _clasif_mod.resultados_liga(p.get("comp_id", ""))
    elif a == "resultados_refresh": _clasif_mod.resultados_refresh(p.get("comp_id", ""))
    elif a == "resultados_detalle": _clasif_mod.resultados_detalle(p.get("title", ""), p.get("plot", ""))
    elif a == "youtube_live_list": _youtube_live_list(p.get("cat", ""))
    elif a == "play_youtube_live": _play_youtube_live(p.get("yt_id", ""), p.get("title", ""))
    elif a == "youtube_install": _youtube_install_prompt()
    elif a == "yt_playlists_menu": _ytp.menu()
    elif a == "yt_playlist_add": _ytp.add_action()
    elif a == "yt_playlist_add_remote": _ytp.add_remote()
    elif a == "yt_playlist_open": _ytp.open_playlist(p.get("list_id", ""), p.get("name", ""))
    elif a == "yt_playlist_list": _ytp.show_list(p.get("list_id", ""), p.get("name", ""))
    elif a == "yt_playlist_open_exec":
        import threading
        threading.Thread(target=_ytp.open_exec, args=(p.get("list_id", ""), p.get("name", ""), p.get("method", "addon"))).start()
    elif a == "yt_playlist_remove":
        _ytp.remove_playlist(p.get("list_id", ""))
        xbmcgui.Dialog().notification("EspaTV", "Playlist eliminada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "podcast_menu": _podcast_menu()
    elif a == "podcast_feed": _podcast_feed(p.get("url", ""), p.get("title", ""))
    elif a == "play_podcast": _play_podcast(p.get("url", ""), p.get("title", ""))
    elif a == "most_watched": _most_watched()
    elif a == "clear_most_watched":
        if xbmcgui.Dialog().yesno("Confirmar", "¿Limpiar toda la lista de lo más visto?"):
            _wh._save([])
            xbmcgui.Dialog().notification("EspaTV", "Lista limpiada", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    elif a == "spanish_section": _spanish_section_menu(p.get("section", ""))
    elif a == "spanish_section_play_all": _spanish_section_play_all(p.get("section", ""))
    elif a == "play_ytdlp_by_id": _play_ytdlp_by_id(p.get("yt_id", ""), p.get("name", ""))
    elif a == "spanish_channel_videos": _spanish_channel_videos(p.get("user", ""), p.get("name", ""))
    elif a == "dm_playlists_search": _dm_playlists_search_menu()
    elif a == "dm_user_playlists": _dm_user_playlists_menu(p.get("user", ""))
    elif a == "dm_saved_playlists": _dm_saved_playlists_menu()
    elif a == "dm_view_playlist": _dm_view_playlist_menu(p.get("pid", ""))
    elif a == "dm_save_playlist":
        if _add_saved_playlist(p.get("pid", ""), p.get("name", ""), p.get("user", ""), int(p.get("count", 0))):
            xbmcgui.Dialog().notification("EspaTV", "Playlist guardada", xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification("EspaTV", "Ya estaba guardada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "dm_unsave_playlist":
        _remove_saved_playlist(p.get("pid", ""))
        xbmcgui.Dialog().notification("EspaTV", "Playlist eliminada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "info_menu": info_menu()
    elif a == "info_note":
        easter_egg_manager.trigger("info_note")
        _felicidad_play_exec(yt_id="dQw4w9WgXcQ", name="Never Gonna Give You Up", method="addon")
    elif a == "noop": pass
    elif a == "trololo":
        easter_egg_manager.trigger("trololo")
        _felicidad_play_exec(yt_id="2Z4m4lnjxkY", name="Trololo", method="addon")
    elif a == "keyboard_cat":
        easter_egg_manager.trigger("keyboard_cat")
        _felicidad_play_exec(yt_id="8WEe-MmC4ag", name="Keyboard Cat", method="addon")
    elif a == "caramelldansen":
        easter_egg_manager.trigger("caramelldansen")
        _felicidad_play_exec(yt_id="PfYnvDL0Qcw", name="Caramelldansen", method="addon")
    elif a == "nyan_cat":
        easter_egg_manager.trigger("nyan_cat")
        _felicidad_play_exec(yt_id="P6antjcBFZ4", name="Nyan Cat", method="addon")
    elif a == "money_money":
        easter_egg_manager.trigger("money_money")
        _felicidad_play_exec(yt_id="ETxmCCsMoD0", name="Money Money Money", method="addon")
    elif a == "video_killed_radio":
        easter_egg_manager.trigger("video_killed_radio")
        _felicidad_play_exec(yt_id="W8r-tXRLazs", name="Video Killed the Radio Star", method="addon")
    elif a == "check_repo_status": _check_repo_status_espatv()
    elif a == "vpn_info": _vpn_info()
    elif a == "yt_pc_info": _yt_pc_info()
    elif a == "info": _info()

    elif a == "install_espatv_repo": _install_espatv_repo()
    elif a == "web_info": _web_info()
    elif a == "manual_search": _manual_search()
    elif a == "top_movies": _tm.show(p.get("page"))
    elif a == "top_pelis_series_menu": _top_pelis_series_menu()
    elif a == "filmaffinity_menu":
        import filmaffinity; filmaffinity.menu()
    elif a == "filmaffinity_submenu":
        h = int(sys.argv[1])
        for lbl, act in [("En Cines España", "filmaffinity_cartelera"), ("Top Valoradas", "filmaffinity_top")]:
            li = xbmcgui.ListItem(label=lbl)
            li.setArt({'icon': 'DefaultVideoPlaylists.png'})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action=act), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
    elif a == "filmaffinity_list":
        import filmaffinity; filmaffinity.show_list(p.get("genre", ""))
    elif a == "filmaffinity_cartelera":
        import filmaffinity; filmaffinity.show_cartelera()
    elif a == "filmaffinity_top":
        import filmaffinity; filmaffinity.show_top()
    elif a == "filmaffinity_cache_cartelera_meta":
        import filmaffinity; filmaffinity.cache_cartelera_meta()
    elif a == "filmaffinity_clear_cartelera_meta":
        import filmaffinity; filmaffinity.clear_cartelera_meta()
    elif a == "sensacine_submenu":
        h = int(sys.argv[1])
        for lbl, act in [("En Cartelera", "sensacine_menu"), ("Estrenos", "sensacine_estrenos")]:
            li = xbmcgui.ListItem(label=lbl)
            li.setArt({'icon': 'DefaultVideoPlaylists.png'})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action=act), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
    elif a == "sensacine_menu":
        import sensacine; sensacine.show_cartelera()
    elif a == "sensacine_estrenos":
        import sensacine; sensacine.show_estrenos()
    elif a == "sensacine_cache_cartelera_meta":
        import sensacine; sensacine.cache_cartelera_meta()
    elif a == "sensacine_clear_cartelera_meta":
        import sensacine; sensacine.clear_cartelera_meta()
    elif a == "sensacine_cache_estrenos_meta":
        import sensacine; sensacine.cache_estrenos_meta()
    elif a == "sensacine_clear_estrenos_meta":
        import sensacine; sensacine.clear_estrenos_meta()
    elif a == "cinemeta_top":
        import cinemeta; cinemeta.show_top()
    elif a == "cinemeta_cache_meta":
        import cinemeta; cinemeta.cache_meta()
    elif a == "cinemeta_clear_meta":
        import cinemeta; cinemeta.clear_meta()
    elif a == "copy_title":
        t = p.get('title', '')
        if t and _copy_to_clipboard(t):
            xbmcgui.Dialog().notification("EspaTV", u"'{0}' copiado al portapapeles".format(t), xbmcgui.NOTIFICATION_INFO, 2500)
    elif a == "show_watch_providers":
        _show_watch_providers(p.get('title', ''), p.get('tmdb_id', ''))
    elif a == "search_movie_multi":
        _search_movie_multi(p.get('q', ''))
    elif a == "archive_menu":
        archive_org.show_menu()
    elif a == "archive_category":
        archive_org.show_category(p.get("q", ""), p.get("page", 1))
    elif a == "archive_search_ui":
        archive_org.search_ui()
    elif a == "archive_play":
        archive_org.play(p.get("archive_id", ""), p.get("title", ""))
    elif a == "tmdb_lists_menu":
        import tmdb_lists; tmdb_lists.show_menu()
    elif a == "tmdb_lists_show":
        import tmdb_lists; tmdb_lists.show_list(p.get("endpoint", ""), p.get("media_type", "movie"), p.get("page", 1))
    elif a == "letterboxd_menu":
        import letterboxd; letterboxd.show_menu()
    elif a == "letterboxd_list":
        import letterboxd; letterboxd.show_list(p.get("list_key", ""), p.get("list_url", ""))
    elif a == "letterboxd_cache_meta":
        import letterboxd; letterboxd.cache_list_meta(p.get("list_key", ""), p.get("list_url", ""))
    elif a == "letterboxd_clear_meta":
        import letterboxd; letterboxd.clear_list_meta(p.get("list_key", ""), p.get("list_url", ""))
    elif a == "advanced_menu": advanced_menu()
    elif a == "show_history": _sh.menu()
    elif a == "history_menu": _history_menu()
    elif a == "search_alt_prompt": _search_alternatives_prompt(p.get("q", ""), p.get("ot", ""))
    elif a == "clear_history": _sh.clear()
    elif a == "remove_history_item": _sh.remove(p.get("q"))
    elif a == "import_backup": _bk.import_backup()
    elif a == "toggle_debug": _toggle_debug()

    elif a == "toggle_recent": _toggle_recent()
    elif a == "set_min_duration": _set_min_duration_filter()
    elif a == "toggle_prioritize_match": _toggle_prioritize_match()
    elif a == "show_favorites": _show_favorites()
    elif a == "add_favorite":
         try:
             params = json.loads(p.get("params", "{}"))
         except (ValueError, TypeError):
             # Si el JSON viene mal formado, extraemos solo la 'q' del título
             params = {'q': p.get("title", "")}
         added = core_settings.add_favorite(p.get("title"), p.get("fav_url"), p.get("icon"), p.get("platform"), p.get("fav_action"), params)
         if added:
             xbmcgui.Dialog().notification("EspaTV", "Añadido a Favoritos", xbmcgui.NOTIFICATION_INFO)
         else:
             xbmcgui.Dialog().notification("EspaTV", "Ya existe en Favoritos", xbmcgui.NOTIFICATION_WARNING)
    elif a == "remove_favorite":
         core_settings.remove_favorite(p.get("fav_url"))
         xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_rename":
         kb = xbmc.Keyboard(p.get("old_title"), 'Renombrar Favorito')
         kb.doModal()
         if kb.isConfirmed():
             new_t = kb.getText()
             if new_t:
                 core_settings.rename_favorite(p.get("fav_url"), new_t)
                 xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_up":
         if core_settings.move_favorite(p.get("fav_url"), "up"):
             xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_down":
         if core_settings.move_favorite(p.get("fav_url"), "down"):
             xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_news": _show_fav_news()
    elif a == "yt_fav_news": _show_yt_fav_news()
    elif a == "fav_export": _bk.export_favorites()
    elif a == "fav_import": _bk.import_favorites()
    elif a == "show_downloads": _show_downloads()
    elif a == "remove_download":
         core_settings.remove_download(p.get("dl_path"))
         xbmc.executebuiltin("Container.Refresh")
    elif a == "delete_download_file":
         _delete_download_file(p.get("dl_path"), p.get("title"))
    elif a == "clear_cache": _clear_cache()
    elif a == "config_remote_port":
        _addon = xbmcaddon.Addon()
        _old = _addon.getSetting('remote_port') or '8089'
        _new = xbmcgui.Dialog().input("Puerto del servidor remoto", defaultt=_old, type=xbmcgui.INPUT_NUMERIC)
        if _new:
            _port_num = int(_new)
            if 1024 <= _port_num <= 65535:
                _addon.setSetting('remote_port', str(_port_num))
                xbmcgui.Dialog().notification("EspaTV", "Puerto cambiado a {0}".format(_port_num), xbmcgui.NOTIFICATION_INFO, 2000)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("EspaTV", "Puerto no válido.\nDebe estar entre 1024 y 65535.")
    elif a == "download_video": _download_video(p.get("vid"), p.get("title"))
    elif a == "toggle_advanced_search": _toggle_advanced_search()
    elif a == "advanced_search_menu": _advanced_search_menu()
    elif a == "setup_pvr": _setup_pvr()
    elif a == "open_pvr": xbmc.executebuiltin("ActivateWindow(TVGuide)")
    elif a == "execute_adv_search": _execute_adv_search(p.get("mode", ""))

    # --- CATEGORY MANAGER ROUTES ---
    elif a == "cat_menu": category_manager.main_menu()
    elif a == "cat_create": category_manager.create_category()
    elif a == "cat_delete": category_manager.delete_category(p.get("name"))
    elif a == "cat_rename": category_manager.rename_category(p.get("name"))
    elif a == "cat_view": category_manager.view_category(p.get("name"))
    elif a == "cat_add_item_dialog": category_manager.add_item_dialog(p.get("q"))
    elif a == "cat_remove_item": category_manager.remove_item(p.get("cat"), p.get("q"))
    elif a == "cat_move_item": category_manager.move_item(p.get("from_cat"), p.get("q"))
    elif a == "cat_export": category_manager.export_categories()
    elif a == "cat_import": category_manager.import_categories()
    elif a == "cat_move_from_favs": 
         # Acción compuesta: Añadir a categoría -> Si éxito -> Borrar de favoritos
         if category_manager.add_item_dialog(p.get("q")):
             removed = core_settings.remove_favorite(p.get("fav_url"))
             if not removed:
                 # Si el borrado de favoritos falla, avisamos; raro pero puede pasar con JSON corrupto
                 xbmcgui.Dialog().notification("EspaTV", "Error: No se pudo quitar de favoritos", xbmcgui.NOTIFICATION_ERROR)
             else:
                 time.sleep(0.2) # Pequeña pausa para asegurar escritura
                 xbmc.executebuiltin("Container.Refresh")
    

    

    elif a == "sanitized_info": _sanitized_info()
    elif a == "version_notes": _version_notes()
    elif a == "version_notes_v1": _version_notes_v1()
    elif a == "view_error_log": _view_error_log()
    elif a == "cache_top_movies_covers": _tm.cache_covers()
    elif a == "clear_top_movies_cache": _tm.clear_cache()
    elif a == "edit_and_search":

        q = p.get("q", "")
        ot = p.get("ot", "")
        kb = xbmc.Keyboard(q, 'Editar y Buscar')
        kb.doModal()
        if kb.isConfirmed():
             nq = kb.getText()
             if nq:


                 xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=nq, ot=ot)})")


    # --- TRAKT ACTIONS ---
    elif a == "elementum_search_prompt": _elementum_search_prompt()
    elif a == "elementum_search": _search_elementum(p.get("q"))
    elif a == "menu_collections":
        import trakt_manager
        trakt_manager.menu_collections()
    elif a == "trakt_root":
        import trakt_manager
        trakt_manager.menu_trakt_root()
    elif a == "trakt_options":
        import trakt_manager
        trakt_manager.menu_options()
    elif a == "trakt_help_guide":
        import trakt_manager
        trakt_manager.help_guide()
    elif a == "trakt_set_key":
        import trakt_manager
        trakt_manager.set_api_key()
    elif a == "trakt_import":
        import trakt_manager
        trakt_manager.import_list()
    elif a == "trakt_view_list":
        import trakt_manager
        trakt_manager.view_list(p.get("list_id"), p.get("show_covers") == "1")
    elif a == "trakt_delete_list":
        import trakt_manager
        trakt_manager.delete_list(p.get("list_id"))
    elif a == "trakt_cache_covers":
        import trakt_manager
        trakt_manager.cache_covers(p.get("list_id"))
    elif a == "trakt_clear_cache":
        import trakt_manager
        trakt_manager.clear_cache(p.get("list_id"))
    elif a == "trakt_refresh_defaults":
        import trakt_manager
        trakt_manager.refresh_all_lists()




    # --- URL PLAYER ---
    elif a == "open_url":
        import url_player; url_player.open_url_dialog()
    elif a == "url_input":
        import url_player; url_player.url_input()
    elif a == "url_remote":
        import url_remote; url_remote.start_remote()
    elif a == "url_history":
        import url_player; url_player.url_history_menu()
    elif a == "url_history_clear":
        import url_player; url_player.history_clear()
    elif a == "url_history_remove":
        import url_player; url_player.history_remove(p.get("url"))
    elif a == "url_bookmarks":
        import url_player; url_player.url_bookmarks_menu()
    elif a == "url_bookmark_save_from_history":
        import url_player; url_player.bookmark_save_from_history(p.get("url"))
    elif a == "url_bookmark_rename":
        import url_player; url_player.bookmark_rename(p.get("url"))
    elif a == "url_bookmark_delete":
        import url_player; url_player.bookmark_delete(p.get("url"))
    elif a == "url_play":
        import url_player; url_player.play_url_action(p.get("url"))
    elif a == "url_scan":
        import url_player; url_player.scan_videos_dialog()
    elif a == "url_player_ensure_sn":
        import url_player; url_player.url_player_ensure_streamninja()

    # --- DM PLAYLISTS ---
    elif a == "dm_playlists_search": _dm_playlists_search()
    elif a == "dm_user_playlists": _dm_user_playlists(p.get("user"))
    elif a == "dm_view_playlist": _dm_view_playlist(p.get("pid"))

    # --- DM SETTINGS ---
    elif a == "set_dm_safe_level": _set_dm_safe_level()
    elif a == "set_dl_mode": _set_dl_mode()

    # --- SEARCH EXTERNAL ---
    elif a == "search_external_prompt": _search_external_prompt(p.get("q"))
    elif a == "dm_gujal_search": _search_dailymotion_gujal(p.get("q"))

    # --- TDT / TV EN DIRECTO ---
    elif a == "live_tv_menu": live_tv_menu()
    elif a == "slyguy_install": _slyguy.install(p.get("addon_id", ""), p.get("title", "Addon"))
    elif a == "tdt_channels_json": tdt_channels_json()
    elif a == "tdt_json_ambit": tdt_json_ambit(p.get("url", ""))
    elif a == "tdt_channels": tdt_channels()
    elif a == "play_tdt": play_tdt(p.get("url", ""), p.get("title", ""), p.get("ua", ""), p.get("ref", ""))
    elif a == "add_custom_iptv": add_custom_iptv()
    elif a == "freetv_menu": freetv_menu()
    elif a == "view_custom_iptv": view_custom_iptv(p.get("url", ""))
    elif a == "delete_custom_iptv": delete_custom_iptv(p.get("url", ""))

    # --- RADIO / TDT POR REGIÓN ---
    elif a == "radio_menu":
        import tdt_providers; tdt_providers.radio_menu()
    elif a == "radio_group":
        import tdt_providers; tdt_providers.radio_group(p.get("group", ""))
    elif a == "play_radio":
        import tdt_providers; tdt_providers.play_radio(p.get("url", ""), p.get("title", ""))


    # --- RTVE PLAY ---
    elif a == "rtve_menu":
        import rtve_catalog; rtve_catalog.main_menu()
    elif a == "rtve_live":
        import rtve_catalog; rtve_catalog.live_channels()
    elif a == "play_rtve_live":
        import rtve_catalog; rtve_catalog.play_live(p.get("url", ""), p.get("title", ""))
    elif a == "rtve_category":
        import rtve_catalog; rtve_catalog.category(p.get("cat_id", ""), p.get("cat_name", ""), int(p.get("page", "1")), p.get("parent_id", ""))
    elif a == "rtve_search":
        import rtve_catalog; rtve_catalog.search()
    elif a == "rtve_open_web":
        import rtve_catalog; rtve_catalog.open_web(p.get("url", ""), p.get("title", ""))
    elif a == "play_rtve_video":
        import rtve_catalog; rtve_catalog.play_video(p.get("video_id", ""), p.get("title", ""))

    # --- WATCH HISTORY ---
    elif a == "watch_history": _wh.show()
    elif a == "del_watch_entry": _wh.del_entry(p.get("url", ""))
    elif a == "clear_watch_history": _wh.clear()

    # --- PVR NATIVO ---
    elif a == "record_stream":
        import pvr_recorder_manager
        pvr_recorder_manager.start_recording_ui(p.get("url", ""), p.get("name", "Grabacion Automatica"))
    elif a == "stop_recording":
        import pvr_recorder_manager
        pvr_recorder_manager.stop_all_recordings()
    elif a == "my_recordings_menu":
        _my_recordings_menu()
    elif a == "delete_recording":
        file_path = p.get("file", "")
        if file_path and xbmcvfs.exists(file_path):
            if xbmcgui.Dialog().yesno("Borrar Grabación", "¿Seguro que quieres borrar este archivo de tu disco duro?\n\n{0}".format(os.path.basename(file_path))):
                xbmcvfs.delete(file_path)
                xbmc.executebuiltin("Container.Refresh")
    elif a == "open_settings":
        xbmcaddon.Addon().openSettings()

    # --- TRENDING / MULTI-SEARCH ---
    elif a == "trending": _show_trending()
    elif a == "multi_search": _multi_search()

    # --- UTILIDADES ---
    elif a == "dm_open_browser": _dm_open_browser(p.get("url", ""))
    elif a == "agenda_open_browser":
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        _felicidad_open_browser(p.get("url", ""))
    elif a == "copy_url": _copy_url(p.get("url", ""))
    elif a == "url_play_clipboard":
        import url_player; url_player.play_clipboard()
    elif a == "log_menu": _lm.menu()
    elif a == "view_kodi_log": _lm.view_log()
    elif a == "view_kodi_log_full": _lm.view_full()
    elif a == "view_kodi_log_errors": _lm.view_errors()
    elif a == "search_kodi_log": _lm.search()
    elif a == "log_info": _lm.info()
    elif a == "export_log": _lm.export()
    elif a == "view_log_visual": _lm.view_visual()
    elif a == "show_log_line": _lm.show_line(p.get("data", ""))
    elif a == "clear_error_log": _lm.clear_error()
    elif a == "open_flowfav": _open_flowfav()
    elif a == "flowfav_install": _flowfav_install()
    elif a == "set_cache_config": _set_cache_config()
    elif a == "toggle_iptv_cache": _toggle_iptv_cache()
    elif a == "set_iptv_cache_ttl": _set_iptv_cache_ttl_dialog()
    elif a == "reset_iptv_cache": _reset_iptv_cache()
    elif a == "set_download_path": _set_download_path()
    elif a == "toggle_inputstream": _toggle_inputstream()
    elif a == "toggle_iptv_anti_errors": _toggle_iptv_anti_errors()
    elif a == "toggle_force_white_text": _toggle_force_white_text()
    elif a == "toggle_dev_mode": _toggle_dev_mode()
    elif a == "accessibility_menu": accessibility_menu()
    elif a == "acc_set_color_mode": _acc_set_color_mode()
    elif a == "acc_toggle_bold": _acc_toggle_bold()
    elif a == "acc_toggle_symbols": _acc_toggle_symbols()

    # --- BACKUPS ---
    elif a == "backups_menu": _bk.menu()
    elif a == "create_backup_full": _bk.create_full()
    elif a == "list_backups": _bk.list_backups()
    elif a == "restore_backup_selective": _bk.restore_selective(p.get("file", ""))
    elif a == "delete_single_backup": _bk.delete_single(p.get("file", ""))
    elif a == "slyguy_install": _slyguy.install(p.get("addon_id", ""), p.get("title", "Addon"))
    elif a == "export_favs_txt": _bk.export_favorites_txt()
    elif a == "open_atresdaily": _open_atresdaily()
    elif a == "open_espadaily": _open_espadaily()
    elif a == "open_loiolog": _open_loiolog()
    elif a == "loiolog_install": _loiolog_install()

    # --- EL TIEMPO (AEMET) ---
    elif a == "aemet_menu":
        import aemet_weather
        aemet_weather.show_aemet_menu(int(sys.argv[1]), _u)
    elif a == "aemet_search":
        import aemet_weather
        aemet_weather.search_location_ui(int(sys.argv[1]), _u)
    elif a == "aemet_save":
        import aemet_weather
        aemet_weather.save_location(p.get("name", ""), p.get("code", ""))
        xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="aemet_menu")))
    elif a == "aemet_remove":
        import aemet_weather
        aemet_weather.remove_location(p.get("code", ""))
        xbmc.executebuiltin("Container.Refresh")
    elif a == "aemet_forecast":
        import aemet_weather
        aemet_weather.show_forecast(int(sys.argv[1]), _u, p.get("code", ""), p.get("name", ""))
    elif a == "aemet_day_info":
        import aemet_weather
        aemet_weather.show_day_info(p.get("code", ""), p.get("name", ""), p.get("day_index", "0"))

    # --- AGENDA DEPORTIVA ---
    elif a == "agenda_menu":
        import espatv_agenda
        espatv_agenda.show_agenda_menu(int(sys.argv[1]), _u)
    elif a == "agenda_events":
        import espatv_agenda
        espatv_agenda.show_agenda_events(int(sys.argv[1]), _u, p.get("sport", ""))
    elif a == "agenda_event_options":
        import espatv_agenda
        espatv_agenda.show_event_options(int(sys.argv[1]), _u, p)
    elif a == "agenda_event_info":
        import espatv_agenda
        espatv_agenda.show_event_info(p)
    elif a == "agenda_futbolenlatv":
        import espatv_agenda
        espatv_agenda.show_futbolenlatv(int(sys.argv[1]), _u)
    elif a == "agenda_futbolhoy":
        import espatv_agenda
        espatv_agenda.show_futbolhoy(int(sys.argv[1]), _u)
    elif a == "agenda_baloncestohoy":
        import espatv_agenda
        espatv_agenda.show_baloncestohoy(int(sys.argv[1]), _u)
    elif a == "agenda_tenishoy":
        import espatv_agenda
        espatv_agenda.show_tenishoy(int(sys.argv[1]), _u)
    elif a == "agenda_sport_channels":
        import espatv_agenda
        espatv_agenda.show_sport_channels_menu(int(sys.argv[1]), _u)
    elif a == "agenda_formulatv":
        import espatv_agenda
        espatv_agenda.show_formulatv_channel(int(sys.argv[1]), _u, p.get("slug", ""), p.get("day", ""))
    elif a == "agenda_refresh":
        import espatv_agenda
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        espatv_agenda.force_refresh()
        try:
            xbmcgui.Dialog().notification(
                "Agenda Deportiva",
                "Actualizando datos…",
                xbmcgui.NOTIFICATION_INFO,
                2500,
            )
        except RuntimeError:
            pass
        xbmc.executebuiltin("Container.Refresh")
    elif a == "agenda_day":
        import espatv_agenda
        espatv_agenda.show_agenda_day(int(sys.argv[1]), _u, int(p.get("day", 1)))
    elif a == "agenda_filters":
        import espatv_agenda
        espatv_agenda.show_agenda_filters(int(sys.argv[1]), _u)
    elif a == "agenda_channels":
        import espatv_agenda
        espatv_agenda.show_agenda_channels(int(sys.argv[1]), _u)
    elif a == "agenda_competitions":
        import espatv_agenda
        espatv_agenda.show_agenda_competitions(int(sys.argv[1]), _u)
    elif a == "agenda_search":
        import espatv_agenda
        espatv_agenda.show_agenda_search(int(sys.argv[1]), _u, prefilled_query=p.get("query"))
    elif a == "agenda_search_all":
        import espatv_agenda
        espatv_agenda.show_agenda_search_all(int(sys.argv[1]), _u, prefilled_query=p.get("query"))
    elif a == "agenda_live_all":
        import espatv_agenda
        espatv_agenda.show_agenda_live_all(int(sys.argv[1]), _u)
    elif a == "search_acestream_prompt":
        _search_acestream_prompt()
    elif a == "search_acestream_results":
        _search_acestream_results(p.get("q", ""))
    elif a == "play_ace_result":
        _play_ace_result(p.get("infohash", ""), p.get("name", ""))
    elif a == "agenda_favorite_toggle":
        import espatv_agenda
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        espatv_agenda.toggle_favorite(p.get("category", ""), p.get("value", ""))
        xbmc.executebuiltin("Container.Refresh")

    # --- UNIVERSO ---
    elif a == "show_universo":
        import universo; universo.show()

    # --- YT-DLP MANTENIMIENTO PC ---
    elif a == "ytdlp_menu": _ytdlp_menu()
    elif a == "ytdlp_instructions": _show_ytdlp_instructions()
    elif a == "ytdlp_check": _check_ytdlp_status()

    else: 
        main_menu()

if __name__ == "__main__":
    try:
        _old = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), '.legal_accepted')
        if os.path.exists(_old):
            os.remove(_old)
    except OSError:
        pass

    stats.ping()

    # Comprobación remota de validez (fail-open: sin red, no bloqueamos al usuario)
    try:
        if not _check_validity():
            xbmcgui.Dialog().ok("EspaTV", "La versión actual del addon está obsoleta o ha sido desactivada temporalmente.\n\nPor favor, actualiza el addon desde el repositorio oficial (GitHub).")
            sys.exit(0)
    except (requests.RequestException, ValueError, OSError):
        pass

    try:
        _hf_win = xbmcgui.Window(10000)
        if not _hf_win.getProperty("espatv_hotfix_checked"):
            _hf_win.setProperty("espatv_hotfix_checked", "1")
            import hotfix as _hf
            import threading
            threading.Thread(
                target=_hf.check_and_apply, name="HotfixRunner", daemon=True
            ).start()
    except Exception:
        pass

    # Auto-limpieza silenciosa de archivos dated viejos (scores_*_YYYYMMDD.json
    # con > 14 días). No bloquea ni avisa al usuario; nunca rompe el arranque.
    try:
        import storage_manager as _sm
        _sm.limpiar_dated()
    except Exception:
        pass

    try:
        router(sys.argv[2][1:])
    except Exception as e:
        import traceback
        _log_error("Unhandled exception: {0}\n{1}".format(e, traceback.format_exc()))
        xbmcgui.Dialog().ok("EspaTV - Error", "Ocurrió un error inesperado al procesar la ruta.\n\nConsulta el log de errores en Ajustes Avanzados.")