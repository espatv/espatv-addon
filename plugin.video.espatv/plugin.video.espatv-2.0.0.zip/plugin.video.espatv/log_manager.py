# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Visor, buscador y exportador del log de Kodi."""
import base64
import json
import os
import re
import sys
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _debug_state_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, 'debug_state.json')


def _is_debug_active():
    f = _debug_state_file()
    if not os.path.exists(f):
        return False
    try:
        with open(f, 'r', encoding='utf-8') as o:
            return json.load(o).get('active', False)
    except (OSError, ValueError):
        return False


def sanitize_line(line):
    line = re.sub(r'(access_token=)[^&\s]+', lambda m: m.group(1) + '***', line)
    line = re.sub(r'(bearer=)[^&\s]+',       lambda m: m.group(1) + '***', line)
    line = re.sub(r'(hdnts=)[^&\s]+',        lambda m: m.group(1) + '***', line)
    line = re.sub(r'(token=)[^&\s]+',        lambda m: m.group(1) + '***', line)
    line = re.sub(r'(Authorization:\s*Bearer\s+)\S+', lambda m: m.group(1) + '***', line, flags=re.IGNORECASE)
    return line


def view_log():
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaTV", "No se encontró el archivo de log de Kodi.")
            return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        last_lines = lines[-100:]
        espa_lines = [sanitize_line(l.rstrip()) for l in last_lines if 'EspaTV' in l.lower() or 'espakodi' in l.lower()]
        if not espa_lines:
            espa_lines = [sanitize_line(l.rstrip()) for l in last_lines[-30:]]
        xbmcgui.Dialog().textviewer("Log de Kodi (EspaTV)", "\n".join(espa_lines[-50:]))
    except OSError as e:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el log:\n{0}".format(e))


def view_full():
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaTV", "No se encontró el archivo de log de Kodi.")
            return
        opts   = ["Últimas 50 líneas", "Últimas 100 líneas", "Últimas 200 líneas"]
        counts = [50, 100, 200]
        sel = xbmcgui.Dialog().select("¿Cuántas líneas?", opts)
        if sel < 0:
            return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        xbmcgui.Dialog().textviewer("Log de Kodi (completo)", "".join(sanitize_line(l) for l in lines[-counts[sel]:]))
    except OSError as e:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el log:\n{0}".format(e))


def view_errors():
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaTV", "No se encontró el archivo de log de Kodi.")
            return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        error_lines = [sanitize_line(l.rstrip()) for l in lines[-500:]
                       if ' error ' in l.lower() or 'warning' in l.lower()
                       or 'exception' in l.lower() or 'traceback' in l.lower()]
        if not error_lines:
            xbmcgui.Dialog().ok("EspaTV", "No se encontraron errores recientes en el log.")
            return
        xbmcgui.Dialog().textviewer("Errores del Log de Kodi", "\n".join(error_lines[-80:]))
    except OSError as e:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el log:\n{0}".format(e))


def search():
    kb = xbmc.Keyboard('', 'Buscar en el log de Kodi')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        return
    term     = kb.getText().strip().lower()
    term_raw = kb.getText().strip()
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaTV", "No se encontró el archivo de log.")
            return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        matches = [sanitize_line(l.rstrip()) for l in lines if term in l.lower()]
        if not matches:
            xbmcgui.Dialog().ok("EspaTV", "No se encontró '{0}' en el log.".format(term_raw))
            return
        xbmcgui.Dialog().textviewer(
            "{0} resultados para '{1}'".format(len(matches), term_raw),
            "\n".join(matches[-80:]),
        )
    except OSError as e:
        xbmcgui.Dialog().ok("Error", str(e))


def info():
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        msg = "[B]Log de Kodi[/B]\n"
        if os.path.exists(log_path):
            size = os.path.getsize(log_path)
            with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
                total_lines = sum(1 for _ in f)
            msg += "Tamaño: {0:.1f} {1}\n".format(
                size / 1048576 if size > 1048576 else size / 1024,
                "MB" if size > 1048576 else "KB",
            )
            msg += "Líneas: {0:,}\n".format(total_lines)
            msg += "Ruta: {0}\n".format(log_path)
        else:
            msg += "No encontrado\n"
        msg += "\n[B]Log Interno EspaTV[/B]\n"
        base_dir = os.path.dirname(os.path.abspath(__file__))
        err_log  = os.path.join(base_dir, 'EspaTV_errors.log')
        if os.path.exists(err_log):
            esize = os.path.getsize(err_log)
            with open(err_log, 'r', encoding='utf-8', errors='replace') as f:
                elines = sum(1 for _ in f)
            msg += "Tamaño: {0:.1f} KB\n".format(esize / 1024)
            msg += "Líneas: {0:,}\n".format(elines)
            msg += "Debug: {0}".format("ACTIVADO" if _is_debug_active() else "DESACTIVADO")
        else:
            msg += "No existe (activa Debug para generarlo)"
        xbmcgui.Dialog().textviewer("Información de Logs", msg)
    except OSError as e:
        xbmcgui.Dialog().ok("Error", str(e))


def export():
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaTV", "No se encontró el archivo de log de Kodi.")
            return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        opts = ["Solo entradas de EspaTV", "Log completo (últimas 500 líneas)", "Solo errores y warnings"]
        sel = xbmcgui.Dialog().select("¿Qué exportar?", opts)
        if sel < 0:
            return
        if sel == 0:
            filtered = [sanitize_line(l) for l in lines if 'EspaTV' in l.lower() or 'espakodi' in l.lower()]
            suffix   = "EspaTV"
        elif sel == 1:
            filtered = [sanitize_line(l) for l in lines[-500:]]
            suffix   = "completo"
        else:
            filtered = [sanitize_line(l) for l in lines
                        if ' error ' in l.lower() or 'warning' in l.lower()
                        or 'exception' in l.lower() or 'traceback' in l.lower()]
            suffix = "errores"
        if not filtered:
            xbmcgui.Dialog().ok("EspaTV", "No hay entradas que exportar.")
            return
        d = xbmcgui.Dialog().browse(3, 'Guardar log exportado', 'files')
        if not d:
            return
        fname = "kodi_log_{0}_{1}.txt".format(suffix, time.strftime("%Y%m%d_%H%M%S"))
        dest  = os.path.join(d, fname) if os.path.isdir(d) else (d if d.lower().endswith('.txt') else d + '.txt')
        with open(dest, 'w', encoding='utf-8') as f:
            f.write("Log exportado por EspaTV -- {0}\n".format(time.strftime('%d/%m/%Y %H:%M:%S')))
            f.write("Tipo: {0}\nLíneas: {1}\n{2}\n\n".format(opts[sel], len(filtered), "=" * 60))
            f.writelines(filtered)
        xbmcgui.Dialog().ok("Exportado", "Log guardado en:\n{0}\n\n{1} líneas exportadas.".format(dest, len(filtered)))
    except OSError as e:
        xbmcgui.Dialog().ok("Error", "No se pudo exportar:\n{0}".format(e))


def clear_error():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    log_file = os.path.join(base_dir, 'EspaTV_errors.log')
    if not os.path.exists(log_file):
        xbmcgui.Dialog().ok("EspaTV", "No existe el archivo de log interno.")
        return
    size_kb = os.path.getsize(log_file) / 1024
    if xbmcgui.Dialog().yesno("EspaTV", "¿Eliminar el log interno?\n\nTamaño: {0:.1f} KB".format(size_kb)):
        try:
            os.remove(log_file)
            xbmcgui.Dialog().notification("EspaTV", "Log interno eliminado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except OSError as e:
            xbmcgui.Dialog().ok("Error", str(e))


def view_visual():
    log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
    if not os.path.exists(log_path):
        xbmcgui.Dialog().ok("EspaTV", "No se encontró el archivo de log de Kodi.")
        return
    opts = ["Últimas 50 líneas", "Últimas 100 líneas", "Últimas 200 líneas", "Solo EspaTV", "Solo errores"]
    sel = xbmcgui.Dialog().select("Modo de vista", opts)
    if sel < 0:
        return
    try:
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            all_lines = f.readlines()
    except OSError as e:
        xbmcgui.Dialog().ok("Error", str(e))
        return
    if sel == 0:
        lines = all_lines[-50:]
    elif sel == 1:
        lines = all_lines[-100:]
    elif sel == 2:
        lines = all_lines[-200:]
    elif sel == 3:
        lines = [l for l in all_lines if 'EspaTV' in l.lower() or 'espakodi' in l.lower()][-100:]
    else:
        lines = [l for l in all_lines if ' error ' in l.lower() or 'exception' in l.lower() or 'traceback' in l.lower()][-100:]
    if not lines:
        xbmcgui.Dialog().ok("EspaTV", "No hay entradas que mostrar.")
        return
    h = int(sys.argv[1])
    for raw in lines:
        line = sanitize_line(raw.rstrip())
        ll   = line.lower()
        if ' error ' in ll or 'exception' in ll or 'traceback' in ll:
            sev = 'error'
        elif 'warning' in ll:
            sev = 'warning'
        elif 'espatv' in ll or 'espakodi' in ll:
            sev = 'espa'
        elif ' debug ' in ll:
            sev = 'debug'
        else:
            sev = 'info'
        ts_display = ""
        if len(line) > 23 and line[4] == '-' and line[10] == ' ':
            ts_display = line[11:19]
            body = line[23:].strip()
            if body.startswith("T:"):
                idx = body.find(' ')
                if idx > 0:
                    body = body[idx:].strip()
            for tag in ['info <general>:', 'error <general>:', 'warning <general>:', 'debug <general>:', 'notice <general>:']:
                if body.lower().startswith(tag):
                    body = body[len(tag):].strip()
                    break
        else:
            body = line
        label_text = body[:117] + "..." if len(body) > 120 else body
        if sev == 'error':
            label = "[COLOR red][B]X[/B][/COLOR] "
            if ts_display: label += "[COLOR grey]{0}[/COLOR] ".format(ts_display)
            label += "[COLOR red]{0}[/COLOR]".format(label_text)
            icon = 'DefaultIconError.png'
        elif sev == 'warning':
            label = "[COLOR yellow][B]![/B][/COLOR] "
            if ts_display: label += "[COLOR grey]{0}[/COLOR] ".format(ts_display)
            label += "[COLOR yellow]{0}[/COLOR]".format(label_text)
            icon = 'DefaultIconWarning.png'
        elif sev == 'espa':
            label = "[COLOR limegreen][B]*[/B][/COLOR] "
            if ts_display: label += "[COLOR grey]{0}[/COLOR] ".format(ts_display)
            label += "[COLOR limegreen]{0}[/COLOR]".format(label_text)
            icon = 'DefaultIconInfo.png'
        elif sev == 'debug':
            label = "[COLOR grey]-"
            if ts_display: label += " {0}".format(ts_display)
            label += " {0}[/COLOR]".format(label_text)
            icon = 'DefaultIconInfo.png'
        else:
            label = "[COLOR white]-[/COLOR] "
            if ts_display: label += "[COLOR grey]{0}[/COLOR] ".format(ts_display)
            label += label_text
            icon = 'DefaultIconInfo.png'
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon})
        li.setInfo('video', {'plot': line})
        encoded = base64.b64encode(line.encode('utf-8')).decode('ascii')
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="show_log_line", data=encoded), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def show_line(data):
    try:
        xbmcgui.Dialog().textviewer("Detalle del Log", base64.b64decode(data).decode('utf-8'))
    except (ValueError, UnicodeDecodeError):
        xbmcgui.Dialog().ok("Error", "No se pudo decodificar la entrada.")


def menu():
    h = int(sys.argv[1])
    base_dir = os.path.dirname(os.path.abspath(__file__))
    err_log  = os.path.join(base_dir, 'EspaTV_errors.log')

    for label, plot, action, is_folder in [
        ("[COLOR limegreen]Log de EspaTV (filtrado)[/COLOR]",
         "Muestra las últimas entradas del log de Kodi que mencionan EspaTV.\nTokens y datos sensibles se censuran automáticamente.",
         "view_kodi_log", False),
        ("[COLOR magenta][B]Visor del Log[/B][/COLOR]",
         "Muestra cada línea del log como un elemento visual individual.\nCodificado por colores según severidad:\n\n[COLOR red]X Error[/COLOR]\n[COLOR yellow]! Warning[/COLOR]\n[COLOR limegreen]* EspaTV[/COLOR]\n[COLOR white]- Info[/COLOR]\n[COLOR grey]- Debug[/COLOR]",
         "view_log_visual", True),
        ("Log de Kodi (completo)",
         "Muestra las últimas líneas del log completo de Kodi, sin filtrar.\nPuedes elegir cuántas líneas ver.",
         "view_kodi_log_full", False),
        ("[COLOR red]Solo Errores y Warnings[/COLOR]",
         "Filtra el log para mostrar solo líneas de error, warning, exception y traceback.",
         "view_kodi_log_errors", False),
        ("[COLOR cyan]Buscar en el Log[/COLOR]",
         "Escribe un texto para buscar en todo el log de Kodi.\nMuestra todas las líneas que coinciden.",
         "search_kodi_log", False),
        ("Exportar Log a archivo",
         "Guarda el log filtrado, completo o de errores en un archivo TXT.\nÚtil para compartir o enviar a soporte.",
         "export_log", False),
        ("Información del Log",
         "Muestra el tamaño, número de líneas y ruta del log de Kodi y del log interno.",
         "log_info", False),
    ]:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=is_folder)

    if os.path.exists(err_log):
        esize = os.path.getsize(err_log) / 1024
        li = xbmcgui.ListItem(label="[COLOR gold]Log Interno ({0:.0f} KB)[/COLOR]".format(esize))
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'plot': "Lee el archivo EspaTV_errors.log generado por el Modo Debug."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_error_log"), listitem=li, isFolder=False)
        li = xbmcgui.ListItem(label="[COLOR red]Borrar Log Interno[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        li.setInfo('video', {'plot': "Elimina el archivo EspaTV_errors.log para liberar espacio."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="clear_error_log"), listitem=li, isFolder=False)

    if xbmc.getCondVisibility("System.HasAddon(plugin.program.loiolog)"):
        ll_label  = "LoioLog: [COLOR green]INSTALADO[/COLOR]"
        ll_action = "open_loiolog"
    else:
        ll_label  = "LoioLog: [COLOR grey]NO INSTALADO[/COLOR]"
        ll_action = "loiolog_install"
    li = xbmcgui.ListItem(label=ll_label)
    li.setArt({'icon': 'DefaultAddonProgram.png'})
    li.setInfo('video', {'plot': "LoioLog es un gestor avanzado de logs para Kodi.\nPermite ver, filtrar, buscar, analizar y exportar los logs del sistema.\n\nSi no está instalado, pulsa para descargarlo e instalarlo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action=ll_action), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
