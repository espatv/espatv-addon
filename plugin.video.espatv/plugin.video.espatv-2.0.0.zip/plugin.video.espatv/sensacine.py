# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Cartelera y estrenos de SensaCine."""
import html
import json
import os
import re
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from _user_agents import desktop_headers as _dh, ACCEPT_HTML

_CARTELERA_URL = "https://www.sensacine.com/peliculas/en-cartelera/cines/"
_ESTRENOS_URL  = "https://www.sensacine.com/peliculas/estrenos/"
_HEADERS = _dh(accept=ACCEPT_HTML, referer="https://www.sensacine.com/")
_SC_TTL = 6 * 3600
_SC_MIN_FILMS = 3


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espatv_sc_cache.json')


def _load_cache():
    empty = {"cartelera": {}}
    try:
        path = _cache_path()
        if not os.path.exists(path):
            return empty
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data.get("cartelera"), dict):
            return empty
        return data
    except (OSError, ValueError) as e:
        xbmc.log("[EspaTV-SC] cache load error: {0}".format(e), xbmc.LOGWARNING)
        return empty


def _save_cache(data):
    try:
        path = _cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError as e:
        xbmc.log("[EspaTV-SC] cache save error: {0}".format(e), xbmc.LOGWARNING)


def _cache_fresh(cache):
    c = cache.get("cartelera", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


def _scrape_cartelera():
    try:
        r = requests.get(_CARTELERA_URL, headers=_HEADERS, timeout=12)
        xbmc.log("[EspaTV-SC] cartelera -> {0}".format(r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+class="[^"]*entity-card[^"]*")', r.text):
            id_m = re.search(r'/peliculas/pelicula-(\d+)/', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="meta-title-link"[^>]*>([^<]+)</a>', block)
            if not title_m:
                continue
            seen.add(fid)
            title = html.unescape(title_m.group(1).strip())
            img_m = re.search(r'data-src="(https://[^"]+acsta\.net[^"]*)"', block)
            if not img_m:
                img_m = re.search(r'\bsrc="(https://[^"]+acsta\.net[^"]*)"', block)
            poster = img_m.group(1) if img_m else ''
            films.append({'id': fid, 'title': title, 'poster': poster})
        if len(films) < _SC_MIN_FILMS:
            xbmc.log(
                "[EspaTV-SC] resultado sospechoso ({0} films), ignorando".format(len(films)),
                xbmc.LOGWARNING,
            )
            return None
        xbmc.log("[EspaTV-SC] scrapeadas {0} películas".format(len(films)), xbmc.LOGINFO)
        return films
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-SC] scrape error: {0}".format(e), xbmc.LOGERROR)
        return None


def _fetch_cartelera():
    cache = _load_cache()

    if _cache_fresh(cache):
        films = cache["cartelera"]["films"]
        xbmc.log(
            "[EspaTV-SC] cartelera desde caché ({0} títulos)".format(len(films)),
            xbmc.LOGINFO,
        )
        return films

    scraped = _scrape_cartelera()
    if scraped is not None:
        films = scraped
        cache["cartelera"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("cartelera", {}).get("films"):
        films = cache["cartelera"]["films"]
        xbmc.log("[EspaTV-SC] SC inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_cartelera():
    import metadata_enricher as me

    films = _fetch_cartelera()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar SensaCine", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False

    if not has_meta:
        li = xbmcgui.ListItem(label="[COLOR yellow][B]>>> Descargar metadatos completos (actores, director...) <<<[/B][/COLOR]")
        li.setArt({'icon': 'DefaultAddonService.png'})
        li.setInfo('video', {'plot': "Descarga sinopsis en español, actores y director de las películas en cartelera."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_cache_cartelera_meta"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="[COLOR red]Borrar metadatos de cartelera[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        li.setInfo('video', {'plot': "Elimina los metadatos guardados de la cartelera actual."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_clear_cartelera_meta"), listitem=li, isFolder=False)

    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "RunPlugin({0})".format(
                _u(action='search_movie_multi', q=f['title']))),
            ("Copiar título", "RunPlugin({0})".format(
                _u(action='copy_title', title=f['title']))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def _estrenos_fresh(cache):
    c = cache.get("estrenos", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


def _scrape_estrenos():
    try:
        r = requests.get(_ESTRENOS_URL, headers=_HEADERS, timeout=12)
        xbmc.log("[EspaTV-SC] estrenos -> {0}".format(r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+class="[^"]*entity-card[^"]*")', r.text):
            id_m = re.search(r'/peliculas/pelicula-(\d+)/', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="meta-title-link"[^>]*>([^<]+)</a>', block)
            if not title_m:
                continue
            seen.add(fid)
            title = html.unescape(title_m.group(1).strip())
            img_m = re.search(r'data-src="(https://[^"]+acsta\.net[^"]*)"', block)
            if not img_m:
                img_m = re.search(r'\bsrc="(https://[^"]+acsta\.net[^"]*)"', block)
            poster = img_m.group(1) if img_m else ''
            films.append({'id': fid, 'title': title, 'poster': poster})
        if len(films) < _SC_MIN_FILMS:
            xbmc.log(
                "[EspaTV-SC] estrenos sospechoso ({0} films), ignorando".format(len(films)),
                xbmc.LOGWARNING,
            )
            return None
        xbmc.log("[EspaTV-SC] estrenos: {0} películas".format(len(films)), xbmc.LOGINFO)
        return films
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-SC] estrenos error: {0}".format(e), xbmc.LOGERROR)
        return None


def _fetch_estrenos():
    cache = _load_cache()

    if _estrenos_fresh(cache):
        films = cache["estrenos"]["films"]
        xbmc.log(
            "[EspaTV-SC] estrenos desde caché ({0} títulos)".format(len(films)),
            xbmc.LOGINFO,
        )
        return films

    scraped = _scrape_estrenos()
    if scraped is not None:
        films = scraped
        cache["estrenos"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("estrenos", {}).get("films"):
        films = cache["estrenos"]["films"]
        xbmc.log("[EspaTV-SC] estrenos inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_estrenos():
    import metadata_enricher as me

    films = _fetch_estrenos()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar SensaCine Estrenos", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False

    if not has_meta:
        li = xbmcgui.ListItem(label="[COLOR yellow][B]>>> Descargar metadatos completos (actores, director...) <<<[/B][/COLOR]")
        li.setArt({'icon': 'DefaultAddonService.png'})
        li.setInfo('video', {'plot': "Descarga sinopsis en español, actores y director de los próximos estrenos."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_cache_estrenos_meta"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="[COLOR red]Borrar metadatos de estrenos[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        li.setInfo('video', {'plot': "Elimina los metadatos guardados de los próximos estrenos."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_clear_estrenos_meta"), listitem=li, isFolder=False)

    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "RunPlugin({0})".format(
                _u(action='search_movie_multi', q=f['title']))),
            ("Copiar título", "RunPlugin({0})".format(
                _u(action='copy_title', title=f['title']))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def cache_cartelera_meta():
    import metadata_enricher as me

    films = _fetch_cartelera()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No hay películas en cartelera", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Descargando metadatos cartelera...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "EspaTV",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_cartelera_meta():
    import metadata_enricher as me

    films = _fetch_cartelera()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("EspaTV", "Metadatos de cartelera eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def cache_estrenos_meta():
    import metadata_enricher as me

    films = _fetch_estrenos()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No hay estrenos disponibles", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Descargando metadatos estrenos...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "EspaTV",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_estrenos_meta():
    import metadata_enricher as me

    films = _fetch_estrenos()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("EspaTV", "Metadatos de estrenos eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")
