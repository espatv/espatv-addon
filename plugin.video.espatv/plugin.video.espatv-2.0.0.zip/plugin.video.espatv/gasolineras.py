# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Gasolineras Baratas — precios en tiempo real de la API REST de minetur."""
import json
import os
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG = "[EspaTV-GAS]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_FILE = os.path.join(_PROFILE, "gasolineras_cache.json")
_STATE_FILE = os.path.join(_PROFILE, "gasolineras_state.json")
_CACHE_TTL = 4 * 3600

_PROVINCIAS = [
    ("01", "Álava"),          ("02", "Albacete"),       ("03", "Alicante"),
    ("04", "Almería"),        ("33", "Asturias"),        ("05", "Ávila"),
    ("06", "Badajoz"),        ("07", "Baleares"),        ("08", "Barcelona"),
    ("09", "Burgos"),         ("10", "Cáceres"),         ("11", "Cádiz"),
    ("39", "Cantabria"),      ("12", "Castellón"),       ("51", "Ceuta"),
    ("13", "Ciudad Real"),    ("14", "Córdoba"),         ("16", "Cuenca"),
    ("17", "Girona"),         ("18", "Granada"),         ("19", "Guadalajara"),
    ("20", "Guipúzcoa"),      ("21", "Huelva"),          ("22", "Huesca"),
    ("23", "Jaén"),           ("15", "La Coruña"),       ("26", "La Rioja"),
    ("35", "Las Palmas"),     ("24", "León"),            ("25", "Lleida"),
    ("27", "Lugo"),           ("28", "Madrid"),          ("29", "Málaga"),
    ("52", "Melilla"),        ("30", "Murcia"),          ("31", "Navarra"),
    ("32", "Ourense"),        ("34", "Palencia"),        ("36", "Pontevedra"),
    ("37", "Salamanca"),      ("38", "Santa Cruz de Tenerife"), ("40", "Segovia"),
    ("41", "Sevilla"),        ("42", "Soria"),           ("43", "Tarragona"),
    ("44", "Teruel"),         ("45", "Toledo"),          ("46", "Valencia"),
    ("47", "Valladolid"),     ("48", "Vizcaya"),         ("49", "Zamora"),
    ("50", "Zaragoza"),
]
_TIMEOUT = 20
_API_BASE = "https://sedeaplicaciones.minetur.gob.es/ServiciosRESTCarburantes/PreciosCarburantes/EstacionesTerrestres/FiltroProvincia/{prov_id}"
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_COMBUSTIBLES = [
    ("Gasolina 95 E5",    "Precio Gasolina 95 E5",    "gold"),
    ("Diésel A",          "Precio Gasoleo A",          "orange"),
    ("Gasolina 98 E5",    "Precio Gasolina 98 E5",     "lightyellow"),
    ("Diésel Premium",    "Precio Gasoleo Premium",    "lightsalmon"),
    ("Gas Natural (GNC)", "Precio Gas Natural Comprimido", "lightblue"),
    ("GLP",               "Precio Gases licuados del petroleo", "plum"),
]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _price(station, field):
    raw = str(station.get(field) or "").replace(",", ".").strip()
    try:
        return float(raw) if raw else None
    except ValueError:
        return None


def _load_cache(prov_id):
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        entry = obj.get(prov_id, {})
        if time.time() - entry.get("ts", 0) < _CACHE_TTL:
            return entry.get("stations")
    except (OSError, ValueError):
        pass
    return None


def _save_cache(prov_id, stations):
    try:
        try:
            with open(_CACHE_FILE, "r", encoding="utf-8") as f:
                obj = json.load(f)
        except (OSError, ValueError):
            obj = {}
        obj[prov_id] = {"ts": time.time(), "stations": stations}
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except OSError as e:
        xbmc.log("{0} Error caché: {1}".format(_LOG, e), xbmc.LOGWARNING)


def _fetch_stations(prov_id):
    url = _API_BASE.format(prov_id=prov_id)
    headers = {
        "User-Agent": "EspaTV/1.0 (Kodi addon; gasolineras)",
        "Accept": "application/json",
    }
    resp = requests.get(url, headers=headers, timeout=_TIMEOUT)
    resp.raise_for_status()
    data = resp.json()
    return data.get("ListaEESSPrecio", [])


def _load_state():
    try:
        with open(_STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {"prov_id": "28", "prov_name": "Madrid"}


def _save_state(prov_id, prov_name):
    try:
        with open(_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump({"prov_id": prov_id, "prov_name": prov_name}, f)
    except OSError:
        pass


def gasolineras_change_prov():
    names = [name for _, name in _PROVINCIAS]
    idx = xbmcgui.Dialog().select("Selecciona provincia", names)
    if idx >= 0:
        prov_id, prov_name = _PROVINCIAS[idx]
        _save_state(prov_id, prov_name)
        xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="gasolineras_menu")))


def gasolineras_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_gasolineras.png")
    state = _load_state()
    prov_id = state["prov_id"]
    prov_name = state["prov_name"]

    li_prov = xbmcgui.ListItem(label="[B][COLOR aqua][ Cambiar provincia: {0} ][/COLOR][/B]".format(prov_name))
    li_prov.setArt({"icon": "DefaultIconInfo.png"})
    li_prov.setInfo("video", {"plot": "Pulsa para seleccionar otra provincia."})
    li_prov.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="gasolineras_change_prov"), listitem=li_prov, isFolder=False)

    for label, field, color in _COMBUSTIBLES:
        li = xbmcgui.ListItem(label="[B][COLOR {0}]{1}[/COLOR][/B] — {2}".format(color, label, prov_name))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Gasolineras más baratas de {0} ordenadas por precio de {1}.".format(prov_name, label)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="gasolineras_lista", prov_id=prov_id, prov_name=prov_name, field=field, fuel_label=label),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def gasolineras_lista(prov_id, prov_name, field, fuel_label):
    h = int(sys.argv[1])
    stations = _load_cache(prov_id)
    if stations is None:
        try:
            xbmcgui.Dialog().notification("Gasolineras", "Consultando precios…", xbmcgui.NOTIFICATION_INFO, 1500)
            stations = _fetch_stations(prov_id)
            _save_cache(prov_id, stations)
        except Exception as e:
            xbmc.log("{0} Error API: {1}".format(_LOG, e), xbmc.LOGERROR)
            li = xbmcgui.ListItem(label="[COLOR red]Error de conexión — comprueba la red[/COLOR]")
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(h)
            return

    with_price = [(s, _price(s, field)) for s in stations]
    with_price = [(s, p) for s, p in with_price if p is not None and p > 0]
    with_price.sort(key=lambda x: x[1])

    if not with_price:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin datos de precio para {0}[/COLOR]".format(fuel_label))
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    icon = _icon("cat_gasolineras.png")
    min_price = with_price[0][1]
    for s, precio in with_price[:50]:
        marca     = (s.get("Rótulo") or s.get("Rotulo") or "Estación").strip()
        direccion = (s.get("Dirección") or s.get("Direccion") or "").strip()
        municipio = (s.get("Municipio") or "").strip()
        horario   = (s.get("Horario") or "").strip()

        if precio <= min_price * 1.02:
            color = "lightgreen"
        elif precio <= min_price * 1.05:
            color = "gold"
        else:
            color = "white"

        label = "[B][COLOR {0}]{1:.3f} €/L[/COLOR][/B]  {2}  [COLOR grey]{3}[/COLOR]".format(
            color, precio, marca, municipio
        )
        plot_lines = [
            "{0}".format(marca),
            "[B]{0}: {1:.3f} €/L[/B]".format(fuel_label, precio),
            "{0}".format(direccion),
            "{0}".format(municipio),
        ]
        if horario:
            plot_lines.append("Horario: {0}".format(horario))
        for lbl2, field2, _ in _COMBUSTIBLES:
            if field2 == field:
                continue
            p2 = _price(s, field2)
            if p2 and p2 > 0:
                plot_lines.append("{0}: {1:.3f} €/L".format(lbl2, p2))

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": marca, "plot": "\n".join(plot_lines)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar precios ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Elimina la caché y recarga precios actuales."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="gasolineras_refresh", prov_id=prov_id, prov_name=prov_name, field=field, fuel_label=fuel_label),
        listitem=li_r,
        isFolder=True,
    )
    xbmcplugin.endOfDirectory(h)


def gasolineras_refresh(prov_id, prov_name, field, fuel_label):
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
    except (OSError, ValueError):
        obj = {}
    obj.pop(prov_id, None)
    try:
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except OSError:
        pass
    xbmc.executebuiltin("Container.Update({0},replace)".format(
        _u(action="gasolineras_lista", prov_id=prov_id, prov_name=prov_name, field=field, fuel_label=fuel_label)))
