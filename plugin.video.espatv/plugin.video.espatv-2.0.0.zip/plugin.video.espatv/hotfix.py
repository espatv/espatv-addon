# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import hashlib
import os
import json
import shutil
import tempfile
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_REMOTE_URL = "https://raw.githubusercontent.com/espakodi/espatv/main/hotfix.py"
_BACKUP_DIR = "hotfix_backups"
_STATE_FILE = "hotfix_state.json"
_RETRY_COOLDOWN_S = 6 * 3600

# Whitelist de SHA-256 de hotfixes legitimos. Si esta vacia, la feature
# queda deshabilitada (fail-safe). Cuando se publique un hotfix:
#   1) Calcular sha256 del fichero remoto.
#   2) Anadir el hash aqui y publicar nueva version del addon.
# Esto evita RCE si el repo de hotfix se compromete.
_HOTFIX_SHA256_WHITELIST = set()


def _paths():
    addon = xbmcaddon.Addon()
    return (
        xbmcvfs.translatePath(addon.getAddonInfo("path")),
        xbmcvfs.translatePath(addon.getAddonInfo("profile")),
    )


def _atomic_write(path, content, encoding="utf-8"):
    parent = os.path.dirname(path) or "."
    os.makedirs(parent, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=parent, suffix=".tmp")
    try:
        data = content if isinstance(content, bytes) else content.encode(encoding)
        os.write(fd, data)
        os.close(fd)
        os.replace(tmp, path)
    except Exception:
        try:
            os.close(fd)
        except OSError:
            pass
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _load_state(data_path):
    sf = os.path.join(data_path, _STATE_FILE)
    try:
        if os.path.exists(sf):
            with open(sf, "r", encoding="utf-8") as f:
                s = json.load(f)
                if isinstance(s, dict) and isinstance(s.get("applied"), list):
                    if not isinstance(s.get("failed"), dict):
                        s["failed"] = {}
                    return s
    except (OSError, ValueError):
        pass
    return {"applied": [], "failed": {}}


def _save_state(state, data_path):
    os.makedirs(data_path, exist_ok=True)
    _atomic_write(os.path.join(data_path, _STATE_FILE), json.dumps(state, ensure_ascii=False))


def _valid_id(hid):
    return (
        isinstance(hid, str)
        and 0 < len(hid) <= 64
        and hid[0].isalnum()
        and all(c.isalnum() or c in "-_." for c in hid)
        and ".." not in hid
    )


def _version_tuple(v):
    if not isinstance(v, str) or not v:
        return ()
    out = []
    for part in v.replace("v", "").split("."):
        digits = ""
        for c in part:
            if c.isdigit():
                digits += c
            else:
                break
        if not digits:
            break
        out.append(int(digits))
    return tuple(out)


def _addon_version():
    try:
        return xbmcaddon.Addon().getAddonInfo("version") or ""
    except Exception:
        return ""


def _version_match(min_v, max_v, cur):
    cur_t = _version_tuple(cur)
    if min_v and cur_t < _version_tuple(min_v):
        return False
    if max_v and cur_t > _version_tuple(max_v):
        return False
    return True


def _make_helpers(addon_path, data_path, hotfix_id):
    backup_root = os.path.join(data_path, _BACKUP_DIR, hotfix_id)

    def _backup(path):
        if not os.path.exists(path):
            return
        try:
            rel = os.path.relpath(path, addon_path)
            if rel.startswith(".."):
                rel = os.path.basename(path)
        except ValueError:
            rel = os.path.basename(path)
        dst = os.path.join(backup_root, rel)
        if os.path.exists(dst):
            return
        parent = os.path.dirname(dst)
        if parent:
            os.makedirs(parent, exist_ok=True)
        shutil.copy2(path, dst)

    def patch_text(path, old, new, count=-1):
        if not isinstance(old, str) or not old:
            xbmc.log("[hotfix] patch_text: 'old' debe ser str no vacio", xbmc.LOGERROR)
            return False
        with open(path, "r", encoding="utf-8") as f:
            src = f.read()
        if old not in src:
            xbmc.log(f"[hotfix] patch_text: patron no encontrado en {path}", xbmc.LOGWARNING)
            return False
        _backup(path)
        new_src = src.replace(old, new) if count == -1 else src.replace(old, new, count)
        _atomic_write(path, new_src)
        return True

    def patch_json(path, mutator):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        _backup(path)
        result = mutator(data)
        if result is not None:
            data = result
        _atomic_write(path, json.dumps(data, ensure_ascii=False, indent=2))
        return True

    def write_file(path, content):
        if os.path.exists(path):
            _backup(path)
        _atomic_write(path, content)
        return True

    return {
        "patch_text": patch_text,
        "patch_json": patch_json,
        "write_file": write_file,
        "ADDON_PATH": addon_path,
        "DATA_PATH": data_path,
    }


def _collect_fixes(ns):
    out = []
    raw_list = ns.get("HOTFIXES")
    if isinstance(raw_list, list):
        for entry in raw_list:
            if not isinstance(entry, dict):
                xbmc.log(f"[hotfix] entrada de HOTFIXES no es dict: {entry!r}", xbmc.LOGWARNING)
                continue
            fid = entry.get("id")
            apply_fn = entry.get("apply")
            if not fid or not callable(apply_fn):
                xbmc.log(f"[hotfix] entrada incompleta en HOTFIXES: {entry!r}", xbmc.LOGWARNING)
                continue
            out.append({
                "id": fid,
                "desc": entry.get("desc", ""),
                "apply": apply_fn,
                "requires_restart": bool(entry.get("requires_restart")),
                "min_version": entry.get("min_version", "") or "",
                "max_version": entry.get("max_version", "") or "",
            })
        return out

    fid = ns.get("HOTFIX_ID")
    apply_fn = ns.get("apply")
    if fid and callable(apply_fn):
        out.append({
            "id": fid,
            "desc": ns.get("HOTFIX_DESC", ""),
            "apply": apply_fn,
            "requires_restart": bool(ns.get("REQUIRES_RESTART")),
            "min_version": ns.get("MIN_VERSION", "") or "",
            "max_version": ns.get("MAX_VERSION", "") or "",
        })
    return out


def check_and_apply():
    try:
        addon_path, data_path = _paths()
        state = _load_state(data_path)

        try:
            import requests
            r = requests.get(_REMOTE_URL, timeout=5)
        except Exception as e:
            xbmc.log(f"[hotfix] fetch error: {e}", xbmc.LOGWARNING)
            return

        if r.status_code != 200:
            xbmc.log(f"[hotfix] respuesta no valida: HTTP {r.status_code}", xbmc.LOGDEBUG)
            return

        r.encoding = "utf-8"
        source = r.text
        if not source:
            return

        # Fail-safe: si la whitelist esta vacia, no ejecutamos nada.
        # Evita RCE si el repo remoto se compromete antes de publicar fixes.
        if not _HOTFIX_SHA256_WHITELIST:
            xbmc.log("[hotfix] whitelist vacia, hotfixes deshabilitados",
                     xbmc.LOGINFO)
            return

        # Verificacion de integridad: el hash del fichero remoto debe
        # coincidir con uno previamente revisado y embebido en el addon.
        src_hash = hashlib.sha256(source.encode("utf-8")).hexdigest()
        if src_hash not in _HOTFIX_SHA256_WHITELIST:
            xbmc.log(
                "[hotfix] hash %s no esta en whitelist, ignorando" % src_hash,
                xbmc.LOGWARNING,
            )
            return

        ns = {}
        try:
            exec(compile(source, "<hotfix-remote>", "exec"), ns)
        except Exception as e:
            xbmc.log(f"[hotfix] error compilando parche remoto: {e}", xbmc.LOGERROR)
            return

        fixes = _collect_fixes(ns)
        if not fixes:
            return

        cur_version = _addon_version()
        applied_set = set(state["applied"])
        seen = set()
        pending = []
        for f in fixes:
            fid = f["id"]
            if fid in applied_set or fid in seen:
                continue
            seen.add(fid)
            if not _version_match(f["min_version"], f["max_version"], cur_version):
                xbmc.log(
                    f"[hotfix] {fid} fuera de rango (cur={cur_version}, "
                    f"min={f['min_version'] or '*'}, max={f['max_version'] or '*'}), saltando",
                    xbmc.LOGDEBUG,
                )
                continue
            pending.append(f)

        if not pending:
            xbmc.log(f"[hotfix] sin fixes pendientes ({len(fixes)} en lista)", xbmc.LOGDEBUG)
            return

        applied_now = []
        requires_restart = False
        now = time.time()

        for fix in pending:
            fid = fix["id"]

            if not _valid_id(fid):
                xbmc.log(f"[hotfix] HOTFIX_ID invalido, parando lote: {fid!r}", xbmc.LOGERROR)
                break

            finfo = state["failed"].get(fid)
            if finfo and now - finfo.get("last_ts", 0) < _RETRY_COOLDOWN_S:
                xbmc.log(
                    f"[hotfix] {fid} en cooldown tras {finfo.get('attempts', 0)} fallos, saltando",
                    xbmc.LOGDEBUG,
                )
                continue

            ns.update(_make_helpers(addon_path, data_path, fid))

            failed_now = False
            try:
                result = fix["apply"](addon_path, data_path)
            except Exception as e:
                xbmc.log(f"[hotfix] error en {fid}: {e} - parando lote", xbmc.LOGERROR)
                failed_now = True
                result = False

            if failed_now or result is False:
                if not failed_now:
                    xbmc.log(f"[hotfix] {fid} abortado por apply() (return False) - parando lote", xbmc.LOGINFO)
                attempts = (finfo or {}).get("attempts", 0) + 1
                state["failed"][fid] = {"attempts": attempts, "last_ts": now}
                _save_state(state, data_path)
                break

            state["applied"].append(fid)
            state["failed"].pop(fid, None)
            _save_state(state, data_path)
            applied_now.append((fid, fix["desc"]))
            xbmc.log(f"[hotfix] aplicado {fid}: {fix['desc']}", xbmc.LOGINFO)

            if fix["requires_restart"]:
                requires_restart = True

        if not applied_now:
            return

        try:
            if len(applied_now) == 1:
                fid, desc = applied_now[0]
                msg = f"Hotfix aplicado: {desc or fid}"
            else:
                msg = f"{len(applied_now)} hotfixes aplicados"
            xbmcgui.Dialog().notification(
                "EspaTV", msg, xbmcgui.NOTIFICATION_INFO, 4000
            )
        except Exception:
            pass

        if requires_restart:
            try:
                xbmcgui.Dialog().ok(
                    "EspaTV - Hotfix",
                    "Se aplicaron parches que requieren reinicio.\n\n"
                    "Reinicia Kodi para que tengan efecto completo.",
                )
            except Exception:
                pass

    except Exception as e:
        xbmc.log(f"[hotfix] error inesperado en runner: {e}", xbmc.LOGERROR)
