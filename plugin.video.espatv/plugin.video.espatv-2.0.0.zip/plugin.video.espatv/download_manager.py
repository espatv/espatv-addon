# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Descargas de video Dailymotion: MP4 directo, HLS por segmentos, y modo ULTRA
con yt-dlp (subproceso en Python externo, evita conflictos con el de Kodi)."""
import io
import json
import os
import time
import urllib.parse
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import core_settings
from _user_agents import UA_DAILYMOTION_LEGACY as _UA_DM

try:
    import requests
except ImportError:
    xbmc.log("[EspaTV/download] requests no disponible", xbmc.LOGERROR)
    raise


def _err(msg):
    try:
        from default import _log_error
        _log_error(msg)
    except ImportError:
        xbmc.log("[EspaTV ERROR] {0}".format(msg), xbmc.LOGERROR)


def _download_video(vid, title):
    if not vid:
        return

    from default import _HEADERS_DM_DESKTOP, _fetch_hls_variants, _load_dm_settings

    try:
        # El player/metadata devuelve qualities; la API publica ya no lo hace
        meta_url = "https://www.dailymotion.com/player/metadata/video/{0}".format(vid)
        r = requests.get(meta_url, headers=_HEADERS_DM_DESKTOP, timeout=12)
        if r.status_code != 200:
            xbmcgui.Dialog().ok("EspaTV", "No se pudo resolver el video para descarga.\nCodigo: {0}".format(r.status_code))
            return
        d = r.json()
        if not d:
            xbmcgui.Dialog().ok("EspaTV", "No se pudo resolver el video para descarga.")
            return
        qs = d.get("qualities") or {}

        all_links = []

        # 1. Buscar enlaces MP4 directos
        for res_key, formats in qs.items():
            if res_key == "auto": continue
            for f in formats:
                u = f.get("url")
                if not u: continue
                if f.get("type") == "video/mp4":
                    res_val = int(res_key) if res_key.isdigit() else 0
                    all_links.append({'label': "{0}p (Descarga Directa MP4)".format(res_key), 'url': u, 'res': res_val, 'type': 'mp4'})

        # 2. Buscar HLS (M3U8) como fallback
        m3u8_master = ""
        if "auto" in qs:
            for s in qs["auto"]:
                if s.get("type") == "application/x-mpegURL":
                    m3u8_master = s.get("url", "")
                    vs = _fetch_hls_variants(m3u8_master, headers=_HEADERS_DM_DESKTOP)
                    for v in vs:
                        rs_str = v['label'].split(' ')[0]
                        res_val = int(rs_str.split('x')[1]) if 'x' in rs_str else 0
                        all_links.append({'label': "{0} (HLS por Segmentos .TS)".format(rs_str), 'url': v['url'], 'res': res_val, 'type': 'hls'})
                    if m3u8_master:
                        all_links.append({'label': "ULTRA (Mejor calidad via yt-dlp)", 'url': m3u8_master, 'res': 99999, 'type': 'ultra'})

        # Ordenar por resolucion
        all_links.sort(key=lambda x: x['res'], reverse=True)

        if not all_links:
            xbmcgui.Dialog().ok("EspaTV", "No se han encontrado enlaces de descarga para este contenido.\n\nEl servidor puede estar bloqueando el acceso directo a este video.")
            return

        # Leer modo de descarga configurado
        dm_cfg = _load_dm_settings()
        dl_mode = dm_cfg.get('dl_mode', 0)

        # Modo 0 (DIRECTO): Mostrar menú de selección (comportamiento actual)
        if dl_mode == 0:
            lbs = [l['label'] for l in all_links]
            sel = xbmcgui.Dialog().select("Selecciona Calidad de Descarga", lbs)
            if sel < 0: return
            target = all_links[sel]
        # Modo 1 (SAFE MODE): Mejor MP4 directo disponible
        elif dl_mode == 1:
            mp4s = [l for l in all_links if l['type'] == 'mp4']
            if mp4s:
                target = mp4s[0]
            else:
                xbmcgui.Dialog().ok("EspaTV", "No hay enlaces MP4 directos.\nCambia a modo ULTRA en ajustes.")
                return
        # Modo 2 (EspaTV): Mejor HLS disponible
        elif dl_mode == 2:
            hls_links = [l for l in all_links if l['type'] == 'hls']
            if hls_links:
                target = hls_links[0]
            else:
                xbmcgui.Dialog().ok("EspaTV", "No hay enlaces HLS disponibles.\nCambia a modo ULTRA en ajustes.")
                return
        # Modo 3 (YT-DLP) y 4 (ULTRA): Usar yt-dlp
        else:
            ultra = [l for l in all_links if l['type'] == 'ultra']
            if ultra:
                target = ultra[0]
            else:
                mp4s = [l for l in all_links if l['type'] == 'mp4']
                target = mp4s[0] if mp4s else all_links[0]

        # Pedir directorio de destino
        path = xbmcgui.Dialog().browse(3, 'Selecciona dónde guardar el video', 'video', '', False, False, '')
        if not path: return

        # Confirmar HLS si aplica
        if target['type'] == 'hls':
            if not xbmcgui.Dialog().yesno("Descarga HLS", "Este video no tiene enlace directo.\nSe bajará por segmentos y se unirán al final.\n\nEs un proceso lento. ¿Continuar?"):
                return

        # Preparar nombres de archivo
        safe_title = "".join([c for c in title if c.isalnum() or c in ' -_']).strip()
        if not safe_title: safe_title = vid
        ext = ".mp4" if target['type'] in ('mp4', 'ultra') else ".ts"
        dest = os.path.join(path, "{0}{1}".format(safe_title, ext))


        if target['type'] == 'mp4':
            _do_download_direct(target['url'], dest, title)
        elif target['type'] == 'ultra':
            _do_download_ultra(vid, dest, title)
        else:
            _do_download_hls(target['url'], dest, title)

    except (requests.RequestException, ValueError, OSError, KeyError) as e:
        _err("Download Error video {0}: {1}".format(vid, e))
        xbmcgui.Dialog().ok("EspaTV Error", "Error al preparar descarga: {0}".format(e))


def _do_download_direct(url, dest, title):
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando MP4", "Conectando: {0}".format(title))
    tmp_dest = dest + ".tmp"
    try:
        clean_url = url.split('|')[0] if '|' in url else url
        dm_h = {"User-Agent": _UA_DM, "Origin": "https://www.dailymotion.com", "Referer": "https://www.dailymotion.com/"}
        r = requests.get(clean_url, headers=dm_h, stream=True, timeout=30)
        total = int(r.headers.get('content-length', 0))
        done = 0
        with open(tmp_dest, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024*256):
                if dp.iscanceled(): break
                f.write(chunk)
                done += len(chunk)
                if total > 0:
                    percent = int(done * 100 / total)
                    dp.update(percent, "Descargado: {0:.1f}MB / {1:.1f}MB".format(
                        done / (1024 * 1024), total / (1024 * 1024)))
        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.replace(tmp_dest, dest)
            core_settings.log_download(title, dest, "MP4")
            xbmcgui.Dialog().ok("¡Éxito!", "Video guardado correctamente en:\n{0}".format(dest))
        elif os.path.exists(tmp_dest):
            os.remove(tmp_dest)
    except (requests.RequestException, OSError) as e:
        if 'dp' in locals(): dp.close()
        if os.path.exists(tmp_dest): os.remove(tmp_dest)
        _err("Error Direct DL: {0}".format(e))
        xbmcgui.Dialog().ok("Error", "Error en transferencia: {0}".format(e))


def _do_download_hls(playlist_url, dest, title):
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando HLS", "Obteniendo segmentos...")
    dm_h = {"User-Agent": _UA_DM, "Origin": "https://www.dailymotion.com", "Referer": "https://www.dailymotion.com/"}
    clean_url = playlist_url.split('|')[0] if '|' in playlist_url else playlist_url
    tmp_dest = dest + ".tmp"
    try:
        params = ""
        if '?' in clean_url:
            params = '?' + clean_url.split('?', 1)[1]

        m3u8_content = requests.get(clean_url, headers=dm_h, timeout=15).text
        segments = [l for l in m3u8_content.splitlines() if l and not l.startswith('#')]
        total_seg = len(segments)

        if total_seg == 0:
            xbmcgui.Dialog().ok("Error", "La lista de reproducción está vacía.")
            return
        with open(tmp_dest, 'wb') as f_out:
            for idx, seg_name in enumerate(segments):
                if dp.iscanceled():
                    break

                seg_url = urllib.parse.urljoin(clean_url, seg_name)
                if params and '?' not in seg_url:
                    seg_url += params

                success = False
                for _attempt in range(3):
                    try:
                        seg_data = requests.get(seg_url, headers=dm_h, timeout=12).content
                        f_out.write(seg_data)
                        success = True
                        break
                    except (requests.RequestException, OSError):
                        continue

                if not success:
                    raise RuntimeError("Fallo crítico en segmento {0}/{1}".format(idx + 1, total_seg))

                dp.update(
                    int((idx + 1) * 100 / total_seg),
                    "Segmento {0}/{1} - {2}".format(idx + 1, total_seg, title),
                )

        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.replace(tmp_dest, dest)
            core_settings.log_download(title, dest, "HLS")
            xbmcgui.Dialog().ok("¡Completado!", "El video HLS se ha unido y guardado en:\n{0}".format(dest))
        elif os.path.exists(tmp_dest):
            os.remove(tmp_dest)
    except (requests.RequestException, OSError, RuntimeError) as e:
        if 'dp' in locals(): dp.close()
        if os.path.exists(tmp_dest): os.remove(tmp_dest)
        _err("HLS Merge Error: {0}".format(e))
        xbmcgui.Dialog().ok("Error Union HLS", "Fallo: {0}".format(e))


def _get_ytdlp_pkg_path():
    profile = xbmcvfs.translatePath(
        xbmcaddon.Addon().getAddonInfo('profile')
    )
    pkg_path = os.path.join(profile, "packages")
    if not os.path.exists(pkg_path):
        os.makedirs(pkg_path)
    return pkg_path


def _ensure_ytdlp():
    """Descarga el wheel py3-none-any de yt-dlp desde PyPI si no está ya extraído."""
    pkg_path = _get_ytdlp_pkg_path()
    ytdlp_dir = os.path.join(pkg_path, "yt_dlp")
    if os.path.isdir(ytdlp_dir):
        return True

    try:
        pypi_r = requests.get("https://pypi.org/pypi/yt-dlp/json", timeout=15)
        if pypi_r.status_code != 200:
            return False
        whl_url = None
        for u in pypi_r.json().get("urls", []):
            if u["filename"].endswith(".whl") and "py3-none-any" in u["filename"]:
                whl_url = u["url"]
                break
        if not whl_url:
            return False
        whl_r = requests.get(whl_url, timeout=120)
        if whl_r.status_code != 200:
            return False
        whl_data = io.BytesIO(whl_r.content)
        with zipfile.ZipFile(whl_data) as zf:
            for member in zf.namelist():
                if member.startswith("yt_dlp/"):
                    zf.extract(member, pkg_path)
        return os.path.isdir(ytdlp_dir)
    except (requests.RequestException, ValueError, OSError, zipfile.BadZipFile) as e:
        _err("Error descargando yt-dlp: {0}".format(e))
    return False


def _find_system_python():
    """Devuelve el comando del primer Python ≥ 3.10 que encuentre en PATH, o None."""
    import subprocess
    no_win = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    for py in ["python", "python3", "py"]:
        try:
            r = subprocess.run(
                [py, "-c", "import sys; v=sys.version_info; print(f'{v.major}.{v.minor}'); assert v >= (3,10)"],
                capture_output=True, text=True, timeout=5,
                creationflags=no_win
            )
            if r.returncode == 0:
                return py
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            continue
    return None


def _write_dl_helper(pkg_path, vid, dest, progress_file):
    helper_path = os.path.join(pkg_path, "_dl_helper.py")
    script = f'''
import sys, os, json
sys.path.insert(0, {repr(pkg_path)})
import yt_dlp

progress_file = {repr(progress_file)}

def hook(d):
    info = {{"status": d.get("status", ""), "percent": 0, "text": ""}}
    if d["status"] == "downloading":
        total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
        done = d.get("downloaded_bytes", 0)
        speed = d.get("speed") or 0
        if total > 0:
            info["percent"] = int(done * 100 / total)
            mb_d = done / (1024*1024)
            mb_t = total / (1024*1024)
            sp = speed / (1024*1024) if speed else 0
            info["text"] = f"{{mb_d:.1f}}MB / {{mb_t:.1f}}MB ({{sp:.1f}} MB/s)"
        elif done > 0:
            info["percent"] = 50
            info["text"] = f"Descargando: {{done/(1024*1024):.1f}}MB"
    elif d["status"] == "finished":
        info["percent"] = 95
        info["text"] = "Finalizando..."
    with open(progress_file, "w") as f:
        json.dump(info, f)

opts = {{
    "format": "best[ext=mp4]/best",
    "outtmpl": {repr(dest)},
    "quiet": True,
    "no_warnings": True,
    "progress_hooks": [hook],
    "noprogress": True,
}}
url = "https://www.dailymotion.com/video/{vid}"
try:
    ydl = yt_dlp.YoutubeDL(opts)
    ydl.download([url])
    with open(progress_file, "w") as f:
        json.dump({{"status": "done", "percent": 100, "text": "Completado"}}, f)
except Exception as e:
    with open(progress_file, "w") as f:
        json.dump({{"status": "error", "percent": 0, "text": str(e)[:300]}}, f)
'''
    with open(helper_path, 'w', encoding='utf-8') as f:
        f.write(script)
    return helper_path


def _do_download_ultra(vid, dest, title):
    """Descarga vía yt-dlp ejecutado en un Python externo (evita conflictos con el de Kodi)."""
    import subprocess

    # Android/dispositivos sin Python del sistema: informar
    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmcgui.Dialog().ok(
            "EspaTV",
            "Las descargas de Dailymotion no están\n"
            "disponibles en Android.\n\n"
            "Dailymotion bloquea descargas directas.\n"
            "Usa un PC con Python 3.10+ instalado."
        )
        return

    try:
        if xbmcvfs.exists(dest):
            if not xbmcgui.Dialog().yesno("EspaTV", "El archivo ya existe. ¿Sobrescribir?"): return
            xbmcvfs.delete(dest)

        dp = xbmcgui.DialogProgress()
        dp.create("Descargando (Modo ULTRA)", "Preparando...")

        if not dest.endswith(".mp4"):
            dest = os.path.splitext(dest)[0] + ".mp4"

        # 1. Buscar Python del sistema >= 3.10
        dp.update(2, "Buscando Python del sistema...")
        py_cmd = _find_system_python()
        if not py_cmd:
            dp.close()
            xbmcgui.Dialog().ok(
                "EspaTV",
                "Se necesita Python 3.10+ instalado en el sistema.\n\n"
                "Descárgalo de python.org e instálalo\n"
                "marcando 'Add to PATH'.\n\n"
                "Después reinicia Kodi."
            )
            return

        # 2. Descargar yt-dlp si no existe
        pkg_path = _get_ytdlp_pkg_path()
        ytdlp_dir = os.path.join(pkg_path, "yt_dlp")
        if not os.path.isdir(ytdlp_dir):
            dp.update(5, "Descargando componente yt-dlp (~3MB)...")
            if not _ensure_ytdlp():
                dp.close()
                xbmcgui.Dialog().ok("EspaTV", "Error descargando yt-dlp.\nComprueba tu conexión a internet.")
                return

        # 3. Generar y ejecutar script auxiliar
        dp.update(10, "Iniciando descarga...")
        progress_file = os.path.join(pkg_path, "_dl_progress.json")
        if os.path.exists(progress_file):
            os.remove(progress_file)

        helper_path = _write_dl_helper(pkg_path, vid, dest, progress_file)
        no_win = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

        proc = subprocess.Popen(
            [py_cmd, helper_path],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=no_win
        )

        # 4. Polling de progreso
        cancelled = False
        while proc.poll() is None:
            if dp.iscanceled():
                cancelled = True
                proc.kill()
                break
            if os.path.exists(progress_file):
                try:
                    with open(progress_file, 'r') as f:
                        info = json.loads(f.read())
                    dp.update(info.get("percent", 0), info.get("text", "Descargando..."))
                except (OSError, ValueError):
                    pass
            time.sleep(0.5)

        dp.close()

        for tmp in [helper_path, progress_file]:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass

        if cancelled:
            for ext in ["", ".part"]:
                p = dest + ext
                if os.path.exists(p):
                    try:
                        os.remove(p)
                    except OSError:
                        pass
            return

        if proc.returncode == 0 and os.path.exists(dest):
            core_settings.log_download(title, dest, "MP4 (ULTRA)")
            xbmcgui.Dialog().ok("EspaTV", "¡Descarga ULTRA completada!")
        else:
            stderr = ""
            try:
                stderr = proc.stderr.read().decode('utf-8', errors='replace')[:200]
            except (OSError, AttributeError):
                pass
            raise RuntimeError("yt-dlp falló (código {0}): {1}".format(proc.returncode, stderr))

    except (subprocess.SubprocessError, OSError, RuntimeError) as e:
        if 'dp' in locals(): dp.close()
        for ext in [".part", ".tmp"]:
            p = dest + ext
            if os.path.exists(p):
                try:
                    os.remove(p)
                except OSError:
                    pass
        _err("Ultra Error: {0}".format(e))
        xbmcgui.Dialog().ok("Error Ultra", "Fallo en descarga Ultra:\n{0}".format(e))
