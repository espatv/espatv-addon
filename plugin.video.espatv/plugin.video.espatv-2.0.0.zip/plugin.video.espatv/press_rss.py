# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Titulares RSS de prensa española."""
import os
import re
import sys
import urllib.parse
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

try:
    import requests
except ImportError:
    requests = None

_PRENSA_FEEDS = [
    {"name": "El País",         "url": "https://feeds.elpais.com/mrss-s/pages/ep/site/elpais.com/portada"},
    {"name": "El Mundo",        "url": "https://e00-elmundo.uecdn.es/elmundo/rss/portada.xml"},
    {"name": "ABC",             "url": "https://www.abc.es/rss/2.0/portada/"},
    {"name": "El Confidencial", "url": "https://rss.elconfidencial.com/espana/"},
    {"name": "20 Minutos",      "url": "https://www.20minutos.es/rss"},
    {"name": "elDiario.es",     "url": "https://www.eldiario.es/rss/"},
    {"name": "Europa Press",    "url": "https://www.europapress.es/rss/rss.aspx"},
    {"name": "RTVE Noticias",   "url": "https://www.rtve.es/rss/temas_noticias.xml"},
    {"name": "Marca",           "url": "https://e00-marca.uecdn.es/rss/portada.xml"},
    {"name": "Diario AS",       "url": "https://feeds.as.com/mrss-s/pages/as/site/as.com/portada"},
    {"name": "Mundo Deportivo", "url": "https://www.mundodeportivo.com/rss/home.xml"},
]


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def menu():
    h = int(sys.argv[1])
    _news_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'news.png')
    for feed in _PRENSA_FEEDS:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(feed['name']))
        li.setArt({'icon': _news_icon})
        li.setInfo('video', {'plot': "Explora los últimos titulares de {0}.".format(feed['name'])})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="press_list", raw_url=feed['url'], name=feed['name']), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def show_list(feed_url, feed_name):
    h = int(sys.argv[1])
    _news_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'news.png')
    try:
        r = requests.get(feed_url, timeout=10)
        r.raise_for_status()
        r.encoding = 'utf-8'
        root = ET.fromstring(r.text)
        items = root.findall('.//item')
        if not items:
            items = root.findall('.//{http://www.w3.org/2005/Atom}entry')

        for item in items:
            t_elem = item.find('title')
            if t_elem is None:
                t_elem = item.find('{http://www.w3.org/2005/Atom}title')
            title = (t_elem.text or "") if t_elem is not None else "Sin Titular"
            title = title.replace("<![CDATA[", "").replace("]]>", "").strip()
            if not title:
                title = "Sin Titular"

            d_elem = item.find('description')
            if d_elem is None:
                d_elem = item.find('{http://www.w3.org/2005/Atom}summary')
            desc = (d_elem.text or "") if d_elem is not None else ""
            desc = desc.replace("<![CDATA[", "").replace("]]>", "").strip()
            desc = re.sub(r'<[^>]+>', '', desc)

            thumb = _news_icon
            media_content = item.find('{http://search.yahoo.com/mrss/}content')
            if media_content is not None and media_content.get('url'):
                thumb = media_content.get('url')
            else:
                media_thumb = item.find('{http://search.yahoo.com/mrss/}thumbnail')
                if media_thumb is not None and media_thumb.get('url'):
                    thumb = media_thumb.get('url')
                else:
                    enclosure = item.find('enclosure')
                    if enclosure is not None and enclosure.get('type', '').startswith('image'):
                        thumb = enclosure.get('url')

            li = xbmcgui.ListItem(label=title)
            li.setArt({'icon': thumb, 'thumb': thumb})
            li.setInfo('video', {'title': title, 'plot': desc})

            safe_desc = desc[:500] if len(desc) > 500 else desc
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="press_read", title=title, desc=safe_desc),
                listitem=li, isFolder=False)

    except Exception as exc:
        xbmc.log("[EspaTV] Error cargando prensa ({0}): {1}".format(feed_url, exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("EspaTV", "Error leyendo el feed.", xbmcgui.NOTIFICATION_ERROR)

    xbmcplugin.endOfDirectory(h)


def read(title, desc):
    xbmcgui.Dialog().textviewer(title, desc)
