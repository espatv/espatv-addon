# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Letterboxd — listas curadas de películas para descubrimiento."""
import html as _html
import json
import os
import re
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from _user_agents import desktop_headers as _dh, ACCEPT_HTML

_TTL = 24 * 3600

# Namespace de los campos extendidos de Letterboxd en su RSS
_LB_TITLE = '{https://a.ltxd.com/rss/ext}filmTitle'
_LB_YEAR  = '{https://a.ltxd.com/rss/ext}filmYear'

_LISTS = [
    ("Top 250 Narrativo",      "https://letterboxd.com/dave/list/official-top-250-narrative-feature-films/rss/"),
    ("Más populares en LB",    "https://letterboxd.com/films/popular/rss/"),
    ("Mejores de la historia", "https://letterboxd.com/dave/list/letterboxd-100/rss/"),
]

_HEADERS = _dh(accept=ACCEPT_HTML, referer="https://letterboxd.com/")


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espatv_letterboxd_cache.json')


def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        xbmc.log("[EspaTV-LB] cache save: {0}".format(e), xbmc.LOGWARNING)


def _parse_rss(content):
    """Extrae pares {title, year} del RSS de Letterboxd."""
    try:
        root = ET.fromstring(content)
    except ET.ParseError as e:
        xbmc.log("[EspaTV-LB] RSS parse error: {0}".format(e), xbmc.LOGERROR)
        return []

    films = []
    seen = set()
    for item in root.findall('.//item'):
        title = (item.findtext(_LB_TITLE) or '').strip()
        year  = (item.findtext(_LB_YEAR)  or '').strip()

        if not title:
            # Fallback: <title> tag tiene formato "N. Título, YYYY - ★★★"
            raw = (item.findtext('title') or '').strip()
            m = re.match(r'^(?:\d+\.\s*)?(.+?)(?:,\s*(\d{4}))?\s*(?:-\s*[★½].*)?$', raw)
            if m:
                title = m.group(1).strip()
                year  = m.group(2) or ''
            else:
                title = raw

        title = _html.unescape(title)
        key = title.lower()
        if title and key not in seen:
            seen.add(key)
            films.append({'title': title, 'year': year})

    return films


def _fetch_list(list_key, list_url):
    cache = _load_cache()
    entry = cache.get(list_key, {})
    if entry and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['films']

    films = []
    try:
        r = requests.get(list_url, headers=_HEADERS, timeout=15)
        xbmc.log("[EspaTV-LB] RSS fetch {0} -> {1}".format(list_url[:60], r.status_code), xbmc.LOGINFO)
        if r.status_code == 200:
            films = _parse_rss(r.content)
        else:
            xbmc.log("[EspaTV-LB] RSS HTTP {0}".format(r.status_code), xbmc.LOGWARNING)
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-LB] RSS request error: {0}".format(e), xbmc.LOGERROR)

    if films:
        cache[list_key] = {'ts': time.time(), 'films': films}
        _save_cache(cache)
    elif entry.get('films'):
        xbmc.log("[EspaTV-LB] usando caché caducada para '{0}'".format(list_key), xbmc.LOGWARNING)
        return entry['films']

    return films


def show_menu():
    h = _handle()
    for label, url in _LISTS:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultVideoPlaylists.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='letterboxd_list', list_key=label, list_url=url),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def show_list(list_key, list_url):
    import metadata_enricher as me

    h = _handle()
    films = _fetch_list(list_key, list_url)
    if not films:
        xbmcgui.Dialog().notification(
            "EspaTV",
            "No se pudo cargar la lista de Letterboxd",
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.endOfDirectory(h)
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')

    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False

    if not has_meta:
        li = xbmcgui.ListItem(label="[COLOR yellow][B]>>> Descargar metadatos completos (actores, director...) <<<[/B][/COLOR]")
        li.setArt({'icon': 'DefaultAddonService.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='letterboxd_cache_meta', list_key=list_key, list_url=list_url),
            listitem=li,
            isFolder=False,
        )
    else:
        li = xbmcgui.ListItem(label="[COLOR red]Borrar metadatos de esta lista[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='letterboxd_clear_meta', list_key=list_key, list_url=list_url),
            listitem=li,
            isFolder=False,
        )

    enrich_items = [
        {'title': f['title'], 'year': int(f['year']) if f.get('year', '').isdigit() else None,
         'media_type': 'movie'}
        for f in films
    ]
    metas = me.batch_enrich(enrich_items, use_cache_only=True)

    for f, meta in zip(films, metas):
        year_int = int(f['year']) if f.get('year', '').isdigit() else 0
        label = "{0} ({1})".format(f['title'], year_int) if year_int else f['title']
        li = xbmcgui.ListItem(label=label)

        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster', '')
        else:
            li.setArt({'icon': 'DefaultVideo.png'})
            li.setInfo('video', {'title': f['title'], 'year': year_int, 'mediatype': 'movie'})
            poster = ''

        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "RunPlugin({0})".format(
                _u(action='search_movie_multi', q=f['title']))),
            ("Copiar título", "RunPlugin({0})".format(
                _u(action='copy_title', title=f['title']))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie')
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def clear_list_meta(list_key, list_url):
    import metadata_enricher as me

    films = _fetch_list(list_key, list_url)
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("EspaTV", "Metadatos de lista eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def cache_list_meta(list_key, list_url):
    import metadata_enricher as me

    films = _fetch_list(list_key, list_url)
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No hay películas para descargar", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [
        {'title': f['title'],
         'year': int(f['year']) if f.get('year', '').isdigit() else None,
         'media_type': 'movie'}
        for f in films
    ]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Descargando metadatos Letterboxd...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "EspaTV", "Metadatos guardados: {0}/{1}".format(count, len(items)), xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")
