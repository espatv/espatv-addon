# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""FilmAffinity / TMDB: cartelera, top y catálogo por géneros."""
import html
import json
import os
import re
import sys
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from _user_agents import desktop_headers as _dh, ACCEPT_HTML
from core_settings import _ESPATV_TMDB_API_KEY

_TMDB_API = "https://api.themoviedb.org/3"
_TMDB_IMG = "https://image.tmdb.org/t/p/w342"

_FA_BASE = "https://www.filmaffinity.com/es"
_FA_HEADERS = _dh(accept=ACCEPT_HTML, referer="https://www.filmaffinity.com/es/")
_CARTELERA_TTL = 6 * 3600
_FA_MIN_FILMS = 3

_GENRES = [
    ("Top General",     "movie", ""),
    ("Accion",          "movie", "28"),
    ("Animacion",       "movie", "16"),
    ("Aventura",        "movie", "12"),
    ("Comedia",         "movie", "35"),
    ("Ciencia Ficcion", "movie", "878"),
    ("Documental",      "movie", "99"),
    ("Drama",           "movie", "18"),
    ("Fantasia",        "movie", "14"),
    ("Terror",          "movie", "27"),
    ("Thriller",        "movie", "53"),
    ("Musical",         "movie", "10402"),
    ("Western",         "movie", "37"),
    ("Belica",          "movie", "10752"),
    ("Series TV",       "tv",    ""),
]

def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

def _fetch(media_type, genre_id):
    params = {
        "api_key": _ESPATV_TMDB_API_KEY,
        "language": "es-ES",
        "region": "ES",
        "sort_by": "vote_average.desc",
        "vote_count.gte": 1000,
        "page": 1,
    }
    if genre_id:
        params["with_genres"] = genre_id
    try:
        r = requests.get(
            "{0}/discover/{1}".format(_TMDB_API, media_type),
            params=params, timeout=10,
        )
        xbmc.log("[EspaTV-TMDB] {0} -> {1}".format(r.url, r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return []
        movies = []
        for item in r.json().get("results", []):
            title  = item.get("title") or item.get("name", "")
            date   = item.get("release_date") or item.get("first_air_date", "")
            year   = int(date[:4]) if date and len(date) >= 4 else 0
            path   = item.get("poster_path", "")
            poster = "{0}{1}".format(_TMDB_IMG, path) if path else ""
            movies.append({
                "title": title, "year": year, "poster": poster,
                "tmdb_id": item.get("id"), "media_type": media_type,
            })
        return movies
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-TMDB] Error: {0}".format(e), xbmc.LOGERROR)
        return []

def menu():
    for label, media_type, genre_id in _GENRES:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultVideoPlaylists.png'})
        url = _u(action="filmaffinity_list", genre="{0}:{1}".format(media_type, genre_id))
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(_handle())

def show_list(genre):
    import metadata_enricher as me

    media_type, genre_id = genre.split(":", 1) if ":" in genre else ("movie", genre)
    movies = _fetch(media_type, genre_id)
    if not movies:
        xbmcgui.Dialog().notification("EspaTV", "No se pudieron cargar los titulos", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    canon_type = 'show' if media_type == 'tv' else 'movie'
    enrich_items = [{'tmdb_id': m['tmdb_id'], 'title': m['title'], 'year': m['year'],
                     'media_type': canon_type} for m in movies]
    metas = me.batch_enrich(enrich_items, use_cache_only=False, max_workers=4)

    for m, meta in zip(movies, metas):
        label = "{0} ({1})".format(m['title'], m['year']) if m['year'] else m['title']
        li = xbmcgui.ListItem(label=label)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or m['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': m['poster'], 'poster': m['poster']})
            li.setInfo('video', {'title': m['title'], 'year': m['year'], 'mediatype': 'movie'})
            poster = m['poster']
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=m['title'], ot=poster, mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espatv_fa_cache.json')


def _load_cache():
    empty = {"cartelera": {}, "posters": {}}
    try:
        path = _cache_path()
        if not os.path.exists(path):
            return empty
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data.get("posters"), dict):
            return empty
        if not isinstance(data.get("cartelera"), dict):
            return empty
        return data
    except (OSError, ValueError) as e:
        xbmc.log("[EspaTV-FA] cache load error: {0}".format(e), xbmc.LOGWARNING)
        return empty


def _save_cache(data):
    try:
        path = _cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError as e:
        xbmc.log("[EspaTV-FA] cache save error: {0}".format(e), xbmc.LOGWARNING)


def _cartelera_fresh(cache):
    c = cache.get("cartelera", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _CARTELERA_TTL


def _scrape_filmaffinity():
    try:
        r = requests.get(
            "{0}/cat_new_th_es.html".format(_FA_BASE),
            headers=_FA_HEADERS, timeout=12,
        )
        xbmc.log("[EspaTV-FA] cat_new_th_es -> {0}".format(r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+data-movie-id=")', r.text):
            id_m = re.search(r'data-movie-id="(\d+)"', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="[^"]*movie-title[^"]*"[^>]*title="([^"]+)"', block)
            if not title_m:
                title_m = re.search(r'class="poster-wrap"[^>]*title="([^"]+)"', block)
            if not title_m:
                continue
            seen.add(fid)
            films.append({'id': fid, 'title': html.unescape(title_m.group(1).strip())})
        if len(films) < _FA_MIN_FILMS:
            xbmc.log(
                "[EspaTV-FA] resultado sospechoso ({0} films), ignorando".format(len(films)),
                xbmc.LOGWARNING,
            )
            return None
        xbmc.log("[EspaTV-FA] scrapeadas {0} películas".format(len(films)), xbmc.LOGINFO)
        return films
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-FA] scrape error: {0}".format(e), xbmc.LOGERROR)
        return None


def _tmdb_poster(title):
    try:
        r = requests.get(
            "{0}/search/movie".format(_TMDB_API),
            params={"api_key": _ESPATV_TMDB_API_KEY, "query": title, "language": "es-ES"},
            timeout=8,
        )
        if r.status_code != 200:
            return ""
        results = r.json().get("results", [])
        if not results:
            return ""
        path = results[0].get("poster_path", "")
        return "{0}{1}".format(_TMDB_IMG, path) if path else ""
    except (requests.RequestException, ValueError):
        return ""


def _resolve_posters(films, poster_cache):
    _key = lambda t: t.lower().strip()
    misses = [f for f in films if _key(f['title']) not in poster_cache]
    if misses:
        xbmc.log("[EspaTV-FA] TMDB: {0} posters nuevos a resolver".format(len(misses)), xbmc.LOGINFO)
        with ThreadPoolExecutor(max_workers=8) as ex:
            future_map = {ex.submit(_tmdb_poster, f['title']): f['title'] for f in misses}
            for future in as_completed(future_map):
                title = future_map[future]
                poster_cache[_key(title)] = future.result()
    return [dict(f, poster=poster_cache.get(_key(f['title']), '')) for f in films]


def _fetch_en_cines():
    cache = _load_cache()

    if _cartelera_fresh(cache):
        films = cache["cartelera"]["films"]
        xbmc.log(
            "[EspaTV-FA] cartelera desde caché ({0} títulos)".format(len(films)),
            xbmc.LOGINFO,
        )
    else:
        scraped = _scrape_filmaffinity()
        if scraped is not None:
            films = scraped
            cache["cartelera"] = {"fetched_at": time.time(), "films": films}
        elif cache.get("cartelera", {}).get("films"):
            films = cache["cartelera"]["films"]
            xbmc.log("[EspaTV-FA] FA inaccesible, usando caché caducada", xbmc.LOGWARNING)
        else:
            return []

    poster_cache = cache.setdefault("posters", {})
    films_with_posters = _resolve_posters(films, poster_cache)
    _save_cache(cache)
    return films_with_posters


def show_cartelera():
    import metadata_enricher as me

    films = _fetch_en_cines()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar FilmAffinity", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False

    if not has_meta:
        li = xbmcgui.ListItem(label="[COLOR yellow][B]>>> Descargar metadatos completos (actores, director...) <<<[/B][/COLOR]")
        li.setArt({'icon': 'DefaultAddonService.png'})
        li.setInfo('video', {'plot': "Descarga sinopsis en español, actores y director de las películas en cartelera."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="filmaffinity_cache_cartelera_meta"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="[COLOR red]Borrar metadatos de cartelera[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        li.setInfo('video', {'plot': "Elimina los metadatos guardados de la cartelera actual."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="filmaffinity_clear_cartelera_meta"), listitem=li, isFolder=False)

    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "Container.Update({0})".format(
                _u(action='search_movie_multi', q=f['title']))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def _top_fresh(cache):
    c = cache.get("top", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _CARTELERA_TTL


def _fetch_tmdb_top_rated():
    try:
        r = requests.get(
            "{0}/movie/top_rated".format(_TMDB_API),
            params={"api_key": _ESPATV_TMDB_API_KEY, "language": "es-ES", "page": 1},
            timeout=12,
        )
        xbmc.log("[EspaTV-FA] top_rated -> {0}".format(r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        for m in r.json().get("results", []):
            title = m.get("title", "").strip()
            if not title:
                continue
            poster_path = m.get("poster_path", "")
            poster = "{0}{1}".format(_TMDB_IMG, poster_path) if poster_path else ""
            year = str(m.get("release_date", ""))[:4]
            rating = "{0:.1f}".format(m.get("vote_average", 0))
            films.append({"tmdb_id": m.get("id"), "id": str(m.get("id", "")),
                          "title": title, "year": year, "rating": rating, "poster": poster})
        if len(films) < _FA_MIN_FILMS:
            xbmc.log(
                "[EspaTV-FA] top_rated sospechoso ({0} films), ignorando".format(len(films)),
                xbmc.LOGWARNING,
            )
            return None
        xbmc.log("[EspaTV-FA] top_rated: {0} películas".format(len(films)), xbmc.LOGINFO)
        return films
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-FA] top_rated error: {0}".format(e), xbmc.LOGERROR)
        return None


def _fetch_top():
    cache = _load_cache()
    if _top_fresh(cache):
        films = cache["top"]["films"]
        xbmc.log(
            "[EspaTV-FA] top desde caché ({0} títulos)".format(len(films)),
            xbmc.LOGINFO,
        )
        return films
    fetched = _fetch_tmdb_top_rated()
    if fetched is not None:
        films = fetched
        cache["top"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("top", {}).get("films"):
        films = cache["top"]["films"]
        xbmc.log("[EspaTV-FA] TMDB inaccesible, usando caché top caducada", xbmc.LOGWARNING)
    else:
        return []
    _save_cache(cache)
    return films


def show_top():
    import metadata_enricher as me

    films = _fetch_top()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar FilmAffinity Top", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    enrich_items = [{'tmdb_id': f.get('tmdb_id') or f.get('id'), 'title': f['title'],
                     'year': int(f['year']) if f.get('year', '').isdigit() else None,
                     'media_type': 'movie'} for f in films]
    metas = me.batch_enrich(enrich_items, use_cache_only=False, max_workers=4)

    for f, meta in zip(films, metas):
        year_int = int(f['year']) if f.get('year', '').isdigit() else 0
        label = "{0} ({1})".format(f['title'], year_int) if year_int else f['title']
        li = xbmcgui.ListItem(label=label)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'year': year_int, 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else f.get('tmdb_id', '')
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "Container.Update({0})".format(
                _u(action='search_movie_multi', q=f['title']))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def cache_cartelera_meta():
    """Descarga y guarda metadatos TMDB para la cartelera actual de FilmAffinity."""
    import metadata_enricher as me

    films = _fetch_en_cines()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No hay películas en cartelera", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Descargando metadatos cartelera...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "EspaTV",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_cartelera_meta():
    """Elimina del caché los metadatos de las películas en cartelera."""
    import metadata_enricher as me

    films = _fetch_en_cines()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("EspaTV", "Metadatos de cartelera eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")
