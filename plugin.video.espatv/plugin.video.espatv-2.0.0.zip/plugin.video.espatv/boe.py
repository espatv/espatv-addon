# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""BOE — Boletín Oficial del Estado. Últimas disposiciones vía RSS oficial."""
import json
import os
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG = "[EspaTV-BOE]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_FILE = os.path.join(_PROFILE, "boe_cache.json")
_CACHE_TTL = 6 * 3600
_TIMEOUT = 15
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_FEEDS = [
    ("BOE — Sumario diario completo",
     "https://www.boe.es/rss/boe.php",
     "royalblue"),
    ("Disposiciones generales (Sección I)",
     "https://www.boe.es/rss/boe.php?s=1",
     "deepskyblue"),
    ("Otras disposiciones (Sección III)",
     "https://www.boe.es/rss/boe.php?s=3",
     "khaki"),
    ("Oposiciones y concursos (Sección II.B)",
     "https://www.boe.es/rss/boe.php?s=2B",
     "mediumseagreen"),
    ("Anuncios oficiales (Sección V.B)",
     "https://www.boe.es/rss/boe.php?s=5B",
     "lightblue"),
    ("Subvenciones y ayudas",
     "https://www.boe.es/rss/canal.php?c=ayudas",
     "gold"),
    ("Becas",
     "https://www.boe.es/rss/canal.php?c=becas",
     "plum"),
]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _load_cache(feed_key):
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        entry = obj.get(feed_key, {})
        if time.time() - entry.get("ts", 0) < _CACHE_TTL:
            return entry.get("items")
    except (OSError, ValueError):
        pass
    return None


def _save_cache(feed_key, items):
    try:
        try:
            with open(_CACHE_FILE, "r", encoding="utf-8") as f:
                obj = json.load(f)
        except (OSError, ValueError):
            obj = {}
        obj[feed_key] = {"ts": time.time(), "items": items}
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except OSError as e:
        xbmc.log("{0} Error guardando caché: {1}".format(_LOG, e), xbmc.LOGWARNING)


def _fetch_rss(url):
    headers = {"User-Agent": "EspaTV/1.0 (Kodi addon; BOE reader)", "Accept": "application/rss+xml, application/xml, */*"}
    resp = requests.get(url, headers=headers, timeout=_TIMEOUT)
    resp.raise_for_status()
    root = ET.fromstring(resp.content)
    ns = {"atom": "http://www.w3.org/2005/Atom"}
    channel = root.find("channel")
    if channel is None:
        return []
    items = []
    for item in channel.findall("item"):
        title = (item.findtext("title") or "").strip()
        link  = (item.findtext("link")  or "").strip()
        desc  = (item.findtext("description") or "").strip()
        pub   = (item.findtext("pubDate") or "").strip()
        if title:
            items.append({"title": title, "link": link, "desc": desc, "pub": pub})
    return items


def boe_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_boe.png")
    for label, url, color in _FEEDS:
        feed_key = urllib.parse.quote_plus(url)
        li = xbmcgui.ListItem(label="[B][COLOR {0}]{1}[/COLOR][/B]".format(color, label))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Fuente: {0}".format(url)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="boe_feed", feed_url=url, feed_label=label), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def boe_feed(feed_url, feed_label):
    h = int(sys.argv[1])
    feed_key = urllib.parse.quote_plus(feed_url)
    items = _load_cache(feed_key)
    if items is None:
        try:
            xbmcgui.Dialog().notification("BOE", "Descargando…", xbmcgui.NOTIFICATION_INFO, 1500)
            items = _fetch_rss(feed_url)
            _save_cache(feed_key, items)
        except Exception as e:
            xbmc.log("{0} Error al obtener RSS: {1}".format(_LOG, e), xbmc.LOGERROR)
            li = xbmcgui.ListItem(label="[COLOR red]Error de conexión — comprueba la red[/COLOR]")
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(h)
            return

    if not items:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin disposiciones disponibles[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    icon = _icon("cat_boe.png")
    for it in items:
        plot = "{0}\n\n{1}\n\n{2}".format(it["title"], it["pub"], it["desc"])
        li = xbmcgui.ListItem(label=it["title"])
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": it["title"], "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="boe_view", title=it["title"], plot=plot), listitem=li, isFolder=False)

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Recarga desde el BOE."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="boe_refresh", feed_url=feed_url, feed_label=feed_label), listitem=li_r, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def boe_view(title, plot):
    xbmcgui.Dialog().textviewer(title, plot)


def boe_refresh(feed_url, feed_label):
    feed_key = urllib.parse.quote_plus(feed_url)
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
    except (OSError, ValueError):
        obj = {}
    obj.pop(feed_key, None)
    try:
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except OSError:
        pass
    xbmc.executebuiltin("Container.Update({0},replace)".format(
        _u(action="boe_feed", feed_url=feed_url, feed_label=feed_label)))
