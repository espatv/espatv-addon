# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Precio PVPC horario de la luz desde apidatos.ree.es."""
import datetime
import json
import os
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_API = "https://apidatos.ree.es/es/datos/mercados/precios-mercados-tiempo-real"
_HEADERS = {'Accept': 'application/json', 'User-Agent': 'EspaTV/1.0'}
_PROFILE = xbmcvfs.translatePath(
    xbmcaddon.Addon("plugin.video.espatv").getAddonInfo('profile')
)
_CACHE_FILE = os.path.join(_PROFILE, 'precio_luz_cache.json')
_CACHE_TTL = 3600

_GEO_PENINSULAR = '8741'
_HTTP_TIMEOUT = 15
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'media')


def _icon(name, fallback='DefaultIconInfo.png'):
    p = os.path.join(_MEDIA, name)
    return p if os.path.exists(p) else fallback

_COLOR_BY_BAND = {
    'cheap':     'lightgreen',
    'under_avg': 'yellowgreen',
    'over_avg':  'orange',
    'expensive': 'lightcoral',
}


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _load_cache():
    try:
        with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
            obj = json.load(f)
        if (time.time() - obj.get('ts', 0)) < _CACHE_TTL:
            return obj.get('data')
    except (OSError, ValueError):
        return None
    return None


def _get_cache_ts():
    try:
        with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
            obj = json.load(f)
        return obj.get('ts', 0)
    except (OSError, ValueError):
        return 0


def _save_cache(data):
    try:
        if not os.path.isdir(_PROFILE):
            os.makedirs(_PROFILE, exist_ok=True)
        with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump({'ts': time.time(), 'data': data}, f, ensure_ascii=False)
    except OSError:
        pass


def _parse_hour(dt_str):
    if not dt_str or len(dt_str) < 13:
        return ''
    return dt_str[11:13]


def _fetch_day(target_date):
    params = {
        'start_date': target_date.strftime("%Y-%m-%dT00:00"),
        'end_date':   target_date.strftime("%Y-%m-%dT23:59"),
        'time_trunc': 'hour',
        'geo_limit':  'peninsular',
        'geo_ids':    _GEO_PENINSULAR,
    }
    try:
        r = requests.get(_API, params=params, headers=_HEADERS, timeout=_HTTP_TIMEOUT)
        if r.status_code != 200:
            return []
        payload = r.json()
    except (requests.RequestException, ValueError):
        return []

    included = payload.get('included') or []
    if not included:
        return []
    values = (included[0].get('attributes') or {}).get('values') or []

    out = []
    for v in values:
        try:
            price_mwh = float(v['value'])
        except (KeyError, TypeError, ValueError):
            continue
        out.append({
            'hour': _parse_hour(v.get('datetime', '')),
            'price_kwh': price_mwh / 1000.0,
        })
    return out


def _fetch():
    cached = _load_cache()
    if cached is not None:
        return cached
    today = datetime.date.today()
    payload = {
        'today':    _fetch_day(today),
        'tomorrow': _fetch_day(today + datetime.timedelta(days=1)),
    }
    if payload['today']:
        _save_cache(payload)
    return payload


def _band(idx, n):
    """Devuelve la banda 'cheap'/'under_avg'/'over_avg'/'expensive' segun cuartil."""
    if idx == 0:
        return 'cheap'
    if idx == n - 1:
        return 'expensive'
    if idx < n / 4:
        return 'cheap'
    if idx < n / 2:
        return 'under_avg'
    if idx < 3 * n / 4:
        return 'over_avg'
    return 'expensive'


def _classify_day(day_list):
    """Anota cada item con band/is_min/is_max sin colisionar precios duplicados."""
    if not day_list:
        return [], None
    ranking = sorted(range(len(day_list)), key=lambda i: day_list[i]['price_kwh'])
    n = len(ranking)
    annotated = [dict(item) for item in day_list]
    for rank, original_idx in enumerate(ranking):
        annotated[original_idx]['band'] = _band(rank, n)
        annotated[original_idx]['is_min'] = (rank == 0)
        annotated[original_idx]['is_max'] = (rank == n - 1)
    prices = [item['price_kwh'] for item in day_list]
    stats = {
        'min': min(prices),
        'max': max(prices),
        'avg': sum(prices) / n,
        'min_hour': day_list[ranking[0]]['hour'],
        'max_hour': day_list[ranking[-1]]['hour'],
    }
    return annotated, stats


def _summary_line(stats):
    if not stats:
        return ""
    return "Mín: {0}:00 ({1:.4f} €/kWh) · Máx: {2}:00 ({3:.4f} €/kWh) · Media: {4:.4f} €/kWh".format(
        stats['min_hour'], stats['min'],
        stats['max_hour'], stats['max'],
        stats['avg'],
    )


def _add_day_items(handle, annotated):
    for item in annotated:
        color = _COLOR_BY_BAND.get(item['band'], 'white')
        flag = ""
        if item['is_min']:
            flag = "  [B][COLOR lightgreen]MIN[/COLOR][/B]"
        elif item['is_max']:
            flag = "  [B][COLOR lightcoral]MAX[/COLOR][/B]"
        label = "[COLOR {0}]{1}:00[/COLOR]   {2:.4f} €/kWh{3}".format(
            color, item['hour'], item['price_kwh'], flag,
        )
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setProperty("IsPlayable", "false")
        li.setInfo('video', {'plot': "Hora: {0}:00\nPrecio: {1:.4f} €/kWh ({2:.2f} €/MWh)".format(
            item['hour'], item['price_kwh'], item['price_kwh'] * 1000,
        )})
        xbmcplugin.addDirectoryItem(
            handle=handle, url=_u(action="noop"), listitem=li, isFolder=False,
        )


def _add_section_header(handle, label, plot):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultIconInfo.png'})
    li.setProperty("IsPlayable", "false")
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(
        handle=handle, url=_u(action="noop"), listitem=li, isFolder=False,
    )


def precio_luz_menu():
    handle = int(sys.argv[1])
    data = _fetch()
    today_list = data.get('today') or []
    tomorrow_list = data.get('tomorrow') or []

    ts = _get_cache_ts()
    if ts:
        ts_str = datetime.datetime.fromtimestamp(ts).strftime("%d/%m/%Y %H:%M")
        li_ts = xbmcgui.ListItem(
            label="[B][COLOR lightgray]Última actualización: {0}[/COLOR][/B]".format(ts_str)
        )
        li_ts.setArt({'icon': _icon('adv_cache.png')})
        li_ts.setProperty("IsPlayable", "false")
        li_ts.setInfo('video', {'plot': "Datos obtenidos el {0} de apidatos.ree.es".format(ts_str)})
        xbmcplugin.addDirectoryItem(handle=handle, url=_u(action="noop"), listitem=li_ts, isFolder=False)

    # Botón refrescar
    li_ref = xbmcgui.ListItem(label="[B][COLOR aqua][ Refrescar datos ][/COLOR][/B]")
    li_ref.setArt({'icon': _icon('adv_refrescar.png')})
    li_ref.setProperty("IsPlayable", "false")
    li_ref.setInfo('video', {'plot': "Borra la caché y descarga los precios más recientes de REE."})
    xbmcplugin.addDirectoryItem(handle=handle, url=_u(action="precio_luz_refresh"),
                                listitem=li_ref, isFolder=False)

    if not today_list:
        xbmcgui.Dialog().notification(
            "EspaTV", "No se pudo obtener el precio de la luz",
            xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        xbmcplugin.endOfDirectory(handle)
        return

    today = datetime.date.today()
    today_ann, today_stats = _classify_day(today_list)
    _add_section_header(
        handle,
        "[B][COLOR royalblue]Hoy {0}[/COLOR][/B]".format(today.strftime("%d/%m/%Y")),
        "Precios PVPC España peninsular.\n{0}".format(_summary_line(today_stats)),
    )
    _add_day_items(handle, today_ann)

    if tomorrow_list:
        tomorrow_ann, tomorrow_stats = _classify_day(tomorrow_list)
        _add_section_header(
            handle,
            "[B][COLOR mediumpurple]Mañana {0}[/COLOR][/B]".format(
                (today + datetime.timedelta(days=1)).strftime("%d/%m/%Y")
            ),
            _summary_line(tomorrow_stats),
        )
        _add_day_items(handle, tomorrow_ann)
    else:
        _add_section_header(
            handle,
            "[COLOR gray][I]Precios de mañana disponibles a partir de las 20:30[/I][/COLOR]",
            "",
        )

    xbmcplugin.endOfDirectory(handle)


def precio_luz_refresh():
    try:
        if os.path.exists(_CACHE_FILE):
            os.remove(_CACHE_FILE)
    except OSError:
        pass
    xbmcgui.Dialog().notification(
        "EspaTV", "Caché borrada — recargando…",
        xbmcgui.NOTIFICATION_INFO, 2000,
    )
    xbmc.executebuiltin("Container.Update({0})".format(_u(action="precio_luz_menu")))
