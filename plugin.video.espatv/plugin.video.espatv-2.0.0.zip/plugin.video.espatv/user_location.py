# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Helper centralizado de localización del usuario (provincia, CCAA, municipio)."""
import xbmcaddon

# Nombre de provincia -> código INE (2 dígitos)
_PROVINCIA_ID = {
    "Álava": "01",        "Albacete": "02",    "Alicante": "03",     "Almería": "04",
    "Ávila": "05",        "Badajoz": "06",     "Baleares": "07",     "Barcelona": "08",
    "Burgos": "09",       "Cáceres": "10",     "Cádiz": "11",        "Castellón": "12",
    "Ciudad Real": "13",  "Córdoba": "14",     "La Coruña": "15",    "Cuenca": "16",
    "Girona": "17",       "Granada": "18",     "Guadalajara": "19",  "Guipúzcoa": "20",
    "Huelva": "21",       "Huesca": "22",      "Jaén": "23",         "León": "24",
    "Lleida": "25",       "La Rioja": "26",    "Lugo": "27",         "Madrid": "28",
    "Málaga": "29",       "Murcia": "30",      "Navarra": "31",      "Ourense": "32",
    "Asturias": "33",     "Palencia": "34",    "Las Palmas": "35",   "Pontevedra": "36",
    "Salamanca": "37",    "Santa Cruz de Tenerife": "38", "Cantabria": "39",
    "Segovia": "40",      "Sevilla": "41",     "Soria": "42",        "Tarragona": "43",
    "Teruel": "44",       "Toledo": "45",      "Valencia": "46",     "Valladolid": "47",
    "Vizcaya": "48",      "Zamora": "49",      "Zaragoza": "50",
    "Ceuta": "51",        "Melilla": "52",
}

_CCAA_CODIGO = {
    "Andalucía": "AN",          "Aragón": "AR",          "Asturias": "AS",
    "Baleares": "IB",           "Canarias": "CN",        "Cantabria": "CB",
    "Castilla-La Mancha": "CM", "Castilla y León": "CL", "Cataluña": "CT",
    "Ceuta": "CE",              "Comunidad Valenciana": "VC", "Extremadura": "EX",
    "Galicia": "GA",            "La Rioja": "RI",        "Madrid": "MD",
    "Melilla": "ML",            "Murcia": "MU",          "Navarra": "NC",
    "País Vasco": "PV",
}

# Festivos autonómicos extra (además de los nacionales) por código CCAA
# Fecha en formato (mes, dia) — se calcula para el año en curso
CCAA_FESTIVOS_EXTRA = {
    "AN": [(2, 28, "Día de Andalucía")],
    "AR": [(4, 23, "Día de Aragón")],
    "AS": [(9, 8, "Día de Asturias")],
    "IB": [(3, 1, "Día de las Islas Baleares")],
    "CN": [(5, 30, "Día de Canarias")],
    "CB": [(8, 15, "Virgen Grande (Cantabria)")],
    "CM": [(5, 31, "Día de Castilla-La Mancha")],
    "CL": [(4, 23, "Día de Castilla y León")],
    "CT": [(9, 11, "Diada de Catalunya")],
    "CE": [(3, 5, "Día de Ceuta")],
    "VC": [(10, 9, "Día de la Comunitat Valenciana")],
    "EX": [(9, 8, "Día de Extremadura")],
    "GA": [(7, 25, "Día de Galicia")],
    "RI": [(6, 9, "Día de La Rioja")],
    "MD": [(5, 2, "Día de la Comunidad de Madrid")],
    "ML": [(9, 17, "Día de Melilla")],
    "MU": [(6, 9, "Día de la Región de Murcia")],
    "NC": [(9, 27, "Día de Navarra")],
    "PV": [(10, 25, "Día del País Vasco")],
}


def get_provincia():
    return xbmcaddon.Addon().getSetting("user_provincia") or "Madrid"


def get_municipio():
    return xbmcaddon.Addon().getSetting("user_municipio") or ""


def get_codigo_postal():
    return xbmcaddon.Addon().getSetting("user_codigo_postal") or ""


def get_ccaa():
    return xbmcaddon.Addon().getSetting("user_ccaa") or "Madrid"


def get_signo_zodiaco():
    return xbmcaddon.Addon().getSetting("user_signo_zodiaco") or "Aries"


def provincia_id_minetur(provincia_str=None):
    """Devuelve el código INE de dos dígitos para la API de minetur."""
    if provincia_str is None:
        provincia_str = get_provincia()
    return _PROVINCIA_ID.get(provincia_str, "28")


def ccaa_codigo(ccaa_str=None):
    """Devuelve el código ISO 3166-2:ES de la CCAA."""
    if ccaa_str is None:
        ccaa_str = get_ccaa()
    return _CCAA_CODIGO.get(ccaa_str, "MD")
