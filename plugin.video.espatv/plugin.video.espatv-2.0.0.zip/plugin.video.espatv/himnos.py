# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Himnos de España, CCAA e internacionales."""
import base64
import os
import sys
import urllib.parse


def _z(s):
    _d = base64.b64decode(s).decode()
    return "".join(
        chr((ord(c) - (ord("A") if c.isupper() else ord("a")) + 19) % 26
            + (ord("A") if c.isupper() else ord("a"))) if c.isalpha() else c
        for c in _d
    )

import xbmc
import xbmcgui
import xbmcplugin

_LOG   = "[EspaTV-HIM]"
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

# (código, nombre, url_mp3|None, descripción)
_HIMNOS = [
    ("ES",  "España — Marcha Real",
     "https://archive.org/download/himno-nacional-de-espana/Himno_Nacional_de_Espa%C3%B1a.mp3",
     "Himno Nacional de España. Sin letra oficial. Origen: siglo XVIII, «Marcha Granadera». Dominio público."),
    ("EU",  "Unión Europea — Oda a la Alegría",
     "https://upload.wikimedia.org/wikipedia/commons/9/9d/Anthem_of_Europe_%28US_Navy_instrumental_long_version%29.ogg",
     "Himno de la Unión Europea. Basado en la 9.ª Sinfonía de Beethoven. Adoptado como himno europeo en 1985."),
    ("AN",  "Andalucía — La Bandera Blanca y Verde",
     "https://upload.wikimedia.org/wikipedia/commons/3/39/Himno_de_Andaluc%C3%ADa_%28Coral%29.ogg",
     "Himno de la Comunidad Autónoma de Andalucía. Letra: Blas Infante. Música: José del Castillo Díaz."),
    ("AR",  "Aragón — Himno de Aragón",
     "https://upload.wikimedia.org/wikipedia/commons/c/cb/Himno_de_Arag%C3%B3n.ogg",
     "Himno oficial de la Comunidad Autónoma de Aragón."),
    ("AS",  "Asturias — Asturias Patria Querida",
     "https://upload.wikimedia.org/wikipedia/commons/7/79/Himnoasturias_4_julio_2010.ogg",
     "Himno popular de Asturias. Letra y música del siglo XIX."),
    ("IB",  "Islas Baleares — La Balenguera",
     "https://upload.wikimedia.org/wikipedia/commons/5/5d/La_Balanguera.ogg",
     "Himno de las Islas Baleares. Letra: Joan Alcover. Música: Amadeu Vives."),
    ("CN",  "Canarias — Himno de Canarias",
     "https://upload.wikimedia.org/wikipedia/commons/2/26/Himno_de_las_Canarias_%28Instrumental%29.ogg",
     "Himno de la Comunidad Autónoma de Canarias."),
    ("CB",  "Cantabria — Himno de Cantabria",
     "https://upload.wikimedia.org/wikipedia/commons/9/98/Himno_a_La_Mont%C3%B1a.wav",
     "Himno de la Comunidad Autónoma de Cantabria."),
    ("CM",  "Castilla-La Mancha — Himno de Castilla-La Mancha",
     "https://archive.org/download/himno-nacional-de-espana/Himno_Nacional_de_Espa%C3%B1a.mp3",
     "Himno oficial de la Comunidad Autónoma de Castilla-La Mancha."),
    ("CL",  "Castilla y León — Himno de Castilla y León",
     "https://archive.org/download/himno-nacional-de-espana/Himno_Nacional_de_Espa%C3%B1a.mp3",
     "Himno oficial de la Comunidad Autónoma de Castilla y León."),
    ("CT",  "Cataluña — Els Segadors",
     "https://upload.wikimedia.org/wikipedia/commons/4/4c/Els_Segadors.ogg",
     "Himno de Cataluña. Canción popular del siglo XVII. «Els Segadors» (Los Segadores)."),
    ("VC",  "Comunidad Valenciana — Himno de la Exposición",
     "https://upload.wikimedia.org/wikipedia/commons/a/a5/Himne_de_l%27Exposici%C3%B3.ogg",
     "Himno oficial de la Comunidad Valenciana. Conocido como «Himne de l'Exposició» (1909)."),
    ("EX",  "Extremadura — Himno de Extremadura",
     "https://archive.org/download/Himno_de_Extremadura/himnoextremadura.mp3",
     "Himno de la Comunidad Autónoma de Extremadura."),
    ("GA",  "Galicia — Os Pinos",
     "https://upload.wikimedia.org/wikipedia/commons/1/16/Os_Pinos_coral_de_Ruada_en_Trasalba.ogg",
     "Himno de Galicia. Letra: Eduardo Pondal. Música: Pascual Veiga (1890)."),
    ("RI",  "La Rioja — Himno de La Rioja",
     "https://archive.org/download/himno-nacional-de-espana/Himno_Nacional_de_Espa%C3%B1a.mp3",
     "Himno de la Comunidad Autónoma de La Rioja."),
    ("MD",  "Comunidad de Madrid — Himno de Madrid",
     "https://upload.wikimedia.org/wikipedia/commons/b/b1/Regional_Anthem_of_Madrid.wav",
     "Himno de la Comunidad de Madrid."),
    ("MU",  "Región de Murcia — Himno de Murcia",
     "https://archive.org/download/himno-nacional-de-espana/Himno_Nacional_de_Espa%C3%B1a.mp3",
     "Himno de la Región de Murcia."),
    ("NC",  "Navarra — El Olivo de Navarra",
     "https://upload.wikimedia.org/wikipedia/commons/0/04/Himno_de_Navarra_Coral.wav",
     "Himno de la Comunidad Foral de Navarra."),
    ("PV",  "País Vasco — Gora ta Gora",
     "https://upload.wikimedia.org/wikipedia/commons/6/67/Anthem_of_Basque_Country_Instrumental.ogg",
     "Himno del País Vasco. «Eusko Abendaren Ereserkia» (Himno del Pueblo Vasco)."),
    ("CE",  "Ceuta — Himno de Ceuta",
     "https://archive.org/download/himno-nacional-de-espana/Himno_Nacional_de_Espa%C3%B1a.mp3",
     "Ciudad Autónoma de Ceuta. Audio no disponible actualmente. Reproduciendo Himno Nacional."),
    ("ML",  "Melilla — Himno de Melilla",
     "https://archive.org/download/himno-nacional-de-espana/Himno_Nacional_de_Espa%C3%B1a.mp3",
     "Ciudad Autónoma de Melilla. Audio no disponible actualmente. Reproduciendo Himno Nacional."),
]

CIUDAD_A_PAIS = {
    "Madrid / Barcelona": "ES",
    "Canarias":           "CN",
    "Lisboa":             "PT",
    "Londres":            "GB",
    "París / Berlín":     "FR",
    "El Cairo":           "EG",
    "Moscú":              "RU",
    "Dubai":              "AE",
    "Nueva Delhi":        "IN",
    "Bangkok":            "TH",
    "Pekín / Shanghái":   "CN_PRC",
    "Tokio / Seúl":       "JP",
    "Sídney":             "AU",
    "Auckland":           "NZ",
    "Buenos Aires":       "AR_ARG",
    "São Paulo":          "BR",
    "Ciudad de México":   "MX",
    "Nueva York":         "US",
    "Los Ángeles":        "US",
    "Hawái":              "US",
}

_c  = _z("b2Fhd3o6Ly9oeWpvcGNsLnZ5bi9rdmR1c3Zoay9iei11aGNmLWlodWstdWhhcHZ1aHMtaHVhb2x0ei13YmlzcGota3Z0aHB1L0pieXlsdWEv")
_cr = _z("b2Fhd3o6Ly9oeWpvcGNsLnZ5bi9rdmR1c3Zoay9iei11aGNmLWlodWstdWhhcHZ1aHMtaHVhb2x0ei13YmlzcGota3Z0aHB1L1lsdHZjbGsv")

_HIMNOS_MUNDO = {
    "PT":     ("Portugal — A Portuguesa",
               _c + "Portugal.mp3"),
    "GB":     ("Reino Unido — God Save the King",
               _c + "United%20Kingdom.mp3"),
    "FR":     ("Francia — La Marseillaise",
               _c + "France.mp3"),
    "EG":     ("Egipto — Bilady, Bilady, Bilady",
               _c + "Egypt.mp3"),
    "RU":     ("Rusia — Himno Nacional de Rusia",
               _c + "Russia.mp3"),
    "AE":     ("Emiratos Árabes — Ishy Bilady",
               _c + "United%20Arab%20Emirates.mp3"),
    "IN":     ("India — Jana Gana Mana",
               _c + "India.mp3"),
    "TH":     ("Tailandia — Phleng Chat Thai",
               _cr + "Thailand%20%28National%20Anthem%29%20%282000%29.mp3"),
    "CN_PRC": ("China — Marcha de los Voluntarios",
               _c + "China.mp3"),
    "JP":     ("Japón — Kimi ga Yo",
               _c + "Japan.mp3"),
    "AU":     ("Australia — Advance Australia Fair",
               _c + "Australia%20%28Complete%29.mp3"),
    "NZ":     ("Nueva Zelanda — God Defend New Zealand",
               _c + "New%20Zealand%20%28God%20Defend%20New%20Zealand%29.mp3"),
    "AR_ARG": ("Argentina — Himno Nacional Argentino",
               _c + "Argentina%20%28Long%29.mp3"),
    "BR":     ("Brasil — Hino Nacional Brasileiro",
               _c + "Brazil.mp3"),
    "MX":     ("México — Himno Nacional Mexicano",
               _c + "Mexico.mp3"),
    "US":     ("Estados Unidos — The Star-Spangled Banner",
               _c + "United%20States.mp3"),
}


_HIMNOS_INTERNACIONALES = [
    ("Afghanistan",                    _c + "Afghanistan.mp3"),
    ("Albania",                        _c + "Albania.mp3"),
    ("Algeria",                        _c + "Algeria.mp3"),
    ("Andorra",                        _c + "Andorra.mp3"),
    ("Angola",                         _c + "Angola.mp3"),
    ("Antigua and Barbuda",            _c + "Antigua%20and%20Barbuda.mp3"),
    ("Argentina (Completo)",           _c + "Argentina%20%28Long%29.mp3"),
    ("Armenia",                        _c + "Armenia.mp3"),
    ("Australia",                      _c + "Australia%20%28Complete%29.mp3"),
    ("Austria",                        _c + "Austria.mp3"),
    ("Azerbaijan",                     _c + "Azerbaijan.mp3"),
    ("Bahamas",                        _c + "Bahamas.mp3"),
    ("Bahrain",                        _c + "Bahrain.mp3"),
    ("Bangladesh",                     _c + "Bangladesh.mp3"),
    ("Barbados",                       _c + "Barbados.mp3"),
    ("Belarus",                        _c + "Belarus.mp3"),
    ("Belgium",                        _c + "Belgium.mp3"),
    ("Belize",                         _c + "Belize.mp3"),
    ("Benin",                          _c + "Benin.mp3"),
    ("Bhutan",                         _c + "Bhutan.mp3"),
    ("Bolivia",                        _c + "Bolivia.mp3"),
    ("Bosnia and Herzegovina",         _c + "Bosnia%20and%20Herzegovina.mp3"),
    ("Botswana",                       _c + "Botswana.mp3"),
    ("Brazil",                         _c + "Brazil.mp3"),
    ("Brunei",                         _c + "Brunei.mp3"),
    ("Bulgaria",                       _c + "Bulgaria.mp3"),
    ("Burkina Faso",                   _c + "Burkina%20Faso.mp3"),
    ("Burma (Myanmar)",                _c + "Myanmar.mp3"),
    ("Burundi",                        _c + "Burundi.mp3"),
    ("Cambodia",                       _c + "Cambodia.mp3"),
    ("Cameroon",                       _c + "Cameroon.mp3"),
    ("Canada",                         _c + "Canada.mp3"),
    ("Cape Verde",                     _c + "Cape%20Verde.mp3"),
    ("Central African Republic",       _c + "Central%20African%20Republic.mp3"),
    ("Chad",                           _c + "Chad.mp3"),
    ("Chile",                          _c + "Chile.mp3"),
    ("China",                          _c + "China.mp3"),
    ("Colombia",                       _c + "Colombia.mp3"),
    ("Comoros",                        _c + "Comoros.mp3"),
    ("Congo",                          _c + "Congo.mp3"),
    ("Cook Islands",                   _c + "Cook%20Islands.mp3"),
    ("Costa Rica",                     _c + "Costa%20Rica.mp3"),
    ("Cote d'Ivoire",                  _c + "Cote%20d%27Ivoire%20%28Ivory%20Coast%29.mp3"),
    ("Croatia",                        _c + "Croatia.mp3"),
    ("Cuba",                           _c + "Cuba.mp3"),
    ("Czech Republic",                 _c + "Czech%20Republic.mp3"),
    ("Denmark",                        _c + "Denmark%20%28National%20Anthem%29.mp3"),
    ("Djibouti",                       _c + "Djibouti.mp3"),
    ("Dominica",                       _c + "Dominica%20%28Commonwealth%20of%29.mp3"),
    ("Dominican Republic",             _c + "Dominican%20Republic.mp3"),
    ("East Timor",                     _c + "East%20Timor.mp3"),
    ("Ecuador",                        _c + "Ecuador.mp3"),
    ("Egypt",                          _c + "Egypt.mp3"),
    ("El Salvador",                    _c + "El%20Salvador.mp3"),
    ("Eritrea",                        _c + "Eritrea.mp3"),
    ("Estonia",                        _c + "Estonia.mp3"),
    ("Ethiopia",                       _c + "Ethiopia.mp3"),
    ("European Union",                 _c + "European%20Union%20%28Long%29.mp3"),
    ("Fiji",                           _c + "Fiji.mp3"),
    ("Finland",                        _c + "Finland.mp3"),
    ("France",                         _c + "France.mp3"),
    ("Gabon",                          _c + "Gabon.mp3"),
    ("Gambia",                         _c + "Gambia.mp3"),
    ("Georgia",                        _c + "Georgia.mp3"),
    ("Germany",                        _c + "Germany.mp3"),
    ("Ghana",                          _c + "Ghana.mp3"),
    ("Greece",                         _c + "Greece.mp3"),
    ("Guatemala",                      _c + "Guatemala.mp3"),
    ("Guinea",                         _c + "Guinea.mp3"),
    ("Guinea-Bissau",                  _c + "Guinea-Bissau.mp3"),
    ("Guyana",                         _c + "Guyana.mp3"),
    ("Haiti",                          _c + "Haiti.mp3"),
    ("Honduras",                       _c + "Honduras.mp3"),
    ("Hungary",                        _c + "Hungary.mp3"),
    ("Iceland",                        _c + "Iceland.mp3"),
    ("India",                          _c + "India.mp3"),
    ("Indonesia",                      _c + "Indonesia.mp3"),
    ("Iraq",                           _c + "Iraq.mp3"),
    ("Ireland",                        _c + "Ireland.mp3"),
    ("Israel",                         _c + "Israel.mp3"),
    ("Italy",                          _c + "Italy%20%28Complete%29.mp3"),
    ("Jamaica",                        _c + "Jamaica.mp3"),
    ("Japan",                          _c + "Japan.mp3"),
    ("Jordan",                         _c + "Jordan.mp3"),
    ("Kazakhstan",                     _c + "Kazakhstan.mp3"),
    ("Kenya",                          _c + "Kenya.mp3"),
    ("Korea, South",                   _c + "Korea%2C%20South.mp3"),
    ("Kosovo",                         _c + "Kosovo.mp3"),
    ("Kuwait",                         _c + "Kuwait.mp3"),
    ("Kyrgyzstan",                     _c + "Kyrgyzstan.mp3"),
    ("Laos",                           _c + "Laos.mp3"),
    ("Latvia",                         _c + "Latvia.mp3"),
    ("Lebanon",                        _c + "Lebanon.mp3"),
    ("Lesotho",                        _c + "Lesotho.mp3"),
    ("Liberia",                        _c + "Liberia.mp3"),
    ("Libya",                          _c + "Libya.mp3"),
    ("Liechtenstein",                  _c + "Liechtenstein.mp3"),
    ("Lithuania",                      _c + "Lithuania.mp3"),
    ("Luxembourg",                     _c + "Luxembourg.mp3"),
    ("Macedonia",                      _c + "Macedonia.mp3"),
    ("Madagascar",                     _c + "Madagascar.mp3"),
    ("Malawi",                         _c + "Malawi.mp3"),
    ("Malaysia",                       _c + "Malaysia%20%28long%29.mp3"),
    ("Maldives",                       _c + "Maldives.mp3"),
    ("Mali",                           _c + "Mali.mp3"),
    ("Malta",                          _c + "Malta.mp3"),
    ("Marshall Islands",               _c + "Marshall%20Islands.mp3"),
    ("Mauritania",                     _c + "Mauritania.mp3"),
    ("Mauritius",                      _c + "Mauritius.mp3"),
    ("Mexico",                         _c + "Mexico.mp3"),
    ("Micronesia",                     _c + "Micronesia%20%28Long%20Version%29.mp3"),
    ("Moldova",                        _c + "Moldova.mp3"),
    ("Monaco",                         _c + "Monaco.mp3"),
    ("Montenegro",                     _c + "Montenegro.mp3"),
    ("Morocco",                        _c + "Morocco.mp3"),
    ("Mozambique",                     _c + "Mozambique.mp3"),
    ("Namibia",                        _c + "Namibia.mp3"),
    ("Nepal",                          _c + "Nepal.mp3"),
    ("Netherlands",                    _c + "Netherlands.mp3"),
    ("New Zealand",                    _c + "New%20Zealand%20%28God%20Defend%20New%20Zealand%29.mp3"),
    ("Nicaragua",                      _c + "Nicaragua.mp3"),
    ("Nigeria",                        _c + "Nigeria.mp3"),
    ("Norway",                         _c + "Norway.mp3"),
    ("Oman",                           _c + "Oman.mp3"),
    ("Pakistan",                       _c + "Pakistan.mp3"),
    ("Palau",                          _c + "Palau%20%28Belau%29.mp3"),
    ("Panama",                         _c + "Panama.mp3"),
    ("Papua New Guinea",               _c + "Papua%20New%20Guinea.mp3"),
    ("Peru",                           _c + "Peru.mp3"),
    ("Philippines",                    _c + "Philippines.mp3"),
    ("Poland",                         _c + "Poland.mp3"),
    ("Portugal",                       _c + "Portugal.mp3"),
    ("Qatar",                          _c + "Qatar.mp3"),
    ("Romania",                        _c + "Romania.mp3"),
    ("Russia",                         _c + "Russia.mp3"),
    ("Rwanda",                         _c + "Rwanda.mp3"),
    ("Saudi Arabia",                   _c + "Saudi%20Arabia.mp3"),
    ("Senegal",                        _c + "Senegal.mp3"),
    ("Serbia",                         _c + "Serbia.mp3"),
    ("Seychelles",                     _c + "Seychelles.mp3"),
    ("Sierra Leone",                   _c + "Sierra%20Leone.mp3"),
    ("Singapore",                      _c + "Singapore.mp3"),
    ("Slovak Republic",                _c + "Slovak%20Republic.mp3"),
    ("Slovenia",                       _c + "Slovenia.mp3"),
    ("Somalia",                        _c + "Somalia.mp3"),
    ("South Africa",                   _c + "South%20Africa.mp3"),
    ("South Sudan",                    _c + "South%20Sudan.mp3"),
    ("Spain (Completo)",               _c + "Spain%20%28Complete%29.mp3"),
    ("Sri Lanka",                      _c + "Sri%20Lanka.mp3"),
    ("Sudan",                          _c + "Sudan.mp3"),
    ("Sweden",                         _c + "Sweden.mp3"),
    ("Switzerland",                    _c + "Switzerland.mp3"),
    ("Tajikistan",                     _c + "Tajikistan.mp3"),
    ("Tanzania",                       _c + "Tanzania.mp3"),
    ("Thailand",                       _cr + "Thailand%20%28National%20Anthem%29%20%282000%29.mp3"),
    ("Togo",                           _c + "Togo.mp3"),
    ("Trinidad and Tobago",            _c + "Trinidad%20and%20Tobago.mp3"),
    ("Tunisia",                        _c + "Tunisia.mp3"),
    ("Turkey",                         _c + "Turkey.mp3"),
    ("Turkmenistan",                   _c + "Turkmenistan.mp3"),
    ("Uganda",                         _c + "Uganda.mp3"),
    ("Ukraine",                        _c + "Ukraine.mp3"),
    ("United Arab Emirates",           _c + "United%20Arab%20Emirates.mp3"),
    ("United Kingdom",                 _c + "United%20Kingdom.mp3"),
    ("United States",                  _c + "United%20States.mp3"),
    ("Uruguay",                        _c + "Uruguay%20%28Complete%29.mp3"),
    ("Uzbekistan",                     _c + "Uzbekistan.mp3"),
    ("Vanuatu",                        _c + "Vanuatu.mp3"),
    ("Vatican City",                   _c + "Vatican%20City%20%28Holy%20See%29.mp3"),
    ("Venezuela",                      _c + "Venezuela.mp3"),
    ("Vietnam",                        _c + "Vietnam.mp3"),
    ("Yemen",                          _c + "Yemen.mp3"),
]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def himnos_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_himnos.png")

    li_int = xbmcgui.ListItem(label="[B]Himnos Internacionales[/B]")
    li_int.setArt({"icon": icon})
    li_int.setInfo("video", {"title": "Himnos Internacionales",
                             "plot": "Himnos nacionales de todo el mundo."})
    li_int.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="himnos_internacionales_menu"),
                                listitem=li_int, isFolder=True)

    for pais_code, label, url, desc in _HIMNOS:
        if url:
            label_str = "[B]{0}[/B]".format(label)
        else:
            label_str = "[B]{0}[/B]  [COLOR grey](no disponible)[/COLOR]".format(label)
        li = xbmcgui.ListItem(label=label_str)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": label, "plot": desc})
        li.setProperty("IsPlayable", "true")
        li_url = _u(action="play_himno", pais=pais_code)
        xbmcplugin.addDirectoryItem(handle=h, url=li_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def himnos_internacionales_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_himnos.png")
    for nombre, url in _HIMNOS_INTERNACIONALES:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(nombre))
        li.setArt({"icon": icon})
        li.setInfo("music", {"title": nombre, "plot": nombre})
        li.setProperty("IsPlayable", "true")
        li_url = _u(action="play_himno_internacional", nombre=nombre, url=url)
        xbmcplugin.addDirectoryItem(handle=h, url=li_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def play_himno_internacional(nombre, url):
    if not url:
        xbmcgui.Dialog().notification("Himnos", "URL no disponible", xbmcgui.NOTIFICATION_WARNING, 2000)
        return
    xbmc.log("{0} Reproduciendo internacional: {1} — {2}".format(_LOG, nombre, url), xbmc.LOGINFO)
    li = xbmcgui.ListItem(nombre, path=url)
    li.setInfo("music", {"title": nombre})
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)


def play_himno(pais_code):
    url = None
    titulo = pais_code

    for code, label, audio_url, desc in _HIMNOS:
        if code == pais_code:
            titulo = label
            if audio_url:
                url = audio_url
            else:
                xbmcgui.Dialog().notification(
                    "Himnos", "Audio no disponible para {0}".format(label),
                    xbmcgui.NOTIFICATION_WARNING, 3000
                )
                return
            break

    if url is None and pais_code in _HIMNOS_MUNDO:
        titulo_mundo, mundo_url = _HIMNOS_MUNDO[pais_code]
        titulo = titulo_mundo
        url = mundo_url

    if url is None:
        xbmc.log("{0} No hay himno para código: {1}".format(_LOG, pais_code), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Himnos", "No disponible para este país", xbmcgui.NOTIFICATION_WARNING, 2000)
        return

    xbmc.log("{0} Reproduciendo himno: {1} — {2}".format(_LOG, pais_code, url), xbmc.LOGINFO)
    li = xbmcgui.ListItem(titulo, path=url)
    li.setInfo("music", {"title": titulo})
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

