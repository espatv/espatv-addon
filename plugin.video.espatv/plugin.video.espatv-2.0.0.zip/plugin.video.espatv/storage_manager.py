# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Storage manager — auditoría y limpieza de cachés del addon.

Útil sobre todo en dispositivos limitados (Firestick, TV Box) donde el
acumulado de cachés del addon puede notarse con el tiempo. Garantiza que
los datos del usuario (favoritos, historial, biblioteca, descargas) NUNCA
se tocan: solo se limpia lo que se puede regenerar.
"""

import os
import re
import sys
import shutil
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG     = "[EspaTV-STORAGE]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_MEDIA   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback

# ─── Registro de cachés ──────────────────────────────────────────────────────
# Cada entrada: clave, label, [archivos], [carpetas], [regex_dinamicos]
# Solo aparece en el menú lo que pesa > 0 bytes.

_CACHES = [
    ("epg",          "Programación TV (EPG en texto)",   ["epg_texto_cache.json"], [], []),
    ("gasolineras",  "Gasolineras",                       ["gasolineras_cache.json"], [], []),
    ("efemerides",   "Efemérides",                        ["efemerides_cache.json"], [], []),
    ("boe",          "BOE",                               ["boe_cache.json"], [], []),
    ("sepe",         "SEPE",                              ["sepe_cache.json"], [], []),
    ("dgt",          "Tráfico DGT",                       ["dgt_incidencias.json"], [], []),
    ("alquiler",     "Alquiler",                          ["alquiler_cache.json"], [], []),
    ("embalses",     "Embalses",                          ["embalses_cache.json"], [], []),
    ("aire",         "Calidad del aire",                  ["aire_cache.json"], [], []),
    ("bolsa",        "Bolsa (IBEX, S&P 500, Cripto)",     ["ibex_cache.json", "sp500_cache.json", "crypto_cache.json"], [], []),
    ("luz",          "Precio de la luz",                  ["precio_luz_cache.json"], [], []),
    ("horoscopo",    "Horóscopo",                         ["horoscopo_cache.json"], [], []),
    ("agenda",       "Agenda cultural",                   ["agenda_cultural_cache.json"], ["agenda_cache"], []),
    ("librivox",     "Audiolibros",                       [], ["librivox_cache"], []),
    ("galeria",      "Galería de arte",                   [], ["galeria_cache"], []),
    ("musica",       "Música",                            [], ["musica_cache"], []),
    ("cine",         "Metadatos de cine (Cinemeta/FA/SC/TMDb)",
                     ["espatv_cinemeta_cache.json", "espatv_fa_cache.json",
                      "espatv_sc_cache.json", "espatv_tmdb_lists_cache.json"], [], []),
    ("archive",      "Archive.org",                       ["espatv_archive_cache.json"], [], []),
    ("trakt_thumbs", "Trakt — miniaturas",                [], [], [r"^trakt_thumbs_\d+\.json$"]),
    ("clasif",       "Clasificaciones deportivas",
                     ["clasif_champions.json", "clasif_laliga.json",
                      "clasif_segunda.json", "clasif_euroliga.json"], [], []),
    ("scores_live",  "Marcadores en directo",
                     ["scores_champions.json", "scores_laliga.json", "scores_segunda.json"], [], []),
    ("scores_old",   "Snapshots de partidos (por fecha)", [], [],
                     [r"^scores_(?:laliga|segunda|champions|euroliga)_\d{8}\.json$"]),
    ("loteria",      "Lotería (HTML cacheado)",          ["loteria_20m.html"], [], []),
    ("transporte",   "Horarios de Transporte (GTFS y cachés de metro)",
                     ["gtfs_metro_malaga.zip", "metro_madrid_cache.json",
                      "metrovalencia_cache.json", "metro_barcelona_cache.json"], [], []),
]

# ─── Auto-limpieza al arrancar ───────────────────────────────────────────────
# Patrón dated → días de retención. Se borra silenciosamente al iniciar.

_DATED_PATTERNS = [
    (re.compile(r"^scores_(?:laliga|segunda|champions|euroliga)_\d{8}\.json$"), 14),
]

# ─── Datos del usuario (visible para transparencia, pero NUNCA se borra) ─────

_USER_DATA = [
    ("Biblioteca enriquecida (metadata)", ["espatv_metadata.db"], []),
    ("Favoritos / Historial / Marcadores",
     ["favorites.json", "watch_history.json", "watched_yt.json",
      "url_bookmarks.json", "url_history.json"], []),
    ("Descargas",                  ["downloads_history.json"], []),
    ("Búsquedas guardadas",        ["search_history.json", "yt_search_history.json"], []),
    ("Listas y playlists",         ["yt_playlists.json", "saved_playlists.json", "custom_iptv.json", "tv_autonomicas.json"], []),
    ("Trakt — sesión",             ["trakt_settings.json"], []),
]

# ─── Red de seguridad: nunca se borra aunque alguien lo añada por error ──────

_PROTECTED = {
    "espatv_metadata.db",
    "favorites.json", "watch_history.json", "watched_yt.json",
    "url_bookmarks.json", "url_history.json",
    "downloads_history.json",
    "search_history.json", "yt_search_history.json",
    "yt_playlists.json", "yt_playlists.json.bak",  # backup automático del usuario
    "saved_playlists.json",
    "custom_iptv.json", "tv_autonomicas.json",
    "trakt_settings.json",
    "easter_eggs_found.json", "egg_count.txt",  # progreso del usuario
    "et.jpg",
    "stats.json", "status_check.json", "messages_state.json",
    "aemet_locations.json",
    # Settings de Kodi en el perfil del addon — JAMÁS tocar
    "settings.xml",
    # Estado mínimo que no merece tocarse
    "alquiler_state.json", "gasolineras_state.json", "iptv_cache_settings.json",
    # Estados de transporte — contienen estaciones guardadas y claves de API
    "metro_madrid_state.json", "metro_malaga_state.json",
    "metrovalencia_state.json", "metro_barcelona_state.json",
}


# ─── Utilidades ──────────────────────────────────────────────────────────────

def _path(name):
    return os.path.join(_PROFILE, name)


def _size_of(path):
    if not os.path.exists(path):
        return 0
    if os.path.isdir(path):
        total = 0
        for root, _, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        return total
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def _delete_path(path):
    """Borra un archivo o carpeta. Devuelve los bytes liberados (0 si falló)."""
    name = os.path.basename(path)
    if name in _PROTECTED:
        xbmc.log("{} BLOQUEADO borrado de archivo protegido: {}".format(_LOG, name), xbmc.LOGWARNING)
        return 0
    sz = _size_of(path)
    try:
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
            return sz if not os.path.exists(path) else 0
        if os.path.exists(path):
            os.remove(path)
            return sz
    except OSError as e:
        xbmc.log("{} Error borrando {}: {}".format(_LOG, path, e), xbmc.LOGWARNING)
    return 0


def fmt_size(b):
    if b < 1024:
        return "{} B".format(b)
    if b < 1024 * 1024:
        return "{:.1f} KB".format(b / 1024.0)
    return "{:.2f} MB".format(b / 1024.0 / 1024.0)


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


# ─── Cálculo de uso ──────────────────────────────────────────────────────────

def _list_profile():
    try:
        return os.listdir(_PROFILE)
    except OSError:
        return []


def _resolver_paths(files, dirs, regex_list, profile_entries):
    """Devuelve la lista de rutas existentes para una entrada de caché."""
    rutas = []
    for f in files:
        p = _path(f)
        if os.path.exists(p):
            rutas.append(p)
    for d in dirs:
        p = _path(d)
        if os.path.exists(p):
            rutas.append(p)
    if regex_list:
        compiled = [re.compile(rx) for rx in regex_list]
        for entry in profile_entries:
            if any(c.match(entry) for c in compiled):
                rutas.append(_path(entry))
    return rutas


def auditar_cache():
    """[(key, label, bytes, rutas), ...] solo categorías con bytes > 0."""
    entries = _list_profile()
    out = []
    for key, label, files, dirs, regex_list in _CACHES:
        rutas = _resolver_paths(files, dirs, regex_list, entries)
        total = sum(_size_of(p) for p in rutas)
        if total > 0:
            out.append((key, label, total, rutas))
    return out


def auditar_user_data():
    """[(label, bytes), ...] de las categorías de datos del usuario con bytes > 0."""
    out = []
    for label, files, dirs in _USER_DATA:
        total = 0
        for f in files:
            total += _size_of(_path(f))
        for d in dirs:
            total += _size_of(_path(d))
        if total > 0:
            out.append((label, total))
    return out


# ─── Auto-limpieza silenciosa al arrancar ────────────────────────────────────

def limpiar_dated():
    """Borra archivos con fecha en el nombre que excedan su retención.

    Pensado para llamar desde default.py al iniciar el plugin. No imprime
    nada al usuario y nunca lanza excepciones que rompan el arranque.
    """
    try:
        now = time.time()
        n, bytes_ = 0, 0
        for entry in _list_profile():
            for pat, dias in _DATED_PATTERNS:
                if not pat.match(entry):
                    continue
                full = _path(entry)
                try:
                    mtime = os.path.getmtime(full)
                except OSError:
                    continue
                if (now - mtime) > dias * 86400:
                    sz = _size_of(full)
                    if _delete_path(full):
                        n += 1
                        bytes_ += sz
                break
        if n > 0:
            xbmc.log("{} Auto-limpieza: {} archivos antiguos, {} liberados".format(
                _LOG, n, fmt_size(bytes_)), xbmc.LOGINFO)
    except Exception as e:
        # Nunca dejar que esto rompa el arranque.
        xbmc.log("{} limpiar_dated() ignorando excepción: {}".format(_LOG, e), xbmc.LOGWARNING)


# ─── Acciones de borrado ─────────────────────────────────────────────────────

def _borrar_rutas(rutas):
    return sum(_delete_path(p) for p in rutas)


def borrar_categoria(key):
    """Borra una categoría concreta tras confirmación del usuario."""
    entry = next((c for c in _CACHES if c[0] == key), None)
    if entry is None:
        return
    _, label, files, dirs, regex_list = entry
    rutas = _resolver_paths(files, dirs, regex_list, _list_profile())
    total = sum(_size_of(p) for p in rutas)

    if total == 0:
        xbmcgui.Dialog().notification("EspaTV", "Esta caché ya está vacía",
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        return

    if not xbmcgui.Dialog().yesno(
        "Borrar caché",
        "{}\n\nSe liberarán [B]{}[/B].\n\nLos datos se volverán a descargar la próxima vez que abras esta sección.".format(
            label, fmt_size(total),
        ),
    ):
        return

    liberado = _borrar_rutas(rutas)
    xbmcgui.Dialog().notification(
        "EspaTV", "Liberados {}".format(fmt_size(liberado)),
        xbmcgui.NOTIFICATION_INFO, 3000,
    )
    xbmc.executebuiltin("Container.Refresh")


def borrar_todas():
    """Borra TODAS las cachés conocidas tras confirmación."""
    audit = auditar_cache()
    total = sum(b for _, _, b, _ in audit)

    if total == 0:
        xbmcgui.Dialog().notification("EspaTV", "No hay cachés que borrar",
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        return

    if not xbmcgui.Dialog().yesno(
        "Borrar TODAS las cachés",
        "Se borrarán todas las cachés del addon ([B]{}[/B] en total).\n\n"
        "[COLOR lightgreen]Tus favoritos, historial, biblioteca, descargas y sesión de Trakt NO se tocan.[/COLOR]\n\n"
        "¿Continuar?".format(fmt_size(total)),
    ):
        return

    liberado = 0
    for _, _, _, rutas in audit:
        liberado += _borrar_rutas(rutas)

    xbmcgui.Dialog().notification(
        "EspaTV", "Liberados {}".format(fmt_size(liberado)),
        xbmcgui.NOTIFICATION_INFO, 3500,
    )
    xbmc.executebuiltin("Container.Refresh")


# ─── Menú ────────────────────────────────────────────────────────────────────

_USER_DATA_PLOTS = {
    "Biblioteca enriquecida (metadata)":
        "Caché unificada de metadatos de TMDB (espatv_metadata.db) compartida por "
        "todas las listas del addon: películas y series de favoritos, historial, "
        "listas IPTV, búsquedas, etc.\n\n"
        "Cada entrada guarda: título y título original, año, sinopsis, géneros, "
        "valoración y votos, duración, director, reparto principal y URLs de "
        "póster y fanart. Por eso, al ojearla, se ve toda la ficha sin volver "
        "a llamar a TMDB.\n\n"
        "Vida útil: las entradas caducan a los 30 días (se ignoran al leer y "
        "se sobrescriben cuando vuelven a hacer falta). Es decir, se purga "
        "sola con el uso normal del addon.\n\n"
        "No se borra desde aquí porque rehidratarla cuesta cientos de "
        "llamadas a TMDB. Si necesitas vaciarla por completo, usa la opción "
        "específica del addon o elimina el archivo espatv_metadata.db.",
    "Favoritos / Historial / Marcadores":
        "Tus favoritos, historial de visualización (incluido YouTube) y URLs "
        "guardadas/marcadas.\n\n"
        "No se borra desde aquí. Para limpiar, ve a la sección correspondiente "
        "del addon (Favoritos, Historial, URLs).",
    "Descargas":
        "Registro de descargas realizadas con el addon.\n\n"
        "No se borra desde aquí. Gestiónalo desde la sección de Descargas.",
    "Búsquedas guardadas":
        "Historial de búsquedas dentro del addon y de YouTube.\n\n"
        "No se borra desde aquí. Bórralo desde el propio buscador.",
    "Listas y playlists":
        "Tus playlists de YouTube guardadas, listas IPTV y "
        "canales autonómicos.\n\n"
        "No se borra desde aquí. Edítalo desde la sección correspondiente.",
    "Trakt — sesión":
        "Token y configuración de tu sesión de Trakt.\n\n"
        "No se borra desde aquí. Cierra sesión desde los ajustes de Trakt "
        "del addon si quieres eliminarlo.",
}

_USER_DATA_PLOT_DEFAULT = (
    "Esta categoría contiene datos personales del usuario y NO se borra "
    "desde el gestor de cachés.\n"
    "Para borrarlos, ve a la sección correspondiente del addon."
)


def _user_data_plot(label):
    return _USER_DATA_PLOTS.get(label, _USER_DATA_PLOT_DEFAULT)


def _add_item(h, label, url, plot=None, icon="DefaultIconInfo.png", folder=False):
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": icon})
    if plot:
        li.setInfo("video", {"plot": plot})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=url or "", listitem=li, isFolder=folder)


def info_almacenamiento():
    """Diálogo de texto que explica qué se borra y qué no."""
    SEP = "─" * 44
    lines = [
        "GESTIÓN DE CACHÉS DEL ADDON",
        SEP,
        "",
        "Este addon guarda dos tipos de información en tu",
        "dispositivo:",
        "",
        "  1) CACHÉS — datos descargados de internet que",
        "     se pueden volver a bajar (programación TV,",
        "     gasolineras, BOE, datos del INE, etc.).",
        "",
        "  2) DATOS DEL USUARIO — favoritos, historial,",
        "     biblioteca enriquecida, descargas, sesión",
        "     de Trakt, etc. Solo existen aquí.",
        "",
        SEP,
        "QUÉ SE PUEDE BORRAR DESDE AQUÍ",
        SEP,
        "",
        "Solo las cachés del grupo (1). Al volver a abrir",
        "la sección correspondiente del addon, los datos",
        "se descargan otra vez. No pierdes nada.",
        "",
        SEP,
        "QUÉ NO SE TOCA NUNCA",
        SEP,
        "",
        "  • Favoritos (favorites.json)",
        "  • Historial de visualización",
        "  • Biblioteca enriquecida (espatv_metadata.db)",
        "  • Marcadores y URLs guardadas",
        "  • Listas IPTV",
        "  • Búsquedas guardadas",
        "  • Sesión de Trakt",
        "  • Descargas (carpeta del usuario)",
        "  • Grabaciones TDT (carpeta del usuario)",
        "",
        "Estos datos solo se borran desde su sección",
        "correspondiente dentro del addon.",
        "",
        SEP,
        "AUTO-LIMPIEZA",
        SEP,
        "",
        "Al arrancar el addon se borran automáticamente",
        "los snapshots de partidos con más de 14 días.",
        "Es silencioso y no afecta a marcadores en directo.",
        "",
        SEP,
        "DISPOSITIVOS LIMITADOS (Firestick, TV Box)",
        SEP,
        "",
        "Si notas que el addon ocupa demasiado espacio,",
        "abre el menú de cachés y pulsa \"Borrar TODAS\".",
        "Es seguro y reversible (los datos se vuelven a",
        "descargar al uso).",
    ]
    xbmcgui.Dialog().textviewer(
        "Gestión de cachés — ayuda",
        "\n".join(lines),
    )


def menu_almacenamiento():
    """Submenú principal: muestra el uso por categoría y permite borrar."""
    h = int(sys.argv[1])

    cache = sorted(auditar_cache(), key=lambda x: -x[2])
    user  = sorted(auditar_user_data(), key=lambda x: -x[1])

    total_cache = sum(b for _, _, b, _ in cache)
    total_user  = sum(b for _, b in user)
    total_all   = total_cache + total_user

    icon_cache  = _icon("adv_cache.png")
    icon_borrar = _icon("adv_borrar.png")

    _add_item(
        h,
        "[B][COLOR aqua]Uso del addon: {}[/COLOR][/B]    [COLOR grey]({} en cachés)[/COLOR]".format(
            fmt_size(total_all), fmt_size(total_cache)
        ),
        url="",
        plot="Resumen del espacio que ocupa el addon en este dispositivo.\n"
             "El menú muestra solo lo borrable. Tus datos personales aparecen al final pero no se pueden borrar desde aquí.",
        icon=icon_cache,
    )

    if cache:
        _add_item(
            h,
            "[COLOR yellow]── CACHÉS (se pueden borrar sin perder datos) ──[/COLOR]",
            url="",
        )
        for key, label, b, _rutas in cache:
            _add_item(
                h,
                "  {0}    [COLOR grey]{1}[/COLOR]".format(label, fmt_size(b)),
                url=_u(action="storage_clear_category", key=key),
                plot="Pulsa para borrar esta caché ({}).\n\n"
                     "Los datos se volverán a descargar la próxima vez "
                     "que abras la sección correspondiente.".format(fmt_size(b)),
                icon=icon_cache,
            )

        _add_item(
            h,
            "[B][COLOR red][ Borrar TODAS las cachés ({}) ][/COLOR][/B]".format(fmt_size(total_cache)),
            url=_u(action="storage_clear_all"),
            plot="Borra todas las cachés del addon. Tus favoritos, historial, biblioteca y sesión de Trakt NO se tocan.",
            icon=icon_borrar,
        )
    else:
        _add_item(
            h,
            "[COLOR lightgreen]No hay cachés que borrar[/COLOR]",
            url="",
        )

    if user:
        _add_item(
            h,
            "[COLOR yellow]── DATOS DEL USUARIO (no se borran desde aquí) ──[/COLOR]",
            url="",
        )
        for label, b in user:
            _add_item(
                h,
                "  {0}    [COLOR grey]{1}[/COLOR]".format(label, fmt_size(b)),
                url="",
                plot=_user_data_plot(label),
            )

    xbmcplugin.endOfDirectory(h)
