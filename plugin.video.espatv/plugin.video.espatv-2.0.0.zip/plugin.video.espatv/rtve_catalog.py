# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""RTVE Play: directos + catálogo (api.rtve.es y ztnr.rtve.es para DRM Widevine)."""
import hashlib
import json
import os
import sys
import time
from urllib.parse import urlencode, quote

import xbmc
import xbmcgui
import xbmcplugin

try:
    import requests
except ImportError:
    import urllib.request
    requests = None

import core_settings


_API_BASE = "https://www.rtve.es/api"

# Video IDs para ztnr.rtve.es
_RTVE_LIVE_CHANNELS = [
    {
        "name": "La 1",
        "video_id": "1688877",
        "logo": "https://img2.rtve.es/css/rtve.commons/rtve.header.footer/i/logoLa1.png",
        "plot": "Canal generalista de RTVE con informativos, series, entretenimiento y deportes.",
    },
    {
        "name": "La 2",
        "video_id": "1688885",
        "logo": "https://img2.rtve.es/css/rtve.commons/rtve.header.footer/i/logoLa2.png",
        "plot": "Canal cultural de RTVE con documentales, cine y programas de divulgación.",
    },
    {
        "name": "Canal 24 Horas",
        "video_id": "1694255",
        "logo": "https://img2.rtve.es/css/rtve.commons/rtve.header.footer/i/logo24h.png",
        "plot": "Canal de noticias 24 horas de RTVE.",
    },
    {
        "name": "Teledeporte",
        "video_id": "1712295",
        "logo": "https://img2.rtve.es/css/rtve.commons/rtve.header.footer/i/logoTdp.png",
        "plot": "Canal deportivo de RTVE.",
    },
    {
        "name": "Clan TVE",
        "video_id": "5466990",
        "logo": "https://img2.rtve.es/css/rtve.commons/rtve.header.footer/i/logoClan.png",
        "plot": "Canal infantil de RTVE.",
    },
]

# Categorías principales del catálogo RTVE (IDs de api.rtve.es/api/tematicas/)
_RTVE_CATEGORIES = [
    {"name": "Series", "id": "864", "icon": "DefaultTVShows.png"},
    {"name": "Cine", "id": "866", "icon": "DefaultMovies.png"},
    {"name": "Documentales", "id": "863", "icon": "DefaultMovies.png"},
    {"name": "Informativos", "id": "862", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Entretenimiento", "id": "102610", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Deportes", "id": "867", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Infantiles", "id": "865", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Cultura", "id": "40270", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Música", "id": "102614", "icon": "DefaultMusicSongs.png"},
    {"name": "Cocina", "id": "102611", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Concursos", "id": "102613", "icon": "DefaultAddonPVRClient.png"},
    {"name": "Humor", "id": "102615", "icon": "DefaultAddonPVRClient.png"},
]


def _log(msg):
    xbmc.log("[EspaTV][rtve] {0}".format(msg), xbmc.LOGINFO)


def _log_error(msg):
    xbmc.log("[EspaTV][rtve] ERROR: {0}".format(msg), xbmc.LOGERROR)


def _handle():
    return int(sys.argv[1])


def _u(**kwargs):
    return "{0}?{1}".format(sys.argv[0], urlencode(kwargs))


from _user_agents import UA_DESKTOP

_HEADERS = {
    "User-Agent": UA_DESKTOP,
}


def _fetch_json(url, timeout=15):
    ttl = core_settings.get_iptv_cache_ttl()
    cache_file = ""
    if core_settings.is_iptv_cache_active() and ttl > 0:
        cache_dir = core_settings.get_iptv_cache_dir()
        cache_key = hashlib.md5(url.encode("utf-8")).hexdigest()
        cache_file = os.path.join(cache_dir, "rtvecat_" + cache_key + ".json")
        if os.path.exists(cache_file):
            try:
                with open(cache_file, "r", encoding="utf-8") as f:
                    cached = json.load(f)
                if (time.time() - cached.get("ts", 0)) < ttl:
                    return cached.get("content", {})
            except (OSError, ValueError):
                pass

    if requests:
        r = requests.get(url, headers=_HEADERS, timeout=timeout)
        r.raise_for_status()
        data = r.json()
    else:
        req = urllib.request.Request(url, headers=_HEADERS)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))

    if core_settings.is_iptv_cache_active() and ttl > 0 and cache_file:
        try:
            with open(cache_file, "w", encoding="utf-8") as f:
                json.dump({"ts": time.time(), "url": url, "content": data}, f, ensure_ascii=False)
        except OSError:
            pass

    return data


def _play_drm_stream(video_id, title=""):
    """Reproduce un MPD de RTVE con Widevine vía inputstream.adaptive."""
    h = _handle()
    stream_url = "https://ztnr.rtve.es/ztnr/{0}.mpd".format(video_id)
    _log("DRM play: {0} → {1}".format(title, stream_url))

    license_url = ""
    try:
        token_url = "{0}/token/{1}".format(_API_BASE, video_id)
        token_data = _fetch_json(token_url)
        license_url = token_data.get("widevineURL", "")
        _log("Widevine URL: {0}".format(license_url))
    except (OSError, ValueError) as e:
        _log_error("Token error: {0}".format(e))

    # Headers para el stream
    headers = {
        "User-Agent": _HEADERS["User-Agent"],
        "Referer": "https://www.rtve.es/",
        "Origin": "https://www.rtve.es",
        "Accept": "*/*",
    }
    headers_string = "&".join(
        ["{0}={1}".format(k, quote(v)) for k, v in headers.items()]
    )

    try:
        li = xbmcgui.ListItem(path=stream_url)
        if title:
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType("video")
            info_tag.setTitle(title)

        # inputstream.adaptive para DASH
        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        li.setProperty("inputstream.adaptive.manifest_headers", headers_string)
        li.setProperty("inputstream.adaptive.stream_headers", headers_string)

        # DRM Widevine
        if license_url:
            li.setProperty("inputstream.adaptive.license_type",
                           "com.widevine.alpha")
            li.setProperty("inputstream.adaptive.license_key", license_url)

        li.setMimeType("application/dash+xml")
        li.setContentLookup(False)

        # Buffering
        li.setProperty("inputstream.adaptive.stream_selection_type", "adaptive")

        xbmcplugin.setResolvedUrl(h, True, li)
        _log("DRM stream iniciado para: {0}".format(title))

    except (RuntimeError, OSError) as e:
        _log_error("DRM play error: {0}".format(e))
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification(
            "RTVE Play", "Error al reproducir",
            xbmcgui.NOTIFICATION_ERROR, 3000)


def main_menu():
    h = _handle()

    # Canales en directo
    li = xbmcgui.ListItem(
        label="[B][COLOR red]RTVE en Directo[/COLOR][/B]"
    )
    li.setArt({"icon": "DefaultAddonPVRClient.png"})
    li.setInfo("video", {"plot": "Canales de RTVE en directo:\n"
                                 "La 1, La 2, 24h, Teledeporte, Clan"})
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="rtve_live"), listitem=li, isFolder=True
    )

    # Catálogo por categorías
    for cat in _RTVE_CATEGORIES:
        li = xbmcgui.ListItem(label=cat["name"])
        li.setArt({"icon": cat["icon"]})
        li.setInfo("video", {"plot": "Programas de RTVE: {0}".format(
            cat["name"])})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="rtve_category", cat_id=cat["id"],
                   cat_name=cat["name"]),
            listitem=li,
            isFolder=True,
        )

    # Búsqueda
    li = xbmcgui.ListItem(
        label="[COLOR dodgerblue][B]Buscar en RTVE[/B][/COLOR]")
    li.setArt({"icon": "DefaultAddonWebSkin.png"})
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="rtve_search"), listitem=li, isFolder=True
    )

    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def live_channels():
    h = _handle()
    xbmcplugin.setContent(h, "videos")
    for ch in _RTVE_LIVE_CHANNELS:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(ch["name"]))
        li.setArt({"icon": ch["logo"], "thumb": ch["logo"]})
        li.setInfo("video", {"title": ch["name"], "plot": ch["plot"]})
        li.setProperty("IsPlayable", "true")
        cm = [("Añadir a Favoritos", "RunPlugin({0})".format(
            _u(action="add_favorite", title=ch["name"],
               fav_url=ch["video_id"], icon=ch["logo"],
               platform="rtve", fav_action="play_rtve_live",
               params=json.dumps({}))
        ))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="play_rtve_live", url=ch["video_id"],
                   title=ch["name"]),
            listitem=li,
            isFolder=False,
        )
    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def play_live(url, title=""):
    _play_drm_stream(url, title)


def category(cat_id, cat_name="", page=1, parent_id=""):
    h = _handle()
    dp = xbmcgui.DialogProgress()
    dp.create("RTVE Play", "Cargando {0}...".format(cat_name or "categoría"))
    try:
        dp.update(20, "Cargando subcategorías...")
        # Intentar hijos (subcarpetas de programas)
        hijos_url = "https://api.rtve.es/api/tematicas/{0}/hijos.json?page={1}".format(
            cat_id, page)
        data = _fetch_json(hijos_url)
        hijos = data.get("page", {}).get("items", [])

        if hijos:
            dp.update(60, "Procesando {0} programas...".format(len(hijos)))
            dp.close()
            xbmcplugin.setContent(h, "tvshows")

            for item in hijos:
                item_id = str(item.get("id", ""))
                name = item.get("title", item.get("name", "Sin título"))
                img = ""
                desc = item.get("shortDescription", item.get("description", "")) or ""
                try:
                    prog_url = "https://www.rtve.es/api/programas/{0}".format(
                        item_id)
                    prog_data = _fetch_json(prog_url)
                    prog_info = prog_data.get("page", {}).get("items", [{}])[0]
                    img = (prog_info.get("imgPoster", "") or
                           prog_info.get("imgCol", "") or
                           prog_info.get("thumbnail", "") or
                           prog_info.get("imgBackground", "") or "")
                    if not desc:
                        desc = prog_info.get("shortDescription", prog_info.get("description", "")) or ""
                except (OSError, ValueError):
                    pass

                li = xbmcgui.ListItem(label=name)
                li.setArt({"thumb": img, "icon": img, "poster": img})
                li.setInfo("video", {"title": name, "plot": desc})
                rtve_web_url = "https://www.rtve.es/play/buscador/?query={0}".format(
                    quote(name))
                cm = [
                    ("Buscar en Dailymotion", "Container.Update({0})".format(
                        _u(action="lfr", q=name, ot=""))),
                    ("Ver en RTVE.es", "RunPlugin({0})".format(
                        _u(action="rtve_open_web", url=rtve_web_url, title=name))),
                ]
                li.addContextMenuItems(cm)
                xbmcplugin.addDirectoryItem(
                    handle=h,
                    url=_u(action="rtve_category", cat_id=item_id,
                           cat_name=name, parent_id=cat_id),
                    listitem=li,
                    isFolder=True,
                )

            total_pages = data.get("page", {}).get("totalPages", 1)
            current_page = data.get("page", {}).get("number", 1)

            if current_page > 1:
                li = xbmcgui.ListItem(
                    label="[COLOR yellow]← Página anterior ({0}/{1})[/COLOR]".format(
                        current_page - 1, total_pages))
                li.setArt({"icon": "DefaultFolder.png"})
                xbmcplugin.addDirectoryItem(
                    handle=h,
                    url=_u(action="rtve_category", cat_id=cat_id,
                           cat_name=cat_name, page=current_page - 1,
                           parent_id=parent_id),
                    listitem=li, isFolder=True)

            if current_page < total_pages:
                li = xbmcgui.ListItem(
                    label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(
                        current_page + 1, total_pages))
                li.setArt({"icon": "DefaultFolder.png"})
                xbmcplugin.addDirectoryItem(
                    handle=h,
                    url=_u(action="rtve_category", cat_id=cat_id,
                           cat_name=cat_name, page=current_page + 1,
                           parent_id=parent_id),
                    listitem=li, isFolder=True)

            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
            return

        # Si no hay hijos, intentar vídeos directos
        dp.update(40, "Buscando vídeos...")
        items = []

        # Si tenemos parent_id, usar API de programas/temporadas (series)
        if parent_id:
            try:
                season_url = "https://www.rtve.es/api/programas/{0}/temporadas/{1}/videos.json?page={2}&size=20".format(
                    parent_id, cat_id, page)
                _log("Intentando temporada: {0}".format(season_url))
                data = _fetch_json(season_url)
                items = data.get("page", {}).get("items", [])
            except (OSError, ValueError) as e:
                _log("Temporada API falló: {0}, usando fallback".format(e))
                items = []

        # Fallback: API de tematicas (para categorías sin temporadas)
        if not items:
            videos_url = "https://api.rtve.es/api/tematicas/{0}/videos.json?page={1}".format(
                cat_id, page)
            data = _fetch_json(videos_url)
            items = data.get("page", {}).get("items", [])

        dp.update(70, "Procesando {0} vídeos...".format(len(items)))
        dp.close()

        if not items:
            xbmcgui.Dialog().notification(
                "RTVE Play", "No se encontraron vídeos",
                xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
            return

        xbmcplugin.setContent(h, "videos")
        for item in items:
            _add_video_item(h, item)

        total_pages = data.get("page", {}).get("totalPages", 1)
        current_page = data.get("page", {}).get("number", 1)

        if current_page > 1:
            li = xbmcgui.ListItem(
                label="[COLOR yellow]← Página anterior ({0}/{1})[/COLOR]".format(
                    current_page - 1, total_pages))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="rtve_category", cat_id=cat_id,
                       cat_name=cat_name, page=current_page - 1,
                       parent_id=parent_id),
                listitem=li, isFolder=True)

        if current_page < total_pages:
            li = xbmcgui.ListItem(
                label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(
                    current_page + 1, total_pages))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="rtve_category", cat_id=cat_id,
                       cat_name=cat_name, page=current_page + 1,
                       parent_id=parent_id),
                listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(h, cacheToDisc=True)

    except (OSError, ValueError, KeyError) as e:
        dp.close()
        _log_error("category: {0}".format(e))
        xbmcgui.Dialog().ok("RTVE Play", "Error al cargar:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
        except RuntimeError:
            pass


def _add_video_item(h, item):
    title = item.get("title", item.get("name", "Sin título"))
    desc = item.get("shortDescription", item.get("description", "")) or ""
    thumb = item.get("thumbnail", item.get("imageSEO", "")) or ""
    try:
        duration = int(item.get("duration", 0) or 0)
    except (ValueError, TypeError):
        duration = 0
    pub_date = item.get("publicationDate", "") or ""
    video_id = str(item.get("id", ""))

    li = xbmcgui.ListItem(label=title)
    li.setArt({"thumb": thumb, "icon": thumb, "poster": thumb})

    plot = desc
    if pub_date:
        plot += "\n\nPublicado: {0}".format(pub_date[:10])
    li.setInfo("video", {
        "title": title,
        "plot": plot,
        "duration": duration // 1000 if duration else 0,
    })
    li.setProperty("IsPlayable", "true")

    web_url = item.get("htmlShortUrl", item.get("htmlUrl", "")) or ""
    if not web_url and video_id:
        web_url = "https://www.rtve.es/v/{0}/".format(video_id)
    cm = [
        ("Buscar en Dailymotion", "Container.Update({0})".format(
            _u(action="lfr", q=title, ot=""))),
        ("Ver en RTVE.es", "RunPlugin({0})".format(
            _u(action="rtve_open_web", url=web_url, title=title))),
    ]
    if web_url:
        cm.append(("Copiar URL", "RunPlugin({0})".format(
            _u(action="copy_url", url=web_url))))
    li.addContextMenuItems(cm)

    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="play_rtve_video", video_id=video_id, title=title),
        listitem=li,
        isFolder=False,
    )


def play_video(video_id, title=""):
    _play_drm_stream(video_id, title)


def search():
    h = _handle()
    kb = xbmc.Keyboard("", "Buscar en RTVE Play")
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(h, cacheToDisc=True)
        return
    query = kb.getText().strip()
    dp = xbmcgui.DialogProgress()
    dp.create("RTVE Play", "Buscando '{0}'...".format(query))
    try:
        dp.update(30, "Consultando api.rtve.es...")
        url = ("https://api.rtve.es/api/search/contents"
               "?search={0}&page=1&size=30&context=tve"
               "&type=completo&tipology=video"
               "&isExpanded=true&isChild=true"
               "&useOntology=false").format(quote(query))
        data = _fetch_json(url)
        dp.update(70, "Procesando resultados...")
        dp.close()

        items = data.get("page", {}).get("items", [])
        if not items:
            xbmcgui.Dialog().notification(
                "RTVE Play",
                "Sin resultados para '{0}'".format(query),
                xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
            return

        xbmcplugin.setContent(h, "videos")
        for item in items:
            _add_video_item(h, item)
        xbmcplugin.endOfDirectory(h, cacheToDisc=True)

    except (OSError, ValueError, KeyError) as e:
        dp.close()
        _log_error("search: {0}".format(e))
        xbmcgui.Dialog().ok("RTVE Play",
                            "Error en la búsqueda:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
        except RuntimeError:
            pass


_FELIX_SLUG = "el-hombre-y-la-tierra"
_FELIX_PROGRAM_TITLE_LC = "el hombre y la tierra"


def _fetch_html(url, timeout=15):
    if requests:
        r = requests.get(url, headers=_HEADERS, timeout=timeout)
        r.raise_for_status()
        return r.text
    import urllib.request as _ureq
    req = _ureq.Request(url, headers=_HEADERS)
    with _ureq.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", errors="ignore")


def _progid_cache_path(slug):
    cache_dir = core_settings.get_iptv_cache_dir()
    return os.path.join(cache_dir, "rtve_progid_" + slug + ".txt")


def _discover_program_id_by_slug(slug):
    """Obtiene el ID de programa RTVE a partir del slug de play-page. Devuelve '' si falla. Cachea en disco."""
    import re as _re
    cache_path = _progid_cache_path(slug)
    try:
        if os.path.exists(cache_path):
            with open(cache_path, "r", encoding="utf-8") as f:
                cached = f.read().strip()
            if cached.isdigit():
                return cached
    except OSError:
        pass

    page_url = "https://www.rtve.es/play/videos/{0}/".format(slug)
    try:
        html = _fetch_html(page_url)
    except (OSError, ValueError) as e:
        _log("discover_program_id ({0}) fetch error: {1}".format(slug, e))
        return ""

    patterns = [
        r'/api/programas/(\d+)/videos',
        r'/api/programas/(\d+)\b',
        r'"programaId"\s*:\s*"?(\d+)"?',
        r'"programa"\s*:\s*\{[^}]*?"id"\s*:\s*"?(\d+)"?',
        r'data-prog(?:rama)?-id=["\'](\d+)["\']',
        r'idAsset["\']?\s*:\s*["\']?(\d+)',
        r'/programas/(\d+)/',
    ]
    for pat in patterns:
        m = _re.search(pat, html)
        if m:
            pid = m.group(1)
            try:
                with open(cache_path, "w", encoding="utf-8") as f:
                    f.write(pid)
            except OSError:
                pass
            _log("discover_program_id ({0}) -> {1} (pat={2})".format(slug, pid, pat))
            return pid
    _log("discover_program_id ({0}): no pattern matched".format(slug))
    return ""


def _is_felix_episode(item):
    pi = item.get("programInfo") or {}
    pi_title = (pi.get("title") or "").strip().lower()
    if pi_title == _FELIX_PROGRAM_TITLE_LC:
        return True
    url = (item.get("htmlUrl") or item.get("htmlShortUrl") or "").lower()
    if "/" + _FELIX_SLUG + "/" in url:
        return True
    return False


def show_felix_rtve(page=1, prog_id=""):
    h = _handle()
    dp = xbmcgui.DialogProgress()
    dp.create("RTVE Play", "El Hombre y la Tierra...")
    try:
        page = int(page)

        prog_id = prog_id or _discover_program_id_by_slug(_FELIX_SLUG)

        items = []
        total_pages = 1
        current_page = page

        if prog_id:
            dp.update(30, "Cargando programa {0}...".format(prog_id))
            try:
                data = _fetch_json(
                    "https://www.rtve.es/api/programas/{0}/videos.json"
                    "?page={1}&size=30".format(prog_id, page)
                )
                items = data.get("page", {}).get("items", []) or []
                total_pages = data.get("page", {}).get("totalPages", 1) or 1
                current_page = data.get("page", {}).get("number", page) or page
            except (OSError, ValueError, KeyError) as e:
                _log("felix programas/{0} fallo: {1}".format(prog_id, e))
                items = []

        if not items:
            dp.update(50, "Buscando y filtrando...")
            data = _fetch_json(
                "https://api.rtve.es/api/search/contents"
                "?search={0}&page={1}&size=60&context=tve"
                "&type=completo&tipology=video"
                "&isExpanded=true&isChild=true"
                "&useOntology=false".format(quote("hombre y la tierra"), page)
            )
            all_items = data.get("page", {}).get("items", []) or []
            items = [it for it in all_items if _is_felix_episode(it)]
            total_pages = data.get("page", {}).get("totalPages", 1) or 1
            current_page = data.get("page", {}).get("number", page) or page

        dp.update(85, "Procesando...")
        dp.close()

        if not items:
            xbmcgui.Dialog().notification(
                "RTVE Play", "Sin resultados",
                xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
            return

        xbmcplugin.setContent(h, "videos")
        for item in items:
            _add_video_item(h, item)

        if current_page > 1:
            li = xbmcgui.ListItem(
                label="[COLOR yellow]← Página anterior ({0}/{1})[/COLOR]".format(
                    current_page - 1, total_pages))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="archive_felix_rtve", page=current_page - 1,
                       prog_id=prog_id),
                listitem=li, isFolder=True)

        if current_page < total_pages:
            li = xbmcgui.ListItem(
                label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(
                    current_page + 1, total_pages))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="archive_felix_rtve", page=current_page + 1,
                       prog_id=prog_id),
                listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(h, cacheToDisc=True)

    except (OSError, ValueError, KeyError) as e:
        dp.close()
        _log_error("felix_rtve: {0}".format(e))
        xbmcgui.Dialog().ok("RTVE Play", "Error al cargar:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
        except RuntimeError:
            pass


_PUNSET_SLUG = "redes"
_PUNSET_PROGRAM_TITLE_LC = "redes"


def _is_punset_episode(item):
    pi = item.get("programInfo") or {}
    pi_title = (pi.get("title") or "").strip().lower()
    if pi_title == _PUNSET_PROGRAM_TITLE_LC:
        return True
    url = (item.get("htmlUrl") or item.get("htmlShortUrl") or "").lower()
    if "/" + _PUNSET_SLUG + "/" in url:
        return True
    return False


def show_punset_rtve(page=1, prog_id=""):
    h = _handle()
    dp = xbmcgui.DialogProgress()
    dp.create("RTVE Play", "Redes — Eduard Punset...")
    try:
        page = int(page)

        prog_id = prog_id or _discover_program_id_by_slug(_PUNSET_SLUG)

        items = []
        total_pages = 1
        current_page = page

        if prog_id:
            dp.update(30, "Cargando programa {0}...".format(prog_id))
            try:
                data = _fetch_json(
                    "https://www.rtve.es/api/programas/{0}/videos.json"
                    "?page={1}&size=30".format(prog_id, page)
                )
                items = data.get("page", {}).get("items", []) or []
                total_pages = data.get("page", {}).get("totalPages", 1) or 1
                current_page = data.get("page", {}).get("number", page) or page
            except (OSError, ValueError, KeyError) as e:
                _log("punset programas/{0} fallo: {1}".format(prog_id, e))
                items = []

        if not items:
            dp.update(50, "Buscando y filtrando...")
            data = _fetch_json(
                "https://api.rtve.es/api/search/contents"
                "?search={0}&page={1}&size=60&context=tve"
                "&type=completo&tipology=video"
                "&isExpanded=true&isChild=true"
                "&useOntology=false".format(quote("redes punset"), page)
            )
            all_items = data.get("page", {}).get("items", []) or []
            items = [it for it in all_items if _is_punset_episode(it)]
            total_pages = data.get("page", {}).get("totalPages", 1) or 1
            current_page = data.get("page", {}).get("number", page) or page

        dp.update(85, "Procesando...")
        dp.close()

        if not items:
            xbmcgui.Dialog().notification(
                "RTVE Play", "Sin resultados",
                xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
            return

        xbmcplugin.setContent(h, "videos")
        for item in items:
            _add_video_item(h, item)

        if current_page > 1:
            li = xbmcgui.ListItem(
                label="[COLOR yellow]← Página anterior ({0}/{1})[/COLOR]".format(
                    current_page - 1, total_pages))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="archive_punset_rtve", page=current_page - 1,
                       prog_id=prog_id),
                listitem=li, isFolder=True)

        if current_page < total_pages:
            li = xbmcgui.ListItem(
                label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(
                    current_page + 1, total_pages))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="archive_punset_rtve", page=current_page + 1,
                       prog_id=prog_id),
                listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(h, cacheToDisc=True)

    except (OSError, ValueError, KeyError) as e:
        dp.close()
        _log_error("punset_rtve: {0}".format(e))
        xbmcgui.Dialog().ok("RTVE Play", "Error al cargar:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
        except RuntimeError:
            pass


def open_web(url, title=""):
    if not url:
        xbmcgui.Dialog().notification("RTVE Play", "URL no disponible",
                                      xbmcgui.NOTIFICATION_WARNING, 2000)
        return
    _log("Abriendo en navegador: {0}".format(url))
    import webbrowser
    try:
        webbrowser.open(url)
    except (OSError, webbrowser.Error) as e:
        _log_error("open_web: {0}".format(e))
        xbmcgui.Dialog().ok(
            "RTVE Play",
            "No se pudo abrir el navegador.\n\nURL: {0}".format(url))
        return
    xbmcgui.Dialog().notification(
        "RTVE Play",
        "Abriendo {0} en navegador...".format(title or "vídeo"),
        xbmcgui.NOTIFICATION_INFO, 3000)


_FILMOTECA_SECTIONS = (
    {
        "name": "NO-DO — Noticiarios y Documentales (1943-1981)",
        "query": "noticiarios",
        "icon": "DefaultAddonPVRClient.png",
        "plot": "Archivo del NO-DO: noticiarios cinematográficos y documentales producidos entre 1943 y 1981.",
    },
    {
        "name": "Filmoteca Española — Cine clásico",
        "query": "filmoteca",
        "icon": "DefaultMovies.png",
        "plot": "Selección del archivo de la Filmoteca Española disponible en RTVE Play.",
    },
    {
        "name": "Documentales históricos",
        "query": "documental historia españa",
        "icon": "DefaultMovies.png",
        "plot": "Documentales sobre la historia de España.",
    },
    {
        "name": "Memoria de España",
        "query": "memoria de españa",
        "icon": "DefaultMovies.png",
        "plot": "Serie documental Memoria de España (RTVE).",
    },
    {
        "name": "Informe Semanal — Archivo histórico",
        "query": "informe semanal",
        "icon": "DefaultAddonPVRClient.png",
        "plot": "Archivo histórico del programa Informe Semanal.",
    },
)


def show_filmoteca_menu():
    h = _handle()
    try:
        li = xbmcgui.ListItem(label="[B][COLOR khaki]Buscar en archivo histórico de RTVE...[/COLOR][/B]")
        _icon_busqueda = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                      'resources', 'media', 'adv_busqueda.png')
        li.setArt({"icon": _icon_busqueda})
        li.setInfo("video", {"plot": "Buscar contenido en el catálogo histórico de RTVE Play."})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="filmoteca_search"), listitem=li, isFolder=True
        )

        for sec in _FILMOTECA_SECTIONS:
            li = xbmcgui.ListItem(label="[B]{0}[/B]".format(sec["name"]))
            li.setArt({"icon": sec["icon"]})
            li.setInfo("video", {"plot": sec["plot"]})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="filmoteca_seccion", q=sec["query"], name=sec["name"]),
                listitem=li,
                isFolder=True,
            )
    except Exception as e:
        _log_error("show_filmoteca_menu: {0}".format(e))
    xbmcplugin.endOfDirectory(h)


def show_filmoteca_seccion(query, name=""):
    h = _handle()
    if not query:
        xbmcplugin.endOfDirectory(h)
        return
    if name:
        try:
            xbmcplugin.setPluginCategory(h, name)
        except Exception:
            pass
    try:
        url = ("https://api.rtve.es/api/search/contents"
               "?search={0}&page=1&size=50&context=tve"
               "&type=completo&tipology=video"
               "&isExpanded=true&isChild=true"
               "&useOntology=false").format(quote(query))
        data = _fetch_json(url)
        items = data.get("page", {}).get("items", [])
        if not items:
            xbmcgui.Dialog().notification(
                "RTVE Play", "Sin resultados para esta sección",
                xbmcgui.NOTIFICATION_INFO, 2500)
            xbmcplugin.endOfDirectory(h)
            return
        xbmcplugin.setContent(h, "videos")
        for item in items:
            _add_video_item(h, item)
        xbmcplugin.endOfDirectory(h, cacheToDisc=True)
    except (OSError, ValueError, KeyError) as e:
        _log_error("filmoteca_seccion: {0}".format(e))
        xbmcgui.Dialog().notification(
            "RTVE Play", "Sección no disponible temporalmente",
            xbmcgui.NOTIFICATION_WARNING, 3000)
        try:
            xbmcplugin.endOfDirectory(h)
        except RuntimeError:
            pass


def filmoteca_search():
    """Alias de la búsqueda existente, expuesto desde el menú Filmoteca."""
    search()