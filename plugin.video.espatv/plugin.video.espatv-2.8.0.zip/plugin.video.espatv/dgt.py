# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import json
import os
import sys
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

_LOG_TAG = "[EspaTV-DGT]"
_ADDON = xbmcaddon.Addon()
_PROFILE_DIR = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
_CACHE_TTL = 10 * 60
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")


def _ri_icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback

from _user_agents import UA_DESKTOP

_API_URL = "https://nap.dgt.es/datex2/v3/dgt/SituationPublication/datex2_v36.xml"
_HEADERS = {
    "User-Agent": UA_DESKTOP,
    "Accept": "application/xml, */*",
}

_CAUSA_MAP = {
    "abnormalTraffic": "Retención",
    "accident": "Accidente",
    "congestion": "Retención",
    "slowTraffic": "Retención",
    "stationaryTraffic": "Retención",
    "queueingTraffic": "Retención",
    "heavyTraffic": "Retención",
    "roadMaintenance": "Obra",
    "constructionWork": "Obra",
    "maintenanceWork": "Mantenimiento",
    "roadworksMaintenance": "Obra",
    "poorEnvironment": "Meteorología adversa",
    "poorWeather": "Meteorología adversa",
    "snow": "Nevada",
    "snowfall": "Nevada",
    "ice": "Hielo",
    "frost": "Hielo",
    "fog": "Niebla",
    "freezingFog": "Niebla",
    "strongWinds": "Viento fuerte",
    "abnormalLoad": "Carga anormal",
    "vehicleObstruction": "Vehículo obstaculizando",
    "brokenDownVehicle": "Vehículo averiado",
    "brokenDownVehicles": "Vehículo averiado",
    "damagedOrBrokenDownVehicle": "Vehículo averiado",
    "specialEvent": "Evento especial",
    "animalPresenceOnTheRoad": "Animales en calzada",
    "environmentalObstruction": "Obstáculo ambiental",
    "infrastructureDamageObstruction": "Daño en infraestructura",
    "obstruction": "Obstáculo",
    "roadOrCarriagewayOrLaneManagement": "Gestión de vía",
    "visibility": "Visibilidad reducida",
}

_TYPE_MAP = {
    "AbnormalTraffic": "Retención",
    "AbnormalTrafficSituation": "Retención",
    "Accident": "Accidente",
    "ConstructionWorks": "Obra",
    "GeneralObstruction": "Obstáculo",
    "MaintenanceWorks": "Mantenimiento",
    "NonWeatherRelatedRoadConditions": "Condición de vía",
    "PoorEnvironmentConditions": "Meteorología adversa",
    "EnvironmentalObstruction": "Obstáculo ambiental",
    "InfrastructureDamageObstruction": "Daño en infraestructura",
    "Obstruction": "Obstáculo",
    "VehicleObstruction": "Vehículo obstaculizando",
    "RoadOrCarriagewayOrLaneManagement": "Gestión de vía",
    "SpeedManagement": "Gestión de velocidad",
    "NetworkManagement": "Gestión de red",
}

_SEVERITY_LEVEL = {
    "low": 1,
    "medium": 2,
    "high": 2,
    "highest": 3,
}

_CATEGORIAS = [
    {"key": "reten",    "label": "Retenciones",    "color": "tomato"},
    {"key": "accident", "label": "Accidentes",      "color": "red"},
    {"key": "obra",     "label": "Obras",           "color": "gold"},
    {"key": "niev|hiel|desliz|nevada", "label": "Nieve / Hielo", "color": "deepskyblue"},
    {"key": "niebla|visib",            "label": "Niebla",        "color": "silver"},
    {"key": "viento",   "label": "Viento fuerte",   "color": "limegreen"},
]
_CAT_OTRAS = "otras"


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), level)


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _cache_path():
    return os.path.join(_PROFILE_DIR, "dgt_incidencias.json")


def _load_cache():
    path = _cache_path()
    if not os.path.exists(path):
        return None
    if (time.time() - os.path.getmtime(path)) >= _CACHE_TTL:
        return None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        try:
            os.remove(path)
        except OSError:
            pass
        return None


def _save_cache(features):
    try:
        os.makedirs(_PROFILE_DIR, exist_ok=True)
        tmp = _cache_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(features, fh, ensure_ascii=False)
        os.replace(tmp, _cache_path())
    except OSError:
        pass


def _local(elem):
    return elem.tag.split("}", 1)[1] if "}" in elem.tag else elem.tag


def _find_text(elem, local_name):
    for child in elem.iter():
        if _local(child) == local_name and child.text:
            return child.text.strip()
    return ""


def _find_all_local(elem, local_name):
    return [c for c in elem.iter() if _local(c) == local_name]


def _parse_datex2(xml_text):
    try:
        root = ET.fromstring(xml_text.encode("utf-8"))
    except ET.ParseError as exc:
        _log("Error parseando XML DGT: {0}".format(exc), xbmc.LOGERROR)
        return []

    _XSI_TYPE = "{http://www.w3.org/2001/XMLSchema-instance}type"

    results = []
    for sit in root.iter():
        if _local(sit) != "situation":
            continue

        rec = next((c for c in sit if _local(c) == "situationRecord"), None)
        if rec is None:
            continue

        carretera = _find_text(sit, "roadName")

        km_elems = _find_all_local(sit, "kilometerPoint")
        pk_ini = km_elems[0].text.strip() if km_elems and km_elems[0].text else ""
        pk_fin = km_elems[1].text.strip() if len(km_elems) > 1 and km_elems[1].text else ""

        xsi_type = rec.attrib.get(_XSI_TYPE, "").split(":")[-1]
        cause_type = _find_text(rec, "causeType") or _find_text(rec, "abnormalTrafficType")
        causa = (
            _CAUSA_MAP.get(cause_type)
            or _TYPE_MAP.get(xsi_type)
            or (cause_type.replace("_", " ").capitalize() if cause_type else xsi_type or "Incidencia")
        )

        desc = ""
        for field in ("roadMaintenanceType", "roadOrCarriagewayOrLaneManagementType", "detailedCauseType"):
            desc = _find_text(rec, field)
            if desc:
                break

        severity_raw = _find_text(sit, "overallSeverity") or _find_text(rec, "severity")
        nivel = _SEVERITY_LEVEL.get(severity_raw, 0)

        province = _find_text(sit, "province")
        municipality = _find_text(sit, "municipality")
        sentido = ", ".join(p for p in (municipality, province) if p)

        fecha_fin = _find_text(rec, "overallEndTime")
        if fecha_fin:
            fecha_fin = fecha_fin[:10]

        if not carretera and not causa:
            continue

        results.append({
            "carretera": carretera,
            "pkInicio": pk_ini,
            "pkFin": pk_fin,
            "pk": pk_ini,
            "causa": causa,
            "descripcion": desc,
            "sentido": sentido,
            "provincia": province,
            "municipio": municipality,
            "nivel": nivel,
            "fechaFin": fecha_fin,
        })

    return results


def _fetch_incidencias():
    cached = _load_cache()
    if cached is not None:
        return cached

    try:
        req = urllib.request.Request(_API_URL, headers=_HEADERS)
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
    except Exception as exc:
        _log("Error fetch DGT: {0}".format(exc), xbmc.LOGERROR)
        return None

    features = _parse_datex2(raw)
    _log("Incidencias DGT: {0}".format(len(features)))
    _save_cache(features)
    return features


def _categorize(props):
    texto = (
        str(props.get("causa") or "")
        + " "
        + str(props.get("descripcion") or "")
    ).upper()
    for cat in _CATEGORIAS:
        for kw in cat["key"].split("|"):
            if kw.upper() in texto:
                return cat["key"]
    return _CAT_OTRAS


def _nivel_stars(nivel):
    try:
        n = int(nivel)
    except (ValueError, TypeError):
        return ""
    stars = "[COLOR gold]" + "●" * n + "[/COLOR]" + "○" * max(0, 3 - n)
    return "  " + stars


def _build_label(props):
    carretera = str(props.get("carretera") or "").strip()
    pk = str(props.get("pk") or props.get("pkInicio") or "").strip()
    causa = str(props.get("causa") or props.get("descripcion") or "Incidencia").strip()
    sentido = str(props.get("sentido") or "").strip()

    partes = []
    if carretera:
        partes.append("[B]{0}[/B]".format(carretera))
    if pk:
        partes.append("km {0}".format(pk))
    partes.append("— {0}".format(causa))
    if sentido:
        partes.append("[COLOR gray]({0})[/COLOR]".format(sentido))
    return "  ".join(partes)


def _build_plot(props):
    lineas = []
    carretera = str(props.get("carretera") or "").strip()
    if carretera:
        lineas.append("[B]Carretera:[/B]  {0}".format(carretera))

    pk_ini = str(props.get("pkInicio") or props.get("pk") or "").strip()
    pk_fin = str(props.get("pkFin") or "").strip()
    if pk_ini and pk_fin and pk_ini != pk_fin:
        lineas.append("[B]Tramo:[/B]  km {0} — {1}".format(pk_ini, pk_fin))
    elif pk_ini:
        lineas.append("[B]Punto:[/B]  km {0}".format(pk_ini))

    causa = str(props.get("causa") or "").strip()
    desc = str(props.get("descripcion") or "").strip()
    if desc and desc.upper() != causa.upper():
        lineas.append("[B]Descripción:[/B]  {0}".format(desc))
    if causa:
        lineas.append("[B]Causa:[/B]  {0}".format(causa))

    sentido = str(props.get("sentido") or "").strip()
    if sentido:
        lineas.append("[B]Ubicación:[/B]  {0}".format(sentido))

    nivel = props.get("nivel")
    stars = _nivel_stars(nivel)
    if stars:
        lineas.append("[B]Nivel:[/B]{0}".format(stars))

    fecha_fin = str(props.get("fechaFin") or "").strip()
    if fecha_fin:
        lineas.append("[B]Prevista hasta:[/B]  {0}".format(fecha_fin))

    return "\n".join(lineas) if lineas else "Sin detalles disponibles."


def dgt_menu():
    h = int(sys.argv[1])

    xbmcgui.Dialog().notification(
        "EspaTV", "Consultando DGT…",
        xbmcgui.NOTIFICATION_INFO, 1200,
    )

    features = _fetch_incidencias()

    if features is None:
        li = xbmcgui.ListItem(label="[COLOR red]Sin conexión — comprueba la red[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    try:
        ts = os.path.getmtime(_cache_path())
        updated_at = time.strftime("%d/%m/%Y  %H:%M", time.localtime(ts))
    except OSError:
        updated_at = None
    upd_label = "[COLOR grey]Actualizado: {0}[/COLOR]".format(updated_at) if updated_at else "[COLOR grey]Sin datos de actualización[/COLOR]"
    li_upd = xbmcgui.ListItem(label=upd_label)
    li_upd.setArt({"icon": "DefaultIconInfo.png"})
    li_upd.setInfo("video", {"plot": "Última actualización: {0}\nLos datos se recargan automáticamente cada 10 minutos.".format(updated_at or "—")})
    li_upd.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="keyboard_cat"), listitem=li_upd, isFolder=False)

    li_cams = xbmcgui.ListItem(label="[B][COLOR aqua]Cámaras de tráfico en directo[/COLOR][/B]")
    li_cams.setArt({"icon": _ri_icon("cat_camaras_dgt.png", "DefaultIconInfo.png")})
    li_cams.setInfo("video", {"plot": "Imágenes en directo de las cámaras de tráfico de la DGT.\nFotografías JPG actualizadas cada ~2 minutos."})
    li_cams.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dgt_camaras_menu"), listitem=li_cams, isFolder=True)

    conteos = {cat["key"]: 0 for cat in _CATEGORIAS}
    conteos[_CAT_OTRAS] = 0
    for props in features:
        conteos[_categorize(props)] += 1

    total = len(features)

    li = xbmcgui.ListItem(
        label="[B][COLOR white]Todas las incidencias[/COLOR][/B]  [COLOR gray]({0})[/COLOR]".format(total)
    )
    li.setArt({"icon": "DefaultIconInfo.png"})
    li.setInfo("video", {"plot": "Muestra todas las incidencias registradas en este momento.", "title": "Todas"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dgt_lista", filtro=""), listitem=li, isFolder=True)

    li_prov = xbmcgui.ListItem(label="[B][COLOR plum]Por provincia / ciudad[/COLOR][/B]")
    li_prov.setArt({"icon": "DefaultIconInfo.png"})
    li_prov.setInfo("video", {"plot": "Filtra incidencias por provincia y municipio.", "title": "Por provincia"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dgt_provincias"), listitem=li_prov, isFolder=True)

    for cat in _CATEGORIAS:
        count = conteos.get(cat["key"], 0)
        label = "[B][COLOR {color}]{label}[/COLOR][/B]  [COLOR gray]({count})[/COLOR]".format(
            color=cat["color"], label=cat["label"], count=count
        )
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultIconInfo.png"})
        li.setInfo("video", {"plot": "{0} registradas ahora.".format(cat["label"]), "title": cat["label"]})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="dgt_lista", filtro=cat["key"]), listitem=li, isFolder=True
        )

    otras = conteos.get(_CAT_OTRAS, 0)
    if otras:
        li = xbmcgui.ListItem(
            label="[B]Otras incidencias[/B]  [COLOR gray]({0})[/COLOR]".format(otras)
        )
        li.setArt({"icon": "DefaultIconInfo.png"})
        li.setInfo("video", {"plot": "Incidencias no clasificadas en las categorías principales.", "title": "Otras"})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="dgt_lista", filtro=_CAT_OTRAS), listitem=li, isFolder=True
        )

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar datos ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Elimina la caché y recarga los datos de la DGT."})
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="dgt_refresh"), listitem=li_r, isFolder=True
    )

    xbmcplugin.endOfDirectory(h)


def _get_provincia(props):
    prov = str(props.get("provincia") or "").strip()
    if not prov:
        sentido = str(props.get("sentido") or "")
        parts = [s.strip() for s in sentido.split(",")]
        if len(parts) >= 2:
            prov = parts[-1]
    return prov


def dgt_provincias():
    h = int(sys.argv[1])

    features = _fetch_incidencias()
    if features is None:
        xbmcgui.Dialog().notification("EspaTV", "Sin conexión", xbmcgui.NOTIFICATION_ERROR, 2000)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    counts = {}
    for props in features:
        prov = _get_provincia(props)
        if prov:
            counts[prov] = counts.get(prov, 0) + 1

    if not counts:
        xbmcgui.Dialog().notification("EspaTV", "Sin datos de provincia disponibles", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    provincias = sorted(counts.keys())
    opciones = ["{0}  ({1})".format(p, counts[p]) for p in provincias]

    idx = xbmcgui.Dialog().select("Selecciona una provincia", opciones)
    if idx < 0:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    provincia = provincias[idx]
    items = [p for p in features if _get_provincia(p) == provincia]
    items.sort(key=lambda p: (-int(p.get("nivel") or 0), str(p.get("carretera") or "")))

    for props in items:
        label = _build_label(props)
        plot = _build_plot(props)
        title = str(props.get("carretera") or "DGT") + " — " + str(props.get("causa") or "Incidencia")
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultIconInfo.png"})
        li.setInfo("video", {"plot": plot, "title": title})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())


def dgt_lista(filtro, provincia=""):
    h = int(sys.argv[1])

    features = _fetch_incidencias()
    if features is None:
        li = xbmcgui.ListItem(label="[COLOR red]Sin conexión — comprueba la red[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    if provincia:
        items = [p for p in features if _get_provincia(p) == provincia]
        if filtro:
            items = [p for p in items if _categorize(p) == filtro]
    elif filtro:
        items = [p for p in features if _categorize(p) == filtro]
    else:
        items = list(features)

    def _sort_key(p):
        try:
            nivel = -int(p.get("nivel") or 0)
        except (ValueError, TypeError):
            nivel = 0
        return (nivel, str(p.get("carretera") or ""))

    items.sort(key=_sort_key)

    if not items:
        li = xbmcgui.ListItem(label="[COLOR limegreen]Sin incidencias en esta categoría[/COLOR]")
        li.setProperty("IsPlayable", "false")
        li.setInfo("video", {"plot": "No hay incidencias registradas ahora mismo en esta categoría."})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for props in items:
        label = _build_label(props)
        plot = _build_plot(props)
        title = str(props.get("carretera") or "DGT") + " — " + str(props.get("causa") or "Incidencia")
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultIconInfo.png"})
        li.setInfo("video", {"plot": plot, "title": title})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())


def dgt_refresh():
    path = _cache_path()
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass
    xbmcgui.Dialog().notification(
        "EspaTV", "Caché DGT eliminada — recargando…",
        xbmcgui.NOTIFICATION_INFO, 1500,
    )
    xbmc.executebuiltin("Container.Update({0})".format(_u(action="dgt_menu")))


# Imagen JPG actualizada ~2 min. La DGT no expone API con nombres; etiqueta genérica.
# Quitar IDs que devuelvan 404.
_CAMS_BASE_URL = "https://infocar.dgt.es/etraffic/data/camaras/{id}.jpg"

_CAMARAS_DGT_IDS = [
    # 1-50
    2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37,
    40, 41, 42, 43, 44, 45, 46, 48, 49, 50,
    # 100-124
    100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110,
    120, 121, 122, 123, 124,
    # 140-183
    140, 141, 142, 143, 144, 145,
    180, 181, 182, 183,
    # 200-210
    200, 201, 202, 210,
]

_CAMARAS_DGT = [
    (cam_id, "Cámara DGT #{0}".format(cam_id), "")
    for cam_id in _CAMARAS_DGT_IDS
]


def _cam_url(cam_id):
    return _CAMS_BASE_URL.format(id=cam_id)


_CAMS_API_URL = "https://nap.dgt.es/datex2/v3/dgt/DevicePublication/camaras_datex2_v36.xml"


def _cams_cache_path():
    return os.path.join(_PROFILE_DIR, "dgt_camaras.json")


def _load_cams_cache():
    path = _cams_cache_path()
    if not os.path.exists(path):
        return None
    if (time.time() - os.path.getmtime(path)) >= 86400:  # 24 horas TTL
        return None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        try:
            os.remove(path)
        except OSError:
            pass
        return None


def _save_cams_cache(cameras):
    try:
        os.makedirs(_PROFILE_DIR, exist_ok=True)
        tmp = _cams_cache_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(cameras, fh, ensure_ascii=False)
        os.replace(tmp, _cams_cache_path())
    except OSError:
        pass


def _parse_camaras_xml(xml_text):
    try:
        root = ET.fromstring(xml_text.encode("utf-8"))
    except ET.ParseError as exc:
        _log("Error parseando XML Cámaras DGT: {0}".format(exc), xbmc.LOGERROR)
        return []

    results = []
    for dev in root.iter():
        if _local(dev) != "device":
            continue

        type_of_device = _find_text(dev, "typeOfDevice")
        if type_of_device != "camera":
            continue

        cam_id = dev.attrib.get("id", "")
        if not cam_id:
            continue

        road_name = _find_text(dev, "roadName")
        road_dest = _find_text(dev, "roadDestination")
        kilometer = _find_text(dev, "kilometerPoint")
        province = _find_text(dev, "province")
        url = _find_text(dev, "deviceUrl")

        if not url:
            continue

        province_formatted = province.strip().title() if province else "Otras"

        parts = []
        if road_name:
            parts.append(road_name.strip())
        if kilometer:
            parts.append("km {0}".format(kilometer.strip()))
        if road_dest:
            parts.append("-> {0}".format(road_dest.strip().title()))
        
        name = "Cámara {0}".format(" ".join(parts)) if parts else "Cámara DGT #{0}".format(cam_id)

        results.append({
            "id": cam_id,
            "name": name,
            "province": province_formatted,
            "url": url,
            "road": road_name,
            "kilometer": kilometer,
            "destination": road_dest,
        })

    return results


def _fetch_camaras():
    cached = _load_cams_cache()
    if cached is not None:
        return cached

    try:
        req = urllib.request.Request(_CAMS_API_URL, headers=_HEADERS)
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
    except Exception as exc:
        _log("Error fetch cámaras DGT: {0}".format(exc), xbmc.LOGERROR)
        fallback_cameras = []
        for cam_id in _CAMARAS_DGT_IDS:
            url = _cam_url(cam_id)
            fallback_cameras.append({
                "id": str(cam_id),
                "name": "Cámara DGT #{0}".format(cam_id),
                "province": "Otras",
                "url": url,
            })
        return fallback_cameras

    cameras = _parse_camaras_xml(raw)
    if cameras:
        _save_cams_cache(cameras)
    else:
        cameras = []
        for cam_id in _CAMARAS_DGT_IDS:
            url = _cam_url(cam_id)
            cameras.append({
                "id": str(cam_id),
                "name": "Cámara DGT #{0}".format(cam_id),
                "province": "Otras",
                "url": url,
            })
    return cameras


def dgt_camaras_menu():
    h = int(sys.argv[1])
    xbmcgui.Dialog().notification("DGT Cámaras", "Cargando lista…", xbmcgui.NOTIFICATION_INFO, 1500)
    cameras = _fetch_camaras()

    if not cameras:
        li = xbmcgui.ListItem(label="[COLOR red]No se pudo obtener la lista de cámaras.[/COLOR]")
        li.setInfo("video", {"plot": "No hay cámaras disponibles en este momento."})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    icon = _ri_icon("cat_camaras_dgt.png")

    by_province = {}
    for cam in cameras:
        prov = cam.get("province", "") or "Otras"
        if prov not in by_province:
            by_province[prov] = []
        by_province[prov].append(cam)

    if len(by_province) > 1:
        for prov_name in sorted(by_province.keys()):
            cams_in_prov = by_province[prov_name]
            li = xbmcgui.ListItem(
                label="[B]{0}[/B]  [COLOR grey]({1} cámaras)[/COLOR]".format(prov_name, len(cams_in_prov))
            )
            li.setArt({"icon": icon})
            li.setInfo("video", {"plot": "{0} cámaras de tráfico en {1}.".format(len(cams_in_prov), prov_name)})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="dgt_camaras_provincia", provincia=prov_name),
                listitem=li,
                isFolder=True,
            )
    else:
        _show_camaras_list(h, cameras, icon)

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar lista ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Recarga la lista de cámaras DGT."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dgt_camaras_refresh"), listitem=li_r, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def dgt_camaras_provincia(provincia):
    h = int(sys.argv[1])
    cameras = _fetch_camaras()
    cameras_prov = [c for c in cameras if (c.get("province", "") or "Otras") == provincia]
    icon = _ri_icon("cat_camaras_dgt.png")
    _show_camaras_list(h, cameras_prov, icon)
    xbmcplugin.endOfDirectory(h)


def _show_camaras_list(h, cameras, icon):
    for cam in cameras:
        nombre = cam.get("name", "Cámara DGT")
        url    = cam.get("url", "")
        prov   = cam.get("province", "")
        if not url:
            continue
        label = "[B]{0}[/B]  [COLOR grey]{1}[/COLOR]".format(nombre, prov) if prov else "[B]{0}[/B]".format(nombre)
        plot  = "Cámara: {0}\nURL: {1}\n\nImagen JPG actualizada cada ~2 minutos.\nPulsa para verla a pantalla completa.".format(nombre, url)
        li = xbmcgui.ListItem(label=label)
        cam_icon = url if url.lower().endswith((".jpg", ".jpeg", ".png")) else icon
        li.setArt({"icon": cam_icon, "thumb": cam_icon})
        li.setInfo("video", {"title": nombre, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="dgt_camara_view", url=url, titulo=nombre),
            listitem=li,
            isFolder=False,
        )


def dgt_camara_view(url, titulo):
    if url and url.startswith("https://"):
        xbmc.executebuiltin('ShowPicture("{0}")'.format(url.replace('"', "%22")))
    else:
        xbmcgui.Dialog().notification("DGT — " + titulo, "URL de cámara no válida", xbmcgui.NOTIFICATION_WARNING, 2000)


def dgt_camaras_refresh():
    path = _cams_cache_path()
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass
    xbmcgui.Dialog().notification(
        "DGT Cámaras", "Caché de cámaras eliminada — recargando…",
        xbmcgui.NOTIFICATION_INFO, 1500,
    )
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="dgt_camaras_menu")))
