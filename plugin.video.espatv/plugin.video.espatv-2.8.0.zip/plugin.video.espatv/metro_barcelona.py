# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Metro de Barcelona: próximos trenes por estación (TMB iMetro API)."""
import json
import os
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG = "[EspaTV-BCN]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_STATE_FILE = os.path.join(_PROFILE, "metro_barcelona_state.json")
_CACHE_FILE = os.path.join(_PROFILE, "metro_barcelona_cache.json")
_CACHE_TTL = 60
_TIMEOUT = 15
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")
_BASE_URL = "https://api.tmb.cat/v1/imetro/estacions"

_STATIONS = {
    # L1
    101: "Fondo (L1)",
    102: "Santa Coloma (L1)",
    103: "Artigues | Santa Coloma (L1)",
    104: "Badalona Pompeu Fabra (L1)",
    105: "Baró de Viver (L1)",
    106: "Santa Eulàlia (L1)",
    107: "Torrassa (L1)",
    108: "Collblanc (L1)",
    109: "Pubilla Cases (L1)",
    110: "Can Serra (L1)",
    111: "Florida (L1)",
    112: "Av. Carrilet (L1)",
    113: "Rambla Just Oliveras (L1)",
    114: "Almeda (L1)",
    115: "Cornellà Centre (L1)",
    116: "Sant Ildefons (L1)",
    117: "Can Boixeres (L1)",
    118: "Mercat Nou (L1)",
    119: "Plaça de Sants (L1/L5)",
    120: "Hostafrancs (L1)",
    121: "Rocafort (L1)",
    122: "Urgell (L1)",
    123: "Universitat (L1/L2)",
    124: "Catalunya (L1/L3)",
    125: "Urquinaona (L1/L4)",
    126: "Arc de Triomf (L1)",
    127: "Marina (L1)",
    128: "Glòries (L1)",
    129: "Clot (L1/L2)",
    130: "Navas (L1)",
    131: "La Sagrera (L1/L5)",
    132: "Congrés (L1)",
    133: "Maragall (L1/L5)",
    134: "Virrei Amat (L1)",
    135: "Vilapicina (L1)",
    136: "Torras i Bages (L1)",
    # L2
    201: "Badalona Pompeu Fabra (L2)",
    202: "Artigues | Santa Coloma (L2)",
    203: "Sant Roc (L2)",
    204: "Gorg (L2)",
    205: "La Pau (L2/L4)",
    206: "Verneda (L2)",
    207: "Pep Ventura (L2)",
    208: "Encants (L2)",
    209: "Sagrada Família (L2/L5)",
    210: "Verdaguer (L2/L5)",
    211: "Passeig de Gràcia (L2/L3/L4)",
    212: "Universitat (L2/L1)",
    213: "Sant Antoni (L2)",
    214: "Paral·lel (L2/L3)",
    215: "Poble Sec (L2)",
    216: "Rocafort (L2)",
    # L3
    301: "Trinitat Nova (L3/L4)",
    302: "Canyelles (L3)",
    303: "Roquetes (L3)",
    304: "Via Júlia (L3)",
    305: "Llucmajor (L3)",
    306: "Maragall (L3/L5)",
    307: "Guinardó | Hospital de Sant Pau (L3/L4)",
    308: "Alfons X (L3)",
    309: "Joanic (L3)",
    310: "Verdaguer (L3/L5)",
    311: "Diagonal (L3/L5)",
    312: "Passeig de Gràcia (L3/L2/L4)",
    313: "Catalunya (L3/L1)",
    314: "Liceu (L3)",
    315: "Drassanes (L3)",
    316: "Paral·lel (L3/L2)",
    317: "Poble Sec (L3)",
    318: "Espanya (L3/L1)",
    319: "Tarragona (L3)",
    320: "Rocafort (L3)",
    321: "Entença (L3)",
    322: "Hospital Clínic (L3)",
    323: "Les Corts (L3)",
    324: "Zona Universitària (L3/L9/L10)",
    325: "Palau Reial (L3)",
    326: "Maria Cristina (L3)",
    327: "Badal (L3)",
    328: "Sants Estació (L3/L5)",
    # L4
    401: "La Pau (L4/L2)",
    402: "Besòs Mar (L4)",
    403: "Besòs (L4)",
    404: "El Maresme | Fòrum (L4)",
    405: "Selva de Mar (L4)",
    406: "Poblenou (L4)",
    407: "Ciutadella | Vila Olímpica (L4)",
    408: "Barceloneta (L4)",
    409: "Jaume I (L4)",
    410: "Urquinaona (L4/L1)",
    411: "Passeig de Gràcia (L4/L2/L3)",
    412: "Girona (L4)",
    413: "Verdaguer (L4/L5)",
    414: "Guinardó | Hospital de Sant Pau (L4/L3)",
    415: "Maragall (L4/L5)",
    416: "Congrés (L4)",
    417: "Navas (L4)",
    418: "La Sagrera (L4/L5)",
    419: "Trinitat Vella (L4)",
    420: "Baró de Viver (L4)",
    421: "Santa Coloma (L4)",
    422: "Badalona (L4)",
    423: "Trinitat Nova (L4/L3)",
    # L5
    501: "Cornellà (L5)",
    502: "Gavarra (L5)",
    503: "Sant Ildefons (L5)",
    504: "Can Boixeres (L5)",
    505: "Badal (L5)",
    506: "Plaça de Sants (L5/L1)",
    507: "Sants Estació (L5/L3)",
    508: "Entença (L5)",
    509: "Hospital Clínic (L5)",
    510: "Diagonal (L5/L3)",
    511: "Verdaguer (L5/L2/L4)",
    512: "Sagrada Família (L5/L2)",
    513: "Encants (L5)",
    514: "Clot (L5/L2)",
    515: "La Sagrera (L5/L1/L4)",
    516: "Maragall (L5/L1/L4)",
    517: "Guinardó | Hospital de Sant Pau (L5/L3/L4)",
    518: "El Carmel (L5)",
    519: "El Coll | La Teixonera (L5)",
    520: "Montbau (L5)",
    521: "Mundet (L5)",
    522: "Vall d'Hebron (L5)",
    523: "Tibidabo (L5)",
    524: "Pàdua (L5)",
    525: "El Putget (L5)",
    526: "Gràcia (L5)",
    # L9 Sud
    901: "Aeroport T1 (L9)",
    902: "Aeroport T2 (L9)",
    903: "Mas Blau (L9)",
    904: "Parc Nou (L9)",
    905: "Centurions (L9)",
    906: "Pedreres (L9)",
    907: "Cal Travieso (L9)",
    908: "Les Moreres (L9)",
    909: "El Prat Estació (L9)",
    910: "Mercabarna (L9)",
    911: "Parc Logístic (L9)",
    912: "Fira (L9)",
    913: "Europa | Fira (L9)",
    914: "Can Tries | Gornal (L9)",
    915: "Torrassa (L9/L1)",
    916: "Collblanc (L9/L1/L10)",
    917: "Zona Universitària (L9/L3/L10)",
    # L10 Nord
    1001: "Collblanc (L10/L9)",
    1002: "Av. Carrilet (L10)",
    1003: "Foneria (L10)",
    1004: "Mercat Nou (L10/L1)",
    1005: "Can Boixeres (L10/L1)",
    1006: "Pubilla Cases (L10/L1)",
    1007: "Zona Universitària (L10/L3/L9)",
    # L11
    1101: "Trinitat Nova (L11/L3/L4)",
    1102: "Casa de l'Aigua (L11)",
    1103: "Torre Baró | Vallbona (L11)",
    1104: "Ciutat Meridiana (L11)",
    1105: "Can Cuiàs (L11)",
}

_STATIONS_SORTED = sorted(_STATIONS.items(), key=lambda x: x[1].lower())


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _ensure_profile():
    if not xbmcvfs.exists(_PROFILE):
        xbmcvfs.mkdirs(_PROFILE)


def _get_keys():
    state = _load_state()
    return state.get("app_id", ""), state.get("app_key", "")


def _load_state():
    try:
        with open(_STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save_state(state):
    _ensure_profile()
    try:
        with open(_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False)
    except OSError:
        pass


def _load_cache(key):
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        entry = obj.get(key, {})
        if time.time() - entry.get("ts", 0) < _CACHE_TTL:
            return entry.get("data")
    except (OSError, ValueError):
        pass
    return None


def _save_cache(key, data):
    _ensure_profile()
    try:
        try:
            with open(_CACHE_FILE, "r", encoding="utf-8") as f:
                obj = json.load(f)
        except (OSError, ValueError):
            obj = {}
        obj[key] = {"ts": time.time(), "data": data}
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except OSError:
        pass


def _fetch_times(codi_estacio, app_id, app_key):
    url = "{0}/{1}/temps".format(_BASE_URL, codi_estacio)
    params = {"app_id": app_id, "app_key": app_key}
    headers = {"User-Agent": "Mozilla/5.0 EspaTV/1.0"}
    resp = requests.get(url, params=params, headers=headers, timeout=_TIMEOUT)
    resp.raise_for_status()
    return resp.json()


def _parse_times(api_data):
    trains = []
    try:
        items = api_data.get("data", {}).get("imetro", [])
        if not isinstance(items, list):
            items = [items]
        for item in items:
            secs = item.get("temps_restant")
            if secs is None or secs < 0:
                continue
            mins = int(secs) // 60
            linea = item.get("codi_linia", "?")
            destino = item.get("desti", "")
            trains.append((mins, str(linea), destino))
    except Exception as e:
        xbmc.log("{0} Error parseando JSON: {1}".format(_LOG, e), xbmc.LOGWARNING)
    trains.sort(key=lambda x: x[0])
    return trains


def metro_barcelona_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_metro_barcelona.png")
    app_id, app_key = _get_keys()
    state = _load_state()
    codi_estacio = state.get("codi_estacio")
    est_name = state.get("estacion_name", "—")

    if app_id and app_key and codi_estacio:
        li = xbmcgui.ListItem(label="[B][COLOR deepskyblue]{0}[/COLOR][/B]".format(est_name))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Ver próximos trenes en {0}.".format(est_name)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="metro_barcelona_trenes", codi_estacio=codi_estacio, estacion_name=est_name),
            listitem=li, isFolder=True,
        )

    if app_id and app_key:
        li_c = xbmcgui.ListItem(label="[COLOR gold][ Cambiar estación: {0} ][/COLOR]".format(est_name))
        li_c.setArt({"icon": "DefaultIconInfo.png"})
        li_c.setInfo("video", {"plot": "Selecciona una estación de Metro de Barcelona."})
        li_c.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="metro_barcelona_cambiar"), listitem=li_c, isFolder=False)

    cfg_label = (
        "[COLOR aqua][ Cambiar claves TMB API ][/COLOR]" if (app_id and app_key)
        else "[COLOR gold][ Configurar claves TMB API ][/COLOR]"
    )
    cfg_plot = (
        "Introduce tu app_id y app_key gratuitos de la API TMB.\n\n"
        "Regístrate gratis en:\n  developer.tmb.cat\n\n"
        "app_id actual: {0}".format(app_id if app_id else "—")
    )
    li_cfg = xbmcgui.ListItem(label=cfg_label)
    li_cfg.setArt({"icon": "DefaultIconInfo.png"})
    li_cfg.setInfo("video", {"plot": cfg_plot})
    li_cfg.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="metro_barcelona_config"), listitem=li_cfg, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def metro_barcelona_config():
    state = _load_state()
    app_id = xbmcgui.Dialog().input(
        "TMB app_id — developer.tmb.cat", defaultt=state.get("app_id", ""),
        type=xbmcgui.INPUT_ALPHANUM,
    )
    if app_id is None:
        return
    app_key = xbmcgui.Dialog().input(
        "TMB app_key — developer.tmb.cat", defaultt=state.get("app_key", ""),
        type=xbmcgui.INPUT_ALPHANUM,
    )
    if app_key is None:
        return
    state["app_id"] = app_id.strip()
    state["app_key"] = app_key.strip()
    _save_state(state)
    xbmc.executebuiltin("Container.Refresh")


def metro_barcelona_cambiar():
    names = [name for _, name in _STATIONS_SORTED]
    idx = xbmcgui.Dialog().select("Selecciona estación — Metro Barcelona", names)
    if idx < 0:
        return
    codi_estacio, est_name = _STATIONS_SORTED[idx]
    state = _load_state()
    state["codi_estacio"] = codi_estacio
    state["estacion_name"] = est_name
    _save_state(state)
    xbmc.executebuiltin("Container.Refresh")


def metro_barcelona_trenes(codi_estacio, estacion_name):
    h = int(sys.argv[1])
    icon = _icon("cat_metro_barcelona.png")
    app_id, app_key = _get_keys()

    if not app_id or not app_key:
        _show_error(h, "Configura las claves TMB API en Ajustes del addon")
        return

    cache_key = "bcn_{0}".format(codi_estacio)

    api_data = _load_cache(cache_key)
    if api_data is None:
        try:
            xbmcgui.Dialog().notification(
                "Metro Barcelona", "Consultando tiempos…",
                xbmcgui.NOTIFICATION_INFO, 1200
            )
            api_data = _fetch_times(int(codi_estacio), app_id, app_key)
            _save_cache(cache_key, api_data)
        except requests.HTTPError as e:
            code = e.response.status_code if e.response else "?"
            if code == 401:
                _show_error(h, "Claves TMB inválidas — revisa app_id y app_key en Ajustes")
            else:
                _show_error(h, "Error del servidor TMB ({0})".format(code))
            return
        except requests.ConnectionError:
            _show_error(h, "Sin conexión — comprueba la red")
            return
        except requests.Timeout:
            _show_error(h, "TMB tardó demasiado — inténtalo de nuevo")
            return
        except Exception as e:
            xbmc.log("{0} Error inesperado: {1}".format(_LOG, e), xbmc.LOGERROR)
            _show_error(h, "Error inesperado — revisa el log de Kodi")
            return

    trains = _parse_times(api_data)

    if not trains:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin servicio ahora en {0}[/COLOR]".format(estacion_name))
        li.setInfo("video", {"plot": "No hay trenes próximos o el servicio iMetro no está activo."})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    else:
        for mins, linea, destino in trains[:20]:
            if mins <= 1:
                color = "tomato"
                tiempo = "ahora" if mins <= 0 else "1 min"
            elif mins <= 5:
                color = "gold"
                tiempo = "{0} min".format(mins)
            else:
                color = "lightgreen"
                tiempo = "{0} min".format(mins)

            label = "[B][COLOR {0}]L{1}[/COLOR][/B]  {2}  [COLOR grey]{3}[/COLOR]".format(
                color, linea, destino.title(), tiempo
            )
            plot = "\n".join([
                "[B]{0}[/B]".format(estacion_name),
                "",
                "  Línea:   [B]L{0}[/B]".format(linea),
                "  Destino: [B]{0}[/B]".format(destino.title()),
                "  Llega:   [B]{0}[/B]".format(tiempo),
            ])
            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": icon})
            li.setInfo("video", {"title": "L{0} → {1}".format(linea, destino.title()), "plot": plot})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Recarga los tiempos en tiempo real (caché: 1 min)."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="metro_barcelona_refresh", codi_estacio=codi_estacio, estacion_name=estacion_name),
        listitem=li_r, isFolder=True,
    )
    xbmcplugin.endOfDirectory(h)


def metro_barcelona_refresh(codi_estacio, estacion_name=""):
    cache_key = "bcn_{0}".format(codi_estacio)
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        obj.pop(cache_key, None)
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except (OSError, ValueError):
        pass
    xbmc.executebuiltin("Container.Update({0},replace)".format(
        _u(action="metro_barcelona_trenes", codi_estacio=codi_estacio, estacion_name=estacion_name)
    ))


def _show_error(h, msg):
    li = xbmcgui.ListItem(label="[COLOR red]{0}[/COLOR]".format(msg))
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)
