# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Metro de Madrid: próximos trenes por estación (CRTM widgets API, sin auth)."""
import json
import os
import sys
import time
import urllib.parse
from datetime import datetime

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG = "[EspaTV-MAD]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_STATE_FILE = os.path.join(_PROFILE, "metro_madrid_state.json")
_CACHE_FILE = os.path.join(_PROFILE, "metro_madrid_cache.json")
_CACHE_TTL = 120
_TIMEOUT = 15
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")
_URL = "https://www.crtm.es/widgets/api/GetStopsTimes.php"

# codStop = "4_XX"  (prefijo 4 = Metro de Madrid)
_STATIONS = {
    "4_1":   "Plaza de Castilla",
    "4_2":   "Valdeacederas",
    "4_3":   "Tetuán",
    "4_4":   "Estrecho",
    "4_5":   "Alvarado",
    "4_6":   "Cuatro Caminos",
    "4_7":   "Ríos Rosas",
    "4_8":   "Iglesia",
    "4_9":   "Bilbao",
    "4_10":  "Tribunal",
    "4_11":  "Gran Vía",
    "4_12":  "Sol",
    "4_13":  "Tirso de Molina",
    "4_14":  "Antón Martín",
    "4_15":  "Estación del Arte",
    "4_16":  "Atocha",
    "4_17":  "Menéndez Pelayo",
    "4_18":  "Pacífico",
    "4_19":  "Puente de Vallecas",
    "4_20":  "Nueva Numancia",
    "4_21":  "Portazgo",
    "4_22":  "Buenos Aires",
    "4_23":  "Alto del Arenal",
    "4_24":  "Miguel Hernández",
    "4_25":  "Sierra de Guadalupe",
    "4_26":  "Villa de Vallecas",
    "4_27":  "Congosto",
    "4_28":  "Ventas",
    "4_29":  "Manuel Becerra",
    "4_30":  "Goya",
    "4_31":  "Príncipe de Vergara",
    "4_32":  "Retiro",
    "4_33":  "Banco de España",
    "4_34":  "Sevilla",
    "4_36":  "Ópera",
    "4_37":  "Santo Domingo",
    "4_38":  "Noviciado",
    "4_39":  "San Bernardo",
    "4_40":  "Quevedo",
    "4_41":  "Canal",
    "4_42":  "Cuatro Caminos (L6)",
    "4_43":  "Legazpi",
    "4_44":  "Delicias",
    "4_45":  "Palos de la Frontera",
    "4_46":  "Embajadores",
    "4_47":  "Lavapiés",
    "4_49":  "Callao",
    "4_50":  "Plaza de España",
    "4_51":  "Ventura Rodríguez",
    "4_52":  "Argüelles",
    "4_53":  "Moncloa",
    "4_57":  "Alonso Martínez",
    "4_58":  "Colón",
    "4_59":  "Serrano",
    "4_60":  "Velázquez",
    "4_62":  "Lista",
    "4_63":  "Diego de León",
    "4_64":  "Avenida de América",
    "4_65":  "Prosperidad",
    "4_66":  "Alfonso XIII",
    "4_67":  "Avenida de La Paz",
    "4_68":  "Arturo Soria",
    "4_69":  "Esperanza",
    "4_70":  "Canillas",
    "4_71":  "Mar de Cristal",
    "4_72":  "San Lorenzo",
    "4_73":  "Parque de Santa María",
    "4_75":  "Torre Arias",
    "4_76":  "Suanzes",
    "4_78":  "Pueblo Nuevo",
    "4_79":  "Quintana",
    "4_80":  "El Carmen",
    "4_83":  "Núñez de Balboa",
    "4_84":  "Rubén Darío",
    "4_86":  "Chueca",
    "4_90":  "La Latina",
    "4_91":  "Puerta de Toledo",
    "4_92":  "Acacias",
    "4_93":  "Pirámides",
    "4_94":  "Marqués de Vadillo",
    "4_95":  "Urgel",
    "4_96":  "Oporto",
    "4_97":  "Vista Alegre",
    "4_98":  "Carabanchel",
    "4_99":  "Eugenia de Montijo",
    "4_100": "Aluche",
    "4_102": "Campamento",
    "4_103": "Casa de Campo",
    "4_113": "Conde de Casal",
    "4_114": "Sainz de Baranda",
    "4_115": "O'Donnell",
    "4_120": "Nuevos Ministerios",
    "4_124": "Ciudad Universitaria",
    "4_127": "Príncipe Pío",
    "4_128": "Puerta del Ángel",
    "4_142": "Gregorio Marañón",
    "4_143": "Alonso Cano",
    "4_159": "Aeropuerto T1-T2-T3",
    "4_191": "Cuzco",
    "4_192": "Santiago Bernabéu",
    "4_199": "Lago",
    "4_200": "Batán",
    "4_204": "Joaquín Vilumbrales",
    "4_205": "Puerta del Sur",
    "4_214": "Móstoles Central",
    "4_261": "Chamartín",
    "4_263": "Pinar de Chamartín",
    "4_273": "Villaverde Alto",
    "4_285": "Aeropuerto T4",
    "4_295": "Valdecarros",
    "4_186": "Arganda del Rey",
}

_STATIONS_SORTED = sorted(_STATIONS.items(), key=lambda x: x[1].lower())


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _ensure_profile():
    if not xbmcvfs.exists(_PROFILE):
        xbmcvfs.mkdirs(_PROFILE)


def _load_state():
    try:
        with open(_STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save_state(state):
    _ensure_profile()
    try:
        with open(_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False)
    except OSError:
        pass


def _load_cache(key):
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        entry = obj.get(key, {})
        if time.time() - entry.get("ts", 0) < _CACHE_TTL:
            return entry.get("data")
    except (OSError, ValueError):
        pass
    return None


def _save_cache(key, data):
    _ensure_profile()
    try:
        try:
            with open(_CACHE_FILE, "r", encoding="utf-8") as f:
                obj = json.load(f)
        except (OSError, ValueError):
            obj = {}
        obj[key] = {"ts": time.time(), "data": data}
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except OSError:
        pass


def _fetch_times(cod_stop):
    params = {"codStop": cod_stop, "type": "1", "orderBy": "1", "stopTimesByIti": "0"}
    headers = {
        "User-Agent": "Mozilla/5.0 EspaTV/1.0",
        "Referer": "https://www.crtm.es/",
    }
    resp = requests.get(_URL, params=params, headers=headers, timeout=_TIMEOUT)
    resp.raise_for_status()
    return resp.json()


def _mins_left(iso_str):
    try:
        dt = datetime.fromisoformat(iso_str)
        now = datetime.now(dt.tzinfo)
        secs = (dt - now).total_seconds()
        return int(secs // 60)
    except Exception:
        return None


def _parse_times(api_data):
    trains = []
    try:
        raw = api_data.get("stopTimes", {}).get("times", {}).get("Time")
        if raw is None:
            return trains
        items = raw if isinstance(raw, list) else [raw]
        for item in items:
            iso_time = item.get("time", "")
            mins = _mins_left(iso_time)
            if mins is None or mins < 0:
                continue
            linea = (item.get("line") or {}).get("shortDescription", "?")
            destino = item.get("destination", "")
            is_night = bool((item.get("line") or {}).get("nightService"))
            trains.append((mins, linea, destino, is_night))
    except Exception as e:
        xbmc.log("{0} Error parseando JSON: {1}".format(_LOG, e), xbmc.LOGWARNING)
    trains.sort(key=lambda x: x[0])
    return trains


def metro_madrid_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_metro_madrid.png")
    state = _load_state()
    cod_stop = state.get("cod_stop")
    est_name = state.get("estacion_name", "—")

    if cod_stop:
        li = xbmcgui.ListItem(label="[B][COLOR deepskyblue]{0}[/COLOR][/B]".format(est_name))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Ver próximos trenes en {0}.".format(est_name)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="metro_madrid_trenes", cod_stop=cod_stop, estacion_name=est_name),
            listitem=li, isFolder=True,
        )

    li_c = xbmcgui.ListItem(label="[COLOR gold][ Cambiar estación: {0} ][/COLOR]".format(est_name))
    li_c.setArt({"icon": "DefaultIconInfo.png"})
    li_c.setInfo("video", {"plot": "Selecciona una estación de Metro de Madrid."})
    li_c.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="metro_madrid_cambiar"), listitem=li_c, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def metro_madrid_cambiar():
    names = [name for _, name in _STATIONS_SORTED]
    idx = xbmcgui.Dialog().select("Selecciona estación — Metro Madrid", names)
    if idx < 0:
        return
    cod_stop, est_name = _STATIONS_SORTED[idx]
    state = _load_state()
    state["cod_stop"] = cod_stop
    state["estacion_name"] = est_name
    _save_state(state)
    xbmc.executebuiltin("Container.Refresh")


def metro_madrid_trenes(cod_stop, estacion_name):
    h = int(sys.argv[1])
    icon = _icon("cat_metro_madrid.png")
    cache_key = "mad_{0}".format(cod_stop)

    api_data = _load_cache(cache_key)
    if api_data is None:
        try:
            xbmcgui.Dialog().notification(
                "Metro Madrid", "Consultando tiempos…",
                xbmcgui.NOTIFICATION_INFO, 1200
            )
            api_data = _fetch_times(cod_stop)
            _save_cache(cache_key, api_data)
        except requests.HTTPError as e:
            _show_error(h, "Error del servidor ({0})".format(e.response.status_code if e.response else "?"))
            return
        except requests.ConnectionError:
            _show_error(h, "Sin conexión — comprueba la red")
            return
        except requests.Timeout:
            _show_error(h, "CRTM tardó demasiado — inténtalo de nuevo")
            return
        except Exception as e:
            xbmc.log("{0} Error inesperado: {1}".format(_LOG, e), xbmc.LOGERROR)
            _show_error(h, "Error inesperado — revisa el log de Kodi")
            return

    trains = _parse_times(api_data)

    if not trains:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin servicio ahora en {0}[/COLOR]".format(estacion_name))
        li.setInfo("video", {"plot": "No hay trenes próximos o el sistema SAE no está activo."})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    else:
        for mins, linea, destino, is_night in trains[:20]:
            if mins <= 1:
                color = "tomato"
                tiempo = "ahora" if mins <= 0 else "1 min"
            elif mins <= 5:
                color = "gold"
                tiempo = "{0} min".format(mins)
            else:
                color = "lightgreen"
                tiempo = "{0} min".format(mins)

            night_tag = "  [COLOR grey][N][/COLOR]" if is_night else ""
            label = "[B][COLOR {0}]L{1}[/COLOR][/B]  {2}  [COLOR grey]{3}[/COLOR]{4}".format(
                color, linea, destino.title(), tiempo, night_tag
            )
            plot = "\n".join([
                "[B]{0}[/B]".format(estacion_name),
                "",
                "  Línea:   [B]L{0}[/B]".format(linea),
                "  Destino: [B]{0}[/B]".format(destino.title()),
                "  Llega:   [B]{0}[/B]".format(tiempo),
            ])
            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": icon})
            li.setInfo("video", {"title": "L{0} → {1}".format(linea, destino.title()), "plot": plot})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Recarga los tiempos en tiempo real (caché: 2 min)."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="metro_madrid_refresh", cod_stop=cod_stop, estacion_name=estacion_name),
        listitem=li_r, isFolder=True,
    )
    xbmcplugin.endOfDirectory(h)


def metro_madrid_refresh(cod_stop, estacion_name=""):
    cache_key = "mad_{0}".format(cod_stop)
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        obj.pop(cache_key, None)
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except (OSError, ValueError):
        pass
    xbmc.executebuiltin("Container.Update({0},replace)".format(
        _u(action="metro_madrid_trenes", cod_stop=cod_stop, estacion_name=estacion_name)
    ))


def _show_error(h, msg):
    li = xbmcgui.ListItem(label="[COLOR red]{0}[/COLOR]".format(msg))
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)
