# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Galería de Obras: colecciones públicas del Met Museum y Wikimedia Commons (CC0/DP)."""
import hashlib
import json
import os
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG     = "[EspaTV-GAL]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_DIR  = os.path.join(_PROFILE, "galeria_cache")
_CACHE_TTL  = 7 * 24 * 3600
_TIMEOUT    = 20
_PAGE_SIZE  = 30
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_MET_SEARCH = "https://collectionapi.metmuseum.org/public/collection/v1/search"
_MET_OBJECT = "https://collectionapi.metmuseum.org/public/collection/v1/objects/{id}"
_MET_HEADERS = {
    "User-Agent": "EspaTV/1.0 (Kodi addon; galeria arte; contact: espakodi@github)",
    "Accept": "application/json",
}

# Artistas españoles destacados: queries para el Met
_ARTISTAS_ES = [
    ("Goya",        "Goya"),
    ("Velázquez",   "Velazquez"),
    ("El Greco",    "El Greco"),
    ("Zurbarán",    "Zurbaran"),
    ("Sorolla",     "Sorolla"),
    ("Murillo",     "Murillo"),
    ("Ribera",      "Ribera"),
    ("Miró",        "Miro"),
    ("Dalí",        "Dali"),
    ("Picasso",     "Picasso"),
]

# Colecciones temáticas
_COLECCIONES = [
    ("Arte Español",            "Spanish painting"),
    ("Pintura Flamenca",        "Flemish painting"),
    ("Renacimiento Italiano",   "Italian Renaissance"),
    ("Arte Islámico",           "Islamic art Spain"),
    ("Escultura Clásica",       "Greek Roman sculpture"),
    ("Impresionismo",           "Impressionism"),
]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _cache_path(key):
    return os.path.join(_CACHE_DIR, hashlib.md5(key.encode()).hexdigest() + ".json")


def _load_cache(key):
    fp = _cache_path(key)
    try:
        with open(fp, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if time.time() - obj.get("ts", 0) < _CACHE_TTL:
            return obj.get("data")
    except (OSError, ValueError):
        pass
    return None


def _save_cache(key, data):
    fp = _cache_path(key)
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        with open(fp, "w", encoding="utf-8") as f:
            json.dump({"ts": time.time(), "data": data}, f, ensure_ascii=False)
    except OSError as e:
        xbmc.log("{0} Error caché: {1}".format(_LOG, e), xbmc.LOGWARNING)


def _met_search(query, is_highlight=False, department_id=None):
    """Busca en el Met y devuelve lista de IDs (públicos con imagen)."""
    cache_key = "met_search_{0}_{1}".format(query, is_highlight)
    cached = _load_cache(cache_key)
    if cached is not None:
        return cached

    params = {
        "q": query,
        "isPublicDomain": "true",
        "hasImages": "true",
    }
    if is_highlight:
        params["isHighlight"] = "true"
    if department_id:
        params["departmentId"] = department_id

    try:
        resp = requests.get(_MET_SEARCH, params=params, headers=_MET_HEADERS, timeout=_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
        ids = data.get("objectIDs") or []
        _save_cache(cache_key, ids)
        return ids
    except Exception as e:
        xbmc.log("{0} Error búsqueda Met: {1}".format(_LOG, e), xbmc.LOGWARNING)
        return []


def _met_object(obj_id):
    """Obtiene los detalles de un objeto del Met."""
    cache_key = "met_obj_{0}".format(obj_id)
    cached = _load_cache(cache_key)
    if cached is not None:
        return cached

    try:
        url = _MET_OBJECT.format(id=obj_id)
        resp = requests.get(url, headers=_MET_HEADERS, timeout=_TIMEOUT)
        resp.raise_for_status()
        obj = resp.json()
        _save_cache(cache_key, obj)
        return obj
    except Exception as e:
        xbmc.log("{0} Error objeto Met {1}: {2}".format(_LOG, obj_id, e), xbmc.LOGWARNING)
        return None


def _show_objects(h, obj_ids, max_items=_PAGE_SIZE):
    shown = 0
    for obj_id in obj_ids:
        if shown >= max_items:
            break
        obj = _met_object(obj_id)
        if not obj:
            continue
        titulo     = obj.get("title", "Sin título")
        artista    = obj.get("artistDisplayName", "Artista desconocido")
        fecha      = obj.get("objectDate", "")
        medium     = obj.get("medium", "")
        imagen_url = obj.get("primaryImageSmall") or obj.get("primaryImage", "")
        departamento = obj.get("department", "")
        museo      = "The Met, Nueva York"

        if not imagen_url:
            continue

        label = "[B]{0}[/B]  [COLOR grey]{1}[/COLOR]".format(titulo, artista)
        plot  = "{0}\n{1}  {2}\n{3}\n{4}\n{5}".format(
            titulo, artista, fecha, medium, departamento, museo
        )
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": imagen_url, "thumb": imagen_url, "poster": imagen_url})
        li.setInfo("video", {"title": titulo, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="galeria_obra_view", title=titulo, plot=plot, img=imagen_url), listitem=li, isFolder=False)
        shown += 1
    return shown


def galeria_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_galeria_arte.png")

    li_wip = xbmcgui.ListItem(label="[COLOR orange][ Sección en construcción — próximamente más colecciones ][/COLOR]")
    li_wip.setArt({"icon": icon})
    li_wip.setInfo("video", {"plot": (
        "Esta sección está en desarrollo.\n"
        "Actualmente muestra obras del Metropolitan Museum of Art (dominio público, CC0).\n"
        "Próximamente se añadirán más museos y colecciones españolas."
    )})
    li_wip.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li_wip, isFolder=False)

    li_art = xbmcgui.ListItem(label="[B][COLOR deepskyblue]Artistas Españoles[/COLOR][/B]")
    li_art.setArt({"icon": icon})
    li_art.setInfo("video", {"plot": "Obras de Goya, Velázquez, El Greco, Zurbarán, Sorolla y otros maestros españoles en el Met."})
    li_art.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="galeria_artistas_es"), listitem=li_art, isFolder=True)

    # Colecciones temáticas
    li_col = xbmcgui.ListItem(label="[B][COLOR gold]Colecciones Temáticas[/COLOR][/B]")
    li_col.setArt({"icon": icon})
    li_col.setInfo("video", {"plot": "Arte español, flamenco, renacimiento, islámico, impresionismo y más."})
    li_col.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="galeria_colecciones"), listitem=li_col, isFolder=True)

    # Búsqueda libre
    li_bus = xbmcgui.ListItem(label="[B][COLOR mediumseagreen]Buscar en el Met[/COLOR][/B]")
    li_bus.setArt({"icon": icon})
    li_bus.setInfo("video", {"plot": "Búsqueda libre en la colección pública del Metropolitan Museum of Art (CC0)."})
    li_bus.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="galeria_buscar"), listitem=li_bus, isFolder=True)

    # Destacadas
    li_dest = xbmcgui.ListItem(label="[B][COLOR orange]Obras Destacadas[/COLOR][/B]")
    li_dest.setArt({"icon": icon})
    li_dest.setInfo("video", {"plot": "Obras marcadas como destacadas en el Met (isHighlight=true). Dominio público."})
    li_dest.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="galeria_destacadas"), listitem=li_dest, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def galeria_artistas_es():
    h = int(sys.argv[1])
    icon = _icon("cat_galeria_arte.png")
    for nombre, query in _ARTISTAS_ES:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(nombre))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Obras de {0} en la colección pública del Met Museum (dominio público).".format(nombre)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="galeria_lista", query=query, titulo=nombre), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def galeria_colecciones():
    h = int(sys.argv[1])
    icon = _icon("cat_galeria_arte.png")
    for nombre, query in _COLECCIONES:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(nombre))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "{0} — colección del Met Museum (dominio público).".format(nombre)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="galeria_lista", query=query, titulo=nombre), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def galeria_buscar():
    kb = xbmc.Keyboard("", "Buscar en el Met")
    kb.doModal()
    if not kb.isConfirmed():
        return
    q = kb.getText().strip()
    if not q:
        return
    xbmc.executebuiltin("Container.Update({0})".format(_u(action="galeria_lista", query=q, titulo=q)))


def galeria_lista(query, titulo):
    h = int(sys.argv[1])
    xbmcgui.Dialog().notification("Galería", "Buscando…", xbmcgui.NOTIFICATION_INFO, 1500)
    ids = _met_search(query)
    if not ids:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin resultados para «{0}»[/COLOR]".format(titulo))
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    _show_objects(h, ids)
    xbmcplugin.endOfDirectory(h)


def galeria_destacadas():
    h = int(sys.argv[1])
    xbmcgui.Dialog().notification("Galería", "Cargando destacadas…", xbmcgui.NOTIFICATION_INFO, 1500)
    ids = _met_search("painting", is_highlight=True)
    if not ids:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin resultados[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    _show_objects(h, ids)
    xbmcplugin.endOfDirectory(h)


def galeria_obra_view(title, plot, img):
    """Muestra la obra a pantalla completa usando ShowPicture."""
    if img:
        xbmc.executebuiltin('ShowPicture("{0}")'.format(img.replace('"', "%22")))
    else:
        xbmcgui.Dialog().textviewer(title, plot)
