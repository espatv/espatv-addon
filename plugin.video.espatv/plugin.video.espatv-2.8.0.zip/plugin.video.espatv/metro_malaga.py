# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Metro de Málaga: horario de parada (GTFS estático NAP, sin tiempo real)."""
import json
import os
import sys
import urllib.parse
import datetime

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import gtfs_horario

_LOG = "[EspaTV-AGP]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_STATE_FILE = os.path.join(_PROFILE, "metro_malaga_state.json")
_GTFS_ZIP = os.path.join(_PROFILE, "gtfs_metro_malaga.zip")
_GTFS_URL = "https://metromalaga.es/GTFS/GTFS_METRO_MALAGA.zip"
_ROUTE_TYPE = None
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _ensure_profile():
    if not xbmcvfs.exists(_PROFILE):
        xbmcvfs.mkdirs(_PROFILE)


def _load_state():
    try:
        with open(_STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save_state(state):
    _ensure_profile()
    try:
        with open(_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False)
    except OSError:
        pass


def _gtfs_ok():
    return not gtfs_horario.necesita_actualizar(_GTFS_ZIP)


def _download_gtfs():
    """Descarga el GTFS. Devuelve True si OK, False si error."""
    _ensure_profile()
    try:
        gtfs_horario.descargar(_GTFS_URL, _GTFS_ZIP)
        return True
    except Exception as e:
        xbmc.log("{0} Error descargando GTFS: {1}".format(_LOG, e), xbmc.LOGERROR)
        return False


# Menú principal

def metro_malaga_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_metro_malaga.png")
    state = _load_state()
    stop_id = state.get("stop_id")
    stop_name = state.get("stop_name", "—")

    if stop_id:
        li = xbmcgui.ListItem(label="[B][COLOR deepskyblue]{0}[/COLOR][/B]".format(stop_name))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Ver horario de hoy en {0}.".format(stop_name)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="metro_malaga_horario", stop_id=stop_id, stop_name=stop_name),
            listitem=li, isFolder=True,
        )

    li_c = xbmcgui.ListItem(label="[COLOR gold][ Cambiar parada: {0} ][/COLOR]".format(stop_name))
    li_c.setArt({"icon": "DefaultIconInfo.png"})
    li_c.setInfo("video", {"plot": "Selecciona una parada de Metro de Málaga.\nLos horarios son estáticos (GTFS) — se actualizan semanalmente."})
    li_c.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="metro_malaga_cambiar"), listitem=li_c, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def metro_malaga_cambiar():
    if not _gtfs_ok():
        xbmcgui.Dialog().notification("Metro de Málaga", "Descargando datos…", xbmcgui.NOTIFICATION_INFO, 2000)
        if not _download_gtfs():
            xbmcgui.Dialog().notification("Metro de Málaga", "Error de conexión", xbmcgui.NOTIFICATION_ERROR, 3000)
            return
    try:
        paradas = gtfs_horario.get_paradas(_GTFS_ZIP, route_type=_ROUTE_TYPE)
    except Exception as e:
        xbmc.log("{0} Error leyendo paradas: {1}".format(_LOG, e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Metro de Málaga", "Error al leer datos GTFS", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    names = [name for _, name in paradas]
    idx = xbmcgui.Dialog().select("Selecciona parada — Metro de Málaga", names)
    if idx < 0:
        return
    stop_id, stop_name = paradas[idx]
    state = _load_state()
    state["stop_id"] = stop_id
    state["stop_name"] = stop_name
    _save_state(state)
    xbmc.executebuiltin("Container.Refresh")


def metro_malaga_horario(stop_id, stop_name):
    h = int(sys.argv[1])
    icon = _icon("cat_metro_malaga.png")

    if not _gtfs_ok():
        xbmcgui.Dialog().notification("Metro de Málaga", "Descargando horarios…", xbmcgui.NOTIFICATION_INFO, 2000)
        if not _download_gtfs():
            _show_error(h, "Error de conexión — comprueba la red")
            return

    now = datetime.datetime.now()
    desde_min = now.hour * 60 + now.minute

    try:
        salidas = gtfs_horario.get_horario_hoy(_GTFS_ZIP, stop_id, desde_min=desde_min, route_type=_ROUTE_TYPE)
    except Exception as e:
        xbmc.log("{0} Error parseando GTFS: {1}".format(_LOG, e), xbmc.LOGERROR)
        _show_error(h, "Error al leer horario — revisa el log de Kodi")
        return

    if not salidas:
        li = xbmcgui.ListItem(label="[COLOR grey]No hay más salidas hoy en {0}[/COLOR]".format(stop_name))
        li.setInfo("video", {"plot": "Los horarios se basan en datos GTFS estáticos."})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    else:
        for dep_min, dep_str, headsign in salidas[:40]:
            mins_left = dep_min - desde_min
            if mins_left <= 3:
                color = "tomato"
            elif mins_left <= 10:
                color = "gold"
            else:
                color = "lightgreen"

            label = "[B][COLOR {0}]{1}[/COLOR][/B]  {2}  [COLOR grey]{3} min[/COLOR]".format(
                color, dep_str, headsign or "—", mins_left
            )
            plot = "\n".join([
                "[B]{0}[/B]".format(stop_name),
                "",
                "  Sale:    [B]{0}[/B]".format(dep_str),
                "  Destino: [B]{0}[/B]".format(headsign or "—"),
                "  En:      [B]{0} min[/B]".format(mins_left),
                "",
                "[COLOR grey]Horario estático (GTFS) — no es tiempo real[/COLOR]",
            ])
            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": icon})
            li.setInfo("video", {"title": "{0} — {1}".format(dep_str, headsign or "—"), "plot": plot})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar horarios ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Recarga el horario (los datos GTFS se actualizan semanalmente)."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="metro_malaga_refresh", stop_id=stop_id, stop_name=stop_name),
        listitem=li_r, isFolder=True,
    )
    xbmcplugin.endOfDirectory(h)


def metro_malaga_refresh(stop_id, stop_name=""):
    try:
        if os.path.isfile(_GTFS_ZIP):
            os.remove(_GTFS_ZIP)
    except OSError:
        pass
    xbmc.executebuiltin("Container.Update({0},replace)".format(
        _u(action="metro_malaga_horario", stop_id=stop_id, stop_name=stop_name)
    ))


def _show_error(h, msg):
    li = xbmcgui.ListItem(label="[COLOR red]{0}[/COLOR]".format(msg))
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)
