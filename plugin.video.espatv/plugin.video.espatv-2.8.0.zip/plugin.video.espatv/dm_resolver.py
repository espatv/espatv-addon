# EspaTV, Copyright (C) 2024-2026 fullstackcurso (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
#
# Resolucion de variantes HLS de Dailymotion usada por default.py.
# Devuelve URL de variante (vod*.cf.dmcdn.net) en vez del master:
# cdndirector.dailymotion.com da 403 con el urllib3 de Kodi 21 (TLS
# fingerprint bloqueado por DM); el urllib3 del Python del sistema si pasa.
#
# Cascada para descargar el master HLS:
#   1. requests directo: puede fallar con urllib3 viejo de Kodi.
#   2. requests.Session con warmup (cookies ts_e/dmvk/__qca).
#   3. subprocess al Python del sistema (solo Windows): TLS moderno.
#   4. urllib.request stdlib como ultimo recurso.

import re
import sys
import urllib.parse
import urllib.request


_UA_DM = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36"
)
HEADERS_DM = {
    "User-Agent": _UA_DM,
    "Origin": "https://www.dailymotion.com",
    "Referer": "https://www.dailymotion.com/",
}

# Script auxiliar para subprocess. Emplea la TLS del sistema para evadir bloqueos en Kodi.
_FETCH_MASTER_SCRIPT = r'''
import sys, urllib.request
url = sys.argv[1]
hdr = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
       "Origin":"https://www.dailymotion.com","Referer":"https://www.dailymotion.com/"}
try:
    import requests
    r = requests.get(url, headers=hdr, timeout=15)
    if r.status_code != 200:
        sys.exit(10 + (r.status_code // 100))
    sys.stdout.buffer.write(r.content)
except ImportError:
    r = urllib.request.urlopen(urllib.request.Request(url, headers=hdr), timeout=15)
    if r.getcode() != 200:
        sys.exit(20)
    sys.stdout.buffer.write(r.read())
'''


def _log(msg, level='info'):
    try:
        import xbmc
        lvl = {'info': xbmc.LOGINFO, 'warning': xbmc.LOGWARNING,
               'error': xbmc.LOGERROR}.get(level, xbmc.LOGINFO)
        xbmc.log(f"[dm_resolver] {msg}", lvl)
    except Exception:
        pass


def _fetch_master_direct(url, timeout=15):
    try:
        import requests
        r = requests.get(url, headers=HEADERS_DM, timeout=timeout)
        if r.status_code == 200 and r.text:
            return r.text
        _log(f"direct status={r.status_code} bytes={len(r.text)}", 'warning')
    except Exception as exc:
        _log(f"direct exception: {exc}", 'warning')
    return None


def _fetch_master_warmup(url, timeout=15):
    try:
        import requests
        s = requests.Session()
        s.get("https://www.dailymotion.com/", headers=HEADERS_DM, timeout=timeout)
        r = s.get(url, headers=HEADERS_DM, timeout=timeout)
        if r.status_code == 200 and r.text:
            _log(f"warmup OK cookies={sorted(s.cookies.keys())}", 'info')
            return r.text
        _log(f"warmup status={r.status_code} bytes={len(r.text)} cookies={sorted(s.cookies.keys())}", 'warning')
    except Exception as exc:
        _log(f"warmup exception: {exc}", 'warning')
    return None


def _fetch_master_subprocess(url, timeout=20):
    if not sys.platform.startswith('win'):
        return None
    try:
        import subprocess
        p = subprocess.run(
            ['python', '-c', _FETCH_MASTER_SCRIPT, url],
            capture_output=True, timeout=timeout,
            creationflags=0x08000000,  # CREATE_NO_WINDOW
        )
        if p.returncode == 0 and p.stdout:
            text = p.stdout.decode('utf-8', errors='replace')
            if text:
                _log(f"subprocess OK bytes={len(text)}", 'info')
                return text
        stderr = (p.stderr or b'').decode('utf-8', errors='replace')[:200]
        _log(f"subprocess rc={p.returncode} stderr={stderr}", 'warning')
    except FileNotFoundError:
        _log("subprocess: python no encontrado en PATH", 'warning')
    except Exception as exc:
        _log(f"subprocess exception: {exc}", 'warning')
    return None


def _fetch_master_urllib(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers=HEADERS_DM)
        resp = urllib.request.urlopen(req, timeout=timeout)
        if resp.getcode() == 200:
            return resp.read().decode('utf-8', errors='replace')
    except Exception as exc:
        _log(f"urllib exception: {exc}", 'warning')
    return None


def _fetch_master(url):
    """Valida y descarga el master HLS."""
    for strategy in (_fetch_master_direct, _fetch_master_warmup,
                     _fetch_master_subprocess, _fetch_master_urllib):
        text = strategy(url)
        if text and '#EXT-X-STREAM-INF' in text:
            return text
    return None


def fetch_hls_variants(master_url, headers=None):
    """Obtiene variantes HLS ordenadas por bitrate (de mayor a menor)."""
    text = _fetch_master(master_url)
    if not text:
        return []

    variants = []
    current_bw = 0
    current_res = ''
    expecting = False
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith('#EXT-X-STREAM-INF'):
            bw_m = re.search(r'BANDWIDTH=(\d+)', line)
            res_m = re.search(r'RESOLUTION=(\d+x\d+)', line)
            current_bw = int(bw_m.group(1)) if bw_m else 0
            current_res = res_m.group(1) if res_m else ''
            expecting = True
        elif expecting and not line.startswith('#'):
            url = line if line.startswith('http') else urllib.parse.urljoin(master_url, line)
            url = url.split('#')[0]
            variants.append({'label': current_res, 'url': url, 'bandwidth': current_bw})
            expecting = False
    variants.sort(key=lambda x: x['bandwidth'], reverse=True)
    return variants
