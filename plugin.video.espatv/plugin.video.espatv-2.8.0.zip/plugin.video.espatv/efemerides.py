# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Efemerides españolas del dia desde Wikipedia (rest_v1/feed/onthisday)."""
import datetime
import json
import os
import sys
import urllib.parse

import requests
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_API_TPL = "https://es.wikipedia.org/api/rest_v1/feed/onthisday/{type}/{mm:02d}/{dd:02d}"
_HEADERS = {'User-Agent': 'EspaTV/1.0', 'Accept': 'application/json'}
_HTTP_TIMEOUT = 15

_PROFILE = xbmcvfs.translatePath(
    xbmcaddon.Addon("plugin.video.espatv").getAddonInfo('profile')
)
_CACHE_FILE = os.path.join(_PROFILE, 'efemerides_cache.json')

_SHORT_TEXT_MAX = 90
_PAGES_PER_PLOT = 3

_KEYWORDS_ES = (
    'españa', 'español', 'española', 'españoles', 'españolas',
    'madrid', 'barcelona', 'sevilla', 'valencia', 'bilbao', 'galicia',
    'cataluña', 'andalucía', 'castilla', 'asturias', 'aragón', 'navarra',
    'extremadura', 'baleares', 'canarias', 'murcia', 'cantabria', 'rioja',
    'país vasco', 'valenciana', 'león', 'mancha', 'ceuta', 'melilla',
    'rey de españa', 'reina de españa', 'borbón', 'casa de austria',
    'cortes españolas', 'congreso de los diputados', 'gobierno de españa',
    'real academia', 'cervantes', 'lorca', 'goya', 'velázquez', 'picasso',
    'dalí', 'unamuno', 'machado', 'galdós', 'pardo bazán',
    'al-ándalus', 'reconquista', 'hispania', 'inquisición española',
    'armada española', 'guerra civil española',
    'transición española', 'constitución española',
    'felipe vi', 'felipe v', 'isabel ii', 'fernando vii',
    'alfonso xiii', 'juan carlos i', 'francisco franco',
)


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _today_key():
    return datetime.date.today().strftime("%Y-%m-%d")


def _load_cache(date_key):
    try:
        with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
            obj = json.load(f)
    except (OSError, ValueError):
        return None
    if obj.get('date') != date_key:
        return None
    return obj.get('data')


def _save_cache(date_key, data):
    try:
        if not os.path.isdir(_PROFILE):
            os.makedirs(_PROFILE, exist_ok=True)
        with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump({'date': date_key, 'data': data}, f, ensure_ascii=False)
    except OSError:
        pass


def _fetch_section(stype, mm, dd):
    url = _API_TPL.format(type=stype, mm=mm, dd=dd)
    try:
        r = requests.get(url, headers=_HEADERS, timeout=_HTTP_TIMEOUT)
        if r.status_code != 200:
            return []
        payload = r.json()
    except (requests.RequestException, ValueError):
        return []
    return payload.get(stype) or []


def _fetch_today():
    date_key = _today_key()
    cached = _load_cache(date_key)
    if cached is not None:
        return cached
    today = datetime.date.today()
    data = {
        'events': _fetch_section('events', today.month, today.day),
        'births': _fetch_section('births', today.month, today.day),
        'deaths': _fetch_section('deaths', today.month, today.day),
    }
    _save_cache(date_key, data)
    return data


def _is_relevant(item):
    text = (item.get('text') or '').lower()
    if any(kw in text for kw in _KEYWORDS_ES):
        return True
    for page in item.get('pages') or []:
        extract = (page.get('extract') or page.get('description') or '').lower()
        if any(kw in extract for kw in _KEYWORDS_ES):
            return True
    return False


def _filter_relevant(items):
    return [it for it in items if _is_relevant(it)]


def _short_text(text, max_len=_SHORT_TEXT_MAX):
    if not text:
        return ""
    text = text.strip()
    if len(text) <= max_len:
        return text
    truncated = text[:max_len].rsplit(' ', 1)[0]
    return truncated + "..."


def _build_plot(item):
    parts = [item.get('text') or '']
    for page in (item.get('pages') or [])[:_PAGES_PER_PLOT]:
        title = page.get('normalizedtitle') or page.get('title') or ''
        extract = page.get('extract') or ''
        if title and extract:
            parts.append("[B]{0}[/B]\n{1}".format(title, extract))
    return "\n\n".join(p for p in parts if p)


def _add_separator(handle, label):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultIconInfo.png'})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=handle, url=_u(action="noop"), listitem=li, isFolder=False,
    )


def _add_section(handle, items, color, prefix=""):
    for item in items:
        year = item.get('year', '')
        text = item.get('text') or ''
        label = "[COLOR {0}][B]{1}[/B][/COLOR]  {2}{3}".format(
            color, year, prefix, _short_text(text),
        )
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'plot': _build_plot(item)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=handle, url=_u(action="noop"), listitem=li, isFolder=False,
        )


_SECTIONS = (
    ('events', 'Acontecimientos', 'lightblue', ''),
    ('births', 'Nacimientos',     'lightgreen', '[I]Nace[/I]: '),
    ('deaths', 'Fallecimientos',  'lightcoral', '[I]Muere[/I]: '),
)


def efemerides_menu():
    handle = int(sys.argv[1])
    today = datetime.date.today()
    data = _fetch_today()

    relevant = {key: _filter_relevant(data.get(key, [])) for key, _, _, _ in _SECTIONS}
    total = sum(len(v) for v in relevant.values())

    header_label = "[B][COLOR royalblue]Un día como hoy ({0}) en la Historia de España[/COLOR][/B]".format(
        today.strftime("%d/%m"),
    )
    header_plot = "{0} eventos · {1} nacimientos · {2} fallecimientos relevantes para España.".format(
        len(relevant['events']),
        len(relevant['births']),
        len(relevant['deaths']),
    )
    li_h = xbmcgui.ListItem(label=header_label)
    li_h.setArt({'icon': 'DefaultIconInfo.png'})
    li_h.setProperty("IsPlayable", "false")
    li_h.setInfo('video', {'plot': header_plot})
    xbmcplugin.addDirectoryItem(
        handle=handle, url=_u(action="noop"), listitem=li_h, isFolder=False,
    )

    if total == 0:
        _add_separator(handle, "[COLOR gray][I]Sin efemérides relevantes para España hoy[/I][/COLOR]")
        xbmcplugin.endOfDirectory(handle)
        return

    for key, title, color, prefix in _SECTIONS:
        items = relevant[key]
        if not items:
            continue
        _add_separator(handle, "[B][COLOR khaki]── {0} ──[/COLOR][/B]".format(title))
        _add_section(handle, items, color, prefix)

    xbmcplugin.endOfDirectory(handle)
