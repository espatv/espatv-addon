# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Calidad del Aire: 12 ciudades espanolas via WAQI (World Air Quality Index)."""
import json
import math
import os
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG     = "[EspaTV-AIR]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_FILE    = os.path.join(_PROFILE, "aire_cache.json")
_CACHE_TTL     = 3600
_CACHE_VERSION = 3
_TIMEOUT    = 20
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_TOKEN      = "3ce5f00ddd1b8e7a4d0d6d916c54cddf3db748e0"
_URL_FEED   = "https://api.waqi.info/feed/{q}/?token=" + _TOKEN
_URL_SEARCH = "https://api.waqi.info/search/?token=" + _TOKEN + "&keyword={kw}"

_RADIO_KM = 50

_CIUDADES = [
    ("madrid",     "Madrid",            "deepskyblue",    40.4168,  -3.7038),
    ("barcelona",  "Barcelona",         "tomato",         41.3851,   2.1734),
    ("valencia",   "Valencia",          "gold",           39.4699,  -0.3763),
    ("sevilla",    "Sevilla",           "orange",         37.3891,  -5.9845),
    ("zaragoza",   "Zaragoza",          "khaki",          41.6488,  -0.8891),
    ("malaga",     "Malaga",            "plum",           36.7213,  -4.4214),
    ("bilbao",     "Bilbao",            "lightgreen",     43.2630,  -2.9350),
    ("palma",      "Palma de Mallorca", "lightblue",      39.5696,   2.6502),
    ("las-palmas", "Las Palmas",        "lightcyan",      28.1248, -15.4300),
    ("vigo",       "Vigo",              "mediumseagreen", 42.2406,  -8.7207),
    ("murcia",     "Murcia",            "lightsalmon",    37.9922,  -1.1307),
    ("granada",    "Granada",           "lightyellow",    37.1773,  -3.5986),
]

_ICA_NIVELES = [
    (50,  "lightgreen", "Buena",      "Calidad del aire satisfactoria, sin riesgo."),
    (100, "gold",       "Moderada",   "Aceptable, pero puede afectar a personas sensibles."),
    (150, "orange",     "Deficiente", "Grupos sensibles pueden experimentar efectos."),
    (200, "tomato",     "Mala",       "Toda la poblacion puede experimentar efectos."),
    (300, "red",        "Muy mala",   "Riesgo para la salud. Evitar actividad al aire libre."),
    (999, "darkred",    "Peligrosa",  "Emergencia sanitaria. No salir al exterior."),
]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _nivel_color(aqi):
    for threshold, color, nombre, recom in _ICA_NIVELES:
        if aqi <= threshold:
            return color, nombre, recom
    return "darkred", "Peligrosa", "Emergencia sanitaria."


def _safe_label(s):
    if not isinstance(s, str):
        s = str(s)
    return s.replace("[", "(").replace("]", ")")


def _safe_v(container, key):
    if not isinstance(container, dict):
        return None
    sub = container.get(key)
    if not isinstance(sub, dict):
        return None
    return sub.get("v")


def _ensure_profile():
    if not xbmcvfs.exists(_PROFILE):
        xbmcvfs.mkdirs(_PROFILE)


def _haversine_km(lat1, lon1, lat2, lon2):
    r = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2) ** 2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) ** 2
    return 2 * r * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def _ciudad_info(ciudad_id):
    for cid, label, color, lat, lon in _CIUDADES:
        if cid == ciudad_id:
            return label, color, lat, lon
    return ciudad_id, "white", 0.0, 0.0


def _empty_cache():
    return {"version": _CACHE_VERSION, "search": {}, "feed": {}}


def _load_cache():
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if not isinstance(obj, dict) or obj.get("version") != _CACHE_VERSION:
            return _empty_cache()
        if not isinstance(obj.get("search"), dict):
            obj["search"] = {}
        if not isinstance(obj.get("feed"), dict):
            obj["feed"] = {}
        return obj
    except (OSError, ValueError):
        return _empty_cache()


def _save_cache(obj):
    _ensure_profile()
    try:
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except OSError as e:
        xbmc.log("{0} Error cache: {1}".format(_LOG, e), xbmc.LOGWARNING)


def _cache_get(section, key):
    obj = _load_cache()
    entry = obj.get(section, {}).get(key)
    if not isinstance(entry, dict):
        return None
    try:
        if time.time() - float(entry.get("ts", 0)) < _CACHE_TTL:
            return entry.get("data")
    except (TypeError, ValueError):
        return None
    return None


def _cache_set(section, key, data):
    obj = _load_cache()
    obj.setdefault(section, {})[key] = {"ts": time.time(), "data": data}
    _save_cache(obj)


def _cache_clear(section, key):
    obj = _load_cache()
    obj.get(section, {}).pop(key, None)
    _save_cache(obj)


def _http_get(url):
    headers = {"User-Agent": "EspaTV/1.0 (Kodi addon; calidad aire)"}
    resp = requests.get(url, headers=headers, timeout=_TIMEOUT)
    resp.raise_for_status()
    return resp.json()


def _fetch_search(ciudad_id, ciudad_label, lat_ref, lon_ref):
    estaciones = []
    seen = set()
    # Dos keywords porque "las-palmas" y "Las Palmas" pueden dar resultados distintos en WAQI.
    keywords = []
    for kw in (ciudad_id, ciudad_label):
        if kw and kw not in keywords:
            keywords.append(kw)
    for kw in keywords:
        url = _URL_SEARCH.format(kw=urllib.parse.quote(kw))
        try:
            data = _http_get(url)
        except Exception as e:
            xbmc.log("{0} Search error '{1}': {2}".format(_LOG, kw, e), xbmc.LOGWARNING)
            continue
        if not isinstance(data, dict) or data.get("status") != "ok":
            continue
        items = data.get("data")
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            uid = item.get("uid")
            if uid is None or uid == "":
                continue
            if uid in seen:
                continue
            station = item.get("station") if isinstance(item.get("station"), dict) else {}
            geo = station.get("geo")
            if not isinstance(geo, (list, tuple)) or len(geo) < 2:
                continue
            try:
                slat, slon = float(geo[0]), float(geo[1])
            except (TypeError, ValueError):
                continue
            if not (-90 <= slat <= 90) or not (-180 <= slon <= 180):
                continue
            dist = _haversine_km(lat_ref, lon_ref, slat, slon)
            if dist > _RADIO_KM:
                continue
            seen.add(uid)
            estaciones.append({
                "uid":  uid,
                "name": station.get("name") or "Estacion {0}".format(uid),
                "aqi":  item.get("aqi"),
                "geo":  [slat, slon],
                "dist": round(dist, 1),
            })
    estaciones.sort(key=lambda x: x["dist"])
    return estaciones


def _fetch_feed(query):
    url = _URL_FEED.format(q=urllib.parse.quote(query))
    data = _http_get(url)
    if not isinstance(data, dict) or data.get("status") != "ok":
        return None
    d = data.get("data")
    if not isinstance(d, dict):
        return None
    iaqi = d.get("iaqi") if isinstance(d.get("iaqi"), dict) else {}
    city = d.get("city") if isinstance(d.get("city"), dict) else {}
    tinfo = d.get("time") if isinstance(d.get("time"), dict) else {}
    return {
        "city":   city.get("name") or query,
        "aqi":    d.get("aqi"),
        "time":   tinfo.get("s") or "",
        "PM2.5":  _safe_v(iaqi, "pm25"),
        "PM10":   _safe_v(iaqi, "pm10"),
        "NO2":    _safe_v(iaqi, "no2"),
        "O3":     _safe_v(iaqi, "o3"),
        "SO2":    _safe_v(iaqi, "so2"),
        "CO":     _safe_v(iaqi, "co"),
    }


def aire_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_aire.png")
    for ciudad_id, label, color, _lat, _lon in _CIUDADES:
        li = xbmcgui.ListItem(label="[B][COLOR {0}]Calidad del Aire — {1}[/COLOR][/B]".format(color, label))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Estaciones de medicion en tiempo real en {0}.".format(label)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="aire_ciudad", ciudad=ciudad_id), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def aire_ciudad(ciudad):
    h = int(sys.argv[1])
    label, color, lat, lon = _ciudad_info(ciudad)
    icon = _icon("cat_aire.png")

    estaciones = _cache_get("search", ciudad)
    if estaciones is None:
        try:
            xbmcgui.Dialog().notification("Calidad del Aire", "Buscando estaciones en {0}…".format(label), xbmcgui.NOTIFICATION_INFO, 1500)
            estaciones = _fetch_search(ciudad, label, lat, lon)
            _cache_set("search", ciudad, estaciones)
        except Exception as e:
            xbmc.log("{0} Error busqueda {1}: {2}".format(_LOG, ciudad, e), xbmc.LOGERROR)
            estaciones = []

    if not estaciones:
        li = xbmcgui.ListItem(label="[COLOR red]Sin estaciones disponibles — comprueba la red[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)
    else:
        for est in estaciones:
            try:
                aqi_val = int(est.get("aqi") or 0)
            except (ValueError, TypeError):
                aqi_val = 0
            ecolor, nivel, _ = _nivel_color(aqi_val) if aqi_val > 0 else ("white", "Sin datos", "")
            aqi_txt = str(aqi_val) if aqi_val > 0 else "—"
            est_name_safe = _safe_label(est["name"])
            etiqueta = "[B][COLOR {0}]AQI {1}[/COLOR][/B] — {2} [COLOR grey]({3} km)[/COLOR]".format(
                ecolor, aqi_txt, est_name_safe, est["dist"]
            )
            li = xbmcgui.ListItem(label=etiqueta)
            li.setArt({"icon": icon})
            li.setInfo("video", {"plot": "{0}\nNivel: {1}\nDistancia al centro de {2}: {3} km".format(
                est_name_safe, nivel, label, est["dist"]
            )})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="aire_estacion", uid=str(est["uid"]), nombre=est["name"], ciudad=ciudad),
                listitem=li,
                isFolder=True,
            )

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar lista de estaciones ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Recarga la lista de estaciones de {0}.".format(label)})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="aire_refresh", ciudad=ciudad), listitem=li_r, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def aire_estacion(uid, nombre, ciudad):
    h = int(sys.argv[1])
    icon = _icon("cat_aire.png")
    if not uid:
        li = xbmcgui.ListItem(label="[COLOR red]Estacion no especificada[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    cache_key = str(uid)

    data = _cache_get("feed", cache_key)
    if data is None:
        try:
            xbmcgui.Dialog().notification("Calidad del Aire", "Consultando {0}…".format(nombre), xbmcgui.NOTIFICATION_INFO, 1500)
            data = _fetch_feed("@" + str(uid))
            if data is not None:
                _cache_set("feed", cache_key, data)
        except Exception as e:
            xbmc.log("{0} Error feed @{1}: {2}".format(_LOG, uid, e), xbmc.LOGERROR)
            data = None

    if not data:
        li = xbmcgui.ListItem(label="[COLOR red]Error al obtener datos de la estacion[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    try:
        aqi_int = int(data.get("aqi") or 0)
    except (ValueError, TypeError):
        aqi_int = 0
    color, nivel_nombre, recom = _nivel_color(aqi_int)
    estacion_name = _safe_label(data.get("city") or nombre)

    li_resumen = xbmcgui.ListItem(
        label="[B][COLOR {0}]{1} — AQI {2} ({3})[/COLOR][/B]".format(color, estacion_name, aqi_int, nivel_nombre)
    )
    li_resumen.setArt({"icon": icon})
    plot_lines = [
        "Estacion: {0}".format(estacion_name),
        "Indice AQI: {0}".format(aqi_int),
        "Nivel: {0}".format(nivel_nombre),
    ]
    if data.get("time"):
        plot_lines.append("Medicion: {0}".format(data["time"]))
    plot_lines.append("")
    for mag in ("PM2.5", "PM10", "NO2", "O3", "SO2", "CO"):
        v = data.get(mag)
        if v is not None:
            try:
                plot_lines.append("{0}: {1:.1f}".format(mag, float(v)))
            except (ValueError, TypeError):
                pass
    plot_lines.append("\n{0}".format(recom))
    li_resumen.setInfo("video", {"title": estacion_name, "plot": "\n".join(plot_lines)})
    li_resumen.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li_resumen, isFolder=False)

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar estacion ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Recarga datos de {0}.".format(estacion_name)})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="aire_estacion_refresh", uid=str(uid), nombre=nombre, ciudad=ciudad),
        listitem=li_r,
        isFolder=True,
    )
    xbmcplugin.endOfDirectory(h)


def aire_refresh(ciudad):
    obj = _load_cache()
    estaciones = (obj.get("search", {}).get(ciudad) or {}).get("data") or []
    feeds = obj.get("feed", {})
    for est in estaciones:
        if isinstance(est, dict):
            feeds.pop(str(est.get("uid")), None)
    obj.get("search", {}).pop(ciudad, None)
    _save_cache(obj)
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="aire_ciudad", ciudad=ciudad)))


def aire_estacion_refresh(uid, nombre, ciudad):
    _cache_clear("feed", str(uid))
    xbmc.executebuiltin("Container.Update({0},replace)".format(
        _u(action="aire_estacion", uid=str(uid), nombre=nombre, ciudad=ciudad)
    ))
