# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""TV autonómicas españolas en directo: streams HLS via lista pública IPTV."""
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

import xbmc
from _user_agents import UA_DESKTOP, ua_desktop_pipe_encoded
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG_TAG = "[EspaTV-TVAuto]"
_ADDON = xbmcaddon.Addon()
_PROFILE_DIR = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
_CACHE_TTL = 12 * 3600

_M3U_URL = "https://iptv-org.github.io/iptv/countries/es.m3u"
_HEADERS = {
    "User-Agent": UA_DESKTOP,
    "Accept": "*/*",
}

_APUNT_ACCOUNT = "6057955885001"
_APUNT_VIDEO   = "6137605659001"
_APUNT_POLICY  = (
    "BCpkADawqM2Yrv2qlBGpB2FCRjQ97X2SDg4r2xbdzl5jKZbkiKrGFaQ2mCXaaNZWyEy"
    "QPtX4LR7OCKmYpat8jXceN9PP_qZMOMQSbNqeDf5kln0xC0-cI2KoRkf8ab1FLRVNVCORQA9ME8vg"
)
_APUNT_LOGO = (
    "https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/"
    "Logotip_d%27%C3%80_Punt_%282017-%29.svg/960px-Logotip_d%27%C3%80_Punt_%282017-%29.svg.png"
)

_AUTONOMICAS_IDS = {
    "TV3.es", "C33.es", "SX3.es", "3Cat.es",
    "APunt.es", "APuntMediterrania.es", "Apunt.es", "apunt.es",
    "ETB1.es", "ETB2.es", "ETB3.es",
    "TVG.es", "TVG2.es",
    "CanalSur.es", "CanalSur2.es",
    "AragonTV.es", "AragonTV2.es",
    "TPA.es",
    "TVCanaria.es", "TVCanaria2.es",
    "IB3.es",
    "RTCLM1.es", "RTCLM2.es",
    "CyLTV.es", "CyLTV2.es",
    "ExtremaduraTV.es",
    "7RM.es",
    "TVRioja.es",
    "OkEuskadi.es",
}

_AUTONOMICAS_KW = [
    "tv3", "canal 33", "sx3", "3cat",
    "à punt", "a punt",
    "etb 1", "etb 2", "etb1", "etb2", "etb 3",
    "tvg", "televisión de galicia", "crtvg",
    "canal sur",
    "aragón tv", "aragon tv",
    "tpa",
    "tv canaria", "tvcanaria",
    "ib3",
    "clm televisión", "rtclm", "castilla-la mancha media",
    "cyl tv", "rtvcyl", "televisión castilla",
    "extremadura tv",
    "7 región de murcia", "7rm",
    "tv rioja",
]

_COMUNIDAD_ORDER = [
    "andalucía", "aragón", "asturias", "baleares", "canarias",
    "cantabria", "castilla-la mancha", "castilla y león", "cataluña",
    "extremadura", "galicia", "madrid", "murcia", "navarra",
    "la rioja", "país vasco", "comunidad valenciana",
]

_HLS_HEADERS = (
    "User-Agent={0}"
    "&Referer=https%3A%2F%2Fplayers.brightcove.net%2F"
    "&Origin=https%3A%2F%2Fplayers.brightcove.net"
).format(ua_desktop_pipe_encoded())


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), level)


def _resolve_apunt():
    """Obtiene la URL HLS de À Punt via Brightcove Playback API."""
    api_url = (
        "https://edge.api.brightcove.com/playback/v1"
        "/accounts/{0}/videos/{1}".format(_APUNT_ACCOUNT, _APUNT_VIDEO)
    )
    try:
        req = urllib.request.Request(api_url, headers={
            "BCOV-Policy": _APUNT_POLICY,
            "Accept": "application/json",
        })
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        for src in data.get("sources", []):
            src_url = src.get("src", "")
            if ".m3u8" in src_url:
                return src_url
    except Exception as exc:
        _log("Error resolviendo À Punt: {0}".format(exc), xbmc.LOGWARNING)
    return ""


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _cache_path():
    return os.path.join(_PROFILE_DIR, "tv_autonomicas.json")


def _load_cache():
    path = _cache_path()
    if not os.path.exists(path):
        return None
    if (time.time() - os.path.getmtime(path)) >= _CACHE_TTL:
        return None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        try:
            os.remove(path)
        except OSError:
            pass
        return None


def _save_cache(channels):
    try:
        os.makedirs(_PROFILE_DIR, exist_ok=True)
        tmp = _cache_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(channels, fh, ensure_ascii=False)
        os.replace(tmp, _cache_path())
    except OSError:
        pass


def _parse_m3u(text):
    """Parsea texto M3U y devuelve lista de dicts {name, url, tvg_id, logo, group}."""
    channels = []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith("#EXTINF"):
            tvg_id = ""
            logo = ""
            group = ""
            name = ""

            m = re.search(r'tvg-id="([^"]*)"', line)
            if m:
                tvg_id = m.group(1).strip()
            m = re.search(r'tvg-logo="([^"]*)"', line)
            if m:
                logo = m.group(1).strip()
            m = re.search(r'group-title="([^"]*)"', line)
            if m:
                group = m.group(1).strip()
            m = re.search(r'tvg-name="([^"]*)"', line)
            if m:
                name = m.group(1).strip()
            if not name:
                comma = line.rfind(",")
                if comma != -1:
                    name = line[comma + 1:].strip()

            i += 1
            while i < len(lines) and (not lines[i].strip() or lines[i].strip().startswith("#")):
                i += 1
            if i < len(lines):
                url = lines[i].strip()
                if url and not url.startswith("#"):
                    channels.append({
                        "name": name,
                        "url": url,
                        "tvg_id": tvg_id,
                        "logo": logo,
                        "group": group,
                    })
        i += 1
    return channels


def _is_autonomica(ch):
    """True si el canal es una TV autonómica española."""
    tvg_id = ch.get("tvg_id", "")
    # iptv-org añade sufijos de calidad: "APunt.es@SD", "TV3.es@HD", etc.
    tvg_id_base = tvg_id.split("@")[0] if "@" in tvg_id else tvg_id
    if tvg_id_base in _AUTONOMICAS_IDS or tvg_id in _AUTONOMICAS_IDS:
        return True
    name_lower = ch.get("name", "").lower()
    for kw in _AUTONOMICAS_KW:
        if kw in name_lower:
            return True
    return False


def _fetch_channels():
    """Descarga la lista M3U, la filtra y cachea. Devuelve lista o None."""
    cached = _load_cache()
    if cached is not None:
        return cached

    try:
        req = urllib.request.Request(_M3U_URL, headers=_HEADERS)
        with urllib.request.urlopen(req, timeout=20) as resp:
            text = resp.read().decode("utf-8", errors="replace")
    except Exception as exc:
        _log("Error descargando M3U: {0}".format(exc), xbmc.LOGERROR)
        return None

    all_channels = _parse_m3u(text)
    autonomicas = [ch for ch in all_channels if _is_autonomica(ch)]

    # Deduplicar por nombre (a veces aparece el mismo canal en SD y HD)
    seen_names = set()
    unique = []
    for ch in autonomicas:
        key = ch["name"].lower().strip()
        if key not in seen_names:
            seen_names.add(key)
            unique.append(ch)

    # Resolver À Punt directamente desde Brightcove (iptv-org usa CDN obsoleto)
    apunt_url = _resolve_apunt()
    if apunt_url:
        apunt_idx = next(
            (i for i, c in enumerate(unique)
             if c.get("tvg_id", "").split("@")[0] == "APunt.es"
             or "punt" in c.get("name", "").lower()),
            None,
        )
        if apunt_idx is not None:
            unique[apunt_idx]["url"] = apunt_url
            unique[apunt_idx]["logo"] = unique[apunt_idx]["logo"] or _APUNT_LOGO
        else:
            unique.insert(0, {
                "name": "A Punt",
                "url": apunt_url,
                "tvg_id": "APunt.es",
                "logo": _APUNT_LOGO,
                "group": "General",
            })

    _log("Autonómicas encontradas: {0}/{1}".format(len(unique), len(all_channels)))
    _save_cache(unique)
    return unique


def tv_autonomicas_menu():
    h = int(sys.argv[1])

    xbmcgui.Dialog().notification(
        "EspaTV", "Cargando canales autonómicos…",
        xbmcgui.NOTIFICATION_INFO, 1200,
    )

    channels = _fetch_channels()

    if channels is None:
        li = xbmcgui.ListItem(label="[COLOR red]Sin conexión — comprueba la red[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    if not channels:
        li = xbmcgui.ListItem(
            label="[COLOR gray]No se encontraron canales autonómicos en la lista[/COLOR]"
        )
        li.setProperty("IsPlayable", "false")
        li.setInfo("video", {"plot": "La lista pública no contiene canales autonómicos en este momento.\nPrueba a actualizar."})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    else:
        for ch in channels:
            name = ch["name"]
            url = ch["url"]
            logo = ch.get("logo", "")

            play_url = "{0}|{1}".format(url, _HLS_HEADERS)

            li = xbmcgui.ListItem(label="[B]{0}[/B]".format(name))
            art = {"icon": "DefaultAddonPVRClient.png"}
            if logo:
                art["thumb"] = logo
                art["icon"] = logo
            li.setArt(art)
            li.setInfo("video", {
                "title": name,
                "plot": "{0}\nSeñal en directo.".format(name),
            })
            li.setProperty("IsPlayable", "true")
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setContentLookup(False)
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="play_webcam", stream_url=play_url, title=name),
                listitem=li,
                isFolder=False,
            )

    # Botón actualizar
    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar canales ][/COLOR]")
    li_r.setArt({"icon": "DefaultAddonService.png"})
    li_r.setInfo("video", {"plot": "Elimina la caché y descarga la lista actualizada de canales."})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="tv_autonomicas_refresh"),
        listitem=li_r,
        isFolder=True,
    )

    xbmcplugin.endOfDirectory(h)


def tv_autonomicas_refresh():
    path = _cache_path()
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass
    xbmcgui.Dialog().notification(
        "EspaTV", "Caché eliminada — recargando canales…",
        xbmcgui.NOTIFICATION_INFO, 1500,
    )
    xbmc.executebuiltin("Container.Update({0})".format(_u(action="tv_autonomicas_menu")))
