# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import os
import zipfile
import json as _json

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


_ESPATV_REPO_ID = "repository.espatv"
_ESPATV_REPO_API_URL = "https://api.github.com/repos/fullstackcurso/espatv/contents/"
_ESPATV_REPO_FALLBACK_ZIP = "https://fullstackcurso.github.io/espatv/repository.espatv-1.0.0.zip"

_SLYGUY_REPO_ID = "repository.slyguy"
_SLYGUY_REPO_ZIP = "https://k.slyguy.xyz/repository.slyguy.zip"

_LOIOLINK_ADDON_ID = "plugin.program.loiolink"
_LOIOLINK_REPO_ID  = "repository.loiolink"
_LOIOLINK_REPO_ZIP = "https://loiolo.io/repository.loiolink-1.0.0.zip"
_LOIOLINK_SOURCE   = "https://loiolo.io/"

_USER_AGENT = "EspaTV/1.0 (Kodi addon installer)"


def _err(msg):
    try:
        from default import _log_error
        _log_error(msg)
    except ImportError:
        xbmc.log("[EspaTV ERROR] {0}".format(msg), xbmc.LOGERROR)


def _http_get(url, timeout=30, retries=2):
    headers = {"User-Agent": _USER_AGENT}
    last_exc = None
    for attempt in range(retries + 1):
        try:
            try:
                import requests as _req
                r = _req.get(url, timeout=timeout, allow_redirects=True, headers=headers)
                return r.status_code, r.content
            except ImportError:
                import urllib.request
                import urllib.error
                req = urllib.request.Request(url, headers=headers)
                try:
                    with urllib.request.urlopen(req, timeout=timeout) as resp:
                        return resp.status, resp.read()
                except urllib.error.HTTPError as e:
                    body = b""
                    try:
                        body = e.read()
                    except Exception:
                        pass
                    return e.code, body
        except Exception as e:
            last_exc = e
            if attempt < retries:
                xbmc.sleep(1500)
    raise last_exc


def _enable_repo_addon(repo_id):
    payload = _json.dumps({"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled",
                           "params": {"addonid": repo_id, "enabled": True}, "id": 1})
    for _ in range(5):
        response = xbmc.executeJSONRPC(payload)
        if '"error"' not in response:
            return
        xbmc.sleep(1000)


def _extract_zip_safe(zip_path, addons_dir):
    with zipfile.ZipFile(zip_path, "r") as zf:
        for entry in zf.namelist():
            resolved = os.path.realpath(os.path.join(addons_dir, entry))
            if not resolved.startswith(os.path.realpath(addons_dir)):
                raise RuntimeError("ZIP contiene ruta sospechosa: {0}".format(entry))
        zf.extractall(addons_dir)


def _install_espatv_repo():
    if xbmc.getCondVisibility("System.HasAddon({0})".format(_ESPATV_REPO_ID)):
        xbmcgui.Dialog().ok("EspaTV", "El repositorio ya está instalado.\nLas actualizaciones automáticas están activas.")
        return

    texto = (
        "Has instalado EspaTV manualmente desde un archivo ZIP.\n\n"
        "Sin el [B]Repositorio Oficial[/B], Kodi no puede comprobar "
        "si hay versiones nuevas del addon. Esto significa que:\n\n"
        "- No recibirás correcciones cuando un canal deje de funcionar\n"
        "- No recibirás funciones nuevas\n"
        "- Tendrías que reinstalar manualmente cada vez\n\n"
        "¿Quieres que EspaTV descargue e instale su repositorio ahora?"
    )
    if not xbmcgui.Dialog().yesno("Actualizaciones Automáticas", texto):
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Descargando repositorio oficial...")
    zip_path = None
    cancelled = False
    success = False
    try:
        # preferimos la API: devuelve el asset más reciente aunque cambie la URL
        zip_url = None
        try:
            dp.update(5, "Buscando última versión del repositorio...")
            if dp.iscanceled():
                cancelled = True
                return
            status, content = _http_get(_ESPATV_REPO_API_URL, timeout=15)
            if status == 200:
                for item in _json.loads(content):
                    name = item.get("name", "")
                    if name.startswith("repository.espatv") and name.endswith(".zip"):
                        zip_url = item.get("download_url")
                        break
        except Exception as e:
            xbmc.log("[EspaTV] API GitHub falló, usando fallback: {0}".format(e), xbmc.LOGWARNING)

        # fallback si la API falla o no hay release
        if not zip_url:
            zip_url = _ESPATV_REPO_FALLBACK_ZIP

        if dp.iscanceled():
            cancelled = True
            return

        dp.update(15, "Descargando desde GitHub...")
        status, content = _http_get(zip_url, timeout=30)
        if status != 200:
            raise RuntimeError("Error HTTP {0}".format(status))
        if len(content) < 4 or content[:2] != b'PK':
            raise RuntimeError("El archivo descargado no es un ZIP válido")
        if len(content) > 50 * 1024 * 1024:
            raise RuntimeError("Tamaño sospechoso: {0}KB".format(len(content) // 1024))

        if dp.iscanceled():
            cancelled = True
            return

        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "repository.espatv.zip")
        with open(zip_path, "wb") as f:
            f.write(content)

        dp.update(50, "Extrayendo repositorio...")
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        _extract_zip_safe(zip_path, addons_dir)

        if dp.iscanceled():
            cancelled = True
            return

        dp.update(80, "Activando repositorio...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(1500)
        xbmc.executebuiltin("InstallAddon({0})".format(_ESPATV_REPO_ID))
        xbmc.sleep(500)
        _enable_repo_addon(_ESPATV_REPO_ID)
        dp.update(100)
        success = True
    except Exception as e:
        _err("Error instalando repo EspaTV: {0}".format(e))
        try:
            dp.close()
        except Exception:
            pass
        choice = xbmcgui.Dialog().yesno("Error de instalación",
            "No se pudo instalar automáticamente.\n\n"
            "Error: {0}\n\n"
            "Puede que necesites activar 'Orígenes desconocidos' "
            "en Ajustes → Sistema → Addons.\n\n"
            "¿Abrir Ajustes del Sistema?".format(e))
        if choice:
            xbmc.executebuiltin("ActivateWindow(systemsettings)")
        return
    finally:
        try:
            dp.close()
        except Exception:
            pass
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except OSError:
                pass

    if cancelled:
        xbmcgui.Dialog().notification("EspaTV", "Instalación cancelada", xbmcgui.NOTIFICATION_INFO, 3000)
        return
    if success:
        xbmcgui.Dialog().ok("EspaTV",
            "El repositorio se ha instalado.\n\n"
            "Comprueba en [B]Add-ons → Instalar desde repositorio[/B] "
            "que aparece [B]EspaTV Repository[/B] para confirmar "
            "que tendrás actualizaciones automáticas.")
        xbmc.executebuiltin("Container.Refresh")


def _auto_install_slyguy_repo(addon_id, addon_name):
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Descargando repositorio SlyGuy...")
    zip_path = None
    try:
        dp.update(10, "Descargando repositorio...")
        status, content = _http_get(_SLYGUY_REPO_ZIP, timeout=30)
        if status != 200:
            raise RuntimeError("Error HTTP {0}".format(status))
        if len(content) < 4 or content[:2] != b'PK':
            raise RuntimeError("El archivo descargado no es un ZIP válido")
        if len(content) > 50 * 1024 * 1024:
            raise RuntimeError("Tamaño sospechoso: {0}KB".format(len(content) // 1024))
        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "repository.slyguy.zip")
        with open(zip_path, "wb") as f:
            f.write(content)
        dp.update(50, "Extrayendo repositorio...")
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        _extract_zip_safe(zip_path, addons_dir)
        dp.update(80, "Actualizando addons locales...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(2000)
        xbmc.executebuiltin("EnableAddon({0})".format(_SLYGUY_REPO_ID))
        xbmc.sleep(1000)
        dp.update(90, "Instalando {0}...".format(addon_name))
        xbmc.executebuiltin("InstallAddon({0})".format(addon_id))
        dp.close()
        xbmcgui.Dialog().notification(
            "EspaTV",
            "Repo SlyGuy instalado. Instalando {0}...".format(addon_name),
            xbmcgui.NOTIFICATION_INFO, 5000)
    except (OSError, zipfile.BadZipFile, RuntimeError) as e:
        dp.close()
        _err("Error instalando repo SlyGuy: {0}".format(e))
        choice = xbmcgui.Dialog().yesno(
            "Error de instalación",
            "No se pudo instalar automáticamente.\n\nError: {0}\n\n"
            "Puede que necesites activar 'Orígenes desconocidos' en Ajustes.\n"
            "¿Abrir Ajustes del Sistema?".format(e))
        if choice:
            xbmc.executebuiltin("ActivateWindow(systemsettings)")
    finally:
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except OSError:
                pass


def _flowfav_install():
    _FLOWFAV_API_URL = "https://api.github.com/repos/loioloio/flowfav/releases/latest"
    _FLOWFAV_ADDON_ID = "plugin.program.flowfavmanager"

    sel = xbmcgui.Dialog().select("Flow FavManager", [
        "Instalar automáticamente",
        "Ver instrucciones manuales"
    ])
    if sel < 0:
        return
    if sel == 1:
        xbmcgui.Dialog().ok("Instrucciónes de instalación",
            "1. Ves a https://github.com/loioloio/flowfav\n"
            "2. Descarga el archivo ZIP de la última release\n"
            "3. En Kodi: Ajustes > Addons > Instalar desde ZIP\n"
            "4. Selecciona el ZIP descargado")
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Descargando Flow FavManager...")
    zip_path = None
    try:
        dp.update(5, "Buscando última versión...")
        status, content = _http_get(_FLOWFAV_API_URL, timeout=15)
        if status != 200:
            raise RuntimeError("No se pudo consultar GitHub (HTTP {0})".format(status))
        import json as _json_fav
        assets = _json_fav.loads(content).get("assets", [])
        zip_url = None
        for asset in assets:
            name = asset.get("name", "")
            if "_ML" in name and name.endswith(".zip"):
                zip_url = asset.get("browser_download_url")
                break
        if not zip_url:
            raise RuntimeError("No se encontró el ZIP en la última release")
        dp.update(10, "Descargando desde GitHub...")
        status, content = _http_get(zip_url, timeout=30)
        if status != 200:
            raise RuntimeError("HTTP {0}".format(status))
        if len(content) < 4 or content[:2] != b'PK':
            raise RuntimeError("El archivo descargado no es un ZIP válido")
        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "flowfav.zip")
        with open(zip_path, "wb") as f:
            f.write(content)
        dp.update(50, "Extrayendo addon...")
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        _extract_zip_safe(zip_path, addons_dir)
        dp.update(80, "Actualizando addons locales...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(2000)
        xbmc.executebuiltin("EnableAddon({0})".format(_FLOWFAV_ADDON_ID))
        xbmc.sleep(1000)
        dp.close()
        xbmcgui.Dialog().notification(
            "EspaTV", "Flow FavManager instalado correctamente",
            xbmcgui.NOTIFICATION_INFO, 5000)
        xbmc.executebuiltin("Container.Refresh")
    except (ValueError, OSError, zipfile.BadZipFile, RuntimeError) as e:
        dp.close()
        _err("Error instalando FlowFav: {0}".format(e))
        choice = xbmcgui.Dialog().yesno(
            "Error de instalación",
            "No se pudo instalar automáticamente.\n\nError: {0}\n\n"
            "Puede que necesites activar 'Orígenes desconocidos' en Ajustes.\n"
            "¿Abrir Ajustes del Sistema?".format(e))
        if choice:
            xbmc.executebuiltin("ActivateWindow(systemsettings)")
    finally:
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except OSError:
                pass


def _loiolog_install():
    _LOIOLOG_API_URL = "https://api.github.com/repos/loioloio/loiolog/releases/latest"
    _LOIOLOG_ADDON_ID = "plugin.program.loiolog"

    if xbmc.getCondVisibility("System.HasAddon(plugin.program.loiolog)"):
        sel = xbmcgui.Dialog().select("LoioLog", [
            "Abrir LoioLog",
            "Reinstalar desde GitHub"
        ])
        if sel == 0:
            xbmc.executebuiltin("RunAddon(plugin.program.loiolog)")
            return
        elif sel < 0:
            return
    else:
        sel = xbmcgui.Dialog().select("LoioLog — Gestor de Logs", [
            "Instalar automáticamente",
            "Ver instrucciones manuales"
        ])
        if sel < 0:
            return
        if sel == 1:
            xbmcgui.Dialog().ok("Instrucciones de instalación",
                "1. Ve a https://github.com/loioloio/loiolog\n"
                "2. Descarga el archivo ZIP de la última release\n"
                "3. En Kodi: Ajustes > Addons > Instalar desde ZIP\n"
                "4. Selecciona el ZIP descargado")
            return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Descargando LoioLog...")
    zip_path = None
    try:
        dp.update(5, "Buscando última versión...")
        status, content = _http_get(_LOIOLOG_API_URL, timeout=15)
        if status != 200:
            raise RuntimeError("No se pudo consultar GitHub (HTTP {0})".format(status))
        import json as _json_ll
        assets = _json_ll.loads(content).get("assets", [])
        zip_url = None
        for asset in assets:
            name = asset.get("name", "")
            if name.endswith(".zip"):
                zip_url = asset.get("browser_download_url")
                break
        if not zip_url:
            raise RuntimeError("No se encontró el ZIP en la última release")
        dp.update(10, "Descargando desde GitHub...")
        status, content = _http_get(zip_url, timeout=30)
        if status != 200:
            raise RuntimeError("HTTP {0}".format(status))
        if len(content) < 4 or content[:2] != b'PK':
            raise RuntimeError("El archivo descargado no es un ZIP válido")
        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "loiolog.zip")
        with open(zip_path, "wb") as f:
            f.write(content)
        dp.update(50, "Extrayendo addon...")
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        _extract_zip_safe(zip_path, addons_dir)
        dp.update(80, "Actualizando addons locales...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(2000)
        xbmc.executebuiltin("EnableAddon({0})".format(_LOIOLOG_ADDON_ID))
        xbmc.sleep(1000)
        dp.close()
        xbmcgui.Dialog().notification(
            "EspaTV", "LoioLog instalado correctamente",
            xbmcgui.NOTIFICATION_INFO, 5000)
        xbmc.executebuiltin("Container.Refresh")
    except (ValueError, OSError, zipfile.BadZipFile, RuntimeError) as e:
        dp.close()
        _err("Error instalando LoioLog: {0}".format(e))
        choice = xbmcgui.Dialog().yesno(
            "Error de instalación",
            "No se pudo instalar automáticamente.\n\nError: {0}\n\n"
            "Puede que necesites activar 'Orígenes desconocidos' en Ajustes.\n"
            "¿Abrir Ajustes del Sistema?".format(e))
        if choice:
            xbmc.executebuiltin("ActivateWindow(systemsettings)")
    finally:
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except OSError:
                pass


def _loiolink_launch():
    try:
        xbmcaddon.Addon(_LOIOLINK_ADDON_ID)
        xbmcgui.Dialog().notification("EspaTV", "Abriendo LoioLink...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_LOIOLINK_ADDON_ID})")
        return
    except Exception:
        pass

    idx = xbmcgui.Dialog().select("LoioLink - instalación", [
        "Instalador automático (puede fallar)",
        "Ver instrucciones de instalación manual",
    ])
    if idx == 0:
        if not xbmcgui.Dialog().yesno("EspaTV",
                "LoioLink no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            return
        _loiolink_repo_install()
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones LoioLink",
            "[B]Cómo instalar LoioLink[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            f"2. Ajustes - Explorador de archivos - Añadir fuente: {_LOIOLINK_SOURCE}\n\n"
            "3. Ajustes - Addons - Instalar desde un archivo zip - LoioLink - "
            "repository.loiolink-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - LoioLink - Addons de programa - LoioLink")


def _loiolink_repo_install():
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Instalando LoioLink...")
    zip_path = None
    try:
        try:
            xbmcaddon.Addon(_LOIOLINK_REPO_ID)
            repo_present = True
        except Exception:
            repo_present = False

        if not repo_present:
            dp.update(5, "Descargando repositorio...")
            status, content = _http_get(_LOIOLINK_REPO_ZIP, timeout=30)
            if status != 200:
                raise RuntimeError(f"HTTP {status} descargando repositorio")
            if len(content) < 4 or content[:2] != b'PK':
                raise RuntimeError("El archivo descargado no es un ZIP válido")
            zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "repository.loiolink.zip")
            with open(zip_path, "wb") as f:
                f.write(content)
            dp.update(20, "Extrayendo repositorio...")
            addons_dir = xbmcvfs.translatePath("special://home/addons/")
            _extract_zip_safe(zip_path, addons_dir)
            dp.update(40, "Registrando repositorio...")
            xbmc.executebuiltin("UpdateLocalAddons()")
            for i in range(30):
                xbmc.sleep(500)
                try:
                    xbmcaddon.Addon(_LOIOLINK_REPO_ID)
                    break
                except Exception:
                    if i in (4, 12):
                        xbmc.executebuiltin(f"EnableAddon({_LOIOLINK_REPO_ID})")
            else:
                raise RuntimeError("Kodi no registró el repositorio")
            xbmc.executebuiltin(f"EnableAddon({_LOIOLINK_REPO_ID})")
            xbmc.sleep(1500)

        dp.update(60, "Actualizando índice del repositorio...")
        xbmc.executebuiltin("UpdateAddonRepos()")
        xbmc.sleep(3000)
        dp.close()

        xbmcgui.Dialog().notification("EspaTV", "Confirma la instalación de LoioLink",
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        xbmc.executebuiltin(f"InstallAddon({_LOIOLINK_ADDON_ID})")

        for _ in range(120):
            xbmc.sleep(500)
            try:
                xbmcaddon.Addon(_LOIOLINK_ADDON_ID)
                xbmcgui.Dialog().notification("EspaTV", "LoioLink instalado correctamente",
                                              xbmcgui.NOTIFICATION_INFO, 5000)
                xbmc.executebuiltin("Container.Refresh")
                return
            except Exception:
                pass

        xbmcgui.Dialog().ok("EspaTV",
            "El repositorio se instaló pero la instalación del addon no se completó.\n\n"
            "Para terminarla: Addons - Instalar desde repositorio - LoioLink - Instalar")

    except (OSError, RuntimeError, zipfile.BadZipFile) as e:
        try:
            dp.close()
        except Exception:
            pass
        _err(f"Error instalando LoioLink: {e}")
        if xbmcgui.Dialog().yesno("Error de instalación",
                f"No se pudo instalar automáticamente.\n\nError: {e}\n\n"
                "¿Abrir Ajustes del Sistema?"):
            xbmc.executebuiltin("ActivateWindow(systemsettings)")
    finally:
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except OSError:
                pass
