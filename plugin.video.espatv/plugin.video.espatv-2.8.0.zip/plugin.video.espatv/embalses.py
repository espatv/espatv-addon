# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Estado de Embalses: datos semanales de embalses.net y MITECO."""
import json
import os
import re
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG     = "[EspaTV-EMB]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_FILE = os.path.join(_PROFILE, "embalses_cache.json")
_CACHE_TTL  = 6 * 3600
_TIMEOUT    = 20
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_URL_MITECO = (
    "https://services.arcgis.com/nXkhrn9nhMYuEcCX/ArcGIS/rest/services"
    "/Informacion_Hidrologica_Nacional/FeatureServer/0/query"
    "?where=1%3D1&outFields=*&returnGeometry=false&f=json&resultRecordCount=500"
)

_URL_EMBALSES_NET = "https://www.embalses.net/cuencas.php"

_CUENCAS = [
    ("CHT",  "Tajo",         "royalblue"),
    ("CHE",  "Ebro",         "deepskyblue"),
    ("CHJ",  "Júcar",        "mediumseagreen"),
    ("CHG",  "Guadalquivir", "gold"),
    ("CHN",  "Norte",        "lightblue"),
    ("CHC",  "Cantábrico",   "lightcyan"),
    ("CHS",  "Segura",       "orange"),
    ("CHD",  "Duero",        "khaki"),
    ("CHM",  "Miño-Sil",    "plum"),
    ("CHG2", "Guadiana",     "lightyellow"),
]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _nivel_color(pct):
    if pct is None:
        return "grey", "Sin datos"
    if pct < 30:
        return "tomato", "Bajo"
    if pct < 60:
        return "gold", "Medio"
    return "mediumseagreen", "Alto"


def _barra(pct):
    if pct is None:
        return "░░░░░░░░░░"
    n = max(0, min(10, round(pct / 10)))
    return "▓" * n + "░" * (10 - n)


def _load_cache():
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if time.time() - obj.get("ts", 0) < _CACHE_TTL:
            return obj.get("data")
    except (OSError, ValueError):
        pass
    return None


def _save_cache(data):
    try:
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump({"ts": time.time(), "data": data}, f, ensure_ascii=False)
    except OSError as e:
        xbmc.log("{0} Error caché: {1}".format(_LOG, e), xbmc.LOGWARNING)


def _fetch_miteco():
    headers = {
        "User-Agent": "EspaTV/1.0 (Kodi addon; embalses España)",
        "Accept": "application/json, */*",
    }
    resp = requests.get(_URL_MITECO, headers=headers, timeout=_TIMEOUT)
    resp.raise_for_status()
    raw = resp.json()

    features = raw.get("features", []) if isinstance(raw, dict) else []
    if not features:
        if isinstance(raw, list):
            features_raw = raw
        elif isinstance(raw, dict):
            features_raw = raw.get("data", raw.get("embalses", raw.get("results", [])))
            if isinstance(features_raw, dict):
                features_raw = list(features_raw.values())
        else:
            features_raw = []
        items = [f if isinstance(f, dict) else {} for f in features_raw]
    else:
        items = [f.get("attributes", {}) for f in features if isinstance(f, dict)]

    embalses = []
    for item in items:
        if not isinstance(item, dict):
            continue
        nombre = (item.get("NOMBRE") or item.get("nombre") or item.get("name") or "").strip()
        cuenca = (item.get("CUENCA") or item.get("cuenca") or item.get("basin") or "").strip()
        cap_raw = (item.get("CAP_TOTAL") or item.get("capacidad") or
                   item.get("total_capacity") or item.get("CAPACIDAD") or 0)
        vol_raw = (item.get("VOLUMEN") or item.get("volumen") or
                   item.get("current_volume") or item.get("VOL_ACTUAL") or 0)
        pct_raw = (item.get("PORCENTAJE") or item.get("porcentaje") or item.get("pct"))
        var_raw = (item.get("VARIACION") or item.get("variacion") or
                   item.get("DIFERENCIA") or item.get("VAR_SEMANA"))
        try:
            cap = float(str(cap_raw).replace(",", "."))
            vol = float(str(vol_raw).replace(",", ".")) if vol_raw else None
            if pct_raw is not None:
                pct = round(float(str(pct_raw).replace(",", ".")), 1)
            else:
                pct = round(vol / cap * 100, 1) if (cap > 0 and vol) else None
            var = round(float(str(var_raw).replace(",", ".")), 1) if var_raw is not None else None
        except (ValueError, ZeroDivisionError, TypeError):
            pct = None
            cap = 0
            vol = None
            var = None

        if nombre:
            embalses.append({"nombre": nombre, "cuenca": cuenca, "pct": pct,
                              "cap": cap, "vol": vol, "var": var})
    return embalses


def _fetch_embalses_net():
    # cuencas.php columns: Cuenca | Capacidad hm³ | Embalsada hm³ (%) | Variación hm³ (%)
    headers = {
        "User-Agent": "Mozilla/5.0 (compatible; EspaTV/1.0)",
        "Accept": "text/html, */*",
    }
    resp = requests.get(_URL_EMBALSES_NET, headers=headers, timeout=_TIMEOUT, verify=False)
    resp.raise_for_status()
    html_text = resp.text
    result = []
    rows = re.findall(r'<tr[^>]*>(.*?)</tr>', html_text, re.DOTALL)
    for row in rows:
        cells = re.findall(r'<td[^>]*>(.*?)</td>', row, re.DOTALL)
        clean = [re.sub(r'<[^>]+>', '', c).strip() for c in cells]
        clean = [c for c in clean if c]
        if len(clean) < 4:
            continue
        nombre = clean[0]
        try:
            cap = float(clean[1].replace('.', '').replace(',', '.'))
        except ValueError:
            continue
        if cap <= 0:
            continue
        # col 2: "8772 (79,34%)", embalsado hm³ y porcentaje de llenado
        vol, pct = None, None
        vol_m = re.match(r'(\d+)', clean[2].replace('.', ''))
        if vol_m:
            try:
                vol = float(vol_m.group(1))
            except ValueError:
                pass
        pct_m = re.search(r'\((\d+)[,.](\d+)%\)', clean[2])
        if pct_m:
            pct = float(pct_m.group(1) + '.' + pct_m.group(2))
        # col 3: "-38 (-0,34%)", variación semanal en hm³
        var = None
        var_m = re.match(r'(-?\d+)', clean[3].strip())
        if var_m:
            try:
                var = int(var_m.group(1))
            except ValueError:
                pass
        result.append({"nombre": nombre, "cuenca": nombre, "pct": pct,
                        "cap": cap, "vol": vol, "var": var})
    return result


def _fetch_all():
    data = _load_cache()
    if data is not None:
        return data
    xbmc.log("{0} Descargando datos de embalses…".format(_LOG), xbmc.LOGINFO)
    try:
        data = _fetch_miteco()
        if not data:
            raise ValueError("MITECO: lista vacía")
    except Exception as e:
        xbmc.log("{0} MITECO falló ({1}), intentando embalses.net…".format(_LOG, e), xbmc.LOGWARNING)
        try:
            data = _fetch_embalses_net()
        except Exception as e2:
            xbmc.log("{0} Fallback también falló: {1}".format(_LOG, e2), xbmc.LOGERROR)
            return None
    _save_cache(data)
    return data


def _agrupar_cuencas(embalses_list):
    cuencas = {}
    for e in embalses_list:
        c = e.get("cuenca", "Otras") or "Otras"
        if c not in cuencas:
            cuencas[c] = {"total_cap": 0.0, "total_vol": 0.0,
                          "total_vol_pct_sum": 0.0, "count_pct": 0.0, "embalses": []}
        cuencas[c]["embalses"].append(e)
        cap = e.get("cap", 0) or 0
        vol = e.get("vol") or 0
        pct = e.get("pct")
        cuencas[c]["total_cap"] += cap
        cuencas[c]["total_vol"] += vol
        if pct is not None:
            cuencas[c]["total_vol_pct_sum"] += pct * cap
            cuencas[c]["count_pct"] += cap
    for c in cuencas:
        tc      = cuencas[c]["count_pct"]
        tot_cap = cuencas[c]["total_cap"]
        tot_vol = cuencas[c]["total_vol"]
        if tc > 0:
            cuencas[c]["avg_pct"] = round(cuencas[c]["total_vol_pct_sum"] / tc, 1)
        elif tot_cap > 0 and tot_vol > 0:
            cuencas[c]["avg_pct"] = round(tot_vol / tot_cap * 100, 1)
        else:
            cuencas[c]["avg_pct"] = None
    return cuencas


def _embalse_label_plot(e):
    nombre = e.get("nombre", "Embalse")
    pct    = e.get("pct")
    cap    = e.get("cap", 0) or 0
    vol    = e.get("vol")
    var    = e.get("var")
    cuenca = e.get("cuenca", "")
    color_pct, nivel_str = _nivel_color(pct)
    barra   = _barra(pct)
    pct_str = "{0}%".format(pct) if pct is not None else "?%"

    vol_cap = ""
    if vol is not None and cap:
        vol_cap = "  [COLOR grey]{0} / {1} hm³[/COLOR]".format(int(vol), int(cap))
    elif cap:
        vol_cap = "  [COLOR grey]{0} hm³[/COLOR]".format(int(cap))

    var_str = ""
    if var is not None:
        arrow = "▲ +" if var > 0 else ("▼ " if var < 0 else "— ")
        col   = "mediumseagreen" if var >= 0 else "tomato"
        var_str = "  [COLOR {0}]{1}{2} hm³[/COLOR]".format(col, arrow, abs(int(var)))

    label = "[B]{0}[/B]  {1}  [COLOR {2}]{3}[/COLOR]{4}{5}".format(
        nombre, barra, color_pct, pct_str, vol_cap, var_str
    )

    plot_lines = [nombre]
    if cuenca and cuenca != nombre:
        plot_lines.append("Cuenca: {0}".format(cuenca))
    plot_lines.append("Llenado: {0}  ({1})".format(pct_str, nivel_str))
    if vol is not None and cap:
        plot_lines.append("Volumen: {0} hm³ de {1} hm³".format(int(vol), int(cap)))
    elif cap:
        plot_lines.append("Capacidad: {0} hm³".format(int(cap)))
    if var is not None:
        arrow = "▲ +" if var > 0 else ("▼ " if var < 0 else "— ")
        plot_lines.append("Variación semanal: {0}{1} hm³".format(arrow, abs(int(var))))

    return label, "\n".join(plot_lines)


def embalses_menu():
    h = int(sys.argv[1])
    xbmcgui.Dialog().notification("Embalses", "Cargando…", xbmcgui.NOTIFICATION_INFO, 1500)
    data = _fetch_all()

    if data is None:
        li = xbmcgui.ListItem(
            label="[COLOR orange]Datos no disponibles temporalmente — pulsa Actualizar para reintentar[/COLOR]"
        )
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar datos ][/COLOR]")
        li_r.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="embalses_refresh"), listitem=li_r, isFolder=True)
        xbmcplugin.endOfDirectory(h)
        return

    icon    = _icon("cat_embalses.png")
    cuencas = _agrupar_cuencas(data)

    all_pcts     = [e.get("pct") for e in data if e.get("pct") is not None]
    nacional_pct = round(sum(all_pcts) / len(all_pcts), 1) if all_pcts else None
    color_nac, nivel_nac = _nivel_color(nacional_pct)
    total_vol = sum(e.get("vol") or 0 for e in data)
    total_cap = sum(e.get("cap") or 0 for e in data)

    plot_nac = ["Media nacional de llenado: {0}%  ({1})".format(
        nacional_pct if nacional_pct is not None else "?", nivel_nac
    ), "{0} embalses monitorizados".format(len(data))]
    if total_vol and total_cap:
        plot_nac.append("Volumen total: {0} hm³ de {1} hm³".format(int(total_vol), int(total_cap)))

    li_nac = xbmcgui.ListItem(
        label="[B][COLOR {0}]España — {1}%  ({2})[/COLOR][/B]  [COLOR grey]{3} embalses[/COLOR]".format(
            color_nac, nacional_pct if nacional_pct is not None else "?", nivel_nac, len(data)
        )
    )
    li_nac.setArt({"icon": icon})
    li_nac.setInfo("video", {"plot": "\n".join(plot_nac)})
    li_nac.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li_nac, isFolder=False)

    sep = xbmcgui.ListItem(label="[COLOR grey]──  Por cuenca hidrográfica  ──[/COLOR]")
    sep.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep, isFolder=False)

    for key, nombre_cuenca, color_cuenca in _CUENCAS:
        cuenca_data = None
        for cuenca_key in cuencas:
            if nombre_cuenca.lower() in cuenca_key.lower() or key.lower() in cuenca_key.lower():
                cuenca_data = cuencas[cuenca_key]
                break
        if cuenca_data is None:
            continue

        pct     = cuenca_data.get("avg_pct")
        n_emb   = len(cuenca_data.get("embalses", []))
        cap_tot = cuenca_data.get("total_cap", 0)
        vol_tot = cuenca_data.get("total_vol", 0)
        color_pct, nivel_str = _nivel_color(pct)
        barra = _barra(pct)

        label = (
            "[B][COLOR {0}]{1}[/COLOR][/B]  {2}  [COLOR {3}]{4}%[/COLOR]"
            "  [COLOR grey]{5} hm³ · {6} embalses[/COLOR]"
        ).format(
            color_cuenca, nombre_cuenca,
            barra, color_pct, pct if pct is not None else "?",
            int(cap_tot), n_emb
        )
        plot_lines = [
            "Cuenca del {0}".format(nombre_cuenca),
            "Llenado medio: {0}%  ({1})".format(pct if pct is not None else "?", nivel_str),
        ]
        if vol_tot and cap_tot:
            plot_lines.append("Volumen embalsado: {0} hm³ de {1} hm³".format(int(vol_tot), int(cap_tot)))
        else:
            plot_lines.append("Capacidad total: {0} hm³".format(int(cap_tot)))
        plot_lines.append("{0} embalses".format(n_emb))

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": "Cuenca del {0}".format(nombre_cuenca), "plot": "\n".join(plot_lines)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="embalses_cuenca", cuenca_nombre=nombre_cuenca),
            listitem=li,
            isFolder=True,
        )

    sep2 = xbmcgui.ListItem(label="[COLOR grey]──  Rankings nacionales  ──[/COLOR]")
    sep2.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep2, isFolder=False)

    li_vacios = xbmcgui.ListItem(label="[B][COLOR tomato]Los 20 más vacíos[/COLOR][/B]")
    li_vacios.setArt({"icon": icon})
    li_vacios.setInfo("video", {"plot": "Los 20 embalses con menor porcentaje de llenado en España."})
    li_vacios.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="embalses_ranking", tipo="vacios"),
        listitem=li_vacios, isFolder=True
    )

    li_llenos = xbmcgui.ListItem(label="[B][COLOR mediumseagreen]Los 20 más llenos[/COLOR][/B]")
    li_llenos.setArt({"icon": icon})
    li_llenos.setInfo("video", {"plot": "Los 20 embalses con mayor porcentaje de llenado en España."})
    li_llenos.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="embalses_ranking", tipo="llenos"),
        listitem=li_llenos, isFolder=True
    )

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar datos ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Elimina la caché y recarga los datos de embalses."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="embalses_refresh"), listitem=li_r, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def embalses_cuenca(cuenca_nombre):
    h = int(sys.argv[1])
    data = _fetch_all()
    if data is None:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    icon    = _icon("cat_embalses.png")
    cuencas = _agrupar_cuencas(data)

    cuenca_data = None
    for cuenca_key, cdata in cuencas.items():
        if cuenca_nombre.lower() in cuenca_key.lower():
            cuenca_data = cdata
            break

    if cuenca_data is None:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin datos para esta cuenca[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    embalses_list = sorted(cuenca_data.get("embalses", []), key=lambda x: (x.get("pct") or 0))
    for e in embalses_list:
        label, plot = _embalse_label_plot(e)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": e.get("nombre", ""), "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def embalses_ranking(tipo="vacios"):
    h = int(sys.argv[1])
    data = _fetch_all()
    if data is None:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    valid   = [e for e in data if e.get("pct") is not None and (e.get("cap") or 0) > 0]
    reverse = (tipo == "llenos")
    top     = sorted(valid, key=lambda x: x["pct"], reverse=reverse)[:20]

    icon = _icon("cat_embalses.png")
    for e in top:
        label, plot = _embalse_label_plot(e)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": e.get("nombre", ""), "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def embalses_refresh():
    try:
        os.remove(_CACHE_FILE)
    except OSError:
        pass
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="embalses_menu")))
