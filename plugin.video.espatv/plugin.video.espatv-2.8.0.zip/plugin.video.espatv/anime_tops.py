# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Tops de anime vía AniList (gratuito, sin key) y MyAnimeList (client ID gratuito)."""
import datetime
import json
import os
import sys
import time
import urllib.parse
from html.parser import HTMLParser

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

_ANILIST_URL = "https://graphql.anilist.co"
_MAL_URL     = "https://api.myanimelist.net/v2"
_TTL         = 24 * 3600
_LOG_TAG     = "[EspaTV-AN]"


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), level)

def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espatv_anime_cache.json')

def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}

def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        _log("cache save: {0}".format(e), xbmc.LOGWARNING)

class _HTMLStripper(HTMLParser):
    def __init__(self):
        super().__init__()
        self._parts = []
    def handle_data(self, data):
        self._parts.append(data)
    def get_text(self):
        return ''.join(self._parts)

def _strip_html(text):
    if not text:
        return ''
    text = text.replace('<br>', '\n').replace('<br/>', '\n').replace('<br />', '\n')
    s = _HTMLStripper()
    s.feed(text)
    return s.get_text().strip()

def _current_season():
    now = datetime.datetime.now()
    month = now.month
    if month in (1, 2, 3):
        return 'WINTER', now.year
    if month in (4, 5, 6):
        return 'SPRING', now.year
    if month in (7, 8, 9):
        return 'SUMMER', now.year
    return 'FALL', now.year


# AniList

_ANILIST_QUERY = """
query ($page: Int, $perPage: Int, $sort: [MediaSort], $season: MediaSeason, $seasonYear: Int) {
  Page(page: $page, perPage: $perPage) {
    pageInfo { currentPage lastPage hasNextPage }
    media(type: ANIME, sort: $sort, season: $season, seasonYear: $seasonYear, isAdult: false) {
      id
      title { romaji english }
      coverImage { large }
      averageScore
      popularity
      genres
      description(asHtml: false)
      episodes
      status
    }
  }
}
"""

_ANILIST_SORTS = [
    ("Trending ahora",        "anilist_trending",  ["TRENDING_DESC"],  None),
    ("Más populares",         "anilist_popular",   ["POPULARITY_DESC"],None),
    ("Mejor valoradas",       "anilist_top",       ["SCORE_DESC"],     None),
    ("Temporada actual",      "anilist_seasonal",  ["SCORE_DESC"],     "seasonal"),
]


def _fetch_anilist(sort_key, page=1):
    cache = _load_cache()
    cache_key = "al:{0}|{1}".format(sort_key, page)
    entry = cache.get(cache_key, {})
    if entry.get('items') and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['items'], entry.get('total_pages', 1)

    # Determinar parámetros de la query
    sort_list, is_seasonal = None, False
    for _, key, sl, mode in _ANILIST_SORTS:
        if key == sort_key:
            sort_list = sl
            is_seasonal = (mode == 'seasonal')
            break
    if sort_list is None:
        sort_list = ['TRENDING_DESC']

    variables = {'page': page, 'perPage': 20, 'sort': sort_list}
    if is_seasonal:
        season, year = _current_season()
        variables['season'] = season
        variables['seasonYear'] = year

    try:
        r = requests.post(_ANILIST_URL,
                          json={'query': _ANILIST_QUERY, 'variables': variables},
                          timeout=12)
        _log("AniList {0} -> {1}".format(sort_key, r.status_code))
        if r.status_code != 200:
            return _cache_fallback(cache, cache_key)
        body = r.json()
        if body.get('errors'):
            _log("AniList GraphQL errors: {0}".format(body['errors']), xbmc.LOGWARNING)
            return _cache_fallback(cache, cache_key)
        page_data = (body.get('data') or {}).get('Page') or {}
    except (requests.RequestException, ValueError) as e:
        _log("AniList error: {0}".format(e), xbmc.LOGERROR)
        return _cache_fallback(cache, cache_key)

    page_info   = page_data.get('pageInfo') or {}
    total_pages = page_info.get('lastPage') or 1
    items = []
    for m in (page_data.get('media') or []):
        titles = m.get('title') or {}
        title  = titles.get('english') or titles.get('romaji') or ''
        if not title:
            continue
        score = (m.get('averageScore') or 0) / 10.0
        items.append({
            'title':    title,
            'poster':   (m.get('coverImage') or {}).get('large') or '',
            'rating':   round(score, 1),
            'genres':   ' / '.join((m.get('genres') or [])[:3]),
            'plot':     _strip_html(m.get('description') or ''),
            'episodes': m.get('episodes') or 0,
        })

    if items:  # no cachear vacíos
        cache[cache_key] = {'ts': time.time(), 'items': items, 'total_pages': total_pages}
        _save_cache(cache)
    return items, total_pages


def _media_icon(name, fallback='DefaultVideoPlaylists.png'):
    p = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')),
        'resources', 'media', name,
    )
    return p if os.path.exists(p) else fallback


def _cache_fallback(cache, cache_key):
    entry = cache.get(cache_key, {})
    stale = entry.get('items')
    if stale:
        _log("usando caché caducada para {0}".format(cache_key), xbmc.LOGWARNING)
        return stale, entry.get('total_pages', 1)
    return [], 1


_ANILIST_SORT_ICONS = {
    'anilist_trending':  'top_trending.png',
    'anilist_popular':   'top_popular.png',
    'anilist_top':       'top_mejores.png',
    'anilist_seasonal':  'top_seasonal.png',
}

def show_anilist_menu():
    h = _handle()
    for label, sort_key, _, _ in _ANILIST_SORTS:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _media_icon(_ANILIST_SORT_ICONS.get(sort_key, ''))})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='anime_anilist_list', sort_key=sort_key, page=1),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def show_anilist_list(sort_key, page=1):
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'anime_anilist', 'Anime · AniList', sort_key=sort_key):
        return

    import metadata_enricher as me

    h    = _handle()
    page = int(page)
    items, total_pages = _fetch_anilist(sort_key, page)

    if not items:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar AniList", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')

    for item in items:
        li = xbmcgui.ListItem(label=item['title'])
        li.setArt({
            'icon':   'DefaultVideo.png',
            'thumb':  item['poster'],
            'poster': item['poster'],
            'fanart': af,
        })
        header = me.build_plot_header(item['rating'], item['genres'])
        li.setInfo('video', {
            'title':    item['title'],
            'plot':     header + item['plot'],
            'rating':   item['rating'],
            'genre':    item['genres'],
            'mediatype': 'tvshow',
        })
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=item['title'], ot=item['poster'], mode='show')
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)

    if page < total_pages:
        li = xbmcgui.ListItem(
            label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(page + 1, total_pages))
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='anime_anilist_list', sort_key=sort_key, page=page + 1),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


# MyAnimeList

_MAL_FIELDS = "title,main_picture,mean,rank,popularity,genres,synopsis,num_episodes,status"

_MAL_LISTS = [
    ("Top All Time",      "all",          "Anime mejor valorado de todos los tiempos.",   'top_mejores.png'),
    ("En emisión ahora",  "airing",       "Anime actualmente en emisión.",                'top_watched.png'),
    ("Próximos estrenos", "upcoming",     "Anime que próximamente comenzará a emitirse.", 'top_anticipated.png'),
    ("Top Películas",     "movie",        "Películas anime mejor valoradas.",             'top_filmaffinity.png'),
    ("Más populares",     "bypopularity", "Anime con más usuarios en lista.",             'top_popular.png'),
]


def _fetch_mal(ranking_type, page=1):
    client_id = core_settings.get_mal_client_id()
    if not client_id:
        return [], 1

    cache = _load_cache()
    cache_key = "mal:{0}|{1}".format(ranking_type, page)
    entry = cache.get(cache_key, {})
    if entry.get('items') and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['items'], entry.get('total_pages', 1)

    offset = (page - 1) * 20
    try:
        r = requests.get(
            "{0}/anime/ranking".format(_MAL_URL),
            params={'ranking_type': ranking_type, 'limit': 20, 'offset': offset,
                    'fields': _MAL_FIELDS},
            headers={'X-MAL-CLIENT-ID': client_id},
            timeout=12,
        )
        _log("MAL {0} -> {1}".format(ranking_type, r.status_code))
        if r.status_code == 401:
            _log("MAL: client ID inválido", xbmc.LOGWARNING)
            return _cache_fallback(cache, cache_key)
        if r.status_code != 200:
            return _cache_fallback(cache, cache_key)
        body = r.json()
    except (requests.RequestException, ValueError) as e:
        _log("MAL error: {0}".format(e), xbmc.LOGERROR)
        return _cache_fallback(cache, cache_key)

    has_next = bool((body.get('paging') or {}).get('next'))
    total_pages = page + 1 if has_next else page
    items = []
    for entry_data in (body.get('data') or []):
        node = entry_data.get('node')
        if not isinstance(node, dict):
            continue
        title = node.get('title') or ''
        if not title:
            continue
        pic = node.get('main_picture') or {}
        genres_list = [g.get('name', '') for g in (node.get('genres') or [])[:3]]
        items.append({
            'title':    title,
            'poster':   pic.get('large') or pic.get('medium') or '',
            'rating':   round(float(node.get('mean') or 0), 1),
            'genres':   ' / '.join(g for g in genres_list if g),
            'plot':     (node.get('synopsis') or '').strip(),
            'episodes': node.get('num_episodes') or 0,
        })

    if items:  # no cachear vacíos
        cache[cache_key] = {'ts': time.time(), 'items': items, 'total_pages': total_pages}
        _save_cache(cache)
    return items, total_pages


def _setup_mal_key():
    kb = xbmc.Keyboard('', 'Introduce tu Client ID de MyAnimeList (gratis en myanimelist.net/apiconfig)')
    kb.doModal()
    if not kb.isConfirmed():
        return
    key = kb.getText().strip()
    if not key:
        return
    core_settings.set_mal_client_id(key)
    xbmcgui.Dialog().notification("EspaTV", "Client ID de MAL guardado", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def show_mal_menu():
    h = _handle()
    client_id = core_settings.get_mal_client_id()
    if not client_id:
        li = xbmcgui.ListItem(label="Configura tu Client ID gratuito de MyAnimeList")
        li.setArt({'icon': _media_icon('top_mal.png')})
        li.setInfo('video', {'plot': (
            "MyAnimeList es la mayor base de datos de anime.\n\n"
            "1. Ve a myanimelist.net/apiconfig y crea una aplicación gratuita.\n"
            "2. Copia el Client ID.\n"
            "3. Pulsa aquí para introducirlo."
        )})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action='anime_mal_setup'), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for label, ranking_type, plot, icon_file in _MAL_LISTS:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _media_icon(icon_file)})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='anime_mal_list', ranking_type=ranking_type, page=1),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def show_mal_list(ranking_type, page=1):
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'anime_mal', 'Anime · MyAnimeList', ranking_type=ranking_type):
        return

    import metadata_enricher as me

    h    = _handle()
    page = int(page)
    items, total_pages = _fetch_mal(ranking_type, page)

    if not items:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar MyAnimeList", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')

    for item in items:
        li = xbmcgui.ListItem(label=item['title'])
        li.setArt({
            'icon':   'DefaultVideo.png',
            'thumb':  item['poster'],
            'poster': item['poster'],
            'fanart': af,
        })
        header = me.build_plot_header(item['rating'], item['genres'])
        li.setInfo('video', {
            'title':    item['title'],
            'plot':     header + item['plot'],
            'rating':   item['rating'],
            'genre':    item['genres'],
            'mediatype': 'tvshow',
        })
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=item['title'], ot=item['poster'], mode='show')
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)

    if page < total_pages:
        li = xbmcgui.ListItem(
            label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(page + 1, total_pages))
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='anime_mal_list', ranking_type=ranking_type, page=page + 1),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


# Menú raíz de anime

def show_menu():
    h = _handle()
    entries = [
        ("AniList — Tops de anime", "anime_anilist_menu", 'top_anilist.png',
         "Trending, populares y mejor valoradas. Sin configuración."),
        ("MyAnimeList — Rankings",  "anime_mal_menu",     'top_mal.png',
         "La mayor base de datos de anime. Requiere Client ID gratuito."),
    ]
    for label, action, icon_file, plot in entries:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _media_icon(icon_file)})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action=action), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)
