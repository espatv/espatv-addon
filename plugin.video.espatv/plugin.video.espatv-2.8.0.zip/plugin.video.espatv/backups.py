# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Copias de seguridad, restauración e importación/exportación de datos."""
import json
import os
import sys
import time
import urllib.parse
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _get_backup_dir():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    d = os.path.join(p, 'backups')
    if not os.path.exists(d): os.makedirs(d)
    return d


def import_backup():
    f = xbmcgui.Dialog().browse(1, 'Seleccionar Backup', 'files', '.zip', False, False, '')
    if not f: return

    file_labels = {
        'settings.json': 'Configuración General',
        'favorites.json': 'Favoritos',
        'search_history.json': 'Historial de Búsquedas DM',
        'yt_search_history.json': 'Historial de Búsquedas YouTube',
        'custom_categories.json': 'Categorías',
        'dm_settings.json': 'Ajustes Dailymotion',
        'watch_history.json': 'Historial de Visionado',
        'custom_iptv.json': 'Listas IPTV',
        'url_history.json': 'Historial de URLs',
        'url_bookmarks.json': 'Marcadores de URLs',
        'saved_playlists.json': 'Playlists DM Guardadas',
        'yt_playlists.json': 'Playlists YouTube Guardadas',
        'downloads_history.json': 'Historial de Descargas',
        'trakt_settings.json': 'Configuración Trakt',
    }
    mergeable = ['favorites.json', 'search_history.json', 'yt_search_history.json',
                 'watch_history.json', 'url_history.json', 'url_bookmarks.json', 'custom_iptv.json',
                 'saved_playlists.json', 'yt_playlists.json', 'downloads_history.json']
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))

    try:
        with zipfile.ZipFile(f, 'r') as zf:
            available = zf.namelist()
        known = [fz for fz in available if fz in file_labels]

        cache_files = [fz for fz in available if fz.startswith("cat_cache_") and fz.endswith(".json")]
        if cache_files:
            known.append('__cache__')
            file_labels['__cache__'] = 'Caché de Categorías ({0})'.format(len(cache_files))

        if not known:
            xbmcgui.Dialog().ok("EspaTV", "Este archivo no contiene datos reconocidos.")
            return

        options = [file_labels.get(fz, fz) for fz in known]
        selected = xbmcgui.Dialog().multiselect("¿Qué deseas importar?", options,
                                                preselect=list(range(len(options))))
        if not selected: return

        files_to_restore = [known[i] for i in selected]
        restored = 0
        with zipfile.ZipFile(f, 'r') as zf:
            for fz in files_to_restore:
                if fz == '__cache__':
                    for cf in cache_files:
                        data = zf.read(cf)
                        with open(os.path.join(p, cf), 'wb') as f_out:
                            f_out.write(data)
                        restored += 1
                    continue
                dest_path = os.path.join(p, fz)
                if fz in mergeable and os.path.exists(dest_path):
                    choice = xbmcgui.Dialog().select(file_labels[fz],
                        ["Sustituir (borrar actual)", "Añadir (fusionar con actual)", "Omitir"])
                    if choice == 2 or choice == -1: continue
                    elif choice == 1:
                        try:
                            with open(dest_path, 'r', encoding='utf-8') as fh: current = json.load(fh)
                            with zf.open(fz) as zfile: backup = json.load(zfile)
                            if isinstance(current, list) and isinstance(backup, list):
                                merged = current + [x for x in backup if x not in current]
                                with open(dest_path, 'w', encoding='utf-8') as fh: json.dump(merged, fh, ensure_ascii=False)
                                restored += 1; continue
                            elif isinstance(current, dict) and isinstance(backup, dict):
                                current.update(backup)
                                with open(dest_path, 'w', encoding='utf-8') as fh: json.dump(current, fh, ensure_ascii=False)
                                restored += 1; continue
                        except (OSError, ValueError):
                            pass
                resolved = os.path.realpath(os.path.join(p, fz))
                if not resolved.startswith(os.path.realpath(p)):
                    continue
                zf.extract(fz, p)
                restored += 1

        xbmcgui.Dialog().ok("Importación Completa", "Se restauraron {0} elementos.".format(restored))
        xbmc.executebuiltin("Container.Refresh")

    except (OSError, ValueError, zipfile.BadZipFile) as e:
        xbmcgui.Dialog().ok("Error", "Fallo al importar:\n{0}".format(e))


def export_favorites():
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaTV", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_INFO)
        return

    ts = time.strftime("%Y%m%d_%H%M")
    default_name = "EspaTV_favoritos_{0}.json".format(ts)

    d = xbmcgui.Dialog().browse(3, 'Guardar Favoritos', 'files', '', False, False, default_name)
    if not d: return

    if os.path.isdir(d):
        d = os.path.join(d, default_name)
    elif not d.lower().endswith(".json"):
        d += ".json"

    try:
        with open(d, 'w', encoding='utf-8') as f:
            json.dump(favs, f, ensure_ascii=False, indent=2)
        xbmcgui.Dialog().ok("Exportar Favoritos", "Guardado correctamente:\n{0}\n\nElementos: {1}".format(os.path.basename(d), len(favs)))
    except OSError as e:
        xbmcgui.Dialog().ok("Error", str(e))


def import_favorites():
    f = xbmcgui.Dialog().browse(1, 'Seleccionar archivo de favoritos', 'files', '.json', False, False, '')
    if not f: return

    try:
        with open(f, 'r', encoding='utf-8') as fp:
            new_favs = json.load(fp)

        if not isinstance(new_favs, list):
            xbmcgui.Dialog().ok("Error", "El archivo no es una lista válida de favoritos.")
            return

        if new_favs and 'url' not in new_favs[0]:
            xbmcgui.Dialog().ok("Error", "El formato del JSON no parece ser de favoritos de EspaTV.")
            return

        opts = ["Fusionar (Añadir nuevos)", "Reemplazar lista completa"]
        sel = xbmcgui.Dialog().select("¿Cómo importar?", opts)
        if sel < 0: return

        if sel == 0:
            added = 0
            for item in new_favs:
                if core_settings.add_favorite(item['title'], item['url'], item['icon'], item['platform'], item['action'], item['params']):
                    added += 1
            xbmcgui.Dialog().notification("EspaTV", "{0} favoritos añadidos".format(added), xbmcgui.NOTIFICATION_INFO)
        else:
            profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
            fav_file = os.path.join(profile, 'favorites.json')
            with open(fav_file, 'w', encoding='utf-8') as out:
                json.dump(new_favs, out)
            xbmcgui.Dialog().notification("EspaTV", "Lista reemplazada", xbmcgui.NOTIFICATION_INFO)

        xbmc.executebuiltin("Container.Refresh")

    except (OSError, ValueError, KeyError) as e:
        xbmcgui.Dialog().ok("Error", str(e))


def create_full():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(profile): os.makedirs(profile)

    groups = [
        ("Favoritos", ['favorites.json']),
        ("Categorías", ['custom_categories.json']),
        ("Historial de Búsquedas DM", ['search_history.json']),
        ("Historial de Búsquedas YouTube", ['yt_search_history.json']),
        ("Historial de Visionado", ['watch_history.json']),
        ("Historial de URLs", ['url_history.json', 'url_bookmarks.json']),
        ("Playlists DM Guardadas", ['saved_playlists.json']),
        ("Playlists YouTube Guardadas", ['yt_playlists.json']),
        ("Historial de Descargas", ['downloads_history.json']),
        ("Configuración General", ['settings.json']),
        ("Ajustes Dailymotion", ['dm_settings.json']),
        ("Configuración Trakt", ['trakt_settings.json']),
        ("Listas IPTV", ['custom_iptv.json']),
    ]

    available_groups = []
    available_labels = []
    for label, files in groups:
        if files == '__cache__':
            has = any(f.startswith("cat_cache_") and f.endswith(".json") for f in os.listdir(profile))
        else:
            has = any(os.path.exists(os.path.join(profile, f)) for f in files)
        if has:
            available_groups.append((label, files))
            available_labels.append(label)

    if not available_labels:
        xbmcgui.Dialog().ok("Backup", "No se encontraron datos que respaldar.\n\nEl perfil del addon aún no tiene archivos guardados.")
        return

    selected = xbmcgui.Dialog().multiselect("¿Qué incluir en el backup?", available_labels,
                                            preselect=list(range(len(available_labels))))
    if not selected:
        return

    ts = time.strftime("%Y%m%d_%H%M%S")
    default_name = "EspaTV_backup_{0}.zip".format(ts)
    loc_opts = ["Guardar en carpeta del addon (por defecto)", "Elegir ubicación"]
    loc_sel = xbmcgui.Dialog().select("¿Dónde guardar?", loc_opts)
    if loc_sel < 0:
        return
    if loc_sel == 1:
        d = xbmcgui.Dialog().browse(3, 'Guardar Backup', 'files', '', False, False, default_name)
        if not d:
            return
        if os.path.isdir(d):
            target = os.path.join(d, default_name)
        elif not d.lower().endswith(".zip"):
            target = d + ".zip"
        else:
            target = d
    else:
        bdir = _get_backup_dir()
        target = os.path.join(bdir, default_name)

    dp = xbmcgui.DialogProgress()
    dp.create("Backup", "Creando copia de seguridad...")
    try:
        added = []
        chosen = [available_groups[i] for i in selected]

        dp.update(20, "Empaquetando datos...")
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as zf:
            for label, files in chosen:
                if files == '__cache__':
                    for cf in os.listdir(profile):
                        if cf.startswith("cat_cache_") and cf.endswith(".json"):
                            cfp = os.path.join(profile, cf)
                            if os.path.exists(cfp):
                                zf.write(cfp, cf)
                                added.append(cf)
                else:
                    for bf in files:
                        fp = os.path.join(profile, bf)
                        if os.path.exists(fp):
                            zf.write(fp, bf)
                            added.append(bf)

        dp.update(80, "Verificando integridad...")
        if not added:
            dp.close()
            if os.path.exists(target):
                os.remove(target)
            xbmcgui.Dialog().ok("Backup", "No se guardó ningún archivo.")
            return

        with zipfile.ZipFile(target, 'r') as zf:
            bad = zf.testzip()
        dp.close()

        size_kb = os.path.getsize(target) / 1024
        msg = "Backup creado correctamente.\n\n"
        msg += "Archivos: {0}\n".format(len(added))
        msg += "Tamaño: {0:.1f} KB\n\n".format(size_kb)
        msg += "Guardado en:\n{0}".format(target)
        if bad:
            msg += "\n\n[COLOR yellow]Advertencia: algunos archivos pueden estar dañados.[/COLOR]"
        xbmcgui.Dialog().ok("Backup Completo", msg)
        xbmc.executebuiltin("Container.Refresh")
    except (OSError, zipfile.BadZipFile) as e:
        dp.close()
        xbmcgui.Dialog().ok("Error", str(e))


def list_backups():
    h = int(sys.argv[1])
    bdir = _get_backup_dir()
    try:
        files = sorted([f for f in os.listdir(bdir) if f.endswith('.zip')], reverse=True)
    except OSError:
        files = []
    if not files:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay copias de seguridad[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    for f in files:
        li = xbmcgui.ListItem(label=f)
        li.setArt({'icon': 'DefaultAddonRepository.png'})
        cm = [("Eliminar backup", "RunPlugin({0})".format(_u(action="delete_single_backup", file=f)))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="restore_backup_selective", file=f), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def restore_selective(fname):
    source = os.path.join(_get_backup_dir(), fname)
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    file_labels = {
        'settings.json': 'Configuración General',
        'favorites.json': 'Favoritos',
        'search_history.json': 'Historial de Búsquedas DM',
        'yt_search_history.json': 'Historial de Búsquedas YouTube',
        'custom_categories.json': 'Categorías',
        'dm_settings.json': 'Ajustes Dailymotion',
        'watch_history.json': 'Historial de Visionado',
        'custom_iptv.json': 'Listas IPTV',
        'url_history.json': 'Historial de URLs',
        'url_bookmarks.json': 'Marcadores de URLs',
        'saved_playlists.json': 'Playlists DM Guardadas',
        'yt_playlists.json': 'Playlists YouTube Guardadas',
        'downloads_history.json': 'Historial de Descargas',
        'trakt_settings.json': 'Configuración Trakt',
    }
    mergeable = ['favorites.json', 'search_history.json', 'yt_search_history.json',
                 'watch_history.json', 'url_history.json', 'url_bookmarks.json', 'custom_iptv.json',
                 'saved_playlists.json', 'yt_playlists.json', 'downloads_history.json']
    try:
        with zipfile.ZipFile(source, 'r') as zf:
            available = zf.namelist()
        known = [f for f in available if f in file_labels]

        cache_files = [f for f in available if f.startswith("cat_cache_") and f.endswith(".json")]
        if cache_files:
            known.append('__cache__')
            file_labels['__cache__'] = 'Caché de Categorías ({0})'.format(len(cache_files))

        if not known:
            xbmcgui.Dialog().ok("EspaTV", "Este backup no contiene datos reconocidos."); return
        options = [file_labels.get(f, f) for f in known]
        selected = xbmcgui.Dialog().multiselect("¿Qué quieres restaurar?", options)
        if not selected: return
        files_to_restore = [known[i] for i in selected]
        with zipfile.ZipFile(source, 'r') as zf:
            for fz in files_to_restore:
                if fz == '__cache__':
                    for cf in cache_files:
                        data = zf.read(cf)
                        with open(os.path.join(profile, cf), 'wb') as f_out:
                            f_out.write(data)
                    continue
                dest_path = os.path.join(profile, fz)
                if fz in mergeable and os.path.exists(dest_path):
                    choice = xbmcgui.Dialog().select(file_labels[fz], ["Sustituir (borrar actual)", "Añadir (fusionar con actual)", "Omitir"])
                    if choice == 2 or choice == -1: continue
                    elif choice == 1:
                        try:
                            with open(dest_path, 'r', encoding='utf-8') as f: current = json.load(f)
                            with zf.open(fz) as zfile: backup = json.load(zfile)
                            if isinstance(current, list) and isinstance(backup, list):
                                merged = current + [x for x in backup if x not in current]
                                with open(dest_path, 'w', encoding='utf-8') as f: json.dump(merged, f, ensure_ascii=False)
                                continue
                            elif isinstance(current, dict) and isinstance(backup, dict):
                                current.update(backup)
                                with open(dest_path, 'w', encoding='utf-8') as f: json.dump(current, f, ensure_ascii=False)
                                continue
                        except (OSError, ValueError):
                            pass
                resolved = os.path.realpath(os.path.join(profile, fz))
                if not resolved.startswith(os.path.realpath(profile)):
                    continue
                zf.extract(fz, profile)
        xbmcgui.Dialog().notification("EspaTV", "Restauración completada", xbmcgui.NOTIFICATION_INFO)
    except (OSError, zipfile.BadZipFile, ValueError) as e:
        xbmcgui.Dialog().ok("Error", "Fallo en restauración: {0}".format(e))


def delete_single(fname):
    path = os.path.join(_get_backup_dir(), fname)
    if xbmcgui.Dialog().yesno("EspaTV", "¿Eliminar '{0}'?".format(fname)):
        try:
            os.remove(path)
            xbmcgui.Dialog().notification("EspaTV", "Backup eliminado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except OSError as e:
            xbmcgui.Dialog().ok("Error", str(e))


def export_favorites_txt():
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaTV", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_WARNING)
        return

    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return

    dest = os.path.join(d, 'favoritos_EspaTV.txt')
    try:
        with open(dest, 'w', encoding='utf-8') as f:
            f.write("Favoritos EspaTV -- {0}\n".format(time.strftime('%d/%m/%Y %H:%M')))
            f.write("Total: {0} favoritos\n".format(len(favs)))
            f.write("=" * 50 + "\n\n")
            for fav in favs:
                title = fav.get('title', 'Sin titulo')
                url = fav.get('url', '')
                action = fav.get('action', '')
                f.write("{0}\n".format(title))
                if url:
                    f.write("  URL: {0}\n".format(url))
                if action:
                    f.write("  Tipo: {0}\n".format(action))
                f.write("\n")
        xbmcgui.Dialog().notification("EspaTV", "Exportados {0} favoritos a TXT".format(len(favs)))
    except OSError as e:
        xbmcgui.Dialog().ok("Error", "No se pudo exportar: {0}".format(e))


def menu():
    h = int(sys.argv[1])
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    li = xbmcgui.ListItem(label="[COLOR limegreen][B]Crear Backup[/B][/COLOR]")
    li.setArt({'icon': _ico('bkp_crear.png')})
    li.setInfo('video', {'plot': "Crea una copia ZIP de tus datos.\nPuedes elegir qué incluir y dónde guardarla."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="create_backup_full"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Restaurar / Ver Backups")
    li.setArt({'icon': _ico('bkp_restaurar.png')})
    li.setInfo('video', {'plot': "Lista los backups creados. Permite restaurar selectivamente."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="list_backups"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[COLOR gold]Importar Backup externo[/COLOR]")
    li.setArt({'icon': _ico('bkp_importar.png')})
    li.setInfo('video', {'plot': "Importa un archivo ZIP desde cualquier ubicación.\nPuedes elegir qué datos restaurar.\nÚtil para backups compartidos o de otro dispositivo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="import_backup"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR cyan]Exportar Favoritos a TXT[/COLOR]")
    li.setArt({'icon': _ico('bkp_exportar_txt.png')})
    li.setInfo('video', {'plot': "Genera un archivo de texto plano con la lista de favoritos."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="export_favs_txt"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
