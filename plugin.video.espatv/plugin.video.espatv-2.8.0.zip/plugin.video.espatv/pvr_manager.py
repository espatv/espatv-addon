# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Gestor del cliente PVR IPTV Simple de Kodi.

Kodi 19/20 acepta cambios via setSetting; Kodi 21 (Omega) requiere
escribir además los `instance-settings-*.xml`. Aplicamos ambos métodos
porque escribir solo via setSetting deja el PVR Manager colgado al 0%.
"""
import os
import json
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from _user_agents import UA_DESKTOP

_PVR_ADDON_ID = "pvr.iptvsimple"

_CHROME_UA = UA_DESKTOP


def is_pvr_installed():
    try:
        xbmcaddon.Addon(_PVR_ADDON_ID)
        return True
    except RuntimeError:
        return False


def _execute_rpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params:
        payload["params"] = params
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        return {}


def enable_pvr():
    resp = _execute_rpc(
        "Addons.SetAddonEnabled",
        {"addonid": _PVR_ADDON_ID, "enabled": True},
    )
    return resp.get("result") == "OK"


def _disable_pvr():
    _execute_rpc(
        "Addons.SetAddonEnabled",
        {"addonid": _PVR_ADDON_ID, "enabled": False},
    )


def trigger_pvr_reload():
    resp = _execute_rpc("PVR.Reload")
    return resp.get("result") == "OK"


def _reset_pvr_database():
    _execute_rpc(
        "Settings.SetSettingValue",
        {"setting": "pvrmanager.resetepg", "value": True},
    )
    _execute_rpc(
        "Settings.SetSettingValue",
        {"setting": "pvrmanager.resetdb", "value": True},
    )


def _build_settings_map(m3u_url, epg_url):
    return {
        "m3uPathType":      "1",
        "m3uUrl":           m3u_url,
        "m3uCache":         "false",
        "epgPathType":      "1",
        "epgUrl":           epg_url,
        "epgCache":         "false",
        "catchupEnabled":   "false",
        "logoPathType":     "0",
        "defaultUserAgent": _CHROME_UA,
    }


def _apply_via_addon_api(m3u_url, epg_url):
    try:
        addon = xbmcaddon.Addon(_PVR_ADDON_ID)
    except RuntimeError:
        return False

    cambios = False
    for key, val in _build_settings_map(m3u_url, epg_url).items():
        if addon.getSetting(key) != val:
            addon.setSetting(key, val)
            cambios = True
    return cambios


def _apply_via_xml(m3u_url, epg_url):
    base = os.path.normpath(
        xbmcvfs.translatePath("special://userdata/addon_data/" + _PVR_ADDON_ID)
    )

    if not os.path.isdir(base):
        return False

    mapping = _build_settings_map(m3u_url, epg_url)
    cambios = False

    targets = []
    settings_xml = os.path.join(base, "settings.xml")
    if os.path.isfile(settings_xml):
        targets.append(settings_xml)
    for fn in os.listdir(base):
        if fn.startswith("instance-settings-") and fn.endswith(".xml"):
            targets.append(os.path.join(base, fn))

    for filepath in targets:
        try:
            tree = ET.parse(filepath)
            root = tree.getroot()
        except ET.ParseError as exc:
            xbmc.log(
                "[EspaTV] XML corrupto en {0}: {1}".format(filepath, exc),
                xbmc.LOGERROR,
            )
            continue

        existing_ids = set()
        file_changed = False

        for node in root.findall("setting"):
            sid = node.get("id")
            existing_ids.add(sid)
            if sid in mapping and (node.text or "") != mapping[sid]:
                node.text = mapping[sid]
                node.attrib.pop("default", None)
                file_changed = True

        for sid, val in mapping.items():
            if sid not in existing_ids:
                ET.SubElement(root, "setting", id=sid).text = val
                file_changed = True

        if file_changed:
            tree.write(filepath, encoding="utf-8", xml_declaration=False)
            cambios = True

    return cambios


def configure_pvr_settings(m3u_url, epg_url):
    """Aplica la configuración PVR (API + XML). Devuelve (exito, hubo_cambios)."""
    _apply_via_addon_api(m3u_url, epg_url)

    try:
        cambios = _apply_via_xml(m3u_url, epg_url)
    except (OSError, ET.ParseError) as exc:
        xbmc.log("[EspaTV] Error configurando PVR: " + str(exc), xbmc.LOGERROR)
        return False, False
    return True, bool(cambios)


def check_and_setup_pvr(m3u_url, epg_url):
    """Instala (si falta), reconfigura y reinicia el cliente PVR.

    Pasos: deshabilitar → escribir XML → habilitar → reset EPG.
    El deshabilitado evita bloqueos de escritura sobre los settings.
    """
    if not is_pvr_installed():
        xbmcgui.Dialog().ok(
            "EspaTV",
            "Para ver la parrilla de TV necesitas el modulo PVR IPTV Simple.\n"
            "Pulsa instalar en la siguiente pantalla.",
        )
        xbmc.executebuiltin("InstallAddon({0})".format(_PVR_ADDON_ID))
        return False

    _disable_pvr()
    time.sleep(0.5)

    success, _cambios = configure_pvr_settings(m3u_url, epg_url)
    enable_pvr()

    if not success:
        return False

    time.sleep(0.5)
    _reset_pvr_database()
    return True
