# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Todavía más — cine y animación libres de Archive.org.

Sin red propia: todas las filas delegan en la accion archive_category existente,
que resuelve con setResolvedUrl. Sin riesgo de bucle de reintentos.
"""
import sys
import urllib.parse

import xbmcgui
import xbmcplugin

# Colecciones reales de Archive.org (numFound verificado jun 2026):
# feature_films ~28000, SciFi_Horror 957, classic_cartoons 81, Blender 45.
# 'AND mediatype:movies' excluye sub-colecciones no reproducibles.
_ARCHIVE_ROWS = [
    ("Cine clásico — Feature Films",      "collection:feature_films AND mediatype:movies"),
    ("Ciencia ficción y terror clásico",  "collection:SciFi_Horror AND mediatype:movies"),
    ("Animación clásica",                 "collection:classic_cartoons AND mediatype:movies"),
    ("Blender Foundation (animación CC)", 'creator:"Blender Foundation" AND mediatype:movies'),
]


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def show_menu():
    """Punto de entrada: abre show_archive_extra directamente (un solo nivel de menú)."""
    show_archive_extra()


def show_archive_extra():
    h = int(sys.argv[1])
    plot = ("Resultados en directo desde Internet Archive (dominio público / CC).\n"
            "El catálogo puede variar. Reproducción directa desde Archive.org.")
    for label, query in _ARCHIVE_ROWS:
        li = xbmcgui.ListItem(label=f"[B]{label}[/B]")
        li.setArt({'icon': 'DefaultMovies.png'})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="archive_category", q=query, page=1),
                                    listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)
