# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Utilidad genérica para descargar y parsear horarios GTFS, sin tiempo real."""
import csv
import datetime
import io
import os
import time
import zipfile

import requests

_TIMEOUT = 60
_GTFS_MAX_AGE = 7 * 24 * 3600  # 7 días


def necesita_actualizar(zip_path):
    """True si el ZIP no existe, está caducado, o no es un ZIP válido."""
    if not os.path.isfile(zip_path):
        return True
    if time.time() - os.path.getmtime(zip_path) > _GTFS_MAX_AGE:
        return True
    if not zipfile.is_zipfile(zip_path):
        return True
    return False


def descargar(url, zip_path):
    """Descarga GTFS ZIP a zip_path de forma atómica. Lanza excepción si falla."""
    resp = requests.get(url, timeout=_TIMEOUT, headers={"User-Agent": "Mozilla/5.0 EspaTV/1.0"})
    resp.raise_for_status()
    tmp_path = zip_path + ".tmp"
    try:
        with open(tmp_path, "wb") as f:
            f.write(resp.content)
        if not zipfile.is_zipfile(tmp_path):
            raise ValueError("Descarga corrupta: no es un ZIP válido")
        os.replace(tmp_path, zip_path)
    except Exception:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        raise


def _csv(zf, name):
    try:
        with zf.open(name) as f:
            return list(csv.DictReader(io.TextIOWrapper(f, encoding="utf-8-sig")))
    except KeyError:
        return []


def get_paradas(zip_path, route_type=None):
    """Lista ordenada de (stop_id, stop_name). Filtra por route_type si se indica."""
    with zipfile.ZipFile(zip_path) as zf:
        stops = {r["stop_id"].strip(): r["stop_name"].strip() for r in _csv(zf, "stops.txt")}
        if route_type is None:
            return sorted(stops.items(), key=lambda x: x[1].lower())

        route_ids = {r["route_id"].strip() for r in _csv(zf, "routes.txt")
                     if r.get("route_type", "").strip() == str(route_type)}
        trips_ids = {r["trip_id"].strip() for r in _csv(zf, "trips.txt")
                     if r.get("route_id", "").strip() in route_ids}
        stop_ids = {r["stop_id"].strip() for r in _csv(zf, "stop_times.txt")
                    if r.get("trip_id", "").strip() in trips_ids}
        return sorted([(sid, stops[sid]) for sid in stop_ids if sid in stops],
                      key=lambda x: x[1].lower())


def get_horario_hoy(zip_path, stop_id, desde_min=0, route_type=None):
    """Lista de (dep_min, dep_str, headsign) para stop_id hoy desde desde_min.
    Los tiempos GTFS >24h (servicio nocturno) se representan correctamente.
    """
    today = datetime.date.today()
    date_str = today.strftime("%Y%m%d")
    dow = ["monday","tuesday","wednesday","thursday","friday","saturday","sunday"][today.weekday()]

    with zipfile.ZipFile(zip_path) as zf:
        # Servicios activos hoy
        activos = set()
        for r in _csv(zf, "calendar.txt"):
            sid = r.get("service_id","").strip()
            if r.get("start_date","").strip() <= date_str <= r.get("end_date","").strip():
                if r.get(dow,"0").strip() == "1":
                    activos.add(sid)
        for r in _csv(zf, "calendar_dates.txt"):
            if r.get("date","").strip() == date_str:
                sid = r.get("service_id","").strip()
                if r.get("exception_type","").strip() == "1":
                    activos.add(sid)
                elif r.get("exception_type","").strip() == "2":
                    activos.discard(sid)

        # Trips activos (con headsign)
        route_ids = None
        if route_type is not None:
            route_ids = {r["route_id"].strip() for r in _csv(zf, "routes.txt")
                         if r.get("route_type","").strip() == str(route_type)}
        trips = {}
        for r in _csv(zf, "trips.txt"):
            if r.get("service_id","").strip() not in activos:
                continue
            if route_ids is not None and r.get("route_id","").strip() not in route_ids:
                continue
            trips[r["trip_id"].strip()] = r.get("trip_headsign","").strip()

        # Salidas en la parada
        deps = []
        for r in _csv(zf, "stop_times.txt"):
            if r.get("stop_id","").strip() != stop_id:
                continue
            tid = r.get("trip_id","").strip()
            if tid not in trips:
                continue
            raw = (r.get("departure_time") or r.get("arrival_time") or "").strip()
            parts = raw.split(":")
            if len(parts) < 2:
                continue
            try:
                h, m = int(parts[0]), int(parts[1])
                dep_min = h * 60 + m
                display = "{:02d}:{:02d}".format(h % 24, m)
                deps.append((dep_min, display, trips[tid]))
            except (ValueError, IndexError):
                continue

    deps.sort(key=lambda x: x[0])
    return [(a, b, c) for a, b, c in deps if a >= desde_min]
