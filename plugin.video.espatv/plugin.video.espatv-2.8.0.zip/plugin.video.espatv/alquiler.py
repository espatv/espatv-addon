# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Alquiler — Evolución del precio del alquiler por provincia (IPC, INE).
Fuente: IPC tabla 76142, subgrupo 'Alquiler de vivienda', variación anual mensual.
Fetch paralelo de 52 series por provincia (cada una <2KB) → carga rápida sin tirar 41 MB."""

import json
import os
import sys
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG           = "[EspaTV-ALQ]"
_PROFILE       = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_FILE    = os.path.join(_PROFILE, "alquiler_cache.json")
_CACHE_VERSION = 4  # bump al cambiar la forma de los datos cacheados
_CACHE_TTL     = 2 * 24 * 3600  # 2 días (datos mensuales del INE)
_TIMEOUT       = 12
_MAX_WORKERS   = 10
_MEDIA         = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

# IPC tabla 76142, subgrupo "Alquiler de vivienda": códigos de serie de "Variación anual"
# extraídos una sola vez del INE (estables, no cambian). Quedan fuera la nacional y "lo que va".
_PROV_SERIES = [
    ("Albacete",                "IPC308975"),
    ("Alicante/Alacant",        "IPC309159"),
    ("Almería",                 "IPC309343"),
    ("Araba/Álava",             "IPC308791"),
    ("Asturias",                "IPC314495"),
    ("Ávila",                   "IPC309527"),
    ("Badajoz",                 "IPC309711"),
    ("Balears, Illes",          "IPC309895"),
    ("Barcelona",               "IPC310079"),
    ("Bizkaia",                 "IPC317255"),
    ("Burgos",                  "IPC310263"),
    ("Cáceres",                 "IPC310447"),
    ("Cádiz",                   "IPC310631"),
    ("Cantabria",               "IPC315599"),
    ("Castellón/Castelló",      "IPC310815"),
    ("Ceuta",                   "IPC317807"),
    ("Ciudad Real",             "IPC310999"),
    ("Córdoba",                 "IPC311183"),
    ("Coruña, A",               "IPC311367"),
    ("Cuenca",                  "IPC311551"),
    ("Gipuzkoa",                "IPC312287"),
    ("Girona",                  "IPC311735"),
    ("Granada",                 "IPC311919"),
    ("Guadalajara",             "IPC312103"),
    ("Huelva",                  "IPC312471"),
    ("Huesca",                  "IPC312655"),
    ("Jaén",                    "IPC312839"),
    ("León",                    "IPC313023"),
    ("Lleida",                  "IPC313207"),
    ("Lugo",                    "IPC313575"),
    ("Madrid",                  "IPC313759"),
    ("Málaga",                  "IPC313943"),
    ("Melilla",                 "IPC317991"),
    ("Murcia",                  "IPC314127"),
    ("Navarra",                 "IPC314311"),
    ("Ourense",                 "IPC318175"),
    ("Palencia",                "IPC314679"),
    ("Palmas, Las",             "IPC314863"),
    ("Pontevedra",              "IPC315047"),
    ("Rioja, La",               "IPC313391"),
    ("Salamanca",               "IPC315231"),
    ("Santa Cruz de Tenerife",  "IPC315415"),
    ("Segovia",                 "IPC315783"),
    ("Sevilla",                 "IPC315967"),
    ("Soria",                   "IPC316151"),
    ("Tarragona",               "IPC316335"),
    ("Teruel",                  "IPC316519"),
    ("Toledo",                  "IPC316703"),
    ("Valencia/València",       "IPC316887"),
    ("Valladolid",              "IPC317071"),
    ("Zamora",                  "IPC317439"),
    ("Zaragoza",                "IPC317623"),
]

_SERIE_URL = "https://servicios.ine.es/wstempus/js/ES/DATOS_SERIE/{cod}?nult=300&det=0"

_MESES = {
    1: "ene",  2: "feb",  3: "mar",  4: "abr",
    5: "may",  6: "jun",  7: "jul",  8: "ago",
    9: "sep", 10: "oct", 11: "nov", 12: "dic",
}


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _fmt_periodo(anyo, mes):
    # (2026, 3) -> 'mar. 2026'
    return "{0}. {1}".format(_MESES.get(mes, "?"), anyo)


# Caché

def _load_cache():
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if obj.get("v") != _CACHE_VERSION:
            return None
        if time.time() - obj.get("ts", 0) >= _CACHE_TTL:
            return None
        data = obj.get("data")
        if not isinstance(data, list) or not data:
            return None
        # Validación defensiva: cada item debe ser [prov, [[anyo,mes,val], ...]]
        first = data[0]
        if (not isinstance(first, list) or len(first) < 2 or
            not isinstance(first[1], list) or not first[1] or
            not isinstance(first[1][0], list) or len(first[1][0]) < 3):
            return None
        return data
    except (OSError, ValueError, KeyError, IndexError, TypeError):
        return None


def _save_cache(data):
    try:
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(
                {"ts": time.time(), "v": _CACHE_VERSION, "data": data},
                f, ensure_ascii=False
            )
    except OSError as e:
        xbmc.log("{} Error caché: {}".format(_LOG, e), xbmc.LOGWARNING)


# Fetch paralelo

def _fetch_one(session, prov_name, cod):
    """Devuelve (prov_name, [(anyo,mes,valor), ...]) más reciente primero, o None si falla."""
    try:
        url = _SERIE_URL.format(cod=cod)
        resp = session.get(url, timeout=_TIMEOUT)
        resp.raise_for_status()
        s = resp.json()
        # Ordenar por Fecha DESC (newest first), filtrando puntos válidos
        puntos = []
        for d in (s.get("Data") or []):
            if d.get("Secreto"):
                continue
            anyo = d.get("Anyo")
            mes  = d.get("FK_Periodo")
            val  = d.get("Valor")
            fecha = d.get("Fecha", 0)
            if anyo is None or mes is None or val is None:
                continue
            try:
                puntos.append((int(fecha), int(anyo), int(mes), round(float(val), 1)))
            except (ValueError, TypeError):
                continue
        puntos.sort(key=lambda p: p[0], reverse=True)
        historico = [(a, m, v) for _f, a, m, v in puntos]
        if not historico:
            return None
        return (prov_name, historico)
    except Exception as e:
        xbmc.log("{} Error serie {}: {}".format(_LOG, cod, e), xbmc.LOGWARNING)
        return None


def _fetch_data():
    """Descarga todas las series provinciales en paralelo y devuelve lista [(prov, historico), ...]."""
    results = []
    with requests.Session() as session:
        session.headers.update({"Accept": "application/json"})
        with ThreadPoolExecutor(max_workers=_MAX_WORKERS) as pool:
            futures = [pool.submit(_fetch_one, session, prov, cod)
                       for prov, cod in _PROV_SERIES]
            for fut in as_completed(futures):
                r = fut.result()
                if r is not None:
                    results.append(r)
    return results


def _load_data():
    cached = _load_cache()
    if cached is not None:
        return cached
    xbmcgui.Dialog().notification(
        "Alquiler", "Consultando datos del INE…",
        xbmcgui.NOTIFICATION_INFO, 2500
    )
    try:
        data = _fetch_data()
        if data:
            _save_cache(data)
        return data
    except Exception as e:
        xbmc.log("{} Error general fetch: {}".format(_LOG, e), xbmc.LOGERROR)
        return None


# Menú Kodi

def _color_for(v):
    if v > 5:    return ("tomato",     "+")
    if v > 2:    return ("orange",     "+")
    if v > 0:    return ("gold",       "+")
    if v == 0:   return ("white",      "")
    return            ("lightgreen", "")


def alquiler_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_alquiler.png")

    data = _load_data()

    if not data:
        li = xbmcgui.ListItem(
            label="[COLOR red]Error al obtener datos del INE — comprueba la conexión[/COLOR]"
        )
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    # Ordenar por variación más reciente desc
    def last_var(historico):
        try:
            return float(historico[0][2])
        except (IndexError, KeyError, TypeError, ValueError):
            return 0.0

    items = sorted(data, key=lambda x: last_var(x[1]), reverse=True)

    _RECIENTES = 12  # meses mostrados en el plot del menú

    # Botón de info fijo arriba
    li_info = xbmcgui.ListItem(label="[COLOR aqua][ ¿Cómo leer estos datos? ][/COLOR]")
    li_info.setArt({"icon": "DefaultIconInfo.png"})
    li_info.setInfo("video", {"plot": "Pulsa para entender qué significa la variación anual del alquiler."})
    li_info.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="alquiler_info"),
                                listitem=li_info, isFolder=False)

    for prov_name, historico in items:
        if not historico:
            continue
        anyo, mes, ultimo_val = historico[0][0], historico[0][1], historico[0][2]
        periodo_str = _fmt_periodo(anyo, mes)
        color, signo = _color_for(ultimo_val)

        var_str = "[B][COLOR {0}]{1}{2:.1f}%[/COLOR][/B]".format(color, signo, ultimo_val)
        label = "{0}  {1}  [COLOR grey]({2})[/COLOR]".format(prov_name, var_str, periodo_str)

        # Plot limpio: últimos 12 meses + nota de histórico completo
        recientes = historico[:_RECIENTES]
        plot_lines = [
            "[B]{0}[/B]".format(prov_name),
            "[COLOR grey]Fuente: INE — IPC subgrupo Alquiler de vivienda[/COLOR]",
            "",
        ]
        for a, m, v in recientes:
            c, sg = _color_for(v)
            plot_lines.append(
                "{0}:  [COLOR {1}]{2}{3:.1f}%[/COLOR]".format(_fmt_periodo(a, m), c, sg, v)
            )
        if len(historico) > len(recientes):
            primero_a, primero_m = historico[-1][0], historico[-1][1]
            plot_lines.append("")
            plot_lines.append(
                "[COLOR grey]…y {0} meses más — pulsa para ver el histórico desde {1}[/COLOR]".format(
                    len(historico) - len(recientes), _fmt_periodo(primero_a, primero_m)
                )
            )

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": prov_name, "plot": "\n".join(plot_lines)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="alquiler_detalle", prov=prov_name),
            listitem=li, isFolder=False,
        )

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar datos ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Elimina la caché y recarga los datos del INE."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="alquiler_refresh"),
                                listitem=li_r, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def alquiler_detalle(prov_name):
    """Abre un textviewer con el histórico completo de la provincia, agrupado por año."""
    cached = _load_cache()
    if not cached:
        cached = _load_data()

    historico = None
    if cached:
        for pname, hist in cached:
            if pname == prov_name:
                historico = hist
                break

    if not historico:
        xbmcgui.Dialog().notification(
            "Alquiler", "No hay datos para {}".format(prov_name),
            xbmcgui.NOTIFICATION_ERROR, 3000,
        )
        return

    SEP = "─" * 44

    # Estadísticas rápidas
    valores = [v for _, _, v in historico]
    val_max = max(valores) if valores else 0.0
    val_min = min(valores) if valores else 0.0
    primero = historico[-1]
    ultimo  = historico[0]

    lines = [
        "VARIACIÓN ANUAL DEL ALQUILER — {}".format(prov_name.upper()),
        SEP,
        "Histórico mensual: {} meses ({} → {})".format(
            len(historico),
            _fmt_periodo(primero[0], primero[1]),
            _fmt_periodo(ultimo[0], ultimo[1]),
        ),
        "Máxima subida: {:+.1f} %    Mínima: {:+.1f} %".format(val_max, val_min),
        SEP,
        "",
    ]

    # Agrupar por año (el histórico viene ordenado del más reciente al más antiguo).
    # El marcador ▲▼● da feedback visual rápido sin necesidad de color.
    def _marker(v):
        if v > 5:   return "▲▲▲"   # subida fuerte
        if v > 2:   return "▲▲ "   # moderada
        if v > 0:   return "▲  "   # leve
        if v == 0:  return "●  "   # sin cambio
        return                "▼  "  # bajada

    last_year = None
    for a, m, v in historico:
        if a != last_year:
            if last_year is not None:
                lines.append("")
            lines.append("═══  {}  ═══".format(a))
            last_year = a
        sign = "+" if v > 0 else ""
        lines.append("  {:<10} {:>9}   {}".format(
            _fmt_periodo(a, m),
            "{}{:.1f} %".format(sign, v),
            _marker(v),
        ))

    lines += [
        "",
        SEP,
        "Fuente: INE — IPC subgrupo «Alquiler de vivienda»",
        "Tabla 76142 — variación anual del índice mensual",
        "(no refleja el precio absoluto en €/m²)",
    ]

    xbmcgui.Dialog().textviewer(
        "Alquiler — {}".format(prov_name),
        "\n".join(lines),
    )


def alquiler_info():
    """Explica qué mide la variación anual del alquiler."""
    SEP = "─" * 44
    lines = [
        "¿QUÉ SIGNIFICA LA VARIACIÓN ANUAL DEL ALQUILER?",
        SEP,
        "",
        "El porcentaje indica cuánto subió o bajó el coste",
        "del alquiler respecto al MISMO MES del año anterior.",
        "",
        "No es una subida acumulada.",
        "",
        "Ejemplo:",
        "  Si en marzo 2026 fue +4.5 %,",
        "  el alquiler costó un 4.5 % MÁS que en marzo 2025.",
        "  No significa que se sumó a meses anteriores.",
        "",
        SEP,
        "CÓMO LEER LA INTENSIDAD",
        SEP,
        "",
        "En la lista de provincias (color del porcentaje):",
        "  Rojo       (> 5 %)      subida fuerte",
        "  Naranja    (2 – 5 %)    subida moderada",
        "  Amarillo   (0 – 2 %)    subida leve",
        "  Blanco     (0 %)        sin cambio",
        "  Verde      (negativo)   bajada respecto al año anterior",
        "",
        "En el histórico de cada provincia (marcador):",
        "  ▲▲▲   subida fuerte (> 5 %)",
        "  ▲▲    subida moderada (2 – 5 %)",
        "  ▲     subida leve (0 – 2 %)",
        "  ●     sin cambio",
        "  ▼     bajada",
        "",
        "Las provincias se ordenan de mayor a menor subida",
        "según el dato más reciente.",
        "",
        SEP,
        "FUENTE DE LOS DATOS",
        SEP,
        "",
        "Instituto Nacional de Estadística (INE)",
        "Índice de Precios de Consumo (IPC)",
        "Subgrupo: Alquiler de vivienda — Tabla 76142",
        "Publicación: mensual, ~2 semanas tras el cierre del mes.",
        "",
        "Los datos reflejan la variación del ÍNDICE de precios,",
        "no el precio absoluto en euros por metro cuadrado.",
    ]
    xbmcgui.Dialog().textviewer(
        "¿Cómo leer estos datos?",
        "\n".join(lines),
    )


def alquiler_refresh():
    try:
        os.remove(_CACHE_FILE)
    except OSError:
        pass
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="alquiler_menu")))
