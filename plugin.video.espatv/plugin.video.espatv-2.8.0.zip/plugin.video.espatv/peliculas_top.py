# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Lista de películas legendarias con metadatos TMDB y paginación."""
import json
import os
import sys
import threading
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def get_movies_list():
    return [
        "Avatar", "Vengadores: Endgame", "Avatar: El sentido del agua", "Titanic", "Star Wars: El despertar de la fuerza",
        "Vengadores: Infinity War", "Spider-Man: No Way Home", "Jurassic World", "El rey león", "Los Vengadores",
        "Fast & Furious 7", "Top Gun: Maverick", "Frozen II", "Barbie", "Vengadores: La era de Ultrón",
        "Super Mario Bros.: La película", "Black Panther", "Harry Potter y las Reliquias de la Muerte - Parte 2",
        "Star Wars: Los últimos Jedi", "Jurassic World: El reino caído", "Frozen", "La bella y la bestia",
        "Los Increíbles 2", "El destino de los furiosos", "Iron Man 3", "Minions", "Capitán América: Civil War",
        "Aquaman", "El Señor de los Anillos: El retorno del Rey", "Spider-Man: Lejos de casa", "Capitana Marvel",
        "Transformers: El lado oscuro de la luna", "Skyfall", "Transformers: La era de la extinción",
        "El caballero oscuro: La leyenda renace", "Joker", "Star Wars: El ascenso de Skywalker", "Toy Story 4",
        "Toy Story 3", "Piratas del Caribe: El cofre del hombre muerto", "El rey león (1994)", "Buscando a Dory",
        "Star Wars: La amenaza fantasma", "Alicia en el país de las maravillas", "Zootrópolis", "Harry Potter y la piedra filosofal",
        "Gru, mi villano favorito 3", "Buscando a Nemo", "Harry Potter y la Orden del Fénix", "Harry Potter y el misterio del príncipe",
        "El Señor de los Anillos: Las dos torres", "Shrek 2", "Bohemian Rhapsody", "El Señor de los Anillos: La comunidad del anillo",
        "Harry Potter y las Reliquias de la Muerte - Parte 1", "El Hobbit: Un viaje inesperado", "El caballero oscuro",
        "Jumanji: Bienvenidos a la jungla", "Harry Potter y el cáliz de fuego", "Spider-Man 3", "Transformers: La venganza de los caídos",
        "Spider-Man: Homecoming", "Ice Age 3: El origen de los dinosaurios", "Ice Age 4: La formación de los continentes",
        "El libro de la selva", "Batman v Superman: El amanecer de la justicia", "El Hobbit: La desolación de Smaug",
        "El Hobbit: La batalla de los cinco ejércitos", "Thor: Ragnarok", "Guardianes de la Galaxia Vol. 2",
        "Inside Out (Del revés)", "Venom", "Thor: Love and Thunder", "Deadpool 2", "Deadpool", "Star Wars: La venganza de los Sith",
        "Spider-Man", "Wonder Woman", "Independence Day", "Animales fantásticos y dónde encontrarlos", "Shrek Tercero",
        "Coco", "Jumanji: Siguiente nivel", "Harry Potter y la cámara secreta", "Star Wars: Una nueva esperanza",
        "ET El extraterrestre", "Misión Imposible: Fallout", "2012", "Indiana Jones y el reino de la calavera de cristal",
        "Fast & Furious 6", "Piratas del Caribe: En el fin del mundo", "El código Da Vinci", "X-Men: Días del futuro pasado",
        "Madagascar 3: De marcha por Europa", "Las crónicas de Narnia: El león, la bruja y el armario", "Man of Steel",
        "Monstruos University", "Matrix Reloaded", "Up", "Gravity", "Capitán América: El Soldado de Invierno",
        "La saga Crepúsculo: Amanecer - Parte 2", "La saga Crepúsculo: Amanecer - Parte 1", "La saga Crepúsculo: Luna nueva",
        "La saga Crepúsculo: Eclipse", "Forrest Gump", "El sexto sentido", "Interestelar", "Origen", "Gladiator",
        "Salvar al soldado Ryan", "La lista de Schindler", "El Padrino", "El Padrino Parte II", "Cadena perpetua",
        "Pulp Fiction", "El club de la lucha", "Matrix", "Goodfellas (Uno de los nuestros)", "Seven", "El silencio de los corderos",
        "La vida es bella", "Ciudad de Dios", "El viaje de Chihiro", "Parásitos", "Psicosis", "Casablanca",
        "El bueno, el feo y el malo", "12 hombres sin piedad", "La milla verde", "El gran dictador", "Cinema Paradiso",
        "Regreso al futuro", "Terminator 2: El juicio final", "Alien, el octavo pasajero", "Apocalypse Now",
        "Django desencadenado", "El resplandor", "WALL-E", "La princesa Mononoke", "Oldboy", "Amélie", "El laberinto del fauno"
    ]


def _get_peliculas_top_cache_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, "peliculas_top_thumbs.json")


def _load_peliculas_top_cache():
    path = _get_peliculas_top_cache_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _trigger_bg_enrich_page(page_items):
    import metadata_enricher as me
    def _fetch():
        try:
            items = [{'title': m, 'media_type': 'movie'} for m in page_items]
            results = me.batch_enrich(items, max_workers=2)
            if any(results):
                xbmc.executebuiltin("Container.Refresh")
        except Exception:
            pass
    threading.Thread(target=_fetch, daemon=True).start()


def show(page):
    import pelis_grid as _pg
    mode = _pg.get_grid_mode()
    if mode == 'grid':
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        _pg.show_from_peliculas_top()
        return

    import metadata_enricher as me

    try:
        page = int(page)
    except (ValueError, TypeError):
        page = 1
    per_page = 50
    movies = get_movies_list()
    total = len(movies)
    start = (page - 1) * per_page
    end = start + per_page
    page_items = movies[start:end]

    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    af = addon.getAddonInfo('fanart')

    first_meta = me.enrich(title=page_items[0], media_type='movie', use_cache_only=True) if page_items else {}
    has_meta = bool(first_meta)
    if not has_meta:
        _trigger_bg_enrich_page(page_items)

    if mode == 'boton' and page == 1:
        icon_grid = os.path.join(addon.getAddonInfo('path'), 'resources', 'media', 'modo_grid.png')
        li_grid = xbmcgui.ListItem(label='[COLOR FF38BDF8][B]Modo Grid[/B][/COLOR]')
        li_grid.setArt({'icon': icon_grid})
        li_grid.setInfo('video', {'plot': 'Vista inmersiva de las 130+ películas legendarias al estilo Netflix.'})
        li_grid.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action='pelis_grid_historia'),
                                    listitem=li_grid, isFolder=False)

    for m in page_items:
        meta = me.enrich(title=m, media_type='movie', use_cache_only=True)
        li = xbmcgui.ListItem(label=m)

        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or ai
        else:
            li.setArt({'thumb': ai, 'icon': ai, 'poster': ai, 'fanart': af})
            li.setInfo('video', {'title': m, 'mediatype': 'movie'})
            poster = ai

        cm = [
            ("Buscar en webs de torrent", "RunPlugin({0})".format(_u(action='elementum_search', q=m))),
            ("Añadir a Mis Favoritos", "RunPlugin({0})".format(
                _u(action='add_favorite', title=m, fav_url=m, icon=poster,
                   platform='Legendarias', fav_action='lfr', params=json.dumps({'q': m}))
            )),
        ]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action='search_alt_prompt', q=m, ot=poster, mode='movie'), listitem=li, isFolder=False)

    if end < total:
        li = xbmcgui.ListItem(label="Siguiente Página ({0}) >>".format(page + 1))
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="peliculas_top", page=page + 1), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def cache_covers():
    import metadata_enricher as me

    if not xbmcgui.Dialog().yesno("EspaTV",
            "¿Quieres descargar los metadatos de las 130+ películas?\n\n"
            "Incluye sinopsis en español, actores y director.\n"
            "[COLOR yellow]Tardará unos minutos[/COLOR] pero se guarda 30 días."):
        return

    movies = get_movies_list()
    items = [{'title': m, 'media_type': 'movie'} for m in movies]

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Descargando metadatos Top Películas...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "EspaTV",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_cache():
    import metadata_enricher as me

    movies = get_movies_list()
    me.delete_items([{'title': m, 'media_type': 'movie'} for m in movies])
    xbmcgui.Dialog().notification("EspaTV", "Metadatos eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")
