# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Tops públicos de Trakt.tv en tiempo real (tendencia, populares, vistos, etc.)."""
import json
import os
import sys
import threading
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

_TRAKT_BASE = "https://api.trakt.tv"
_TTL        = 10 * 3600
_LOG_TAG    = "[EspaTV-TT]"

# wrapped=True → el objeto película/serie está en item['movie'] o item['show']
# wrapped=False → item es directamente el objeto película/serie (endpoint popular)
_TOPS = [
    ("Tendencia ahora — Películas",  "movies/trending",      "movie", True),
    ("Más populares — Películas",    "movies/popular",       "movie", False),
    ("Más vistas hoy — Películas",   "movies/watched/daily", "movie", True),
    ("Más esperadas — Películas",    "movies/anticipated",   "movie", True),
    ("Taquilla USA",                 "movies/boxoffice",     "movie", True),
    ("Tendencia ahora — Series",     "shows/trending",       "show",  True),
    ("Más populares — Series",       "shows/popular",        "show",  False),
    ("Más vistas hoy — Series",      "shows/watched/daily",  "show",  True),
    ("Más esperadas — Series",       "shows/anticipated",    "show",  True),
    ("Más favoritadas — Películas",  "movies/favorited/daily","movie", True),
    ("Más favoritadas — Series",     "shows/favorited/daily", "show",  True),
]

_GENRE_ES = {
    'action': 'Acción', 'adventure': 'Aventura', 'animation': 'Animación',
    'comedy': 'Comedia', 'crime': 'Crimen', 'documentary': 'Documental',
    'drama': 'Drama', 'fantasy': 'Fantasía', 'history': 'Historia',
    'horror': 'Terror', 'music': 'Música', 'mystery': 'Misterio',
    'romance': 'Romance', 'science-fiction': 'Ciencia ficción',
    'thriller': 'Suspense', 'war': 'Bélica', 'western': 'Western',
    'family': 'Familia', 'kids': 'Infantil',
}


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), level)

def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espatv_trakt_tops_cache.json')

def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}

def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        _log("cache save: {0}".format(e), xbmc.LOGWARNING)

def _trakt_get(path, page=1, paginate=True):
    api_key = core_settings.get_trakt_api_key()
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': api_key,
    }
    params = {'extended': 'full', 'limit': 20}
    if paginate:
        params['page'] = page
    url = "{0}/{1}".format(_TRAKT_BASE, path)
    try:
        r = requests.get(url, params=params, headers=headers, timeout=12)
        _log("{0} -> {1}".format(path, r.status_code))
        if r.status_code == 429:
            _log("rate limit hit", xbmc.LOGWARNING)
            return None, 1
        if r.status_code != 200:
            return None, 1
        total = int(r.headers.get('X-Pagination-Page-Count', 1))
        return r.json(), total
    except (requests.RequestException, ValueError) as e:
        _log("fetch error {0}: {1}".format(path, e), xbmc.LOGERROR)
        return None, 1

def _extract_media(item, media_type, wrapped):
    if wrapped:
        return item.get(media_type) or {}
    return item

def _genres_str(genres_list):
    translated = [_GENRE_ES.get(g, g.capitalize()) for g in (genres_list or [])[:3]]
    return ' / '.join(translated)

def _fetch_list(path, media_type, wrapped, page):
    cache = _load_cache()
    cache_key = "{0}|{1}".format(path, page)
    entry = cache.get(cache_key, {})
    # Solo se sirve caché con datos: una entrada vacía (fallo transitorio cacheado) se
    # trata como miss y se re-pide. Evita envenenar la fila durante todo el TTL.
    if entry.get('items') and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['items'], entry.get('total_pages', 1)

    paginate = path != 'movies/boxoffice'
    raw, total_pages = _trakt_get(path, page=page, paginate=paginate)

    if raw is None:
        cached_items = entry.get('items')
        if cached_items:
            _log("{0} inaccesible, usando caché caducada".format(path), xbmc.LOGWARNING)
            return cached_items, entry.get('total_pages', 1)
        return [], 1

    items = []
    for item in raw:
        media = _extract_media(item, media_type, wrapped)
        if not media:
            continue
        ids = media.get('ids') or {}
        tmdb_id = ids.get('tmdb')
        imdb_id = ids.get('imdb') or ''
        title   = media.get('title') or media.get('name') or ''
        year    = media.get('year') or 0
        if not title:
            continue
        items.append({
            'tmdb_id':  tmdb_id,
            'imdb_id':  imdb_id,
            'title':    title,
            'year':     year,
            'overview': media.get('overview') or '',
            'rating':   media.get('rating') or 0,
            'votes':    media.get('votes') or 0,
            'runtime':  media.get('runtime') or 0,
            'genres':   _genres_str(media.get('genres')),
            'cert':     media.get('certification') or '',
        })

    if items:  # no cachear vacíos: no envenenar la caché con un fallo transitorio
        cache[cache_key] = {'ts': time.time(), 'items': items, 'total_pages': total_pages}
        _save_cache(cache)
    return items, total_pages


def _media_icon(name, fallback='DefaultVideoPlaylists.png'):
    p = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')),
        'resources', 'media', name,
    )
    return p if os.path.exists(p) else fallback


def show_menu():
    h = _handle()
    icons = {
        'movies/trending':       _media_icon('top_trending.png',   'DefaultMovies.png'),
        'movies/popular':        _media_icon('top_popular.png',    'DefaultMovies.png'),
        'movies/watched/daily':  _media_icon('top_watched.png',    'DefaultMovies.png'),
        'movies/anticipated':    _media_icon('top_anticipated.png','DefaultMovies.png'),
        'movies/boxoffice':      _media_icon('top_boxoffice.png',  'DefaultMovies.png'),
        'movies/favorited/daily':_media_icon('top_favorited.png',  'DefaultMovies.png'),
        'shows/trending':        _media_icon('top_trending.png',   'DefaultTVShows.png'),
        'shows/popular':         _media_icon('top_popular.png',    'DefaultTVShows.png'),
        'shows/watched/daily':   _media_icon('top_watched.png',    'DefaultTVShows.png'),
        'shows/anticipated':     _media_icon('top_anticipated.png','DefaultTVShows.png'),
        'shows/favorited/daily': _media_icon('top_favorited.png',  'DefaultTVShows.png'),
    }
    for label, path, media_type, wrapped in _TOPS:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icons.get(path, 'DefaultVideoPlaylists.png')})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='trakt_tops_list', path=path, media_type=media_type,
                   wrapped='1' if wrapped else '0', page=1),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def _trigger_bg_enrich(items):
    import metadata_enricher as me
    def _fetch():
        try:
            results = me.batch_enrich(items, max_workers=2)
            if any(results):
                xbmc.executebuiltin("Container.Refresh")
        except Exception:
            pass
    threading.Thread(target=_fetch, daemon=True).start()


def show_list(path, media_type, wrapped, page=1):
    import pelis_grid as _pg
    _t = 'Series' if media_type in ('tv', 'show') else 'Películas'
    if _pg.apply_grid_mode(_handle(), 'trakt', 'Trakt · {0}'.format(_t),
                           path=path, media_type=media_type, wrapped=str(wrapped)):
        return

    import metadata_enricher as me

    h   = _handle()
    page = int(page)
    items, total_pages = _fetch_list(path, media_type, wrapped, page)

    if not items:
        xbmcgui.Dialog().notification(
            "EspaTV", "No se pudo cargar el top de Trakt", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    kodi_mt = 'tvshow' if media_type == 'show' else 'movie'
    missing_meta = []

    for item in items:
        year_int = item['year'] or 0
        label    = "{0} ({1})".format(item['title'], year_int) if year_int else item['title']
        li       = xbmcgui.ListItem(label=label)

        meta = me.enrich(
            tmdb_id=item['tmdb_id'], imdb_id=item['imdb_id'],
            title=item['title'], year=year_int or None,
            media_type=media_type, use_cache_only=True,
        )
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or ''
        else:
            header = me.build_plot_header(
                item['rating'], item['genres'], runtime=item['runtime'],
            )
            li.setArt({'icon': 'DefaultVideo.png', 'fanart': af})
            info = {
                'title':    item['title'],
                'year':     year_int,
                'plot':     header + item['overview'],
                'rating':   item['rating'],
                'votes':    str(item['votes']),
                'genre':    item['genres'],
                'duration': item['runtime'] * 60 if item['runtime'] else 0,
                'mediatype': kodi_mt,
            }
            if item['cert']:
                info['mpaa'] = item['cert']
            li.setInfo('video', info)
            poster = ''
            missing_meta.append({
                'tmdb_id':    item['tmdb_id'],
                'imdb_id':    item['imdb_id'],
                'title':      item['title'],
                'year':       year_int or None,
                'media_type': media_type,
            })

        tmdb_id = (meta.get('ids') or {}).get('tmdb', item['tmdb_id']) if meta else item['tmdb_id']
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=item['title'], tmdb_id=tmdb_id or ''))),
            ("Buscar en más fuentes", "Container.Update({0})".format(
                _u(action='search_movie_multi', q=item['title'], tmdb_id=(tmdb_id or ''), media_type=media_type))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=item['title'], ot=poster, mode=media_type, tmdb_id=(tmdb_id or ''))
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)

    if page < total_pages:
        li = xbmcgui.ListItem(
            label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(
                page + 1, total_pages))
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='trakt_tops_list', path=path, media_type=media_type,
                   wrapped='1' if wrapped else '0', page=page + 1),
            listitem=li,
            isFolder=True,
        )

    if missing_meta:
        _trigger_bg_enrich(missing_meta)

    xbmcplugin.endOfDirectory(h)
