# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Calendario Astronómico Anual: eventos del año compilados del ROA."""
import datetime
import os
import sys
import urllib.parse

import xbmcgui
import xbmcplugin

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

# Eventos (mes, dia, nombre, tipo, descripcion)
# Tipos: eclipse_solar, eclipse_lunar, meteor, conjuncion, equinoccio, solsticio, planeta
_EVENTOS_2025 = [
    (1,  3,  "Cuadrántidas",               "meteor",      "Lluvia de meteoros anual. Pico de actividad con hasta 120 meteoros/hora en condiciones óptimas. Radiante en Boyero."),
    (3,  14, "Eclipse total de Luna",       "eclipse_lunar","Eclipse total de Luna visible desde América y partes de Europa/África. En España se podrá observar parte."),
    (3,  20, "Equinoccio de primavera",     "equinoccio",  "El Sol cruza el ecuador celeste hacia el norte. Inicio astronómico de la primavera en el hemisferio norte. 09:01 UTC."),
    (4,  13, "Eclipse parcial de Sol",      "eclipse_solar","Eclipse parcial de Sol visible en el noroeste de Europa. En España peninsular no es visible."),
    (5,  6,  "Eta Acuáridas",              "meteor",      "Lluvia de meteoros proveniente del cometa Halley. Pico de 50 meteoros/hora. Mejor vista desde el hemisferio sur."),
    (6,  21, "Solsticio de verano",         "solsticio",   "El día más largo del año en el hemisferio norte. El Sol alcanza su punto más alto en el cielo. 02:42 UTC."),
    (7,  28, "Delta Acuáridas del Sur",    "meteor",      "Lluvia de meteoros moderada. Hasta 20 meteoros/hora. Buena vista desde latitudes del sur."),
    (8,  12, "Perseidas",                  "meteor",      "La lluvia de meteoros más famosa del verano. Hasta 100 meteoros/hora. Radiante en la constelación de Perseo."),
    (9,  22, "Equinoccio de otoño",        "equinoccio",  "El Sol cruza el ecuador celeste hacia el sur. Inicio astronómico del otoño en el hemisferio norte. 18:19 UTC."),
    (10, 7,  "Dracónidas",                 "meteor",      "Lluvia de meteoros corta pero intensa. Pico variable; en años buenos puede superar 100 meteoros/hora."),
    (10, 21, "Oriónidas",                  "meteor",      "Meteoros del cometa Halley. Hasta 20 meteoros/hora. Radiante en Orión."),
    (11, 17, "Leónidas",                   "meteor",      "Famosa por sus tormentas de meteoros históricas. Hasta 15 meteoros/hora en años normales."),
    (12, 13, "Gemínidas",                  "meteor",      "La lluvia de meteoros más activa del año, con hasta 120 meteoros/hora. Radiante en Géminis. Origen: asteroide Faetón."),
    (12, 21, "Solsticio de invierno",      "solsticio",   "La noche más larga del año en el hemisferio norte. El Sol alcanza su punto más bajo. 15:03 UTC."),
    (12, 21, "Úrsidas",                    "meteor",      "Lluvia de meteoros modesta (10/hora) coincidente con el solsticio de invierno. Radiante en la Osa Menor."),
]

_EVENTOS_2026 = [
    (1,  3,  "Cuadrántidas",               "meteor",      "Lluvia de meteoros anual. Hasta 120 meteoros/hora. Radiante en Boyero."),
    (2,  17, "Eclipse anular de Sol",       "eclipse_solar","Eclipse anular de Sol visible en el sur de África y Antártida."),
    (3,  20, "Equinoccio de primavera",     "equinoccio",  "Inicio astronómico de la primavera. 14:46 UTC."),
    (6,  21, "Solsticio de verano",         "solsticio",   "El día más largo del año en el hemisferio norte. 08:24 UTC."),
    (8,  2,  "Eclipse total de Sol",        "eclipse_solar","Eclipse total de Sol visible en zonas del océano Ártico, Groenlandia e Islandia."),
    (8,  12, "Perseidas",                  "meteor",      "Lluvia de meteoros del verano. Hasta 100 meteoros/hora. Radiante en Perseo."),
    (8,  28, "Eclipse total de Luna",       "eclipse_lunar","Eclipse total de Luna visible desde Europa, África y América."),
    (9,  23, "Equinoccio de otoño",        "equinoccio",  "Inicio astronómico del otoño. 00:05 UTC."),
    (12, 13, "Gemínidas",                  "meteor",      "Lluvia de meteoros más activa del año. Hasta 120 meteoros/hora."),
    (12, 21, "Solsticio de invierno",      "solsticio",   "La noche más larga del año. 21:50 UTC."),
]

_TIPO_CONFIG = {
    "eclipse_solar":  ("●", "tomato",         "Eclipse Solar"),
    "eclipse_lunar":  ("○", "deepskyblue",    "Eclipse Lunar"),
    "meteor":         ("★", "gold",           "Lluvia de Meteoros"),
    "conjuncion":     ("◆", "plum",           "Conjunción Planetaria"),
    "equinoccio":     ("◈", "mediumseagreen", "Equinoccio"),
    "solsticio":      ("☼", "orange",         "Solsticio"),
    "planeta":        ("◎", "lightblue",      "Evento Planetario"),
}

_MESES_ES = ["", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
             "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
_DIAS_ES  = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _days_until(year, month, day):
    try:
        target = datetime.date(year, month, day)
        return (target - datetime.date.today()).days
    except ValueError:
        return None


def calendario_menu():
    h  = int(sys.argv[1])
    icon = _icon("cat_calendario_astro.png")
    today = datetime.date.today()
    year  = today.year
    eventos = _EVENTOS_2025 if year == 2025 else _EVENTOS_2026

    mes_actual = 0
    for mes, dia, nombre, tipo, desc in eventos:
        icono_tipo, color, tipo_label = _TIPO_CONFIG.get(tipo, ("✨", "white", tipo))
        days_left = _days_until(year, mes, dia)

        if mes != mes_actual:
            mes_actual = mes
            sep = xbmcgui.ListItem(label="[COLOR gold]──  {0} {1}  ──[/COLOR]".format(_MESES_ES[mes], year))
            sep.setArt({"icon": "DefaultAddonNone.png"})
            sep.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep, isFolder=False)

        if days_left is None:
            continue
        if days_left < 0:
            fecha_color = "grey"
        elif days_left == 0:
            fecha_color = "tomato"
        elif days_left <= 14:
            fecha_color = "gold"
        else:
            fecha_color = "white"

        try:
            d = datetime.date(year, mes, dia)
            dia_semana = _DIAS_ES[d.weekday()]
        except ValueError:
            dia_semana = ""

        label = "{0} [B][COLOR {1}]{2}[/COLOR][/B]   [COLOR grey]{3} {4} {5}[/COLOR]".format(
            icono_tipo, fecha_color, nombre, dia_semana, dia, _MESES_ES[mes]
        )
        plot = "{0}  {1}\n{2} {3} de {4} de {5}\n\n{6}".format(
            icono_tipo, nombre, dia_semana, dia, _MESES_ES[mes].lower(), year, desc
        )
        if days_left >= 0:
            plot += "\n\n[COLOR grey]Faltan {0} día{1}[/COLOR]".format(
                days_left, "s" if days_left != 1 else ""
            )

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": nombre, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
