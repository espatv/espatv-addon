# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Guía de programación (EPG) desde tdtchannels.com."""
import gzip
import hashlib
import io
import json
import os
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone

import xbmc
import core_settings

try:
    import requests
except ImportError:
    requests = None

_EPG_URL = "https://www.tdtchannels.com/epg/TV.xml.gz"
_epg_cache = {"data": None, "ts": 0}


def fetch():
    now = time.time()
    if _epg_cache["data"] and (now - _epg_cache["ts"]) < 7200:
        return _epg_cache["data"]
    try:
        ttl = core_settings.get_iptv_cache_ttl()
        if ttl <= 0:
            ttl = 7200

        c_file = ""
        programmes = None
        if core_settings.is_iptv_cache_active():
            c_dir = core_settings.get_iptv_cache_dir()
            c_key = hashlib.md5(_EPG_URL.encode('utf-8')).hexdigest()
            c_file = os.path.join(c_dir, 'epg_' + c_key + '.json')
            if os.path.exists(c_file):
                try:
                    with open(c_file, 'r', encoding='utf-8') as f:
                        meta = json.load(f)
                    if (now - meta.get('ts', 0)) < ttl:
                        programmes = meta.get('data', {})
                except (OSError, ValueError):
                    pass

        if not programmes:
            r = requests.get(_EPG_URL, timeout=20)
            if r.status_code != 200:
                return {}
            xml_data = gzip.GzipFile(fileobj=io.BytesIO(r.content)).read()
            root = ET.fromstring(xml_data)
            now_dt = datetime.now(timezone.utc).replace(tzinfo=None)
            programmes = {}
            for prog in root.findall("programme"):
                ch_id = prog.get("channel", "")
                start_s = prog.get("start", "")
                stop_s = prog.get("stop", "")
                if not ch_id or not start_s or not stop_s:
                    continue
                try:
                    start_dt = datetime.strptime(start_s[:14], "%Y%m%d%H%M%S")
                    stop_dt = datetime.strptime(stop_s[:14], "%Y%m%d%H%M%S")
                except ValueError:
                    continue
                if start_dt <= now_dt < stop_dt:
                    title_el = prog.find("title")
                    title_text = title_el.text if title_el is not None and title_el.text else ""
                    desc_el = prog.find("desc")
                    desc_text = desc_el.text if desc_el is not None and desc_el.text else ""
                    programmes[ch_id] = {"title": title_text, "desc": desc_text,
                                         "start": start_s[:14], "stop": stop_s[:14]}

            if core_settings.is_iptv_cache_active() and c_file:
                try:
                    with open(c_file, 'w', encoding='utf-8') as f:
                        json.dump({'ts': now, 'data': programmes}, f, ensure_ascii=False)
                except OSError:
                    pass

        _epg_cache["data"] = programmes
        _epg_cache["ts"] = now
        return programmes
    except Exception as e:
        xbmc.log("[EspaTV] EPG fetch error: {0}".format(e), xbmc.LOGERROR)
        return {}


def format_time(t):
    if len(t) >= 12:
        try:
            utc_dt = datetime.strptime(t[:14] if len(t) >= 14 else t[:12] + "00", "%Y%m%d%H%M%S")
            local_offset = -time.timezone if not time.daylight else -time.altzone
            local_dt = utc_dt + timedelta(seconds=local_offset)
            return "{0:02d}:{1:02d}".format(local_dt.hour, local_dt.minute)
        except (ValueError, TypeError):
            return "{0}:{1}".format(t[8:10], t[10:12])
    return ""
