# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import html as _html
import re
from urllib.parse import urljoin, urlparse
from urllib.request import urlopen, Request

try:
    import xbmc
    _log = lambda msg: xbmc.log("[EspaTV/tgscan] {0}".format(msg), xbmc.LOGDEBUG)
except ImportError:
    _log = lambda msg: None

from _user_agents import UA_DESKTOP as _UA

_BASE = "https://t.me/s/{channel}"
_MAX_BYTES = 256 * 1024
_TIMEOUT = 12
_MAX_PAGES = 3
_MAX_RESULTS = 50

_VIDEO_EXTS = frozenset((".mp4", ".mkv", ".webm", ".avi", ".mov", ".m3u8", ".mpd", ".ts"))
_DOC_EXTS = frozenset((".torrent", ".zip", ".rar", ".7z", ".nfo"))


def scan_channel(channel_or_url, max_pages=_MAX_PAGES):
    """
    Escanea un canal PÚBLICO de Telegram.

    Solo funciona con canales que tienen username público (t.me/nombre).
    Los grupos privados y canales privados no son accesibles sin autenticación.

    channel_or_url acepta: @canal, t.me/canal, https://t.me/s/canal
    Devuelve lista de dicts compatibles con html_scanner.
    """
    channel = _normalize_channel(channel_or_url)
    if not channel:
        _log("Canal inválido: {0}".format(channel_or_url))
        return []

    seen = set()
    results = []
    before_id = None

    for _ in range(max(1, max_pages)):
        html = _fetch_page(channel, before_id)
        if not html:
            break

        items = _extract_message_items(html, channel)
        new_items = [i for i in items if i["url"] not in seen]
        for item in new_items:
            seen.add(item["url"])
            results.append(item)
            if len(results) >= _MAX_RESULTS:
                return results

        before_id = _extract_oldest_id(html)
        if not before_id or not new_items:
            break

    return results


def _normalize_channel(raw):
    """Extrae el nombre del canal de cualquier formato de entrada."""
    raw = raw.strip()
    # Quitar esquema y dominio
    raw = re.sub(r'^https?://', '', raw)
    raw = re.sub(r'^t\.me/s/', '', raw)
    raw = re.sub(r'^t\.me/', '', raw)
    raw = raw.lstrip('@').split('/')[0].split('?')[0].strip()
    # Nombre válido: letras, números, guión bajo, mín 5 chars (límite de Telegram)
    if re.match(r'^[a-zA-Z0-9_]{5,}$', raw):
        return raw
    return ""


def _fetch_page(channel, before_id=None):
    url = _BASE.format(channel=channel)
    if before_id:
        url += "?before={0}".format(before_id)
    try:
        req = Request(url, headers={
            "User-Agent": _UA,
            "Accept-Language": "es-ES,es;q=0.9",
        })
        with urlopen(req, timeout=_TIMEOUT) as resp:
            if resp.status != 200:
                _log("HTTP {0} para {1}".format(resp.status, url))
                return ""
            return resp.read(_MAX_BYTES).decode("utf-8", errors="replace")
    except OSError as exc:
        _log("Error descargando {0}: {1}".format(url, exc))
        return ""


def _extract_message_items(html, channel):
    results = []
    # Cada mensaje tiene un wrapper con data-post="canal/N"
    msg_re = re.compile(
        r'<div[^>]+class=["\'][^"\']*tgme_widget_message_wrap[^"\']*["\'][^>]*>'
        r'(.*?)'
        r'(?=<div[^>]+class=["\'][^"\']*tgme_widget_message_wrap|$)',
        re.S,
    )

    for msg_m in msg_re.finditer(html):
        block = msg_m.group(1)
        # Texto del mensaje (para usar como título)
        text_m = re.search(
            r'class=["\'][^"\']*tgme_widget_message_text[^"\']*["\'][^>]*>(.*?)</(?:div|p)>',
            block, re.S,
        )
        raw_text = ""
        if text_m:
            raw_text = re.sub(r'<[^>]+>', ' ', text_m.group(1)).strip()
            raw_text = _html.unescape(re.sub(r'\s+', ' ', raw_text))[:120]

        block_seen = set()

        # 1. Vídeos adjuntos: <video src="..."> dentro del bloque
        for vm in re.finditer(r'<video[^>]+src=["\']([^"\']+)["\']', block, re.I):
            src = vm.group(1).strip()
            if src and src not in block_seen:
                block_seen.add(src)
                results.append(_make_item(src, raw_text or _basename(src), ""))

        # 2. Documentos adjuntos: <a href="..."> dentro de un wrapper de documento.
        # Comprobamos primero si existe el wrapper para no iterar todos los <a> del bloque
        # en mensajes sin adjuntos.
        if re.search(r'class=["\'][^"\']*tgme_widget_message_document[^"\']*["\']', block, re.I):
            for am in re.finditer(r'<a\s[^>]*?href=["\']([^"\']+)["\']', block, re.I):
                href = am.group(1).strip()
                if not href.startswith("http"):
                    continue
                ext = _ext(href)
                if (ext in _VIDEO_EXTS or ext in _DOC_EXTS) and href not in block_seen:
                    block_seen.add(href)
                    results.append(_make_item(href, raw_text or _basename(href), ext))

        # 3. Links externos en el texto del mensaje (plataformas de vídeo conocidas)
        for lm in re.finditer(r'href=["\']([^"\']+)["\']', block, re.I):
            href = lm.group(1).strip()
            if not href.startswith("http"):
                continue
            if href in block_seen:
                continue
            # Excluir links internos de Telegram y CDN de miniaturas
            if "t.me" in href or "telegram.org" in href or "telegra.ph" in href or "thumbs" in href:
                continue
            ext = _ext(href)
            if ext in _VIDEO_EXTS or ext in _DOC_EXTS or _is_known_platform(href):
                block_seen.add(href)
                results.append(_make_item(href, raw_text or _basename(href), ext))

    return results


def _extract_oldest_id(html):
    """Extrae el ID de mensaje más antiguo de la página para paginación."""
    ids = re.findall(r'data-post=["\'][^/]+/(\d+)["\']', html)
    if ids:
        try:
            return str(min(int(i) for i in ids))
        except ValueError:
            pass
    return None


def _make_item(url, title, ext):
    return {
        "url": url,
        "title": title or url[:80],
        "ext": ext.lstrip(".") if ext else _ext(url).lstrip("."),
        "filesize": None,
        "duration": None,
        "source": "telegram",
    }


def _basename(url):
    try:
        path = urlparse(url).path
        name = path.rstrip("/").rsplit("/", 1)[-1]
        if "." in name:
            name = name.rsplit(".", 1)[0]
        return name.replace("-", " ").replace("_", " ")[:80]
    except ValueError:
        return url[:80]


def _ext(url):
    try:
        path = urlparse(url).path.lower()
        if "." in path:
            return "." + path.rsplit(".", 1)[-1].split("?")[0]
    except ValueError:
        pass
    return ""


def _is_known_platform(url):
    return bool(re.search(
        r'(youtube\.com|youtu\.be|dailymotion\.com|vimeo\.com|'
        r'twitch\.tv|rumble\.com|odysee\.com|streamable\.com)',
        url, re.I,
    ))
