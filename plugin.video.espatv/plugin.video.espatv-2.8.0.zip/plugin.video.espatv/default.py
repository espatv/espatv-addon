# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""
EspaTV - Buscador y agregador multimedia para Kodi.

EspaTV permite la búsqueda y reproducción de contenido público alojado en 
plataformas como Dailymotion y otras fuentes de acceso libre y legal.

Desarrollado por fullstackcurso, espatv y espakodi - RubénSDFA1laberot.

Expansión futura:
Está prevista la adaptación del addon para abarcar más países 
hispanohablantes. Invitamos a cualquier desarrollador interesado a colaborar.

Aviso Legal:
Este addon ha sido diseñado con la estricta intención de respetar los 
derechos de autor, facilitando únicamente el acceso a contenido público. 
Ante cualquier inquietud legal, por favor, póngase en contacto.

Origen del proyecto:
Este addon es la adaptación oficial para Kodi de un ecosistema web y móvil 
creado por RubénSDFA1laberot, cuyos recursos se harán públicos próximamente 
en los repositorios asociados al proyecto.
"""
import sys
import os
import shutil
import socket
import threading
import time
import urllib.parse
from urllib.parse import urljoin, quote
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
import xbmcvfs
import json
import difflib
import re
import hashlib
import xml.etree.ElementTree as ET

# --- ACCESIBILIDAD ---
# xbmcgui.ListItem es una clase C++ nativa; se emplea una factory function.

# Migrar force_white_text a acc_color_mode si no se ha configurado previamente.
try:
    _mig_addon = xbmcaddon.Addon()
    if _mig_addon.getSetting('acc_migrated_v1') != 'true':
        if (_mig_addon.getSetting('acc_color_mode') in ('', 'none')
                and _mig_addon.getSetting('force_white_text') == 'true'):
            _mig_addon.setSetting('acc_color_mode', 'white')
        _mig_addon.setSetting('acc_migrated_v1', 'true')
    del _mig_addon
except Exception:
    pass

_ACC_COLOR_MODE = 'none'
_ACC_FORCE_BOLD = False
_ACC_STRIP_SYMBOLS = False
try:
    _acc_addon = xbmcaddon.Addon()
    _ACC_COLOR_MODE = _acc_addon.getSetting('acc_color_mode') or 'none'
    _ACC_FORCE_BOLD = _acc_addon.getSetting('acc_force_bold') == 'true'
    _ACC_STRIP_SYMBOLS = _acc_addon.getSetting('acc_strip_symbols') == 'true'
    del _acc_addon
except Exception:
    pass

_ACC_ANY_ACTIVE = (_ACC_COLOR_MODE not in ('', 'none')) or _ACC_FORCE_BOLD or _ACC_STRIP_SYMBOLS

if _ACC_ANY_ACTIVE:
    # Tablas de remapeo para modos daltónicos
    _ACC_DRG_MAP = {  # daltonic_rg: deuteranopia/protanopia (sin rojo-verde)
        'red': 'orange', 'tomato': 'orange', 'crimson': 'orange',
        'maroon': 'orange', 'coral': 'orange', 'firebrick': 'orange',
        'green': 'cyan', 'lime': 'cyan', 'limegreen': 'cyan',
        'mediumseagreen': 'cyan', 'palegreen': 'cyan', 'springgreen': 'cyan',
        'darkgreen': 'cyan', 'forestgreen': 'cyan', 'seagreen': 'cyan',
        'aqua': 'cyan', 'cyan': 'cyan', 'deepskyblue': 'deepskyblue',
        'skyblue': 'skyblue', 'lightskyblue': 'lightskyblue',
        'royalblue': 'royalblue', 'cornflowerblue': 'cornflowerblue', 'blue': 'blue',
        'gold': 'yellow', 'khaki': 'yellow', 'yellow': 'yellow',
        # Neutros: preservar. gray/grey marcan items deshabilitados.
        'gray': 'gray', 'grey': 'grey', 'white': 'white',
        'darkgray': 'darkgray', 'darkgrey': 'darkgrey',
        'lightgray': 'lightgray', 'lightgrey': 'lightgrey',
        'black': 'black', 'silver': 'silver',
    }
    _ACC_DBY_MAP = {  # daltonic_by: tritanopia (sin azul-amarillo)
        'yellow': 'magenta', 'gold': 'magenta', 'khaki': 'magenta',
        'lemonchiffon': 'magenta', 'lightyellow': 'magenta',
        'blue': 'red', 'deepskyblue': 'red', 'royalblue': 'red',
        'cornflowerblue': 'red', 'lightskyblue': 'red', 'navy': 'red',
        'aqua': 'red', 'cyan': 'red', 'teal': 'red', 'turquoise': 'red',
        'skyblue': 'red', 'steelblue': 'red', 'cadetblue': 'red',
        # Neutros: preservar.
        'gray': 'gray', 'grey': 'grey', 'white': 'white',
        'darkgray': 'darkgray', 'darkgrey': 'darkgrey',
        'lightgray': 'lightgray', 'lightgrey': 'lightgrey',
        'black': 'black', 'silver': 'silver',
    }
    # Colores "destructivos" que el alto contraste preserva en rojo
    _ACC_HCD_KEEP_RED = frozenset({'red', 'tomato', 'crimson', 'maroon', 'coral', 'firebrick'})

    _ACC_COLOR_RE = re.compile(r'\[COLOR\s+([a-zA-Z0-9]+)\]')
    _ACC_SYMBOL_TABLE = str.maketrans({'★': '*', '●': '*', '○': '-', '▲': '^', '▼': 'v', '◑': '~', '◐': '~'})

    def _acc_remap(match):
        c = match.group(1).lower()
        if _ACC_COLOR_MODE == 'white':
            return '[COLOR white]'
        elif _ACC_COLOR_MODE == 'daltonic_rg':
            return '[COLOR ' + _ACC_DRG_MAP.get(c, 'white') + ']'
        elif _ACC_COLOR_MODE == 'daltonic_by':
            return '[COLOR ' + _ACC_DBY_MAP.get(c, 'white') + ']'
        elif _ACC_COLOR_MODE == 'hc_dark':
            return '[COLOR ' + (c if c in _ACC_HCD_KEEP_RED else 'yellow') + ']'
        elif _ACC_COLOR_MODE == 'hc_light':
            return '[COLOR ' + (c if c in _ACC_HCD_KEEP_RED else 'black') + ']'
        return match.group(0)

    def _acc_transform(s):
        # Nota: La transformación no es idempotente; aplicar solo una vez por label.
        if not isinstance(s, str) or not s:
            return s
        if _ACC_STRIP_SYMBOLS:
            s = s.translate(_ACC_SYMBOL_TABLE)
        if _ACC_FORCE_BOLD and '[B]' not in s:
            s = '[B]' + s + '[/B]'
        if _ACC_COLOR_MODE not in ('', 'none'):
            s = _ACC_COLOR_RE.sub(_acc_remap, s)
        return s

    def _ww(s):
        return _acc_transform(s)

    try:
        # Prevenir monkey-patching duplicado en re-importaciones en el mismo proceso.
        _OrigListItem = getattr(xbmcgui, '_OrigListItemEspatv', None) or xbmcgui.ListItem
        xbmcgui._OrigListItemEspatv = _OrigListItem

        def _ListItemFactory(*args, **kwargs):
            if 'label' in kwargs:
                kwargs['label'] = _acc_transform(kwargs['label'])
            elif args:
                args = (_acc_transform(args[0]),) + args[1:]
            if 'label2' in kwargs:
                kwargs['label2'] = _acc_transform(kwargs['label2'])
            elif len(args) >= 2:
                args = (args[0], _acc_transform(args[1])) + args[2:]
            return _OrigListItem(*args, **kwargs)

        xbmcgui.ListItem = _ListItemFactory
        xbmc.log("[EspaTV] Accessibility patch installed (color={0} bold={1} symbols={2})".format(
            _ACC_COLOR_MODE, _ACC_FORCE_BOLD, _ACC_STRIP_SYMBOLS), xbmc.LOGINFO)
    except Exception as _e:
        xbmc.log("[EspaTV] Accessibility patch failed: {0}".format(_e), xbmc.LOGWARNING)

else:
    def _ww(s):
        return s
    # Restaurar ListItem original si la factory quedó instalada en un run previo del mismo proceso.
    try:
        _orig = getattr(xbmcgui, '_OrigListItemEspatv', None)
        if _orig is not None and xbmcgui.ListItem is not _orig:
            xbmcgui.ListItem = _orig
    except Exception:
        pass

import webcams as _webcams
import core_settings
import category_manager
import ytdlp_resolver
from _user_agents import UA_DESKTOP
import stats
import easter_egg_manager
import precio_luz
import librivox
import efemerides
import ibex
from install_helpers import (
    _install_espatv_repo,
    _flowfav_install,
    _loiolog_install,
    _loiolink_launch,
)
from podcast_player import (_podcast_menu, _podcast_feed, _play_podcast,
                            _podcast_add_custom, _podcast_delete_custom)
from download_manager import _download_video
import yt_watched_tracker as _ywt
import watch_history as _wh
import log_manager as _lm
import yt_search as _yts
import search_history as _sh
import press_rss as _pr
import epg as _epg
import slyguy_installer as _slyguy
import peliculas_top as _tm
import yt_playlists as _ytp
import backups as _bk
import default_dispatch_extras as _extras

try:
    import requests
except ImportError:
    xbmc.log("[EspaTV] requests module not available", xbmc.LOGERROR)
    sys.exit(1)

try:
    from _user_agents import desktop_headers as _browser_headers
except ImportError:
    def _browser_headers(**_):
        return {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'}

# Firma de build original, no eliminar
_ORIGIN = "espakodi-rubensdfa1laberot-v1"

try:
    _home_win = xbmcgui.Window(10000)
    if not _home_win.getProperty("espatv_started"):
        _home_win.setProperty("espatv_started", "1")
        xbmc.log(
            "[EspaTV] Addon original por RubénSDFA1laberot — "
            "https://github.com/espakodi — GPL-2.0-or-later",
            xbmc.LOGINFO,
        )
except Exception:
    pass

_STATUS_URL = "https://raw.githubusercontent.com/espakodi/espatv/main/status.json"
_MESSAGES_URL = "https://raw.githubusercontent.com/espakodi/espatv/main/messages.json"

_DM_API_BASE = "https://api.dailymotion.com"
_DM_FIELDS = "id,title,thumbnail_720_url,thumbnail_360_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"


def _dm_search(query, extra_params=None):
    params = {
        "search": query, "limit": 30, "language": "es",
        "fields": _DM_FIELDS,
    }
    if extra_params:
        params.update(extra_params)
    try:
        resp = requests.get(_DM_API_BASE + "/videos", params=params, timeout=15)
        if resp.status_code == 200:
            return resp.json().get("list", [])
    except (requests.RequestException, ValueError) as exc:
        _log_error("DM search error: {0}".format(exc))
    return []


def _dm_resolve(vid):
    fields = _DM_FIELDS + ",qualities"
    try:
        resp = requests.get("{0}/video/{1}".format(_DM_API_BASE, vid),
                            params={"fields": fields}, timeout=15)
        if resp.status_code == 200:
            return resp.json()
    except (requests.RequestException, ValueError) as exc:
        _log_error("DM resolve error: {0}".format(exc))
    return None



_HEADERS_DM_DESKTOP = {
    "User-Agent": UA_DESKTOP,
    "Origin": "https://www.dailymotion.com",
    "Referer": "https://www.dailymotion.com/",
}


def _fetch_hls_variants(master_url, headers=None):
    """Devuelve las variantes del master playlist HLS, ordenadas de mayor a menor bitrate."""
    variants = []
    req_headers = headers if headers else {}
    try:
        r = requests.get(master_url, headers=req_headers, timeout=15)
        if r.status_code != 200:
            return variants

        lines = r.text.strip().splitlines()

        current_label = "unknown"
        current_bw = 0
        expecting_url = False

        for line in lines:
            line = line.strip()
            if not line:
                continue

            if line.startswith('#EXT-X-STREAM-INF'):
                res_match = re.search(r'RESOLUTION=(\d+x\d+)', line)
                bw_match = re.search(r'BANDWIDTH=(\d+)', line)
                current_label = res_match.group(1) if res_match else "unknown"
                current_bw = int(bw_match.group(1)) if bw_match else 0
                expecting_url = True
            elif expecting_url and not line.startswith('#'):
                stream_url = line
                if not stream_url.startswith('http'):
                    stream_url = urljoin(master_url, stream_url)
                variants.append({'label': current_label, 'url': stream_url, 'bandwidth': current_bw})
                expecting_url = False

        variants.sort(key=lambda x: x.get('bandwidth', 0), reverse=True)
    except (requests.RequestException, ValueError) as exc:
        _log_error("HLS variants lookup error: {0}".format(exc))
    return variants


def _dm_play_direct(vid, max_quality=1080):
    """Resolución directa via API de metadatos. Devuelve {url, mime, subs, headers} o None."""
    if not isinstance(vid, str) or not vid.strip():
        xbmc.log("[EspaTV] _dm_play_direct: ID de video invalido", xbmc.LOGWARNING)
        return None
        
    vid_safe = quote(vid.strip())
    
    try:
        meta_url = "https://www.dailymotion.com/player/metadata/video/{0}".format(vid_safe)
        r = requests.get(meta_url, headers=_HEADERS_DM_DESKTOP, timeout=15)
        
        if r.status_code != 200:
            xbmc.log("[EspaTV] _dm_play_direct error HTTP: {0}".format(r.status_code), xbmc.LOGWARNING)
            return None
            
        data = r.json()
        
        # Log GEO-Block/Errores específicos
        if data.get("error"):
            err_msg = data["error"].get("message", "Error API desconocido")
            xbmc.log("[EspaTV] Dailymotion API Error: {0}".format(err_msg), xbmc.LOGWARNING)
            return None

        qualities = data.get("qualities", {})
        subtitles = []
        subs_data = data.get("subtitles", {})
        
        # Extracción defensiva de subtítulos (la estructura varía entre vídeos)
        if isinstance(subs_data, dict):
            for lang, sub_list in subs_data.items():
                if isinstance(sub_list, list):
                    for sub in sub_list:
                        if isinstance(sub, dict) and sub.get("url"):
                            subtitles.append(sub.get("url"))

        # Buscar MP4 directo (mejor compatibilidad en Android)
        best_mp4 = None
        best_res = 0
        for res_key, formats in qualities.items():
            if res_key == "auto":
                continue
            try:
                res_val = int(res_key)
            except (ValueError, TypeError):
                continue
                
            if res_val > max_quality:
                continue
                
            for fmt in formats:
                if isinstance(fmt, dict) and fmt.get("type") == "video/mp4" and res_val > best_res:
                    best_mp4 = fmt.get("url")
                    best_res = res_val
                    
        if best_mp4:
            xbmc.log("[EspaTV] _dm_play_direct: MP4 directo {0}p".format(best_res), xbmc.LOGINFO)
            return {"url": best_mp4, "mime": "video/mp4", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}

        # Buscar HLS (fallback si no hay MP4 directo)
        hls_url = None
        if "auto" in qualities:
            for item in qualities["auto"]:
                if isinstance(item, dict) and item.get("type") == "application/x-mpegURL":
                    hls_url = item.get("url")
                    break
                    
        if hls_url:
            xbmc.log("[EspaTV] _dm_play_direct: parseando manifiesto HLS", xbmc.LOGINFO)
            variants = _fetch_hls_variants(hls_url, headers=_HEADERS_DM_DESKTOP)
            if not variants:
                # Fallback: Evitar error 403 (TLS fingerprinting en Kodi 21) usando dm_resolver
                try:
                    import dm_resolver as _dm_res
                    variants = _dm_res.fetch_hls_variants(hls_url)
                    if variants:
                        xbmc.log("[EspaTV] _dm_play_direct: dm_resolver obtuvo variantes via cascada TLS", xbmc.LOGINFO)
                except Exception as _exc:
                    xbmc.log("[EspaTV] _dm_play_direct: dm_resolver fallido: {0}".format(_exc), xbmc.LOGWARNING)

            if variants:
                filtered = []
                for v in variants:
                    label = v.get("label", "")
                    try:
                        height = int(label.split("x")[1].split(" ")[0]) if "x" in label else 0
                    except (ValueError, IndexError):
                        height = 0
                        
                    if height > 0 and height <= max_quality:
                        filtered.append(v)
                
                target = filtered[0] if filtered else variants[-1]
                xbmc.log("[EspaTV] _dm_play_direct: variante HLS seleccionada: {0}".format(target.get("label")), xbmc.LOGINFO)
                return {"url": target["url"], "mime": "application/x-mpegURL", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}

            # Sin variantes parseables, pasar la URL maestra directamente
            xbmc.log("[EspaTV] _dm_play_direct: sin variantes, usando master URL", xbmc.LOGWARNING)
            return {"url": hls_url, "mime": "application/x-mpegURL", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}

    except (requests.RequestException, ValueError) as exc:
        xbmc.log("[EspaTV] _dm_play_direct error: {0}".format(exc), xbmc.LOGERROR)
    return None


_DM_SYSPY_SCRIPT = r'''
import sys, json, re
try:
    import requests
    _GET = lambda u, h: requests.get(u, headers=h, timeout=15)
    _STATUS = lambda r: r.status_code
    _TEXT = lambda r: r.text
except ImportError:
    import urllib.request
    def _GET(u, h):
        return urllib.request.urlopen(urllib.request.Request(u, headers=h), timeout=15)
    _STATUS = lambda r: r.getcode()
    _TEXT = lambda r: r.read().decode()
vid = sys.argv[1]
hdr = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
       "Origin":"https://www.dailymotion.com","Referer":"https://www.dailymotion.com/"}
r = _GET("https://www.dailymotion.com/player/metadata/video/"+vid, hdr)
if _STATUS(r) != 200:
    sys.exit(1)
data = json.loads(_TEXT(r))
if data.get("error"):
    sys.exit(2)
hls = ""
for it in data.get("qualities",{}).get("auto",[]):
    if it.get("type") == "application/x-mpegURL":
        hls = it.get("url",""); break
if not hls:
    sys.exit(3)
r2 = _GET(hls, hdr)
if _STATUS(r2) != 200:
    sys.exit(4)
master = _TEXT(r2)
m = re.findall(r"NAME=\"(\d+)\"[^\n]*\n([^\n]+)", master)
m.sort(key=lambda x: int(x[0]), reverse=True)
url = (m[0][1] if m else hls).split("#cell")[0]
print(json.dumps({"url": url}))
'''


def _dm_play(vid, dm_level=0, max_quality=1080):
    """Cascada Dailymotion: dm_gujal (extreme/basic) → fallback directo MP4/HLS."""
    try:
        import dm_gujal

        if dm_level == 2:
            xbmc.log("[EspaTV] _dm_play: usando modo EXTREMO para {0}".format(vid), xbmc.LOGINFO)
            url, subs, mime = dm_gujal.play_dm_extreme(vid, max_quality=max_quality)
            if url:
                return {'url': url, 'subs': subs, 'mime': mime or 'application/x-mpegURL'}
        elif dm_level == 1:
            xbmc.log("[EspaTV] _dm_play: usando modo BASICO para {0}".format(vid), xbmc.LOGINFO)
            url, mime = dm_gujal.play_dm_basic(vid)
            if url:
                return {'url': url, 'mime': mime or 'application/x-mpegURL'}
        else:
            # Default (nivel 0): extreme primero, basic como fallback
            xbmc.log("[EspaTV] _dm_play: usando modo DEFAULT (extreme+fallback) para {0}".format(vid), xbmc.LOGINFO)
            url, subs, mime = dm_gujal.play_dm_extreme(vid, max_quality=max_quality)
            if url:
                xbmc.log("[EspaTV] _dm_play: extreme OK, mime={0}".format(mime), xbmc.LOGINFO)
                return {'url': url, 'subs': subs, 'mime': mime or 'application/x-mpegURL'}
            xbmc.log("[EspaTV] _dm_play: extreme falló, intentando basic...", xbmc.LOGINFO)
            url, mime = dm_gujal.play_dm_basic(vid)
            if url:
                xbmc.log("[EspaTV] _dm_play: basic OK, mime={0}".format(mime), xbmc.LOGINFO)
                return {'url': url, 'mime': mime or 'application/x-mpegURL'}
    except (ImportError, RuntimeError, AttributeError) as exc:
        _log_error("dm_gujal play error: {0}".format(exc))
        xbmc.log("[EspaTV] _dm_play EXCEPTION: {0}".format(exc), xbmc.LOGERROR)

    # Fallback directo: moderna extracción nativa
    xbmc.log("[EspaTV] _dm_play: intentando fallback directo para {0}".format(vid), xbmc.LOGINFO)
    result = _dm_play_direct(vid, max_quality=max_quality)
    if result:
        xbmc.log("[EspaTV] _dm_play: fallback directo OK", xbmc.LOGINFO)
        return result

    xbmc.log("[EspaTV] _dm_play: todos los métodos fallaron para {0}".format(vid), xbmc.LOGWARNING)
    return None


def _dm_play_android(vid, dm_level=0, max_quality=1080):
    """Variante no-Windows: intenta resolución directa primero.
    
    Android/Linux nativos no soportan cabeceras inyectadas en la URL por dm_gujal.
    """
    result = None

    xbmc.log("[EspaTV] _dm_play_android: resolucion directa para {0}".format(vid), xbmc.LOGINFO)
    direct = _dm_play_direct(vid, max_quality=max_quality)
    if direct and direct.get('url'):
        xbmc.log("[EspaTV] _dm_play_android: resolucion directa OK", xbmc.LOGINFO)
        result = direct
    else:
        xbmc.log("[EspaTV] _dm_play_android: fallback dm_gujal para {0}".format(vid), xbmc.LOGINFO)
        gujal = _dm_play(vid, dm_level=dm_level, max_quality=max_quality)
        if gujal and gujal.get('url'):
            xbmc.log("[EspaTV] _dm_play_android: dm_gujal OK", xbmc.LOGINFO)
            result = gujal

    if result is None:
        xbmc.log("[EspaTV] _dm_play_android: sin resultados para {0}".format(vid), xbmc.LOGWARNING)
        return None

    # Remover cabeceras para evitar inyección en la URL (incompatible con Android nativo).
    result.pop('headers', None)
    return result


def _dm_search_channels(query):
    try:
        params = {"search": query, "limit": 20, "fields": "id,screenname,username,avatar_720_url"}
        resp = requests.get(_DM_API_BASE + "/users", params=params, timeout=15)
        if resp.status_code == 200:
            return resp.json().get("list", [])
    except (requests.RequestException, ValueError) as exc:
        _log_error("DM channel search error: {0}".format(exc))
    return []


def _dm_list_user_playlists(user):
    try:
        params = {"limit": 50, "fields": "id,name,description,videos_total"}
        resp = requests.get("{0}/user/{1}/playlists".format(_DM_API_BASE, user),
                           params=params, timeout=15)
        if resp.status_code == 200:
            results = resp.json().get("list", [])
            for r in results:
                r["count"] = r.pop("videos_total", 0)
            return results
    except (requests.RequestException, ValueError) as exc:
        _log_error("DM user playlists error: {0}".format(exc))
    return []


def _dm_view_playlist_api(pid):
    try:
        params = {"limit": 50, "fields": _DM_FIELDS}
        resp = requests.get("{0}/playlist/{1}/videos".format(_DM_API_BASE, pid),
                           params=params, timeout=15)
        if resp.status_code == 200:
            return resp.json().get("list", [])
    except (requests.RequestException, ValueError) as exc:
        _log_error("DM view playlist error: {0}".format(exc))
    return []


def _get_saved_playlists_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, 'saved_playlists.json')


def _load_saved_playlists():
    path = _get_saved_playlists_file()
    if not os.path.exists(path):
        return []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def _save_saved_playlists(data):
    path = _get_saved_playlists_file()
    with open(path, 'w', encoding='utf-8') as f:
        f.write(json.dumps(data, ensure_ascii=False, indent=2))


def _add_saved_playlist(pid, name, user, count=0):
    saved = _load_saved_playlists()
    for s in saved:
        if s.get('pid') == pid:
            return False
    saved.append({'pid': pid, 'name': name, 'user': user, 'count': count})
    _save_saved_playlists(saved)
    return True


def _remove_saved_playlist(pid):
    saved = _load_saved_playlists()
    saved = [s for s in saved if s.get('pid') != pid]
    _save_saved_playlists(saved)


def _dm_playlists_search_menu():
    kb = xbmc.Keyboard('', 'Buscar canal en Dailymotion')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText():
        return
    query = kb.getText()
    channels = _dm_search_channels(query)
    if not channels:
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron canales", xbmcgui.NOTIFICATION_WARNING)
        return
    h = int(sys.argv[1])
    for ch in channels:
        username = ch.get('username', '')
        screenname = ch.get('screenname', username)
        avatar = ch.get('avatar_720_url', '')
        li = xbmcgui.ListItem(label=screenname)
        li.setArt({'icon': avatar, 'thumb': avatar})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dm_user_playlists", user=username), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _dm_user_playlists_menu(user):
    playlists = _dm_list_user_playlists(user)
    if not playlists:
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron playlists", xbmcgui.NOTIFICATION_WARNING)
        return
    h = int(sys.argv[1])
    saved_pids = {s['pid'] for s in _load_saved_playlists()}
    for pl in playlists:
        pid = pl.get('id', '')
        name = pl.get('name', 'Sin nombre')
        count = pl.get('count', 0)
        is_saved = pid in saved_pids
        prefix = "[COLOR green]★[/COLOR] " if is_saved else ""
        li = xbmcgui.ListItem(label="{0}{1} ({2} vídeos)".format(prefix, name, count))
        # Menú contextual: guardar o quitar
        ctx = []
        if is_saved:
            ctx.append(("Quitar de guardados", "RunPlugin({0})".format(_u(action="dm_unsave_playlist", pid=pid))))
        else:
            ctx.append(("Guardar playlist", "RunPlugin({0})".format(_u(action="dm_save_playlist", pid=pid, name=name, user=user, count=count))))
        li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dm_view_playlist", pid=pid), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _dm_saved_playlists_menu():
    saved = _load_saved_playlists()
    h = int(sys.argv[1])
    if not saved:
        li = xbmcgui.ListItem(label="[COLOR grey]No tienes playlists guardadas[/COLOR]")
        li.setInfo('video', {'plot':
            "Para guardar una playlist:\n"
            "1. Ve a Catálogo → Playlists de Dailymotion\n"
            "2. Busca un canal (ej: antena3, telecinco...)\n"
            "3. Entra en el canal y verás sus playlists\n"
            "4. Mantén pulsado sobre una playlist → Guardar playlist\n\n"
            "Para borrar una playlist guardada:\n"
            "Mantén pulsado sobre ella → Quitar de guardados"})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    for s in saved:
        pid = s.get('pid', '')
        name = s.get('name', 'Sin nombre')
        user = s.get('user', '')
        count = s.get('count', 0)
        li = xbmcgui.ListItem(label="{0} ({1} vídeos) — {2}".format(name, count, user))
        ctx = [("Quitar de guardados", "RunPlugin({0})".format(_u(action="dm_unsave_playlist", pid=pid)))]
        li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dm_view_playlist", pid=pid), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _dm_view_playlist_menu(pid):
    items = _dm_view_playlist_api(pid)
    if not items:
        xbmcgui.Dialog().notification("EspaTV", "Playlist vacía o error", xbmcgui.NOTIFICATION_WARNING)
        return
    h = int(sys.argv[1])
    for v in items:
        vid = v.get('id', '')
        title = v.get('title', 'Sin título')
        thumb = v.get('thumbnail_720_url') or v.get('thumbnail_360_url') or v.get('thumbnail_url', '')
        duration = v.get('duration', 0)
        owner = v.get('owner.screenname', '')
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': thumb, 'icon': thumb})
        li.setInfo('video', {'title': title, 'duration': duration, 'plot': "Canal: {0}".format(owner)})
        li.setProperty('IsPlayable', 'true')
        cm = []
        cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action='download_video', vid=vid, title=title))))
        cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action='dm_open_browser', url=vid))))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vid)))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vid), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def _l(m): xbmc.log("[EspaTV] {0}".format(m), xbmc.LOGINFO)
def _u(**k): return sys.argv[0] + "?" + urllib.parse.urlencode(k)
def _fix_img(t):
    return t

def _load_spanish_channels():
    data = {}
    try:
        addon_path = xbmcaddon.Addon().getAddonInfo('path')
        main_path = os.path.join(addon_path, 'canales_espana.json')
        if os.path.exists(main_path):
            with open(main_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        meme_path = os.path.join(addon_path, 'museo_meme.json')
        if os.path.exists(meme_path):
            with open(meme_path, 'r', encoding='utf-8') as f:
                data.update(json.load(f))
    except (OSError, ValueError) as e:
        xbmc.log("[EspaTV] Error cargando canales: {0}".format(e), xbmc.LOGWARNING)
    return data


def _spanish_section_menu(section):
    data = _load_spanish_channels()
    sec = data.get(section)
    if not sec:
        xbmcgui.Dialog().notification("EspaTV", "Sección no encontrada", xbmcgui.NOTIFICATION_WARNING)
        return
    h = int(sys.argv[1])
    if section == 'museo_meme' and xbmcaddon.Addon().getSetting("cinema_mode_auto") == "true":
        xbmcplugin.endOfDirectory(h, succeeded=False)
        _spanish_section_cinema(section)
        return
    channels = sec.get('channels', [])
    url_channels = [ch for ch in channels if ch.get('url', '')]
    if url_channels and section == 'museo_meme':
        li_all = xbmcgui.ListItem(label="[B][COLOR gold]Reproducir todo ({0} vídeos)[/COLOR][/B]".format(len(url_channels)))
        _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
        _icon = os.path.join(_mp, sec.get('icon', ''))
        li_all.setArt({'icon': _icon, 'thumb': _icon})
        _full_plot = sec.get('plot', '')
        _warning = _full_plot.split('\n\n', 1)[-1] if '\n\n' in _full_plot else _full_plot
        li_all.setInfo('video', {'title': 'Reproducir todo', 'plot': _warning})
        li_all.setProperty('SpecialSort', 'top')
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="spanish_section_play_all", section=section), listitem=li_all, isFolder=False)

        li_cinema = xbmcgui.ListItem(label="[COLOR FF38BDF8][B]Modo Cine[/B][/COLOR]")
        li_cinema.setArt({'icon': 'DefaultMovies.png'})
        li_cinema.setInfo('video', {'plot': "Navega los vídeos con miniaturas grandes y fondo dinámico."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="spanish_section_cinema", section=section), listitem=li_cinema, isFolder=False)
    watched = _ywt.load()
    for ch in channels:
        direct_url = ch.get('url', '')
        name = ch.get('name', '')
        if direct_url:
            m = re.search(r'[?&]v=([^&]+)', direct_url)
            yt_id = m.group(1) if m else ''
            is_watched = yt_id in watched
            label = "[COLOR gray](Visto) {0}[/COLOR]".format(name) if is_watched else "[COLOR lime]{0}[/COLOR]".format(name)
            thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id) if yt_id else 'DefaultVideo.png'
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': thumb, 'thumb': thumb})
            _desc = ch.get('description', '')
            _year = ch.get('year', '')
            _chan = ch.get('channel', '')
            _views = ch.get('views', 0)
            _plot_parts = []
            if _chan:
                _plot_parts.append('Canal: {0}'.format(_chan))
            if _year:
                _plot_parts.append('Año: {0}'.format(_year))
            if _views:
                _plot_parts.append('Vistas: {0:,}'.format(_views).replace(',', '.'))
            if _desc:
                _plot_parts.append(_desc)
            li.setInfo('video', {'title': name, 'plot': '\n'.join(_plot_parts), 'year': int(_year) if _year.isdigit() else 0})
            fav_params = json.dumps({"yt_id": yt_id, "name": name, "ctype": "video", "burl": direct_url})
            cm = []
            if yt_id:
                if is_watched:
                    cm.append(("Desmarcar como visto", "RunPlugin({0})".format(_u(action='yt_toggle_watched', yt_id=yt_id))))
                else:
                    cm.append(("Marcar como visto", "RunPlugin({0})".format(_u(action='yt_toggle_watched', yt_id=yt_id))))
                cm.append(("Añadir a cola de reproducción", "RunPlugin({0})".format(_u(action='yt_queue_add', yt_id=yt_id, name=name))))
            cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(
                _u(action='add_favorite', title=name, fav_url='yt_{0}'.format(yt_id),
                   icon=thumb, platform='youtube', fav_action='felicidad_play', params=fav_params))))
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_play", yt_id=yt_id, name=name, ctype="video", burl=direct_url), listitem=li, isFolder=True)
            continue
        username = ch.get('username', '')
        if not name:
            name = username
        li = xbmcgui.ListItem(label=name)
        try:
            r = requests.get("{0}/user/{1}".format(_DM_API_BASE, username),
                           params={"fields": "avatar_720_url,screenname"}, timeout=5)
            if r.status_code == 200:
                info = r.json()
                avatar = info.get('avatar_720_url', '')
                if avatar:
                    li.setArt({'icon': avatar, 'thumb': avatar})
                real_name = info.get('screenname', name)
                li.setLabel(real_name)
            else:
                li.setArt({'icon': 'DefaultActor.png'})
                li.setLabel(_ww("{0} [COLOR grey](no disponible)[/COLOR]".format(name)))
        except (requests.RequestException, ValueError):
            li.setArt({'icon': 'DefaultActor.png'})
        ctx = []
        ctx.append(("Ver playlists del canal", "Container.Update({0})".format(_u(action="dm_user_playlists", user=username))))
        fav_params = json.dumps({"user": username, "name": name})
        ctx.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(_u(action='add_favorite', title=name, fav_url='spanish_channel_videos_{0}'.format(username), icon=li.getArt('icon'), platform='catalogo', fav_action='spanish_channel_videos', params=fav_params))))
        li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="spanish_channel_videos", user=username, name=name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _play_ytdlp_by_id(yt_id, name=""):
    h = int(sys.argv[1])
    stream_url = None
    try:
        stream_url = ytdlp_resolver.resolve("https://www.youtube.com/watch?v={0}".format(yt_id))
    except Exception as exc:
        xbmc.log("[EspaTV] _play_ytdlp_by_id resolve error ({0}): {1}".format(yt_id, exc), xbmc.LOGWARNING)
    if stream_url:
        thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
        li = xbmcgui.ListItem(label=name or yt_id, path=stream_url)
        li.setArt({"icon": thumb, "thumb": thumb})
        li.setInfo("video", {"title": name or yt_id})
        li.setProperty("IsPlayable", "true")
        li.setContentLookup(False)
        try:
            _wh.add(yt_id, name or yt_id, thumb=thumb, duration=0)
        except (OSError, ValueError):
            pass
        xbmcplugin.setResolvedUrl(h, True, li)
    else:
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem(label=name or yt_id))


def _spanish_section_play_all(section):
    data = _load_spanish_channels()
    sec = data.get(section)
    if not sec:
        return
    videos = [ch for ch in sec.get('channels', []) if ch.get('url', '')]
    if not videos:
        xbmcgui.Dialog().notification("EspaTV", "No hay vídeos en esta sección", xbmcgui.NOTIFICATION_WARNING)
        return
    has_yt = xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)")
    has_ytdlp = ytdlp_resolver.is_available()
    if not has_yt and not has_ytdlp:
        xbmcgui.Dialog().ok("EspaTV", "Se necesita el addon YouTube o yt-dlp para reproducir toda la lista.")
        return
    try:
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        added = 0
        for ch in videos:
            url = ch.get('url', '')
            name = ch.get('name', '')
            m = re.search(r'[?&]v=([^&]+)', url)
            yt_id = m.group(1) if m else ''
            if not yt_id:
                continue
            thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
            li = xbmcgui.ListItem(label=name)
            li.setArt({'icon': thumb, 'thumb': thumb})
            li.setInfo('video', {'title': name})
            li.setProperty('IsPlayable', 'true')
            if has_yt:
                plugin_url = "plugin://plugin.video.youtube/play/?video_id={0}".format(yt_id)
            else:
                plugin_url = _u(action="play_ytdlp_by_id", yt_id=yt_id, name=name)
            pl.add(plugin_url, li)
            added += 1
        if added == 0:
            xbmcgui.Dialog().notification("EspaTV", "No se encontraron vídeos válidos", xbmcgui.NOTIFICATION_WARNING)
            return
        xbmcgui.Dialog().notification("EspaTV", "Reproduciendo {0} vídeos...".format(added), xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.Player().play(pl)
    except Exception as exc:
        xbmc.log("[EspaTV] _spanish_section_play_all error: {0}".format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("EspaTV", "Error al iniciar la reproducción", xbmcgui.NOTIFICATION_ERROR)


def _spanish_channel_videos(user, name=""):
    """Vídeos recientes de un canal DM español. Empieza el menú con un acceso a sus playlists."""
    try:
        params = {"limit": 50, "fields": _DM_FIELDS, "sort": "recent"}
        resp = requests.get("{0}/user/{1}/videos".format(_DM_API_BASE, user),
                           params=params, timeout=15)
        if resp.status_code != 200:
            xbmcgui.Dialog().notification("EspaTV", "Canal no disponible", xbmcgui.NOTIFICATION_WARNING)
            return
        items = resp.json().get("list", [])
    except (requests.RequestException, ValueError) as exc:
        xbmcgui.Dialog().notification("EspaTV", "Error: {0}".format(exc), xbmcgui.NOTIFICATION_ERROR)
        return
    if not items:
        xbmcgui.Dialog().notification("EspaTV", "Sin vídeos recientes", xbmcgui.NOTIFICATION_INFO)
        return
    h = int(sys.argv[1])
    li_pl = xbmcgui.ListItem(label="[COLOR yellow]Ver playlists de {0}[/COLOR]".format(name or user))
    li_pl.setArt({'icon': 'DefaultVideoPlaylists.png'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dm_user_playlists", user=user), listitem=li_pl, isFolder=True)
    for v in items:
        vid = v.get('id', '')
        title = v.get('title', 'Sin título')
        thumb = v.get('thumbnail_720_url') or v.get('thumbnail_360_url') or v.get('thumbnail_url', '')
        duration = v.get('duration', 0)
        owner = v.get('owner.screenname', name)
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': thumb, 'icon': thumb})
        li.setInfo('video', {'title': title, 'duration': duration, 'plot': "Canal: {0}".format(owner)})
        li.setProperty('IsPlayable', 'true')
        cm = []
        cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action='download_video', vid=vid, title=title))))
        cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action='dm_open_browser', url=vid))))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vid)))))
        fav_params = json.dumps({"q": title, "ot": thumb})
        cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(_u(action='add_favorite', title=title, fav_url='lfr_{0}'.format(vid), icon=thumb, platform='dailymotion', fav_action='lfr', params=fav_params))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vid), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def _resolve_icon(icon, fallback, _mp):
    if not icon:
        return fallback
    if icon.startswith('Default'):
        return icon
    p = os.path.join(_mp, icon)
    return p if os.path.isfile(p) else fallback


def _run(**k):
    return "RunPlugin(" + _u(**k) + ")"


# Definición declarativa de los items del menú principal y del catálogo "Más".
# label/plot pueden ser str o callable (se evalúan al renderizar, para conteos dinámicos).
# 'default': ubicación inicial cuando no hay menu_layout.json guardado.
# 'condition': callable->bool o None (None = siempre visible).
# 'movable': False = no se puede mover entre menús, solo reordenar (p.ej. "Más").
# 'section_key': si está, el item es una sección dinámica de canales (datos desde JSON).
# El orden de inserción define el orden por defecto.
_MENU_ITEMS_MASTER = {
    # ---------- Menú principal ----------
    'agenda_menu': {
        'label': "[B][COLOR limegreen]Agenda Deportiva TV[/COLOR][/B]", 'action': 'agenda_menu',
        'icon': 'agenda.png', 'fallback': 'DefaultAddonPVRClient.png', 'is_folder': True, 'default': 'main',
        'plot': "Programación deportiva de hoy en la TV española.\nFútbol, baloncesto, F1, tenis y más.",
    },
    'live_tv_menu': {
        'label': "[COLOR orange][B]TV y Radio en Directo[/B][/COLOR]", 'action': 'live_tv_menu',
        'icon': 'directo.png', 'fallback': 'DefaultAddonPVRClient.png', 'is_folder': True, 'default': 'main',
        'plot': "Canales de televisión y radio en directo, listas IPTV y más.",
    },
    'top_pelis_series_menu': {
        'label': "[B][COLOR coral]Top Películas y Series[/COLOR][/B]", 'action': 'top_pelis_series_menu',
        'icon': 'peliculas.png', 'fallback': 'DefaultVideoPlaylists.png', 'is_folder': True, 'default': 'main',
        'plot': "Cartelera, estrenos y tops de FilmAffinity, SensaCine, Cinemeta y Trakt.tv.",
    },
    'yt_search': {
        'label': "[B][COLOR red]Buscar en YouTube[/COLOR][/B]", 'action': 'yt_search',
        'icon': 'youtube.png', 'fallback': 'DefaultMusicVideos.png', 'is_folder': True, 'default': 'main',
        'plot': "Busca vídeos directamente en YouTube.\nLos resultados se reproducen aquí o se abren en el navegador.",
    },
    'manual_search': {
        'label': "[B][COLOR dodgerblue]Buscar en Dailymotion[/COLOR][/B]", 'action': 'manual_search',
        'icon': 'dailymotion.png', 'fallback': 'DefaultAddonWebSkin.png', 'is_folder': True, 'default': 'main',
        'plot': '',
    },
    'aemet_menu': {
        'label': "[B][COLOR lightskyblue]El Tiempo[/COLOR][/B]", 'action': 'aemet_menu',
        'icon': 'tiempo.png', 'fallback': 'DefaultAddonWeather.png', 'is_folder': True, 'default': 'main',
        'plot': "Pronóstico meteorológico oficial de España (AEMET).\nAñade tus ubicaciones y consulta el tiempo de los próximos 7 días.",
    },
    'press_menu': {
        'label': "[B][COLOR pink]Prensa[/COLOR][/B]", 'action': 'press_menu',
        'icon': 'prensa.png', 'fallback': 'DefaultPlaylist.png', 'is_folder': True, 'default': 'main',
        'plot': "Lee los titulares de última hora de los principales diarios y portales de noticias nacionales.",
    },
    'podcast_menu': {
        'label': "[B][COLOR coral]Podcast[/COLOR][/B]", 'action': 'podcast_menu',
        'icon': 'podcast.png', 'fallback': 'DefaultMusicSongs.png', 'is_folder': True, 'default': 'main',
        'plot': "Podcasts populares en español.\nEscucha los últimos episodios directamente.",
    },
    'loiolink_launch': {
        'label': "[B][COLOR deepskyblue]loiolink[/COLOR][/B]", 'action': 'loiolink_launch',
        'icon': 'loiolink.png', 'fallback': 'DefaultNetwork.png', 'is_folder': False, 'default': 'main',
        'plot': (
            "Centro de control web y navaja suiza para tu Kodi. Un sistema privado y local que funciona sin instalar aplicaciones ni registrarse.\n\n"
            "• Mando a distancia: Controla lo que estás viendo, navega por los menús o gestiona tus addons desde la web.\n"
            "• Toda tu colección: Navega por películas, series y música desde el navegador y reprodúcelas en la TV.\n"
            "• Streaming al móvil: Envía el vídeo desde el televisor para verlo en la pantalla de tu móvil, tablet o PC.\n"
            "• Favoritos: Edita y reordena accesos directos desde el navegador.\n"
            "• Escribe sin usar el mando: Escribe búsquedas o enlaces en el navegador y aparecen al instante en Kodi.\n"
            "• Copiar y pegar: Pega texto en buscadores de Kodi o copia nombres con el menú contextual.\n"
            "• Envío de vídeos, torrents, M3U o AceStream para reproducir, grabar o guardar en local.\n"
            "• Escáner web y Telegram: Rastrea páginas y canales para recopilar torrents, vídeos y enlaces.\n"
            "• Instalación de addons y archivos: Envía ZIPs o APKs desde el navegador para instalarlos al instante.\n"
            "• Grabación HLS: Graba emisiones en directo o programa grabaciones.\n"
            "• Explorador de archivos: Navega por carpetas y gestiona fuentes.\n"
            "• Apagado y reinicio: Apaga, reinicia o suspende el equipo remotamente.\n"
            "• Copia de seguridad: Guarda o restaura addons, favoritos y fuentes."
        ),
    },
    'open_url': {
        'label': "[B][COLOR mediumpurple]Abrir URL[/COLOR][/B]", 'action': 'open_url',
        'icon': 'url.png', 'fallback': 'DefaultAddSource.png', 'is_folder': True, 'default': 'main',
        'plot': "Reproduce una URL pegada: Dailymotion, YouTube, m3u8, mp4, mpd...",
    },
    'catalog_menu': {
        'label': lambda: ("[B][COLOR springgreen]Más[/COLOR][/B]" + (
            " [COLOR lime]●[/COLOR]" if xbmcaddon.Addon().getSetting('catalog_dot_seen') != 'true' else "")),
        'action': 'catalog_menu', 'icon': 'catalogo.png', 'fallback': 'DefaultFolder.png',
        'is_folder': True, 'default': 'main', 'movable': False,
        'plot': (
            "Verano · Educación y Divulgación · Cocina Española\n"
            "DGT — Tráfico · Playlists de YouTube · Mis Playlists de Dailymotion\n"
            "Tendencias · Buscar en Dailymotion · Último Boletín de Noticias\n"
            "España en Vivo (webcams) · Reloj Mundial\n"
            "Lotería Nacional · Precio de la Luz · Gasolineras Baratas\n"
            "IBEX 35 · Estado de Embalses · Calidad del Aire · Polen y Alergias\n"
            "Festivos · BOE · Empleo SEPE · Horarios de Transporte · Alquiler\n"
            "Audiolibros · Documentales · Efemérides · Galería de Arte\n"
            "Himnos · Astronomía y Cielos · Música Libre · Horóscopo · Agenda Cultural\n"
            "TV Nacional · Noticias · Deportes · Motor · Cine · Series · Infantil · Música · Gaming · Cultura"
        ),
    },
    'history_menu': {
        'label': "[B][COLOR aqua]Historial[/COLOR][/B]", 'action': 'history_menu',
        'icon': 'historial.png', 'fallback': 'DefaultAddonRepository.png', 'is_folder': True, 'default': 'main',
        'plot': '',
    },
    'show_favorites': {
        'label': "[B][COLOR khaki]Mis Favoritos[/COLOR][/B]", 'action': 'show_favorites',
        'icon': 'favoritos.png', 'fallback': 'DefaultSets.png', 'is_folder': True, 'default': 'main',
        'plot': '',
    },
    'show_downloads': {
        'label': "[B][COLOR lightblue]Descargas[/COLOR][/B]", 'action': 'show_downloads',
        'icon': 'descargas.png', 'fallback': 'DefaultHardDisk.png', 'is_folder': True, 'default': 'main',
        'plot': (
            "Vídeos descargados localmente y torrents P2P.\n\n"
            "[COLOR yellow]Aviso:[/COLOR] Descargar vídeos puede infringir los Términos de Servicio de las plataformas "
            "y las leyes de propiedad intelectual. "
            "El usuario es el único responsable del uso que haga de esta función."
        ),
    },
    'info_menu': {
        'label': "EspaKodi e Información", 'action': 'info_menu',
        'icon': 'info.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'main',
        'plot': '',
    },
    # ---------- Catálogo "Más" ----------
    'felicidad_menu': {
        'label': lambda: "[B][COLOR khaki]Verano[/COLOR][/B] ({0})".format(sum(len(v) for v in _FELICIDAD_VERANIEGA_YT.values())),
        'action': 'felicidad_menu', 'icon': 'cat_felicidad.png', 'fallback': 'DefaultMusicVideos.png',
        'is_folder': True, 'default': 'catalog',
        'plot': "Contenido para el buen rollo veraniego.\nGrand Prix, Humor Amarillo, summer mixes y buenas vibraciones.\nRequiere addon YouTube.",
    },
    'educacion_menu': {
        'label': lambda: "[B][COLOR cornflowerblue]Educación y Divulgación[/COLOR][/B] ({0})".format(sum(len(v) for v in _EDUCACION_DIVULGACION_YT.values())),
        'action': 'educacion_menu', 'icon': 'cat_educacion.png', 'fallback': 'DefaultAddonHelper.png',
        'is_folder': True, 'default': 'catalog',
        'plot': "Canales de divulgación científica, historia, matemáticas y tecnología en español.\nRequiere addon YouTube.",
    },
    'cocina_menu': {
        'label': lambda: "[B][COLOR peru]Cocina Española[/COLOR][/B] ({0})".format(sum(len(v) for v in _COCINA_ESPANOLA_YT.values())),
        'action': 'cocina_menu', 'icon': 'cat_cocina.png', 'fallback': 'DefaultMusicVideos.png',
        'is_folder': True, 'default': 'catalog',
        'condition': lambda: sum(len(v) for v in _COCINA_ESPANOLA_YT.values()) > 0,
        'plot': "Recetas y cocina española en YouTube.\nTortillas, paellas, tapas y mucho más.",
    },
    'dgt_menu': {
        'label': "[B][COLOR mediumpurple]DGT — Estado del tráfico[/COLOR][/B]", 'action': 'dgt_menu',
        'icon': 'dgt_coche.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Incidencias en carretera en tiempo real: retenciones, accidentes, obras, niebla, nieve.",
    },
    'yt_playlists_menu': {
        'label': lambda: "[B][COLOR tomato]{0}[/COLOR][/B]".format(
            "Playlists de YouTube ({0})".format(len(_ytp._load_yt_playlists())) if _ytp._load_yt_playlists() else "Playlists de YouTube"),
        'action': 'yt_playlists_menu', 'icon': 'DefaultVideoPlaylists.png', 'fallback': 'DefaultVideoPlaylists.png',
        'is_folder': True, 'default': 'catalog',
        'plot': "Gestiona tus playlists de YouTube.\nPega la URL de una playlist y accede a ella desde aquí.\nPuedes pegar desde el mando o desde tu móvil/PC.",
    },
    'play_latest_news': {
        'label': "[B][COLOR goldenrod]Último Boletín de Noticias[/COLOR][/B]", 'action': 'play_latest_news',
        'icon': 'radio_blanca.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': False, 'is_playable': True,
        'default': 'catalog',
        'plot': "Reproduce el audio del último informativo nacional de radio (Cadena SER / RNE / COPE).\nSe reproduce en segundo plano.",
    },
    'trending': {
        'label': "[B][COLOR limegreen]Tendencias[/COLOR][/B]", 'action': 'trending',
        'icon': 'DefaultMusicTop100.png', 'fallback': 'DefaultMusicTop100.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Vídeos trending en español de la última semana.",
    },
    'dm_playlists_search': {
        'label': "[B][COLOR steelblue]Buscar canales y playlists[/COLOR][/B]", 'action': 'dm_playlists_search',
        'icon': 'DefaultAddonsSearch.png', 'fallback': 'DefaultAddonsSearch.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Busca cualquier canal de Dailymotion por nombre.\nPuedes explorar sus vídeos, ver sus playlists y guardarlas en tu colección.",
    },
    'dm_saved_playlists': {
        'label': lambda: ("[B][COLOR plum]Mis Playlists guardadas ({0})[/COLOR][/B]".format(len(_load_saved_playlists()))
                          if _load_saved_playlists() else "[B][COLOR plum]Mis Playlists guardadas[/COLOR][/B]"),
        'action': 'dm_saved_playlists', 'icon': 'DefaultPlaylist.png', 'fallback': 'DefaultPlaylist.png',
        'is_folder': True, 'default': 'catalog',
        'plot': "Playlists de Dailymotion que has guardado.\nPuedes guardar playlists desde la búsqueda y borrarlas desde aquí.",
    },
    'webcams_menu': {
        'label': "[B][COLOR turquoise]España en Vivo[/COLOR][/B]", 'action': 'webcams_menu',
        'icon': 'webcam_blanca.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Cámaras web en directo de playas, ciudades y montañas de España.",
    },
    'reloj_mundial_menu': {
        'label': "[B][COLOR deepskyblue]Reloj Mundial[/COLOR][/B]", 'action': 'reloj_mundial_menu',
        'icon': 'reloj_mundial.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Hora actual en las principales ciudades del mundo.",
    },
    'loteria_menu': {
        'label': "[B][COLOR royalblue]Lotería Nacional[/COLOR][/B]", 'action': 'loteria_menu',
        'icon': 'cat_loteria.png', 'fallback': 'DefaultAddonGame.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Últimos resultados de Primitiva, Euromillones, Bonoloto, El Gordo, ONCE y más.",
    },
    'precio_luz_menu': {
        'label': "[B][COLOR gold]Precio de la Luz por Horas[/COLOR][/B]", 'action': 'precio_luz_menu',
        'icon': 'cat_luz.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Precio PVPC de la electricidad en España, hora a hora.\nFuente: API oficial de Red Eléctrica de España (apidatos.ree.es).",
    },
    'librivox_menu': {
        'label': "[B][COLOR khaki]Audiolibros[/COLOR][/B]", 'action': 'librivox_menu',
        'icon': 'cat_audiolibros.png', 'fallback': 'DefaultAudio.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Audiolibros gratuitos de dominio público.\nObras en español e inglés.",
    },
    'archive_documentales_es': {
        'label': "[B][COLOR mediumseagreen]Documentales en español[/COLOR][/B]", 'action': 'archive_documentales_es',
        'icon': 'cat_documentales.png', 'fallback': 'DefaultMovies.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Documentales en español del archivo público de Internet Archive.\nHistoria, naturaleza, ciencia, cultura y más.\n\nLos documentales se obtienen mediante búsqueda en directo cada vez que entras. No hay enlaces fijos: el catálogo puede variar en cada consulta.",
    },
    'efemerides_menu': {
        'label': "[B][COLOR lightblue]Un día como hoy en la Historia de España[/COLOR][/B]", 'action': 'efemerides_menu',
        'icon': 'cat_efemerides.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Efemérides relevantes para España según Wikipedia.\nAcontecimientos, nacimientos y fallecimientos del día.",
    },
    'ibex_menu': {
        'label': "[B][COLOR orange]IBEX 35 — Mercados[/COLOR][/B]", 'action': 'ibex_menu',
        'icon': 'cat_ibex.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Cotización del IBEX 35, histórico mensual y precios de los 35 valores del índice.",
    },
    'embalses_menu': {
        'label': "[B][COLOR deepskyblue]Estado de Embalses[/COLOR][/B]", 'action': 'embalses_menu',
        'icon': 'cat_embalses.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Nivel de llenado de los embalses españoles por cuenca hidrográfica.\nDatos semanales del MITECO.",
    },
    'aire_menu': {
        'label': "[B][COLOR lightblue]Calidad del Aire[/COLOR][/B]", 'action': 'aire_menu',
        'icon': 'cat_aire.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Calidad del aire en tiempo real en 12 ciudades españolas.\nMúltiples estaciones por ciudad. Niveles de NO₂, PM₁₀ y otros contaminantes.",
    },
    'polen_menu': {
        'label': "[B][COLOR palegreen]Nivel de Polen y Alergias[/COLOR][/B]", 'action': 'polen_menu',
        'icon': 'cat_polen.png', 'fallback': 'DefaultAddonHealth.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Niveles aerobiológicos por tipo de polen (Gramíneas, Olivo, etc.)\nNiveles de concentración actuales y prevención de alergias.",
    },
    'festivos_menu': {
        'label': "[B][COLOR tomato]Festivos Nacionales y Autonómicos[/COLOR][/B]", 'action': 'festivos_menu',
        'icon': 'cat_festivos.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Calendario de festivos nacionales y de tu Comunidad Autónoma para 2025 y 2026.\nConfigura tu CCAA en Ajustes.",
    },
    'boe_menu': {
        'label': "[B][COLOR royalblue]BOE — Boletín Oficial del Estado[/COLOR][/B]", 'action': 'boe_menu',
        'icon': 'cat_boe.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Últimas disposiciones del BOE: leyes, oposiciones, subvenciones y anuncios oficiales.",
    },
    'sepe_menu': {
        'label': "[B][COLOR mediumseagreen]Empleo SEPE y Oposiciones[/COLOR][/B]", 'action': 'sepe_menu',
        'icon': 'cat_sepe.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Convocatorias del SEPE, oposiciones a la Administración Pública y subvenciones al empleo.",
    },
    'gasolineras_menu': {
        'label': "[B][COLOR gold]Gasolineras Baratas[/COLOR][/B]", 'action': 'gasolineras_menu',
        'icon': 'cat_gasolineras.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Precios de carburantes en tiempo real ordenados de más barato a más caro.\nAPI oficial del Ministerio de Industria.\n[COLOR yellow]Puede requerir VPN.[/COLOR]",
    },
    'submenu_transporte': {
        'label': "[B][COLOR deepskyblue]Horarios de Transporte[/COLOR][/B]", 'action': 'submenu_transporte',
        'icon': 'cat_transporte.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Próximos trenes de metro y cercanías de varias ciudades españolas.\nDatos en tiempo real y horarios GTFS estáticos según la red.",
    },
    'alquiler_menu': {
        'label': "[B][COLOR coral]Evolución del Precio del Alquiler[/COLOR][/B]", 'action': 'alquiler_menu',
        'icon': 'cat_alquiler.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Variación del alquiler vs. el mismo mes del año anterior, por provincia.\nOrdenado de mayor a menor subida, con serie histórica mensual.\nFuente: INE — IPC subgrupo Alquiler de vivienda.",
    },
    'galeria_menu': {
        'label': "[B][COLOR plum]Galería de Obras de Arte[/COLOR][/B]", 'action': 'galeria_menu',
        'icon': 'cat_galeria_arte.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Obras de Goya, Velázquez, El Greco, Dalí y otros maestros en el Metropolitan Museum.\nColección pública de dominio público (CC0).",
    },
    'himnos_menu': {
        'label': "[B][COLOR orange]Himnos de España y CCAA[/COLOR][/B]", 'action': 'himnos_menu',
        'icon': 'cat_himnos.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Himno nacional de España, himnos de las 17 Comunidades Autónomas y el himno de la UE.\nArchivos de audio en dominio público de Wikimedia Commons.",
    },
    'submenu_astronomia': {
        'label': "[B][COLOR deepskyblue]Astronomía y Cielos[/COLOR][/B]", 'action': 'submenu_astronomia',
        'icon': 'cat_astronomia.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Fases Lunares y Calendario Astronómico Anual.\nCálculos locales sin necesidad de conexión.",
    },
    'musica_libre_menu': {
        'label': "[B][COLOR lightgreen]Música Libre[/COLOR][/B]", 'action': 'musica_libre_menu',
        'icon': 'cat_musica_libre.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Música con licencia Creative Commons y radios online libres. Sin registro.",
    },
    'horoscopo_menu': {
        'label': "[B][COLOR khaki]Horóscopo Diario[/COLOR][/B]", 'action': 'horoscopo_menu',
        'icon': 'cat_horoscopo.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Predicción del día para los 12 signos del zodiaco.\nConfigura tu signo en Ajustes.",
    },
    'agenda_cultural_menu': {
        'label': "[B][COLOR sandybrown]Agenda Cultural Nacional[/COLOR][/B]", 'action': 'agenda_cultural_menu',
        'icon': 'cat_agenda_cultural.png', 'fallback': 'DefaultIconInfo.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Fiestas de Interés Turístico Internacional y Nacional.\nNoticias del Ministerio de Cultura.",
    },
    # Secciones dinámicas de canales (datos desde canales_espana.json / museo_meme.json)
    'museo_meme': {'section_key': 'museo_meme', 'default': 'catalog'},
    'tv_nacional': {'section_key': 'tv_nacional', 'default': 'catalog'},
    'noticias': {'section_key': 'noticias', 'default': 'catalog'},
    'deportes': {'section_key': 'deportes', 'default': 'catalog'},
    'motor': {'section_key': 'motor', 'default': 'catalog'},
    'cine': {'section_key': 'cine', 'default': 'catalog'},
    'series': {'section_key': 'series', 'default': 'catalog'},
    'infantil': {'section_key': 'infantil', 'default': 'catalog'},
    'musica': {'section_key': 'musica', 'default': 'catalog'},
    'lifestyle': {'section_key': 'lifestyle', 'default': 'catalog'},
    'gaming': {'section_key': 'gaming', 'default': 'catalog'},
    'cultura': {'section_key': 'cultura', 'default': 'catalog'},
    'arte_museos_menu': {
        'label': lambda: "[B][COLOR orchid]Arte y Museos[/COLOR][/B] ({0})".format(sum(len(v) for v in _ARTE_MUSEOS_YT.values())),
        'action': 'arte_museos_menu', 'icon': 'cat_arte.png', 'fallback': 'DefaultPicture.png',
        'is_folder': True, 'default': 'catalog',
        'condition': lambda: sum(len(v) for v in _ARTE_MUSEOS_YT.values()) > 0,
        'plot': "Canales y vídeos de los grandes museos españoles en YouTube.\nPrado, Reina Sofía, Guggenheim, Patrimonio Nacional, flamenco y más.",
    },
    'internacional_es': {'section_key': 'internacional_es', 'default': 'catalog'},
    'filmoteca_menu': {
        'label': "[B][COLOR sandybrown]Filmoteca y NO-DO[/COLOR][/B]", 'action': 'filmoteca_menu',
        'icon': 'cat_filmoteca.png', 'fallback': 'DefaultMovies.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Archivo histórico de RTVE: NO-DO, Filmoteca Española, Memoria de España y más.",
    },
    'youtube_live_menu': {
        'label': "[B][COLOR crimson]YouTube[/COLOR][/B]", 'action': 'youtube_live_menu',
        'icon': 'DefaultAddonPVRClient.png', 'fallback': 'DefaultAddonPVRClient.png', 'is_folder': True, 'default': 'catalog',
        'plot': "Canales de YouTube en directo en español.\n24h noticias, música, documentales y más.",
    },
    'todavia_mas_menu': {
        'label': "[B][COLOR mediumpurple]Todavía más...[/COLOR][/B]", 'action': 'todavia_mas_menu',
        'icon': 'DefaultAddonHelper.png', 'fallback': 'DefaultAddonHelper.png',
        'is_folder': True, 'default': 'catalog',
        'plot': "Cine y animación libres de Internet Archive: clásicos de dominio público, ciencia ficción, animación clásica y films CC de la Blender Foundation.",
    },
}


def _ordered_merge(saved, defaults, valid):
    """Keys guardados (presentes en valid, sin duplicar) seguidos de los defaults
    que aún no han aparecido. Núcleo de orden compartido por el menú y el diálogo
    de búsqueda: tolerante a keys obsoletos (se descartan) y a items nuevos (al final)."""
    out, seen = [], set()
    for k in saved:
        if k in valid and k not in seen:
            out.append(k)
            seen.add(k)
    for k in defaults:
        if k not in seen:
            out.append(k)
            seen.add(k)
    return out


def _get_effective_layout():
    layout = core_settings.load_menu_layout()
    valid = set(_MENU_ITEMS_MASTER)
    # seen evita duplicados intra-lista e inter-lista (JSON corrupto o editado a mano):
    # el primer sitio donde aparece un key gana, no se vuelve a colocar.
    main_keys, catalog_keys, seen = [], [], set()
    for k in layout.get('main', []):
        if k in valid and k not in seen:
            main_keys.append(k)
            seen.add(k)
    for k in layout.get('catalog', []):
        if k in valid and k not in seen:
            catalog_keys.append(k)
            seen.add(k)
    for key, defn in _MENU_ITEMS_MASTER.items():
        if key not in seen:
            (main_keys if defn['default'] == 'main' else catalog_keys).append(key)
            seen.add(key)
    # Items no movibles: forzarlos a su menú por defecto
    for key, defn in _MENU_ITEMS_MASTER.items():
        if defn.get('movable', True):
            continue
        home = main_keys if defn['default'] == 'main' else catalog_keys
        other = catalog_keys if defn['default'] == 'main' else main_keys
        if key in other:
            other.remove(key)
        if key not in home:
            home.append(key)
    return main_keys, catalog_keys


def _item_display_label(key, spanish_data):
    defn = _MENU_ITEMS_MASTER.get(key)
    if not defn:
        return key
    sk = defn.get('section_key')
    if sk:
        sec = spanish_data.get(sk) if spanish_data else None
        return "[B]{0}[/B]".format(sec.get('name', sk) if sec else sk)
    label = defn['label']
    return label() if callable(label) else label


def _catalog_has_visible(catalog_keys):
    section_keys = []
    for k in catalog_keys:
        defn = _MENU_ITEMS_MASTER.get(k)
        if not defn:
            continue
        if defn.get('section_key'):
            section_keys.append(defn['section_key'])
            continue
        cond = defn.get('condition')
        if cond is None or cond():
            return True
    if not section_keys:
        return False
    data = _load_spanish_channels()
    return any(data.get(sk) for sk in section_keys)


def _render_menu_item(key, h, _mp, location, main_keys, catalog_keys, spanish_data=None, fanart=''):
    defn = _MENU_ITEMS_MASTER.get(key)
    if not defn:
        return False
    # Aislamiento por item: un label/plot/condition que falle (p.ej. un global de
    # conteo ausente en una versión futura) no debe tumbar el menú entero al arrancar.
    try:
        cond = defn.get('condition')
        if cond and not cond():
            return False
        sk = defn.get('section_key')
        if sk:
            if spanish_data is None:
                spanish_data = _load_spanish_channels()
            sec = spanish_data.get(sk)
            if not sec:
                return False
            count = len(sec.get('channels', []))
            label = "[B]{0}[/B] ({1})".format(sec.get('name', sk), count)
            icon = _resolve_icon(sec.get('icon', 'DefaultFolder.png'), 'DefaultFolder.png', _mp)
            plot = sec.get('plot', '')
            action, params, is_folder, is_playable = 'spanish_section', {'section': sk}, True, False
        else:
            label = defn['label']() if callable(defn['label']) else defn['label']
            plot = defn.get('plot', '')
            if callable(plot):
                plot = plot()
            icon = _resolve_icon(defn.get('icon', ''), defn.get('fallback', 'DefaultFolder.png'), _mp)
            action = defn['action']
            params = defn.get('params', {})
            is_folder = defn.get('is_folder', True)
            is_playable = defn.get('is_playable', False)

        li = xbmcgui.ListItem(label=label)
        art = {'icon': icon}
        if fanart:
            art['fanart'] = fanart
        li.setArt(art)
        if plot:
            li.setInfo('video', {'plot': plot})
        if is_playable:
            li.setProperty("IsPlayable", "true")

        seq = main_keys if location == 'main' else catalog_keys
        idx = seq.index(key) if key in seq else -1
        cm = []
        if idx > 0:
            cm.append(("Subir en el menú", _run(action='menu_item_up', key=key, location=location)))
        if 0 <= idx < len(seq) - 1:
            cm.append(("Bajar en el menú", _run(action='menu_item_down', key=key, location=location)))
        if defn.get('movable', True):
            if location == 'main':
                cm.append(("Mover al catálogo (Más)", _run(action='menu_move_to_catalog', key=key)))
            else:
                cm.append(("Mover al menú principal", _run(action='menu_move_to_main', key=key)))
        cm.append(("Personalizar menú…", _run(action='customize_menu_screen')))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action, **params), listitem=li, isFolder=is_folder)
        return True
    except Exception as e:
        _l("Menú: item '{0}' omitido por error: {1}".format(key, e))
        return False


def _menu_move(key, to_location):
    defn = _MENU_ITEMS_MASTER.get(key)
    if not defn or not defn.get('movable', True):
        return
    main_keys, catalog_keys = _get_effective_layout()
    for seq in (main_keys, catalog_keys):
        if key in seq:
            seq.remove(key)
    (main_keys if to_location == 'main' else catalog_keys).append(key)
    core_settings.save_menu_layout({'main': main_keys, 'catalog': catalog_keys})
    xbmc.executebuiltin("Container.Refresh")


def _menu_shift(key, location, delta):
    main_keys, catalog_keys = _get_effective_layout()
    seq = main_keys if location == 'main' else catalog_keys
    if key not in seq:
        return
    i = seq.index(key)
    j = i + delta
    if j < 0 or j >= len(seq):
        return
    seq[i], seq[j] = seq[j], seq[i]
    core_settings.save_menu_layout({'main': main_keys, 'catalog': catalog_keys})
    xbmc.executebuiltin("Container.Refresh")


def _customize_menu_screen():
    h = int(sys.argv[1])
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    li = xbmcgui.ListItem(label="[B]Gestionar menú principal[/B]")
    li.setArt({'icon': _ico('opciones.png')})
    li.setInfo('video', {'plot': "Reordena los elementos del menú principal y muévelos al catálogo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="reorder_menu", location="main"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]Gestionar catálogo (Más)[/B]")
    li.setArt({'icon': _ico('catalogo.png', 'DefaultFolder.png')})
    li.setInfo('video', {'plot': "Reordena los elementos del catálogo y muévelos al menú principal."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="reorder_menu", location="catalog"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR orange]Restaurar menú por defecto[/COLOR]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    li.setInfo('video', {'plot': "Devuelve el menú principal y el catálogo a su estado original."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="reset_menu_layout"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _reset_menu_layout_action():
    if xbmcgui.Dialog().yesno("Restaurar menú", "¿Devolver el menú principal y el catálogo a su orden original?"):
        core_settings.reset_menu_layout()
        xbmcgui.Dialog().notification("EspaTV", "Menú restaurado", xbmcgui.NOTIFICATION_INFO)


def _reorder_menu(location):
    main_keys, catalog_keys = _get_effective_layout()
    keys = list(main_keys if location == 'main' else catalog_keys)
    if len(keys) < 2:
        xbmcgui.Dialog().notification("EspaTV", "No hay elementos suficientes para reordenar", xbmcgui.NOTIFICATION_INFO)
        return
    spanish_data = _load_spanish_channels()
    title = "Reordenar " + ("menú principal" if location == 'main' else "catálogo")
    other_label = "catálogo (Más)" if location == 'main' else "menú principal"
    while True:
        labels = ["↕  " + _item_display_label(k, spanish_data) for k in keys]
        labels.append("[COLOR orange]Restaurar menú por defecto[/COLOR]")
        sel = xbmcgui.Dialog().select(title, labels)
        if sel < 0:
            return
        if sel == len(keys):
            if xbmcgui.Dialog().yesno("Restaurar menú", "¿Devolver el menú al orden original?"):
                core_settings.reset_menu_layout()
                xbmcgui.Dialog().notification("EspaTV", "Menú restaurado", xbmcgui.NOTIFICATION_INFO)
                return
            continue
        key = keys[sel]
        movable = _MENU_ITEMS_MASTER.get(key, {}).get('movable', True)
        opts = []
        if sel > 0:
            opts.append(('up', "↑ Subir"))
        if sel < len(keys) - 1:
            opts.append(('down', "↓ Bajar"))
        if movable:
            opts.append(('move', "→ Mover a " + other_label))
        opts.append(('cancel', "Cancelar"))
        sel2 = xbmcgui.Dialog().select("Mover «{0}»".format(_item_display_label(key, spanish_data)), [o[1] for o in opts])
        if sel2 < 0:
            continue
        act = opts[sel2][0]
        if act == 'cancel':
            continue
        if act == 'up':
            keys[sel - 1], keys[sel] = keys[sel], keys[sel - 1]
            other = catalog_keys if location == 'main' else main_keys
            core_settings.save_menu_layout({'main': keys, 'catalog': other} if location == 'main'
                                           else {'main': other, 'catalog': keys})
        elif act == 'down':
            keys[sel + 1], keys[sel] = keys[sel], keys[sel + 1]
            other = catalog_keys if location == 'main' else main_keys
            core_settings.save_menu_layout({'main': keys, 'catalog': other} if location == 'main'
                                           else {'main': other, 'catalog': keys})
        elif act == 'move':
            keys.pop(sel)
            if location == 'main':
                catalog_keys = list(catalog_keys) + [key]
                core_settings.save_menu_layout({'main': keys, 'catalog': catalog_keys})
            else:
                main_keys = list(main_keys) + [key]
                core_settings.save_menu_layout({'main': main_keys, 'catalog': keys})
            if len(keys) < 2:
                xbmcgui.Dialog().notification("EspaTV", "Elemento movido", xbmcgui.NOTIFICATION_INFO)
                return


def _catalog_menu():
    xbmcaddon.Addon().setSetting('catalog_dot_seen', 'true')
    h = int(sys.argv[1])
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    spanish_data = _load_spanish_channels()
    main_keys, catalog_keys = _get_effective_layout()
    _eff_fanart = '' if core_settings.is_fanart_disabled() else (core_settings.get_custom_fanart() or xbmcaddon.Addon().getAddonInfo('fanart'))

    def _ri(name, fallback='DefaultFolder.png'):
        if name and not name.startswith('Default'):
            p = os.path.join(_mp, name)
            return p if os.path.isfile(p) else fallback
        return name or fallback

    def _add_separator():
        li_sep = xbmcgui.ListItem(label="[COLOR gray]────────────────────────────────────────[/COLOR]")
        li_sep.setArt({'icon': _ri('sep_line.png', 'DefaultAddonNone.png')})
        li_sep.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="trololo"), listitem=li_sep, isFolder=False)

    for key in catalog_keys:
        # El separador va anclado justo encima de "Museo del Meme" (primera sección de
        # canales), siga donde siga ese item al reordenar. Solo si va a renderizarse.
        if key == 'museo_meme' and spanish_data.get('museo_meme'):
            _add_separator()
        _render_menu_item(key, h, _mp, 'catalog', main_keys, catalog_keys, spanish_data, fanart=_eff_fanart)

    # Nota informativa
    li = xbmcgui.ListItem(label="[COLOR gray][I]Nota: La mayoría del contenido se obtiene automáticamente. Algunos videos se han añadido manualmente para dar coherencia a cada sección.[/I][/COLOR]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    li.setInfo('video', {'plot': "La mayoría del contenido mostrado se obtiene mediante búsquedas automáticas por categoría.\nAlgunos canales y videos han sido añadidos manualmente para dar sentido y coherencia a cada sección.\nSu presencia no implica afinidad, preferencia ni promoción por parte de los desarrolladores."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="info_note"), listitem=li, isFolder=False)

    # --- Anuncios de otros addons ---
    li = xbmcgui.ListItem(label="[B][COLOR cornflowerblue]EspaDaily[/COLOR][/B] — Explorador de TV Española")
    li.setArt({'icon': 'DefaultAddonVideo.png'})
    li.setInfo('video', {'plot': "EspaDaily, el puente entre Kodi y las principales plataformas de TV española.\n\nNo elude muros de pago ni DRM — funciona con contenido en abierto."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="open_espadaily"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _my_recordings_menu():
    h = int(sys.argv[1])
    rec_path = xbmcaddon.Addon().getSetting("record_path")
    if not rec_path:
        xbmcgui.Dialog().notification("EspaTV", "Carpeta no configurada", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(h)
        return

    pvr_dir = os.path.join(rec_path, "Grabaciones_PVR")
    if not os.path.isdir(pvr_dir):
        li = xbmcgui.ListItem(label="No hay grabaciones guardadas actualmente")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    try:
        dirs, files = xbmcvfs.listdir(pvr_dir)
    except (OSError, RuntimeError):
        files = []

    xbmcplugin.setContent(h, "videos")
    has_videos = False

    for f in sorted(files, reverse=True):
        # Compatibilidad: xbmcvfs.listdir puede devolver bytes en algunas plataformas
        if isinstance(f, bytes):
            f = f.decode('utf-8', errors='ignore')
        if not f.lower().endswith(('.ts', '.mp4', '.partial')):
            continue
        has_videos = True
        file_path = os.path.join(pvr_dir, f)
        try:
            size = os.path.getsize(file_path) if os.path.exists(file_path) else 0
            s_str = "{0:.1f} MB".format(size / 1024.0 / 1024.0)
        except OSError:
            s_str = "Desconocido"

        is_partial = f.lower().endswith('.partial')
        label = f"[COLOR gray][incompleta][/COLOR] {f}" if is_partial else f
        plot = "Grabación incompleta (interrumpida):\n{0}\n\nTamaño: {1}".format(f, s_str) if is_partial else "Grabación PVR:\n{0}\n\nTamaño: {1}".format(f, s_str)

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultVideo.png'})
        li.setInfo('video', {'plot': plot})
        if is_partial:
            base = f[:-8].lower()  # quita ".partial"
            li.setMimeType('video/mp4' if base.endswith('.mp4') else 'video/mp2t')
            li.setContentLookup(False)

        cm = [("Borrar grabación", "RunPlugin({0})".format(_u(action="delete_recording", file=file_path)))]
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=h, url=file_path, listitem=li, isFolder=False)

    if not has_videos:
        li = xbmcgui.ListItem(label="No hay grabaciones guardadas actualmente")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

# --- REMOTE CHECKS ---

def _check_validity():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    sf = os.path.join(p, 'status_check.json')

    now = time.time()
    st = {'last_check': 0, 'disabled': False}
    if os.path.exists(sf):
        try:
            with open(sf, 'r', encoding='utf-8') as f:
                st = json.load(f)
        except (OSError, ValueError):
            pass

    if st.get('disabled', False):
        return False

    if now - st.get('last_check', 0) > 604800:
        data = None
        try:
            r = requests.get(_STATUS_URL, timeout=10)
            if r.status_code == 200:
                data = r.json()
        except (requests.RequestException, ValueError):
            pass

        if data:
            if not data.get('allowed', True):
                st['disabled'] = True
                with open(sf, 'w', encoding='utf-8') as f:
                    json.dump(st, f)
                return False

            min_v = data.get('min_version', '0.0.0')
            cur_v = xbmcaddon.Addon().getAddonInfo('version')
            def pv(v): return [int(x) for x in v.replace('v','').split('.') if x.isdigit()]

            if pv(cur_v) < pv(min_v):
                st['disabled'] = True
                with open(sf, 'w', encoding='utf-8') as f:
                    json.dump(st, f)
                return False

            st['last_check'] = now
            st['disabled'] = False
            with open(sf, 'w', encoding='utf-8') as f:
                json.dump(st, f)

    return True


def _check_messages():
    data = None
    try:
        r = requests.get(_MESSAGES_URL, timeout=5)
        if r.status_code == 200:
            data = r.json()
    except (requests.RequestException, ValueError):
        pass

    if not data:
        return

    # Soporte para formato plano {"id":..} y formato array {"messages":[..]}
    if isinstance(data, dict) and "messages" in data:
        msgs = data["messages"]
        if not isinstance(msgs, list) or not msgs: return
        msg = msgs[0]  # Mostrar solo el ultimo/primer mensaje
    elif isinstance(data, dict) and "id" in data:
        msg = data  # Formato plano legacy
    else:
        return

    mid = msg.get("id")
    if not mid: return

    # repeat: cuantas veces mostrar. -1=siempre, 0=nunca, N=N veces. Default=1 (una vez)
    mrep = msg.get("repeat", 1)
    if mrep == 0: return

    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    mf = os.path.join(p, 'messages_state.json')
    st = {}
    if os.path.exists(mf):
        try:
            with open(mf, 'r', encoding='utf-8') as f:
                st = json.load(f)
        except (OSError, ValueError):
            pass

    views = st.get(str(mid), 0)
    show_it = False
    if mrep == -1:
        show_it = True
    elif views < mrep:
        show_it = True

    if show_it:
        title = msg.get("title", msg.get("titulo", "Aviso EspaTV"))
        body = msg.get("text", msg.get("message", ""))
        xbmcgui.Dialog().ok(title, body)
        st[str(mid)] = views + 1
        with open(mf, 'w', encoding='utf-8') as f:
            json.dump(st, f)


def main_menu():
    try:
        _check_messages()
    except (requests.RequestException, ValueError, OSError):
        pass  # No bloquear el menu si falla la comprobacion de mensajes

    def _bg_download_ascii():
        import time as _t
        _t.sleep(5)
        _profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if not os.path.exists(_profile):
            os.makedirs(_profile)
        _dst = os.path.join(_profile, 'ascii.jpg')
        if os.path.exists(_dst):
            return
        try:
            _url = 'https://raw.githubusercontent.com/fullstackcurso/Ruta-Fullstack/main/ascii.jpg'
            r = requests.get(_url, timeout=10)
            if r.status_code == 200 and len(r.content) > 1000:
                with open(_dst, 'wb') as f:
                    f.write(r.content)
                xbmc.log("[EspaTV] ascii.jpg downloaded OK", xbmc.LOGINFO)
        except (requests.RequestException, OSError):
            pass
    import threading
    threading.Thread(target=_bg_download_ascii, daemon=True).start()

    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    h = int(sys.argv[1])
    main_keys, catalog_keys = _get_effective_layout()
    catalog_visible = _catalog_has_visible(catalog_keys)
    _eff_fanart = '' if core_settings.is_fanart_disabled() else (core_settings.get_custom_fanart() or xbmcaddon.Addon().getAddonInfo('fanart'))
    for key in main_keys:
        if key == 'catalog_menu' and not catalog_visible:
            continue
        _render_menu_item(key, h, _mp, 'main', main_keys, catalog_keys, fanart=_eff_fanart)

    # Opciones: siempre al final, no movible (punto de acceso a la personalización)
    _opciones_label = "[B][COLOR thistle]Opciones, mantenimiento y anti-errores[/COLOR][/B]"
    if xbmcaddon.Addon().getSetting('opciones_dot_seen') != 'true':
        _opciones_label += " [COLOR lime]●[/COLOR]"
    li = xbmcgui.ListItem(label=_opciones_label)
    li.setArt({'icon': _ico('opciones.png', 'DefaultAddonService.png')})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="advanced_menu"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)

    # Bienvenida tras instalar/actualizar (tras endOfDirectory: el menú ya está cargado)
    try:
        import welcome_splash
        welcome_splash.show_if_needed()
    except Exception as e:
        xbmc.log(f'[espatv] welcome_splash error: {e}', xbmc.LOGERROR)

def info_menu():
    h = int(sys.argv[1])
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ico(name):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else 'DefaultIconInfo.png'

    # Universo EspaKodi
    li = xbmcgui.ListItem(label="[COLOR skyblue]Universo EspaKodi[/COLOR]")
    li.setArt({'icon': _ico('info_universo.png')})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="show_universo"), listitem=li, isFolder=False)

    # Versión
    if _is_debug_active():
        li = xbmcgui.ListItem(label="Hecho por RubénSDFA1laberot")
        li.setArt({'icon': _ico('info_version.png')})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="sanitized_info"), listitem=li, isFolder=False)
    else:
        try:
            ver = xbmcaddon.Addon().getAddonInfo("version") or "?.?.?"
        except RuntimeError:
            ver = "?.?.?"
        li = xbmcgui.ListItem(label="Versión {0}".format(ver))
        li.setArt({'icon': _ico('info_version.png')})
        li.addContextMenuItems([("Créditos", "RunPlugin({0})".format(_u(action="caramelldansen")))])
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_version_video"), listitem=li, isFolder=False)

    # Actualizaciones / Repositorio
    _repo_id = "repository.espatv"
    is_installed = xbmc.getCondVisibility("System.HasAddon({0})".format(_repo_id))
    status_tag = "[COLOR lime]● INSTALADO[/COLOR]" if is_installed else "[COLOR orange]○ NO DETECTADO[/COLOR]"
    li = xbmcgui.ListItem(label="Actualizaciones: {0}".format(status_tag))
    li.setArt({'icon': _ico('info_repo.png')})
    li.setInfo('video', {'plot': "Verifica que el repositorio oficial está instalado para que el addon se mantenga actualizado solo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="check_repo_status"), listitem=li, isFolder=False)

    # EspaKodi Addons
    li = xbmcgui.ListItem(label="Addons EspaKodi")
    li.setArt({'icon': _ico('info_addons.png')})
    li.setInfo('video', {'plot': 'Instala y gestiona los addons del ecosistema EspaKodi: EspaDaily, AtresDaily, LoioLog, Flow FavManager, StreamNinja, TopZilla y loiolink.'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="espakodi_addons_menu"), listitem=li, isFolder=True)

    # Aviso VPN
    li = xbmcgui.ListItem(label="[B][COLOR yellow]La VPN puede causar fallos o ser necesaria[/COLOR][/B] — Algunos servidores bloquean VPNs (desactívala si un vídeo no carga). En otros casos puede ser necesaria.")
    li.setArt({'icon': _ico('info_vpn.png')})
    li.setInfo('video', {'plot': "Algunos servidores bloquean conexiones VPN. Si un vídeo no carga, prueba desactivando la VPN. En otros casos puede ser necesaria para que el contenido cargue correctamente."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="vpn_info"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _play_version_video():
    try:
        video_url = "https://raw.githubusercontent.com/espatv/espatv.github.io/main/media/espatv.mp4"
        li = xbmcgui.ListItem(label="EspaTV")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'title': 'EspaTV'})
        li.setProperty('IsPlayable', 'true')
        xbmc.Player().play(video_url, li)
    except Exception as exc:
        xbmc.log("[EspaTV] _play_version_video error: {0}".format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("EspaTV", "Error al reproducir video", xbmcgui.NOTIFICATION_ERROR)


def _check_repo_status_espatv():
    _repo_id = "repository.espatv"
    installed = xbmc.getCondVisibility("System.HasAddon({0})".format(_repo_id))

    if not installed:
        try:
            import xml.etree.ElementTree as ET
            addons_path = xbmcvfs.translatePath("special://home/addons/")
            dirs, _ = xbmcvfs.listdir(addons_path)
            for d in dirs:
                if "repository" not in d.lower() and "espatv" not in d.lower():
                    continue
                xml_vfs = "special://home/addons/{0}/addon.xml".format(d)
                if not xbmcvfs.exists(xml_vfs):
                    continue
                try:
                    vf = xbmcvfs.File(xml_vfs)
                    content = vf.read()
                    vf.close()
                    root = ET.fromstring(content)
                    if root.attrib.get('id', '') == _repo_id:
                        installed = True
                        break
                except (OSError, ET.ParseError, AttributeError, TypeError):
                    continue
        except Exception as e:
            xbmc.log("[EspaTV] Deep scan repo: {0}".format(e), xbmc.LOGWARNING)

    if installed:
        xbmcgui.Dialog().ok(
            "Estado del Repositorio",
            "[COLOR green][B]● INSTALADO Y ACTIVO[/B][/COLOR]\n\n"
            "El repositorio oficial está configurado correctamente.\n\n"
            "El addon se actualizará automáticamente cuando haya nuevas versiones disponibles."
        )
    else:
        if xbmcgui.Dialog().yesno(
            "Repositorio No Detectado",
            "Para recibir mejoras y actualizaciones automáticas, es necesario\n"
            "instalar el repositorio oficial de EspaTV.\n\n"
            "¿Deseas instalarlo ahora mismo?"
        ):
            _install_espatv_repo()


def _yt_pc_info():
    xbmcgui.Dialog().textviewer(
        "¿YouTube no funciona?",
        "YouTube bloquea peticiones desde IPs residenciales sin sesión activa "
        "(error: 'Sign in to confirm you're not a bot'). "
        "Afecta tanto al addon de YouTube como a yt-dlp.\n\n"
        "[B]Solución 1 — VPN[/B]\n"
        "Activa una VPN. Funciona con cualquier método de reproducción.\n\n"
        "[B]Solución 2 — Fallback automático con curl_cffi (solo yt-dlp)[/B]\n"
        "Si usas 'Reproducir con yt-dlp', EspaTV reintenta automáticamente "
        "imitando el fingerprint TLS de Chrome si tienes instalado curl_cffi:\n"
        "   pip install curl_cffi\n\n"
        "Con curl_cffi instalado el reintento ocurre solo, sin que tengas que hacer nada."
    )


def _vpn_info():
    xbmcgui.Dialog().ok(
        "VPN y compatibilidad",
        "Algunos servidores bloquean conexiones VPN.\n\n"
        "Si un vídeo no carga, prueba [B]desactivando la VPN[/B].\n\n"
        "En otros casos, algunos servidores pueden requerir VPN "
        "para funcionar correctamente."
    )


def _history_menu():
    # Enlace a Historial de Visionado dentro del historial
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    li = xbmcgui.ListItem(label="[B][COLOR mediumpurple]Historial de Visionado[/COLOR][/B]")
    li.setArt({'icon': _ico('historial.png', 'DefaultRecentlyAddedEpisodes.png')})
    li.setInfo('video', {'plot': "Vídeos reproducidos recientemente desde Dailymotion."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="watch_history"), listitem=li, isFolder=True)

    _sh.menu(skip_end=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _api_keys_menu():
    h = int(sys.argv[1])
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ico(n, fb='DefaultAddonService.png'):
        p = os.path.join(_mp, n)
        return p if os.path.exists(p) else fb

    user_tmdb = core_settings.get_tmdb_user_key()
    pool_count = len(core_settings._TMDB_KEY_POOL_B64)
    if user_tmdb:
        tmdb_status = "[COLOR green]Personalizada activa[/COLOR]"
        tmdb_plot = "Clave TMDB personalizada configurada. Tiene prioridad sobre el pool.\n\nPulsa para cambiarla o borrarla."
    elif pool_count:
        tmdb_status = "Pool interno ({0} claves)".format(pool_count)
        tmdb_plot = "El addon usa su pool de claves propias.\nPuedes añadir la tuya para tener prioridad máxima (recomendado para uso intensivo)."
    else:
        tmdb_status = "[COLOR orange]Sin claves — configura la tuya[/COLOR]"
        tmdb_plot = "No hay clave TMDB configurada. Pulsa para introducir la tuya desde themoviedb.org."
    li = xbmcgui.ListItem(label="TMDB — {0}".format(tmdb_status))
    li.setArt({'icon': _ico('top_tmdb.png')})
    li.setInfo('video', {'plot': tmdb_plot})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='api_key_tmdb_setup'), listitem=li, isFolder=False)

    mdb_pool = len(core_settings._MDBLIST_KEY_POOL_B64)
    mdb_user_keys = core_settings.get_mdblist_user_keys()
    if mdb_user_keys:
        mdb_status = "{0} clave{1} de usuario".format(len(mdb_user_keys), 's' if len(mdb_user_keys) > 1 else '')
    elif mdb_pool:
        mdb_status = "Pool interno ({0} claves)".format(mdb_pool)
    else:
        mdb_status = "[COLOR orange]Sin claves — configura la tuya[/COLOR]"
    li = xbmcgui.ListItem(label="MDbList — {0}".format(mdb_status))
    li.setArt({'icon': _ico('top_mdblist.png')})
    li.setInfo('video', {'plot': "Gestiona las claves de MDbList. Si una falla por rate limit se prueba la siguiente automáticamente."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='mdblist_manage_keys'), listitem=li, isFolder=True)

    user_trakt = core_settings.get_trakt_settings().get('api_key', '').strip()
    if user_trakt:
        trakt_status = "[COLOR green]Personalizada activa[/COLOR]"
        trakt_plot = "Clave (client ID) de Trakt personalizada configurada. Tiene prioridad sobre la del addon.\n\nPulsa para cambiarla o borrarla."
    else:
        trakt_status = "Cliente interno del addon"
        trakt_plot = "El addon usa su propio client ID de Trakt (compartido por todos los usuarios). Para uso intensivo o si distribuyes el addon, añade el tuyo desde trakt.tv/oauth/applications para no agotar el límite compartido."
    li = xbmcgui.ListItem(label="Trakt — {0}".format(trakt_status))
    li.setArt({'icon': _ico('top_trakt_real.png')})
    li.setInfo('video', {'plot': trakt_plot})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='api_key_trakt_setup'), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _api_key_tmdb_setup():
    current = core_settings.get_tmdb_user_key()
    opts = ["Introducir nueva clave TMDB"]
    if current:
        opts.append("Borrar clave personalizada (volver al pool)")
    sel = xbmcgui.Dialog().select("Clave TMDB personalizada", opts)
    changed = False
    if sel == 0:
        kb = xbmc.Keyboard(current, 'API key de TMDB (themoviedb.org)')
        kb.doModal()
        if kb.isConfirmed():
            key = kb.getText().strip()
            core_settings.set_tmdb_user_key(key)
            xbmcgui.Dialog().notification("EspaTV", "Clave TMDB guardada", xbmcgui.NOTIFICATION_INFO)
            changed = True
    elif sel == 1:
        core_settings.set_tmdb_user_key('')
        xbmcgui.Dialog().notification("EspaTV", "Clave TMDB personalizada eliminada", xbmcgui.NOTIFICATION_INFO)
        changed = True
    if changed:
        xbmc.executebuiltin("Container.Refresh")


def _api_key_trakt_setup():
    current = core_settings.get_trakt_settings().get('api_key', '').strip()
    opts = ["Introducir nueva clave Trakt"]
    if current:
        opts.append("Borrar clave personalizada (usar la del addon)")
    sel = xbmcgui.Dialog().select("Clave Trakt personalizada", opts)
    changed = False
    if sel == 0:
        kb = xbmc.Keyboard(current, 'Client ID de Trakt (trakt.tv/oauth/applications)')
        kb.doModal()
        if kb.isConfirmed():
            key = kb.getText().strip()
            core_settings.set_trakt_api_key(key)
            xbmcgui.Dialog().notification("EspaTV", "Clave Trakt guardada", xbmcgui.NOTIFICATION_INFO)
            changed = True
    elif sel == 1:
        core_settings.set_trakt_api_key('')
        xbmcgui.Dialog().notification("EspaTV", "Clave Trakt personalizada eliminada", xbmcgui.NOTIFICATION_INFO)
        changed = True
    if changed:
        xbmc.executebuiltin("Container.Refresh")


def advanced_menu():
    _adv_addon = xbmcaddon.Addon()
    _adv_addon.setSetting('opciones_dot_seen', 'true')
    _mp = os.path.join(_adv_addon.getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    # Personalizar menú (orden y reparto entre menú principal y catálogo)
    li = xbmcgui.ListItem(label="[B]Personalizar menú[/B]")
    li.setArt({'icon': _ico('opciones.png')})
    li.setInfo('video', {'plot': "Reordena los elementos y muévelos entre el menú principal y el catálogo (Más).\nTambién puedes hacerlo con el menú contextual sobre cada elemento."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="customize_menu_screen"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Configurar filas del Modo Cine[/B]")
    li.setArt({'icon': _ico('modo_grid.png', 'DefaultMovies.png')})
    li.setInfo('video', {'plot': "Elige qué filas aparecen en el Modo Cine (películas y series).\nPor defecto solo se muestran las secciones que cambian a menudo; aquí puedes activar géneros, Oscar, etc."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="configure_cinema_rows"), listitem=li, isFolder=False)

    # Accesibilidad (submenú)
    li = xbmcgui.ListItem(label="[B]Accesibilidad[/B]")
    li.setArt({'icon': _ico('adv_accesibilidad.png', 'DefaultAddonSkin.png')})
    li.setInfo('video', {'plot': "Opciones para daltónicos, baja visión y otros problemas visuales.\nModo de color, texto en negrita, sustitución de símbolos."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="accessibility_menu"), listitem=li, isFolder=True)

    # Texto blanco (acceso directo)
    _cur_acc_mode = xbmcaddon.Addon().getSetting('acc_color_mode') or 'none'
    if _cur_acc_mode == 'white':
        wt_label = "   Texto blanco (acceso rápido): [COLOR green]ACTIVADO[/COLOR]"
        wt_plot = "Pulsa para desactivar y volver a los colores originales."
    elif _cur_acc_mode in ('', 'none'):
        wt_label = "   Texto blanco (acceso rápido): [COLOR grey]DESACTIVADO[/COLOR]"
        wt_plot = "Pulsa para forzar todos los textos a blanco.\nPara más opciones de color y accesibilidad, entra en el submenú Accesibilidad de arriba."
    else:
        _cur_name = _ACC_COLOR_NAMES.get(_cur_acc_mode, _cur_acc_mode)
        wt_label = "   Texto blanco (acceso rápido): [COLOR orange]Otro modo activo[/COLOR]"
        wt_plot = "Hay otro modo de Accesibilidad activo: {0}.\n\nPulsar aquí lo SOBRESCRIBIRÁ con 'Texto blanco'. Para configurar otros modos, usa el submenú Accesibilidad.".format(_cur_name)
    li = xbmcgui.ListItem(label=wt_label)
    li.setArt({'icon': _ico('adv_accesibilidad.png', 'DefaultAddonSkin.png')})
    li.setInfo('video', {'plot': wt_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_force_white_text"), listitem=li, isFolder=False)

    # Fanart / Fondo de pantalla (un solo botón con todas las opciones)
    _fan_off = core_settings.is_fanart_disabled()
    _cf = core_settings.get_custom_fanart()
    if _fan_off:
        _cf_label = "Fanart / Fondo de pantalla: [COLOR grey]OCULTO[/COLOR]"
    elif _cf:
        _cf_label = "Fanart / Fondo de pantalla: [COLOR green]PERSONALIZADO[/COLOR]"
    else:
        _cf_label = "Fanart / Fondo de pantalla: [COLOR grey]PREDETERMINADO[/COLOR]"
    _cf_plot = "Gestiona la imagen de fondo del addon:\n\nElegir tu propia imagen, volver a la predeterminada u ocultar el fondo por completo (ni el personalizado ni el del addon)."
    li = xbmcgui.ListItem(label=_cf_label)
    li.setArt({'icon': _ico('adv_skin.png', 'DefaultAddonSkin.png'), 'fanart': '' if _fan_off else (_cf or _adv_addon.getAddonInfo('fanart'))})
    li.setInfo('video', {'plot': _cf_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="manage_custom_fanart"), listitem=li, isFolder=False)

    # Búsqueda Avanzada
    if core_settings.is_advanced_search_active():
        label = "Búsqueda DM: [COLOR green]AVANZADO (Submenú)[/COLOR]"
        plot = "Al pulsar 'Buscar manualmente', se abrirá un menú intermedio con opciones de búsqueda especializada (Cine, Exacta, etc.).\n\n[COLOR blue][I]Pulsa para volver a Búsqueda Directa[/I][/COLOR]"
    else:
        label = "Búsqueda DM: [COLOR grey]SIMPLE (Directa)[/COLOR]"
        plot = "Al pulsar 'Buscar manualmente', se abrirá directamente el teclado para escribir.\n\n[COLOR blue][I]Pulsa para activar el Menú Avanzado[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _ico('adv_busqueda.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_advanced_search"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Atajos '¿Dónde buscar?'")
    li.setArt({'icon': _ico('adv_busqueda.png')})
    li.setInfo('video', {'plot': "Gestiona el menú '¿Dónde quieres buscar?'.\n\nAñade atajos (cualquier addon instalado, comando o favorito de Kodi) y reordena u oculta cualquier opción, tanto tus atajos como las fijas."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_shortcuts_menu"), listitem=li, isFolder=True)

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.espadaily)"):
        _eda_on = core_settings.is_espadaily_integration_enabled()
        if _eda_on:
            _eda_label = "   Buscar en EspaDaily: [COLOR green]ACTIVADO[/COLOR]"
            _eda_plot = "Al buscar contenido, aparece 'Buscar en EspaDaily' como opción en el menú '¿Dónde quieres buscar?'.\n\nÚtil cuando EspaTV falla.\n\n[COLOR blue][I]Pulsa para desactivar.[/I][/COLOR]"
        else:
            _eda_label = "   Buscar en EspaDaily: [COLOR grey]DESACTIVADO[/COLOR]"
            _eda_plot = "Activa para que aparezca 'Buscar en EspaDaily' en el menú '¿Dónde quieres buscar?'.\n\nEspaDaily y EspaTV comparten origen. Si uno falla, el otro puede funcionar.\n\n[COLOR blue][I]Pulsa para activar.[/I][/COLOR]"
        li = xbmcgui.ListItem(label=_eda_label)
        li.setArt({'icon': _ico('adv_busqueda.png')})
        li.setInfo('video', {'plot': _eda_plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_espadaily_integration"), listitem=li, isFolder=False)

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.topzilla)"):
        _tz_on = core_settings.is_topzilla_integration_enabled()
        if _tz_on:
            _tz_label = "   Buscar en TopZilla: [COLOR green]ACTIVADO[/COLOR]"
            _tz_plot = "Al buscar contenido, aparece 'Buscar en TopZilla' como opción en el menú '¿Dónde quieres buscar?'.\n\nTopZilla es el sistema de búsqueda más completo del ecosistema.\n\n[COLOR blue][I]Pulsa para desactivar.[/I][/COLOR]"
        else:
            _tz_label = "   Buscar en TopZilla: [COLOR grey]DESACTIVADO[/COLOR]"
            _tz_plot = "Activa para que aparezca 'Buscar en TopZilla' en el menú '¿Dónde quieres buscar?'.\n\nTopZilla permite buscar, filtrar y consultar fichas de películas y series de forma avanzada.\n\n[COLOR blue][I]Pulsa para activar.[/I][/COLOR]"
        li = xbmcgui.ListItem(label=_tz_label)
        li.setArt({'icon': _ico('topzilla.png')})
        li.setInfo('video', {'plot': _tz_plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_topzilla_integration"), listitem=li, isFolder=False)

    # Método de entrada de búsqueda
    _si = (xbmcaddon.Addon().getSetting('search_input_default') or 'Preguntar siempre').strip()
    _si_label = f"Método de búsqueda: [COLOR green]{_si}[/COLOR]"
    li = xbmcgui.ListItem(label=_si_label)
    li.setArt({'icon': _ico('adv_busqueda.png')})
    li.setInfo('video', {'plot': "Elige cómo introducir el texto al buscar.\n\nTeclado: usa el teclado de Kodi.\nDesde móvil/PC: escribe desde el mando web.\nPreguntar siempre: te pregunta cada vez."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_search_input_method"), listitem=li, isFolder=False)

    # Modo Anti-Errores IPTV
    anti_err = xbmcaddon.Addon().getSetting('iptv_anti_errors') == 'true'
    if anti_err:
        ae_label = "Modo Anti-Errores IPTV: [COLOR green]ACTIVADO[/COLOR]"
    else:
        ae_label = "Modo Anti-Errores IPTV: [COLOR grey]DESACTIVADO[/COLOR]"
    ae_plot = "Si un canal te da 'Playback failed', activa este modo para solucionarlo."
    li = xbmcgui.ListItem(label=ae_label)
    li.setArt({'icon': _ico('adv_anti_errores.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': ae_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_iptv_anti_errors"), listitem=li, isFolder=False)

    # Inicio automático de addons
    li = xbmcgui.ListItem(label="Inicio automático de addons")
    li.setArt({'icon': _ico('adv_autostart.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Configura hasta 3 addons de Kodi para que se abran solos al arrancar.\n\nFunciona con cualquier addon instalado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="autostart_menu"), listitem=li, isFolder=True)

    # Inicio automático de favoritos
    li = xbmcgui.ListItem(label="Inicio automático de favoritos")
    li.setArt({'icon': _ico('adv_autostart.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Elige hasta 3 favoritos de Kodi para que se abran solos al arrancar.\n\nUsa los favoritos que ya tienes guardados en Kodi."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="autofav_menu"), listitem=li, isFolder=True)

    # Ajustes PVR y Generales
    li = xbmcgui.ListItem(label="Ajustes de Grabaciones")
    li.setArt({'icon': _ico('adv_grabaciones.png', 'DefaultAddonProgram.png')})
    li.setInfo('video', {'plot': "Configura la carpeta de destino para las grabaciones PVR de IPTV y TDT."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_settings"), listitem=li, isFolder=False)

    # Debug
    if _is_debug_active():
        li = xbmcgui.ListItem(label="Modo Debug: [COLOR green]ACTIVADO[/COLOR]")
    else:
        li = xbmcgui.ListItem(label="Modo Debug: [COLOR red]DESACTIVADO[/COLOR]")
    li.setArt({'icon': _ico('adv_debug.png')})
    li.setInfo('video', {'plot': "Activa el registro detallado de errores.\n\nPuedes generar un archivo de log interno para solucionar problemas. Puede ralentizar el addon."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_debug"), listitem=li, isFolder=False)

    # Dev Mode (solo visible con Debug activo)
    if _is_debug_active():
        dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
        is_dev = os.path.exists(dev_flag)
        if is_dev:
            dev_label = "   Modo Desarrollo: [COLOR green]ACTIVO[/COLOR]"
        else:
            dev_label = "   Modo Desarrollo: [COLOR grey]DESACTIVADO[/COLOR]"
        li = xbmcgui.ListItem(label=dev_label)
        li.setArt({'icon': _ico('adv_dev.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Protege los modulos internos del addon.\nCuando esta ACTIVO, el addon no se actualiza desde internet.\n\nDesactivar para recibir actualizaciones normales."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_dev_mode"), listitem=li, isFolder=False)

    # Log y Diagnóstico
    li = xbmcgui.ListItem(label="Log y Diagnóstico")
    li.setArt({'icon': _ico('adv_log.png', 'DefaultIconInfo.png')})
    li.setInfo('video', {'plot': "Herramientas para ver y analizar el log de Kodi y del addon.\nFiltrar errores, buscar entradas, ver tamaño, etc."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="log_menu"), listitem=li, isFolder=True)


        

    # Priorizar por Ajuste (Match) vs Duración
    if core_settings.is_prioritize_match_active():
        label = "Priorizar DM: [COLOR green]AJUSTE AL CONTEXTO[/COLOR]"
        plot = "MODO PRECISIÓN: Los resultados se ordenan según cuánto se parecen las palabras clave al título buscado.\n\nIdeal si te aparecen vídeos largos que no tienen nada que ver con lo que buscas.\n\n[COLOR blue][I]Pulsa para priorizar por DURACIÓN (Estándar)[/I][/COLOR]"
    else:
        label = "Priorizar DM: [COLOR grey]DURACIÓN (ESTÁNDAR)[/COLOR]"
        plot = "MODO CLÁSICO: Se da mucha importancia a la duración del vídeo para encontrar capítulos completos.\n\nPuede causar que aparezcan vídeos largos que no coinciden bien con el nombre.\n\n[COLOR blue][I]Pulsa para priorizar por PRECISIÓN[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _ico('adv_priorizar.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_prioritize_match"), listitem=li, isFolder=False)

    # Priorizar Contenido Reciente
    if core_settings.is_recent_active():
        label = "Filtro Temporal DM: [COLOR green]RECIENTES PRIMERO[/COLOR]"
        plot = "MODO NOTICIAS: Los vídeos se ordenan por FECHA DE SUBIDA.\n\nIdeal para ver informativos de hoy o programas diarios.\n\n[COLOR blue][I]Pulsa para desactivar[/I][/COLOR]"
    else:
        label = "Filtro Temporal DM: [COLOR grey]RELEVANCIA (POR DEFECTO)[/COLOR]"
        plot = "MODO MIXTO: El orden depende de cuánto se parezca el título, sin importar si el vídeo es de ayer o de hace meses.\n\n[COLOR blue][I]Pulsa para activar orden RECIENTE[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _ico('adv_filtro_tiempo.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_recent"), listitem=li, isFolder=False)

    # Modo Cine automático
    cinema_auto = xbmcaddon.Addon().getSetting("cinema_mode_auto") == "true"
    if cinema_auto:
        label_cinema = "Modo Cine automático: [COLOR green]ACTIVADO[/COLOR]"
        plot_cinema = "Al abrir una categoría de YouTube se abre directamente el Modo Cine.\n\n[COLOR blue][I]Pulsa para desactivar[/I][/COLOR]"
    else:
        label_cinema = "Modo Cine automático: [COLOR grey]DESACTIVADO[/COLOR]"
        plot_cinema = "Al abrir una categoría de YouTube se muestra el menú habitual.\n\n[COLOR blue][I]Pulsa para activar[/I][/COLOR]"
    li = xbmcgui.ListItem(label=label_cinema)
    li.setArt({'icon': _ico('cat_cine.png', 'DefaultMovies.png')})
    li.setInfo('video', {'plot': plot_cinema})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_cinema_auto"), listitem=li, isFolder=False)

    flix_lazy = core_settings.is_flix_lazy_enabled()
    if flix_lazy:
        label_lazy = "Carga perezosa del Modo Cine: [COLOR green]ACTIVADA[/COLOR]"
        plot_lazy = "El Modo Cine carga solo las primeras filas y el resto al hacer scroll.\n\nÚtil si tienes un dispositivo o internet lento, o muchas filas activas.\n\n[COLOR blue][I]Pulsa para desactivar[/I][/COLOR]"
    else:
        label_lazy = "Carga perezosa del Modo Cine: [COLOR grey]DESACTIVADA[/COLOR]"
        plot_lazy = "El Modo Cine carga todas las filas activas al abrir.\n\nActívala para cargar solo las primeras y el resto al hacer scroll (útil si tienes un dispositivo o internet lento, o con muchas filas).\n\n[COLOR blue][I]Pulsa para activar[/I][/COLOR]"
    li = xbmcgui.ListItem(label=label_lazy)
    li.setArt({'icon': _ico('cat_cine.png', 'DefaultMovies.png')})
    li.setInfo('video', {'plot': plot_lazy})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_flix_lazy_load"), listitem=li, isFolder=False)

    # Recordar última posición del Modo Cine
    flix_remember = core_settings.is_flix_remember_pos_enabled()
    if flix_remember:
        label_remember = "Recordar posición en el Modo Cine: [COLOR green]ACTIVADA[/COLOR]"
        plot_remember = "Al reabrir el Modo Cine vuelves al modo (Cine/Series), la fila y la película donde estabas.\n\nÚtil al salir a ver resultados de una búsqueda y volver.\n\n[COLOR blue][I]Pulsa para desactivar[/I][/COLOR]"
    else:
        label_remember = "Recordar posición en el Modo Cine: [COLOR grey]DESACTIVADA[/COLOR]"
        plot_remember = "El Modo Cine se abre siempre en lo destacado (arriba), en modo Cine.\n\nActívala para volver a la última fila y película donde estabas.\n\n[COLOR blue][I]Pulsa para activar[/I][/COLOR]"
    li = xbmcgui.ListItem(label=label_remember)
    li.setArt({'icon': _ico('cat_cine.png', 'DefaultMovies.png')})
    li.setInfo('video', {'plot': plot_remember})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_flix_remember_pos"), listitem=li, isFolder=False)

    # Tráiler del Modo Cine (submenú único: activar + indicador de carga)
    _tcfg = core_settings.load_trailer_config()
    if _tcfg['enabled']:
        label_tr = "Tráiler del Modo Cine: [COLOR green]ACTIVADO[/COLOR]"
    else:
        label_tr = "Tráiler del Modo Cine: [COLOR grey]DESACTIVADO[/COLOR]"
    li = xbmcgui.ListItem(label=label_tr)
    li.setArt({'icon': _ico('cat_cine.png', 'DefaultMovies.png')})
    li.setInfo('video', {'plot': "Configura el tráiler de YouTube que se reproduce al pasar unos segundos sobre una película.\n\nActivar/desactivar, tiempo de espera, idioma y el indicador de carga.\n\n[COLOR blue][I]Pulsa para configurar[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="trailer_config"), listitem=li, isFolder=False)

    _pgm_raw = (xbmcaddon.Addon().getSetting('pelis_grid_mode') or 'Preguntar').strip()
    _pgm_colors = {'Lista': '[COLOR grey]LISTA[/COLOR]', 'Botón': '[COLOR cyan]BOTÓN[/COLOR]',
                   'Grid directo': '[COLOR green]GRID DIRECTO[/COLOR]', 'Preguntar': '[COLOR grey]PREGUNTAR[/COLOR]'}
    _pgm_plots = {
        'Lista': 'Cinemeta, Top Valoradas y Mejores de la Historia muestran solo la lista de películas, sin botón Modo Grid.',
        'Botón': 'Se añade un botón "Modo Grid" al inicio de cada sección de películas.',
        'Grid directo': 'Al entrar en Cinemeta, Top Valoradas o Mejores de la Historia se abre directamente el grid visual.',
        'Preguntar': 'La próxima vez que entres en una sección de películas se volverá a preguntar qué modo prefieres.',
    }
    li_pgm = xbmcgui.ListItem(label='Vista de películas: {0}'.format(_pgm_colors.get(_pgm_raw, _pgm_raw)))
    li_pgm.setArt({'icon': _ico('top_mejores.png', 'DefaultMovies.png')})
    li_pgm.setInfo('video', {'plot': _pgm_plots.get(_pgm_raw, '') + '\n\n[COLOR blue][I]Pulsa para cambiar[/I][/COLOR]'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_pelis_grid_mode"), listitem=li_pgm, isFolder=False)

    # Filtro Anti-Trailers
    min_m = core_settings.get_min_duration()
    if min_m > 0:
        label = f"Anti-Trailers DM: [COLOR green]SOLO +{min_m} MIN[/COLOR]"
        plot = f"MODO CAPÍTULO: Oculta automáticamente cualquier vídeo de menos de {min_m} minutos.\n\nIdeal para limpiar trailers, clips y avances de los resultados de búsqueda.\n\n[COLOR blue][I]Pulsa para cambiar o desactivar[/I][/COLOR]"
    else:
        label = "Anti-Trailers DM: [COLOR grey]DESACTIVADO[/COLOR]"
        plot = "MODO TODOS: Muestra todos los resultados encontrados, sin importar su duración.\n\n[COLOR blue][I]Pulsa para filtrar por duración mínima[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _ico('adv_antitrailers.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_min_duration"), listitem=li, isFolder=False)

    # Copias de Seguridad
    li = xbmcgui.ListItem(label="Copias de Seguridad")
    li.setArt({'icon': _ico('adv_backup.png', 'DefaultAddonRepository.png')})
    li.setInfo('video', {'plot': "Crea, restaura e importa copias ZIP de todos los datos del addon.\nHistorial, favoritos, categorías, configuración y más."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="backups_menu"), listitem=li, isFolder=True)

    # Almacenamiento
    li = xbmcgui.ListItem(label="Almacenamiento y Cachés")
    li.setArt({'icon': _ico('adv_cache.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Ver y liberar espacio ocupado por las cachés del addon.\nBorra por categoría o limpia todo de una vez.\nNunca borra favoritos, historial ni tu configuración."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="storage_menu"), listitem=li, isFolder=True)

    # Claves API
    li = xbmcgui.ListItem(label="Claves API")
    li.setArt({'icon': _ico('opciones.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Gestiona las claves API de TMDB y MDbList.\nPuedes añadir tus propias claves con máxima prioridad.\nSi no configuras nada, el addon usa su pool interno."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="api_keys_menu"), listitem=li, isFolder=True)

    # Ruta de Descargas
    cfg = _load_dm_settings()
    d_path = cfg.get('download_path', '')
    dl_label = "Ruta de Descargas: [COLOR green]{0}[/COLOR]".format(d_path) if d_path else "Ruta de Descargas: [COLOR grey]NO CONFIGURADA[/COLOR]"
    li = xbmcgui.ListItem(label=dl_label)
    li.setArt({'icon': _ico('adv_ruta_dl.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Selecciona la carpeta donde se guardarán los vídeos descargados."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_download_path"), listitem=li, isFolder=False)
    
    # Modo Anti-Errores Dailymotion
    dm_level = cfg.get('dm_safe_level', 0)
    if dm_level == 0:
        dm_label = "Modo Anti-Errores DM: [COLOR grey]DESACTIVADO[/COLOR]"
    elif dm_level == 1:
        dm_label = "Modo Anti-Errores DM: [COLOR green]BÁSICO[/COLOR]"
    elif dm_level == 2:
        dm_label = "Modo Anti-Errores DM: [COLOR gold]EXTREMO[/COLOR]"
    else:
        dm_label = "Modo Anti-Errores DM: [COLOR cyan]YT-DLP[/COLOR]"
    dm_plot = (
        "MODO ANTI-ERRORES DAILYMOTION:\n\n"
        "[B]DESACTIVADO:[/B] Conexión normal de EspaTV.\n"
        "[B]BÁSICO:[/B] Simula teléfono móvil Android.\n"
        "[B]EXTREMO:[/B] Técnicas avanzadas (Subtítulos, Verificación de enlaces, etc).\n"
        "[B]YT-DLP:[/B] Usa yt-dlp. Recomendado en Windows donde el CDN bloquea Kodi.\n\n"
        "[I]Pulsa para cambiar el nivel.[/I]"
    )
    li = xbmcgui.ListItem(label=dm_label)
    li.setArt({'icon': _ico('adv_anti_errores.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': dm_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_dm_safe_level"), listitem=li, isFolder=False)

    # Modo de Descarga
    dl_mode = cfg.get('dl_mode', 0)
    if dl_mode == 0:
        d_mode_txt = "[COLOR grey]DIRECTO (Normal)[/COLOR]"
    elif dl_mode == 1:
        d_mode_txt = "[COLOR green]SAFE MODE (Gujal)[/COLOR]"
    elif dl_mode == 2:
        d_mode_txt = "[COLOR gold]MODO EspaTV (HLS Process)[/COLOR]"
    elif dl_mode == 3:
        d_mode_txt = "[COLOR cyan]YT-DLP (Externo)[/COLOR]"
    else:
        d_mode_txt = "[COLOR magenta]ULTRA (Multi-hilo HLS+)[/COLOR]"
        
    dl_s_label = f"Modo de Descarga: {d_mode_txt}"
    dl_s_plot = (
        "MODO DE DESCARGA:\n\n"
        "[B]DIRECTO:[/B] Muestra menú para elegir calidad.\n"
        "[B]SAFE MODE:[/B] Descarga el mejor MP4 directo.\n"
        "[B]EspaTV:[/B] Descarga por segmentos HLS.\n"
        "[B]YT-DLP:[/B] Usa yt-dlp (mejor calidad). Requiere Python 3.10+.\n"
        "[B]ULTRA:[/B] Igual que YT-DLP (mejor calidad). Recomendado en PC."
    )
    li = xbmcgui.ListItem(label=dl_s_label)
    li.setArt({'icon': _ico('adv_modo_dl.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': dl_s_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_dl_mode"), listitem=li, isFolder=False)

    # Mantenimiento yt-dlp (solo PC)
    if xbmc.getCondVisibility("System.Platform.Windows | System.Platform.Linux | System.Platform.OSX"):
        li = xbmcgui.ListItem(label="Mantenimiento PC (yt-dlp)")
        li.setArt({'icon': _ico('adv_ytdlp.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Muestra las instrucciones paso a paso para instalar yt-dlp en tu PC, o ejecuta un diagnóstico para comprobar si ya está instalado y funcionando correctamente."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ytdlp_menu"), listitem=li, isFolder=False)

    # --- Caché IPTV ---
    iptv_cache_on = core_settings.is_iptv_cache_active()
    ttl_val = core_settings.get_iptv_cache_ttl()
    ttl_name = "Desactivada"
    for v, n in core_settings._IPTV_CACHE_TTL_OPTIONS:
        if v == ttl_val: ttl_name = n; break

    if iptv_cache_on:
        c_label = "Caché IPTV/TDT: [COLOR green]ACTIVA ({0})[/COLOR]".format(ttl_name)
    else:
        c_label = "Caché IPTV/TDT: [COLOR grey]DESACTIVADA[/COLOR]"
    c_plot = (
        "CACHÉ IPTV / TDT:\n\n"
        "Guarda en disco los canales (M3U, TDT, etc) para que "
        "al pulsar ATRÁS se carguen al instante.\n\n"
        "[B]Estado:[/B] {0}\n"
        "[B]Duración:[/B] {1}\n\n"
        "[I]Pulsa para activar o desactivar.[/I]"
    ).format("Activa" if iptv_cache_on else "Desactivada", ttl_name)
    li = xbmcgui.ListItem(label=c_label)
    li.setArt({'icon': _ico('adv_cache.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': c_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_iptv_cache"), listitem=li, isFolder=False)

    if iptv_cache_on:
        ttl_label = "   Duración de caché IPTV: [COLOR green]{0}[/COLOR]".format(ttl_name)
        li = xbmcgui.ListItem(label=ttl_label)
        li.setArt({'icon': _ico('adv_filtro_tiempo.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Selecciona cuánto tiempo se mantienen guardados los canales.\n\n1 hora: Se actualizan rápido.\n12 horas: Equilibrio.\n1 día: Menos internet.\n1 semana: Ultra rápido.\n\n[I]Pulsa para cambiar.[/I]"})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_iptv_cache_ttl"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="   [COLOR orange]Restaurar caché por defecto[/COLOR]")
        li.setArt({'icon': _ico('adv_borrar.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Desactiva la caché IPTV y elimina todos los archivos cacheados.\nEl addon volverá a descargar los datos en cada entrada, como venía de fábrica."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="reset_iptv_cache"), listitem=li, isFolder=False)

    # Recordar posición en las listas
    _remember_pos = xbmcaddon.Addon().getSetting('remember_list_position') == 'true'
    _rp_estado = "[COLOR green]ACTIVADO[/COLOR]" if _remember_pos else "[COLOR grey]DESACTIVADO[/COLOR]"
    _rp_plot = (
        "RECORDAR POSICIÓN EN LAS LISTAS\n\n"
        "Algunas secciones (agenda, catálogos, clasificaciones...) no se guardan en disco, "
        "así que al volver con ATRÁS o al cerrar un vídeo Kodi las reconstruye desde cero "
        "y pierde el punto donde estabas.\n\n"
        "Con esta opción activa, esas listas se guardan en disco y al volver se restauran "
        "al instante conservando tu posición.\n\n"
        "A cambio, el contenido puede quedar algo desactualizado hasta que refresques "
        "(pulsa ATRÁS y vuelve a entrar).\n\n"
        "[I]Pulsa para activar o desactivar.[/I]"
    )
    li = xbmcgui.ListItem(label=f"Recordar posición en las listas: {_rp_estado}")
    li.setArt({'icon': _ico('adv_cache.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': _rp_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_remember_position"), listitem=li, isFolder=False)

    # PVR Integracion Nativa
    import pvr_manager
    if pvr_manager.is_pvr_installed():
        li = xbmcgui.ListItem(label="Abrir Guía de Televisión Nativa (PVR)")
        li.setArt({'icon': _ico('adv_pvr.png', 'DefaultAddonPVRClient.png')})
        li.setInfo('video', {'plot': "Salta instantáneamente a la sección 'TV' de Kodi para ver la parrilla de horarios."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_pvr"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="Forzar Auto-Configuración PVR")
        li.setArt({'icon': _ico('adv_pvr.png', 'DefaultAddonPVRClient.png')})
        li.setInfo('video', {'plot': "Utiliza esto para forzar que EspaTV reinstale y sobreescriba tu guía si falla."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="setup_pvr"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="Auto-Configurar Guía de TV Nativa (PVR Grid)")
        li.setArt({'icon': _ico('adv_pvr.png', 'DefaultAddonPVRClient.png')})
        li.setInfo('video', {'plot': "Esta opción vinculará la programación TDT con la sección nativa 'TV' del menú principal de Kodi.\n\nTe proporcionará una cuadrícula de horarios por horas (Grid) súper fluida. Reemplazará configuraciones PVR anteriores."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="setup_pvr"), listitem=li, isFolder=False)

    # Reproductor TDT (InputStream)
    use_ia = xbmcaddon.Addon().getSetting('use_inputstream') == 'true'
    if use_ia:
        ia_label = "Motor TDT (En Directo): [COLOR green]INPUTSTREAM ADAPTIVE[/COLOR]"
        ia_plot = "REPRODUCTOR AVANZADO: Forzando Kodi a usar el motor InputStream para M3U8.\n\nMejora la reconexión de red y permite pausar el directo (TimeShift).\n\n[COLOR blue][I]Pulsa para desactivar y volver al Reproductor Nativo de Kodi.[/I][/COLOR]"
    else:
        ia_label = "Motor TDT (En Directo): [COLOR grey]NATIVO (Por defecto)[/COLOR]"
        ia_plot = "REPRODUCTOR ESTÁNDAR: Usando el motor de vídeo nativo interno de Kodi.\n\nEl directo no se puede pausar, pero es compatible con todos los sistemas operativos.\n\n[COLOR blue][I]Pulsa para activar InputStream (Requiere addon instalado).[/I][/COLOR]"
    li = xbmcgui.ListItem(label=ia_label)
    li.setArt({'icon': _ico('adv_motor_tdt.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': ia_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_inputstream"), listitem=li, isFolder=False)

    # Puerto del servidor remoto
    _cur_port = xbmcaddon.Addon().getSetting('remote_port') or '8089'
    li = xbmcgui.ListItem(label="Puerto servidor remoto: [COLOR deepskyblue]{0}[/COLOR]".format(_cur_port))
    li.setArt({'icon': _ico('adv_puerto.png', 'DefaultNetwork.png')})
    li.setInfo('video', {'plot': "Puerto inicial del servidor HTTP local para enviar URLs o texto desde el móvil o PC.\nSi el puerto está ocupado, se prueban los 10 siguientes.\nPuerto actual: {0}".format(_cur_port)})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="config_remote_port"), listitem=li, isFolder=False)

    # Seguridad del servidor remoto
    _remote_secure = xbmcaddon.Addon().getSetting('remote_secure') == 'true'
    _secure_label = "[COLOR lime]ACTIVADA[/COLOR]" if _remote_secure else "[COLOR gray]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label="Seguridad mando web: {0}".format(_secure_label))
    li.setArt({'icon': _ico('adv_anti_errores.png', 'DefaultAddonProgram.png')})
    li.setInfo('video', {'plot': "Activa o desactiva la protección del mando web.\n\nCómo funciona el mando web:\nAl usarlo, EspaTV levanta un servidor HTTP en tu red local y muestra una URL. Abres esa dirección en el móvil y puedes enviar URLs a Kodi, controlar la reproducción o escanear páginas web.\n\nSEGURIDAD DESACTIVADA (por defecto):\nCualquier dispositivo en tu red WiFi puede acceder al mando. Ideal en casa con red de confianza.\n\nSEGURIDAD ACTIVADA:\nLa URL incluye un código único generado al arrancar el mando. Sin ese código nadie puede acceder aunque esté en tu red. Recomendado en redes públicas, hoteles o WiFi compartida."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_remote_secure"), listitem=li, isFolder=False)

    # Borrar Caché
    li = xbmcgui.ListItem(label="[COLOR red]¡BORRAR TODA LA CACHÉ![/COLOR]")
    li.setArt({'icon': _ico('adv_borrar.png', 'DefaultIconError.png')})
    li.setInfo('video', {'plot': "Elimina datos temporales de canales, historial de red y caché IPTV.\nNO borra tus listas ni tu configuración.\n\nSOLUCIONA PROBLEMAS: úsalo si los menús muestran información antigua o comportamientos extraños."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="clear_cache"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _toggle_inputstream():
    cur = xbmcaddon.Addon().getSetting('use_inputstream') == 'true'
    xbmcaddon.Addon().setSetting('use_inputstream', "false" if cur else "true")
    if not cur:
        try:
            xbmcaddon.Addon('inputstream.adaptive')
            xbmcgui.Dialog().notification("Reproductor", "InputStream Adaptive ACTIVADO", xbmcgui.NOTIFICATION_INFO)
        except RuntimeError:
            xbmcgui.Dialog().ok("Aviso Importante", "Has activado usar InputStream Adaptive, pero parece que el componente oficial no está instalado.\n\nVe al repositorio oficial de Kodi -> Addons de Vídeo InputStream e instala InputStream Adaptive para que funcione, o vuelve a desactivar esta opción.")
    else:
        xbmcgui.Dialog().notification("Reproductor", "InputStream Adaptive DESACTIVADO", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_remote_secure():
    cur = xbmcaddon.Addon().getSetting('remote_secure') == 'true'
    xbmcaddon.Addon().setSetting('remote_secure', "false" if cur else "true")
    if not cur:
        xbmcgui.Dialog().notification("Mando web", "Seguridad ACTIVADA", xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("Mando web", "Seguridad DESACTIVADA", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _url_player_config_menu():
    addon = xbmcaddon.Addon()
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    h = int(sys.argv[1])

    # webremote_mode es labelenum: puede venir como etiqueta o como índice
    mode_raw = (addon.getSetting('webremote_mode') or 'Red local').strip()
    mode_internet = mode_raw in ('1', 'Internet')

    # 1. Modo de conexión
    mode_label = "[COLOR cyan]Internet (relay ntfy)[/COLOR]" if mode_internet else "[COLOR green]Red local[/COLOR]"
    li = xbmcgui.ListItem(label=f"Modo de conexión: {mode_label}")
    li.setArt({'icon': _ico('adv_puerto.png', 'DefaultNetwork.png')})
    li.setInfo('video', {'plot': (
        "Cómo escucha el receptor de URLs.\n\n"
        "[B]Red local:[/B] accesible solo en tu WiFi. Rápido y sin dependencias.\n\n"
        "[B]Internet (relay ntfy):[/B] usa el servidor ntfy para recibir URLs desde fuera de casa.\n\n"
        "[COLOR blue][I]Pulsa para cambiar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_webremote_mode"), listitem=li, isFolder=False)

    # 2. Puerto (reutiliza handler config_remote_port)
    cur_port = addon.getSetting('remote_port') or '8089'
    li = xbmcgui.ListItem(label=f"Puerto servidor: [COLOR deepskyblue]{cur_port}[/COLOR]")
    li.setArt({'icon': _ico('adv_puerto.png', 'DefaultNetwork.png')})
    li.setInfo('video', {'plot': (
        f"Puerto inicial del servidor HTTP local para enviar URLs desde el móvil o PC.\n"
        f"Si está ocupado, se prueban los 10 siguientes.\nPuerto actual: {cur_port}\n\n"
        "[COLOR blue][I]Pulsa para cambiar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="config_remote_port"), listitem=li, isFolder=False)

    # 3. Seguridad (reutiliza handler toggle_remote_secure)
    secure = addon.getSetting('remote_secure') == 'true'
    secure_label = "[COLOR lime]ACTIVADA[/COLOR]" if secure else "[COLOR gray]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label=f"Seguridad (código de acceso): {secure_label}")
    li.setArt({'icon': _ico('adv_anti_errores.png', 'DefaultAddonProgram.png')})
    li.setInfo('video', {'plot': (
        "Protección del mando web.\n\n"
        "DESACTIVADA (por defecto): cualquier dispositivo de tu WiFi puede acceder. Ideal en casa.\n\n"
        "ACTIVADA: la URL incluye un código único; sin él nadie accede aunque esté en tu red. "
        "Recomendado en redes públicas.\n\n"
        "[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_remote_secure"), listitem=li, isFolder=False)

    # 4. Confirmar antes de reproducir
    confirm = addon.getSetting('webremote_confirm') == 'true'
    confirm_label = "[COLOR lime]SÍ[/COLOR]" if confirm else "[COLOR grey]NO[/COLOR]"
    li = xbmcgui.ListItem(label=f"Confirmar antes de reproducir: {confirm_label}")
    li.setArt({'icon': _ico('adv_anti_errores.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': (
        "Si está activo, Kodi pregunta antes de reproducir cada URL recibida desde el móvil o PC. "
        "Evita reproducciones accidentales.\n\n"
        "[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_webremote_confirm"), listitem=li, isFolder=False)

    # 5 y 6. Solo en modo Internet
    if mode_internet:
        ntfy_server = (addon.getSetting('webremote_server') or 'https://ntfy.sh').rstrip('/')
        ntfy_topic = addon.getSetting('webremote_topic') or '(se genera al primer uso)'

        li = xbmcgui.ListItem(label=f"Servidor relay: [COLOR deepskyblue]{ntfy_server}[/COLOR]")
        li.setArt({'icon': _ico('adv_puerto.png', 'DefaultNetwork.png')})
        li.setInfo('video', {'plot': (
            f"URL del servidor ntfy para el relay de Internet.\nActual: {ntfy_server}\n\n"
            f"Canal asignado: {ntfy_topic}\n\n"
            "Puedes usar el público ntfy.sh o alojar el tuyo.\n\n"
            "[COLOR blue][I]Pulsa para cambiar la URL.[/I][/COLOR]"
        )})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_webremote_server"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR orange]Regenerar canal ntfy[/COLOR]")
        li.setArt({'icon': _ico('adv_refrescar.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': (
            f"Canal actual: {ntfy_topic}\n\n"
            "Borra el canal para que se genere uno nuevo aleatorio al próximo arranque del mando.\n"
            "Tendrás que actualizar la suscripción en tu móvil.\n\n"
            "[COLOR blue][I]Pulsa para regenerar.[/I][/COLOR]"
        )})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="reset_webremote_topic"), listitem=li, isFolder=False)

    # Resolver Debrid (estado leído de settings, sin llamadas de red)
    deb_enabled = addon.getSetting('debrid_enabled') == 'true'
    deb_provider, deb_auth, deb_user = _debrid_status()
    if deb_enabled and deb_auth:
        deb_label = "Resolver Debrid: [COLOR lime]{0}[/COLOR]".format(
            "{0} · {1}".format(deb_provider, deb_user) if deb_user else deb_provider)
    elif deb_enabled:
        deb_label = "Resolver Debrid: [COLOR orange]activado, sin vincular[/COLOR]"
    else:
        deb_label = "Resolver Debrid: [COLOR gray]desactivado[/COLOR]"
    li = xbmcgui.ListItem(label=deb_label)
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': (
        "Reproduce enlaces de hosters premium (1fichier, Mega, Rapidgator...) y "
        "convierte magnets en streams directos usando tu cuenta Debrid.\n\n"
        "Vincula la cuenta, elige proveedor y opciones.\n\n"
        "[COLOR blue][I]Pulsa para gestionar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_menu"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)

def _debrid_status():
    """Devuelve (provider, authorized, user) del proveedor activo, sin red. Defensivo."""
    provider = xbmcaddon.Addon().getSetting('debrid_provider') or 'AllDebrid'
    try:
        import debrid_resolver
        r = debrid_resolver.get_resolver()
        return provider, r.is_authorized(), r.stored_user()
    except Exception:
        return provider, False, ""

def _debrid_menu():
    addon = xbmcaddon.Addon()
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    h = int(sys.argv[1])
    enabled = addon.getSetting('debrid_enabled') == 'true'
    provider, authorized, user = _debrid_status()

    # Estado (informativo, sin red)
    if authorized:
        estado = "[COLOR lime]{0} · {1}[/COLOR]".format(provider, user) if user else "[COLOR lime]{0}[/COLOR]".format(provider)
    else:
        estado = "[COLOR gray]Sin vincular[/COLOR]"
    li = xbmcgui.ListItem(label="Estado: {0}".format(estado))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Proveedor activo y cuenta vinculada."})
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)

    # Activar/desactivar resolución
    en_label = "[COLOR lime]ACTIVADA[/COLOR]" if enabled else "[COLOR grey]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label="Resolución Debrid: {0}".format(en_label))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Si está activa, magnets y enlaces de hosters premium se resuelven con tu cuenta antes del método normal.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_toggle_enabled"), listitem=li, isFolder=False)

    # Proveedor
    li = xbmcgui.ListItem(label="Proveedor: [COLOR deepskyblue]{0}[/COLOR]".format(provider))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Servicio Debrid a usar: AllDebrid, Real-Debrid, TorBox o Premiumize."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_set_provider"), listitem=li, isFolder=False)

    if not authorized:
        supports_pin = True
        try:
            import debrid_resolver
            supports_pin = debrid_resolver.get_resolver().SUPPORTS_PIN
        except Exception:
            pass
        if supports_pin:
            li = xbmcgui.ListItem(label="[COLOR limegreen]Vincular cuenta (código PIN)[/COLOR]")
            li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
            li.setInfo('video', {'plot': "Muestra un código para introducir en la web del proveedor y vincula tu cuenta automáticamente."})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_authorize_pin"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR limegreen]Introducir API Key manualmente[/COLOR]")
        li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Pega la API key de tu cuenta (la encuentras en la web del proveedor)."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_authorize_key"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="Comprobar cuenta / tráfico")
        li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Consulta el estado de tu cuenta (premium, caducidad)."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_account"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR lightsalmon]Desconectar cuenta[/COLOR]")
        li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Elimina la cuenta vinculada de este addon."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_deauthorize"), listitem=li, isFolder=False)

    # Toggles de comportamiento
    cached = addon.getSetting('debrid_cached_only') == 'true'
    li = xbmcgui.ListItem(label="Solo caché (no esperar descargas): {0}".format(
        "[COLOR lime]SÍ[/COLOR]" if cached else "[COLOR grey]NO[/COLOR]"))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Si está activo, un magnet que no esté ya en la nube se omite (cae a Elementum) en lugar de esperar a que se descargue."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_toggle_cached"), listitem=li, isFolder=False)

    cleanup = addon.getSetting('debrid_auto_cleanup') == 'true'
    li = xbmcgui.ListItem(label="Borrar torrent tras reproducir: {0}".format(
        "[COLOR lime]SÍ[/COLOR]" if cleanup else "[COLOR grey]NO[/COLOR]"))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Elimina el torrent de tu cuenta tras obtener el enlace, para no llenar la nube."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_toggle_cleanup"), listitem=li, isFolder=False)

    quality = addon.getSetting('debrid_auto_quality') == 'true'
    li = xbmcgui.ListItem(label="Auto-seleccionar mayor calidad/archivo: {0}".format(
        "[COLOR lime]SÍ[/COLOR]" if quality else "[COLOR grey]NO[/COLOR]"))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Si está activo, elige automáticamente el archivo de vídeo más grande y la mayor calidad sin preguntar."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_toggle_quality"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _debrid_reset_instance():
    try:
        import debrid_resolver
        debrid_resolver.reset_resolver()
    except Exception:
        pass

def _debrid_toggle_enabled():
    addon = xbmcaddon.Addon()
    cur = addon.getSetting('debrid_enabled') == 'true'
    if not cur:
        # Disclaimer de uso responsable la primera vez que se activa
        if addon.getSetting('debrid_disclaimer_seen') != 'true':
            if not xbmcgui.Dialog().yesno(
                "Resolver Debrid - Uso responsable",
                "El resolver usa TU cuenta Debrid para reproducir los enlaces y magnets que TÚ proporcionas.\n\n"
                "Eres responsable del contenido al que accedes y de respetar la ley de tu país y los términos de tu servicio Debrid.\n\n"
                "¿Activar el Resolver Debrid?"):
                return
            addon.setSetting('debrid_disclaimer_seen', 'true')
        addon.setSetting('debrid_enabled', 'true')
        xbmcgui.Dialog().notification("Debrid", "Resolución ACTIVADA", xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        addon.setSetting('debrid_enabled', 'false')
        xbmcgui.Dialog().notification("Debrid", "Resolución DESACTIVADA", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _debrid_set_provider():
    opciones = ["AllDebrid", "Real-Debrid", "TorBox", "Premiumize"]
    cur = xbmcaddon.Addon().getSetting('debrid_provider') or 'AllDebrid'
    pre = opciones.index(cur) if cur in opciones else 0
    sel = xbmcgui.Dialog().select("Proveedor Debrid", opciones, preselect=pre)
    if sel < 0:
        return
    xbmcaddon.Addon().setSetting('debrid_provider', opciones[sel])
    _debrid_reset_instance()
    xbmcaddon.Addon().setSetting('debrid_hosts_cache', '')  # invalida cache de hosts del anterior
    xbmc.executebuiltin("Container.Refresh")

def _debrid_authorize_pin():
    try:
        import debrid_resolver
        ok = debrid_resolver.get_resolver().authorize_pin()
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "Error al vincular:\n{0}".format(e))
        return
    if ok:
        xbmcgui.Dialog().notification("Debrid", "Cuenta vinculada", xbmcgui.NOTIFICATION_INFO, 2500)
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _debrid_authorize_key():
    key = xbmcgui.Dialog().input("API Key del proveedor")
    if not key:
        return
    try:
        import debrid_resolver
        ok = debrid_resolver.get_resolver().authorize_apikey(key)
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "Error:\n{0}".format(e))
        return
    if ok:
        xbmcgui.Dialog().notification("Debrid", "Cuenta vinculada", xbmcgui.NOTIFICATION_INFO, 2500)
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _debrid_deauthorize():
    if not xbmcgui.Dialog().yesno("Debrid", "¿Desconectar la cuenta de este addon?"):
        return
    try:
        import debrid_resolver
        debrid_resolver.get_resolver().deauthorize()
    except Exception:
        pass
    _debrid_reset_instance()
    xbmcgui.Dialog().notification("Debrid", "Cuenta desconectada", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _debrid_account():
    try:
        import debrid_resolver
        info = debrid_resolver.get_resolver().account_info()
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "No se pudo consultar la cuenta:\n{0}".format(e))
        return
    estado = "Premium" if info.get("premium") else "No premium"
    expiry = info.get("expiry_text") or ""
    days = info.get("days")
    extra = info.get("extra") or ""
    lineas = ["Usuario: {0}".format(info.get("username", "?")), "Estado: {0}".format(estado)]
    if expiry:
        dtxt = " ({0} días)".format(days) if isinstance(days, int) else ""
        lineas.append("Válida hasta: {0}{1}".format(expiry, dtxt))
    if extra:
        lineas.append(extra)
    xbmcgui.Dialog().ok("Cuenta Debrid", "\n".join(lineas))

def _debrid_toggle_cached():
    cur = xbmcaddon.Addon().getSetting('debrid_cached_only') == 'true'
    xbmcaddon.Addon().setSetting('debrid_cached_only', "false" if cur else "true")
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _debrid_toggle_cleanup():
    cur = xbmcaddon.Addon().getSetting('debrid_auto_cleanup') == 'true'
    xbmcaddon.Addon().setSetting('debrid_auto_cleanup', "false" if cur else "true")
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _debrid_toggle_quality():
    cur = xbmcaddon.Addon().getSetting('debrid_auto_quality') == 'true'
    xbmcaddon.Addon().setSetting('debrid_auto_quality', "false" if cur else "true")
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _set_webremote_mode():
    # labelenum: se guarda la ETIQUETA (igual que _set_search_input_method)
    labels = ["Red local", "Internet"]
    addon = xbmcaddon.Addon()
    cur_raw = (addon.getSetting('webremote_mode') or 'Red local').strip()
    cur = 1 if cur_raw in ('1', 'Internet') else 0
    sel = xbmcgui.Dialog().select("Modo de conexión del receptor de URLs",
                                  ["Red local (solo WiFi)", "Internet (relay ntfy)"], preselect=cur)
    if sel < 0:
        return
    addon.setSetting('webremote_mode', labels[sel])
    xbmcgui.Dialog().notification("Mando web", f"Modo: {labels[sel]}", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_webremote_confirm():
    cur = xbmcaddon.Addon().getSetting('webremote_confirm') == 'true'
    xbmcaddon.Addon().setSetting('webremote_confirm', "false" if cur else "true")
    msg = "Confirmación ACTIVADA" if not cur else "Confirmación DESACTIVADA"
    xbmcgui.Dialog().notification("Mando web", msg, xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _set_webremote_server():
    addon = xbmcaddon.Addon()
    cur = (addon.getSetting('webremote_server') or 'https://ntfy.sh').strip()
    nuevo = xbmcgui.Dialog().input("Servidor relay ntfy (URL completa)", defaultt=cur)
    if not nuevo:
        return
    nuevo = nuevo.strip().rstrip('/')
    if not nuevo.startswith(("http://", "https://")):
        xbmcgui.Dialog().ok("EspaTV", "URL no válida. Debe empezar por http:// o https://")
        return
    addon.setSetting('webremote_server', nuevo)
    xbmcgui.Dialog().notification("Mando web", "Servidor actualizado", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _reset_webremote_topic():
    addon = xbmcaddon.Addon()
    cur = addon.getSetting('webremote_topic') or '(no asignado)'
    if not xbmcgui.Dialog().yesno(
        "Regenerar canal ntfy",
        f"Canal actual: {cur}\n\nSe generará uno nuevo al próximo arranque del mando.\n"
        "Tendrás que actualizar la suscripción en tu móvil.\n\n¿Continuar?"
    ):
        return
    addon.setSetting('webremote_topic', '')
    xbmcgui.Dialog().notification("Mando web", "Canal regenerado al próximo uso", xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_remember_position():
    cur = xbmcaddon.Addon().getSetting('remember_list_position') == 'true'
    xbmcaddon.Addon().setSetting('remember_list_position', "false" if cur else "true")
    estado = "DESACTIVADO" if cur else "ACTIVADO"
    xbmcgui.Dialog().notification("EspaTV", f"Recordar posición {estado}", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _set_search_input_method():
    opciones = ["Preguntar siempre", "Teclado", "Desde móvil/PC"]
    cur = (xbmcaddon.Addon().getSetting('search_input_default') or 'Preguntar siempre').strip()
    preselect = opciones.index(cur) if cur in opciones else 0
    sel = xbmcgui.Dialog().select("Método de entrada de búsqueda", opciones, preselect=preselect)
    if sel < 0:
        return
    xbmcaddon.Addon().setSetting('search_input_default', opciones[sel])
    xbmc.executebuiltin("Container.Refresh")


def _toggle_iptv_anti_errors():
    cur = xbmcaddon.Addon().getSetting('iptv_anti_errors') == 'true'
    xbmcaddon.Addon().setSetting('iptv_anti_errors', "false" if cur else "true")
    if not cur:
        xbmcgui.Dialog().notification("Anti-Errores", "Modo Anti-Errores ACTIVADO", xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("Anti-Errores", "Modo Anti-Errores DESACTIVADO", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _manage_custom_fanart():
    fan_off = core_settings.is_fanart_disabled()
    cf = core_settings.get_custom_fanart()

    labels = ['Cambiar imagen personalizada' if cf else 'Elegir imagen personalizada']
    actions = [_pick_custom_fanart]
    if cf:
        labels.append('Quitar imagen personalizada')
        actions.append(_clear_custom_fanart)
    labels.append('[COLOR green]Mostrar fondo de pantalla[/COLOR]' if fan_off else '[COLOR orange]Ocultar fondo de pantalla[/COLOR]')
    actions.append(_toggle_fanart_disabled)

    opt = xbmcgui.Dialog().select('Fanart / Fondo de pantalla', labels)
    if opt < 0:
        return
    actions[opt]()


def _toggle_fanart_disabled():
    new_state = not core_settings.is_fanart_disabled()
    core_settings.set_fanart_disabled(new_state)
    msg = "Fondo de pantalla desactivado" if new_state else "Fondo de pantalla activado"
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _pick_custom_fanart():
    current = core_settings.get_custom_fanart()
    path = xbmcgui.Dialog().browse(1, 'Seleccionar imagen de fondo (fanart)', 'files', '.jpg|.jpeg|.png|.gif|.bmp', False, False, current or '')
    if path and os.path.isfile(path):
        core_settings.set_custom_fanart(path)
        if core_settings.is_fanart_disabled():
            core_settings.set_fanart_disabled(False)
        xbmcgui.Dialog().notification("EspaTV", "Fanart personalizado guardado", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _clear_custom_fanart():
    core_settings.clear_custom_fanart()
    xbmcgui.Dialog().notification("EspaTV", "Fanart personalizado eliminado", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


_AUTOSTART_DELAY_LABELS = ['Sin espera', '5 seg', '10 seg', '15 seg', '30 seg', '1 min']

# Prefijos de addons que no tiene sentido lanzar como autostart
_AUTOSTART_SKIP_PREFIXES = (
    'xbmc.', 'kodi.', 'service.', 'skin.', 'resource.',
    'script.module.', 'metadata.', 'inputstream.', 'pvr.',
)

def _get_launchable_addons():
    try:
        resp = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Addons.GetAddons',
            'params': {'enabled': True}
        })))
    except Exception:
        return []
    addons = (resp.get('result') or {}).get('addons') or []
    result = [
        (a.get('name', a['addonid']), a['addonid'])
        for a in addons
        if not any(a['addonid'].startswith(p) for p in _AUTOSTART_SKIP_PREFIXES)
        and a['addonid'] != 'plugin.video.espatv'
    ]
    result.sort(key=lambda x: x[0].lower())
    return result

def _autostart_delay_label(raw):
    try:
        idx = int(raw)
        return _AUTOSTART_DELAY_LABELS[idx] if 0 <= idx < len(_AUTOSTART_DELAY_LABELS) else 'Sin espera'
    except (ValueError, TypeError):
        return raw if raw in _AUTOSTART_DELAY_LABELS else 'Sin espera'

def _autostart_menu():
    addon = xbmcaddon.Addon()
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback
    for i in range(1, 4):
        enabled = addon.getSetting(f'autostart_{i}_enabled') == 'true'
        addon_id = addon.getSetting(f'autostart_{i}_id').strip()
        delay_label = _autostart_delay_label(addon.getSetting(f'autostart_{i}_delay'))

        if enabled and addon_id:
            nombre = addon_id
            try:
                nombre = xbmcaddon.Addon(addon_id).getAddonInfo('name')
            except RuntimeError:
                pass
            label = f"Slot {i}: [COLOR green]{nombre}[/COLOR]  ({delay_label})"
            plot = f"Addon: {nombre}\nID: {addon_id}\nRetardo: {delay_label}\n\n[I]Pulsa para editar o desactivar.[/I]"
        else:
            label = f"Slot {i}: [COLOR grey]Sin configurar[/COLOR]"
            plot = "Slot vacío. Pulsa para configurar un addon que se abrirá automáticamente al arrancar Kodi."

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _ico('adv_autostart.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="autostart_config_slot", slot=i), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _autostart_config_slot(slot):
    addon = xbmcaddon.Addon()
    addon_id = addon.getSetting(f'autostart_{slot}_id').strip()
    enabled = addon.getSetting(f'autostart_{slot}_enabled') == 'true'
    delay_label = _autostart_delay_label(addon.getSetting(f'autostart_{slot}_delay'))
    delay_idx = next((i for i, l in enumerate(_AUTOSTART_DELAY_LABELS) if l == delay_label), 0)

    nombre = addon_id
    if addon_id:
        try:
            nombre = xbmcaddon.Addon(addon_id).getAddonInfo('name')
        except RuntimeError:
            pass

    if enabled and addon_id:
        # Slot activo: mostrar info real de lo que va a pasar y opciones concretas
        delay_txt = f'después de {delay_label}' if delay_label != 'Sin espera' else 'en cuanto Kodi arranque'
        sel = xbmcgui.Dialog().select(
            f'Slot {slot}: {nombre} se abre {delay_txt}',
            ['Cambiar addon', 'Cambiar retardo', 'Desactivar este slot']
        )
        if sel < 0:
            return
        if sel == 2:
            addon.setSetting(f'autostart_{slot}_enabled', 'false')
            xbmcgui.Dialog().notification("Inicio automático", f"Slot {slot} desactivado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return
        if sel == 1:
            idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
            if idx < 0:
                return
            addon.setSetting(f'autostart_{slot}_delay', _AUTOSTART_DELAY_LABELS[idx])
            xbmcgui.Dialog().notification("Inicio automático", f"Retardo: {_AUTOSTART_DELAY_LABELS[idx]}", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return
        # sel == 0: cambiar addon → flujo de picker completo abajo

    # Flujo completo: slot vacío/desactivado, o "Cambiar addon"
    addons_lista = _get_launchable_addons()
    if not addons_lista:
        xbmcgui.Dialog().notification("Inicio automático", "No se encontraron addons instalados", xbmcgui.NOTIFICATION_WARNING)
        xbmc.executebuiltin("Container.Refresh")
        return

    names = [f"{name}  [COLOR grey]({aid})[/COLOR]" for name, aid in addons_lista]
    presel = next((i for i, (_, aid) in enumerate(addons_lista) if aid == addon_id), -1)
    sel_addon = xbmcgui.Dialog().select("Seleccionar addon a lanzar al arrancar", names, preselect=presel)
    if sel_addon < 0:
        return

    nuevo_id = addons_lista[sel_addon][1]
    nuevo_nombre = addons_lista[sel_addon][0]

    idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
    nuevo_delay = _AUTOSTART_DELAY_LABELS[idx] if idx >= 0 else delay_label

    # Guardar todo de una vez solo cuando se han completado ambas selecciones
    addon.setSetting(f'autostart_{slot}_enabled', 'true')
    addon.setSetting(f'autostart_{slot}_id', nuevo_id)
    addon.setSetting(f'autostart_{slot}_delay', nuevo_delay)

    xbmcgui.Dialog().notification("Inicio automático", f"Slot {slot}: {nuevo_nombre}", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _get_kodi_favourites():
    # El texto de cada <favourite> es el builtin exacto que Kodi ejecuta
    # (RunAddon(...), ActivateWindow(...), PlayMedia(...)). Lo leemos tal cual
    # en vez de reconstruirlo desde JSON-RPC, que es ambiguo para los plugin://.
    ruta = xbmcvfs.translatePath('special://profile/favourites.xml')
    try:
        root = ET.parse(ruta).getroot()
    except (OSError, ET.ParseError):
        # No existe (aún no hay favoritos), ilegible, o XML corrupto.
        return []
    favs = []
    for elem in root.findall('favourite'):
        cmd = (elem.text or '').strip()
        name = elem.get('name') or cmd
        if cmd:
            favs.append((name, cmd, elem.get('thumb') or ''))
    return favs

def _autofav_menu():
    addon = xbmcaddon.Addon()
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback
    for i in range(1, 4):
        enabled = addon.getSetting(f'autofav_{i}_enabled') == 'true'
        titulo = addon.getSetting(f'autofav_{i}_title').strip()
        delay_label = _autostart_delay_label(addon.getSetting(f'autofav_{i}_delay'))

        if enabled and titulo:
            label = f"Favorito {i}: [COLOR green]{titulo}[/COLOR]  ({delay_label})"
            plot = f"Favorito: {titulo}\nRetardo: {delay_label}\n\n[I]Pulsa para editar o desactivar.[/I]"
        else:
            label = f"Favorito {i}: [COLOR grey]Sin configurar[/COLOR]"
            plot = "Slot vacío. Pulsa para elegir un favorito de Kodi que se abrirá automáticamente al arrancar."

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _ico('adv_autostart.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="autofav_config_slot", slot=i), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _autofav_config_slot(slot):
    addon = xbmcaddon.Addon()
    titulo = addon.getSetting(f'autofav_{slot}_title').strip()
    enabled = addon.getSetting(f'autofav_{slot}_enabled') == 'true'
    delay_label = _autostart_delay_label(addon.getSetting(f'autofav_{slot}_delay'))
    delay_idx = next((i for i, l in enumerate(_AUTOSTART_DELAY_LABELS) if l == delay_label), 0)

    if enabled and titulo:
        delay_txt = f'después de {delay_label}' if delay_label != 'Sin espera' else 'en cuanto Kodi arranque'
        sel = xbmcgui.Dialog().select(
            f'Favorito {slot}: {titulo} se abre {delay_txt}',
            ['Cambiar favorito', 'Cambiar retardo', 'Desactivar este slot']
        )
        if sel < 0:
            return
        if sel == 2:
            addon.setSetting(f'autofav_{slot}_enabled', 'false')
            xbmcgui.Dialog().notification("Inicio automático", f"Favorito {slot} desactivado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return
        if sel == 1:
            idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
            if idx < 0:
                return
            addon.setSetting(f'autofav_{slot}_delay', _AUTOSTART_DELAY_LABELS[idx])
            xbmcgui.Dialog().notification("Inicio automático", f"Retardo: {_AUTOSTART_DELAY_LABELS[idx]}", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return
        # sel == 0: cambiar favorito → flujo de picker completo abajo

    favs = _get_kodi_favourites()
    if not favs:
        xbmcgui.Dialog().notification("Inicio automático", "No tienes favoritos guardados en Kodi", xbmcgui.NOTIFICATION_WARNING)
        xbmc.executebuiltin("Container.Refresh")
        return

    names = [name for name, _cmd, _thumb in favs]
    presel = next((i for i, (name, _c, _t) in enumerate(favs) if name == titulo), -1)
    sel_fav = xbmcgui.Dialog().select("Seleccionar favorito a lanzar al arrancar", names, preselect=presel)
    if sel_fav < 0:
        return

    nuevo_titulo, nuevo_cmd, _ = favs[sel_fav]

    idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
    nuevo_delay = _AUTOSTART_DELAY_LABELS[idx] if idx >= 0 else delay_label

    addon.setSetting(f'autofav_{slot}_enabled', 'true')
    addon.setSetting(f'autofav_{slot}_title', nuevo_titulo)
    addon.setSetting(f'autofav_{slot}_cmd', nuevo_cmd)
    addon.setSetting(f'autofav_{slot}_delay', nuevo_delay)

    xbmcgui.Dialog().notification("Inicio automático", f"Favorito {slot}: {nuevo_titulo}", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_force_white_text():
    cur = xbmcaddon.Addon().getSetting('acc_color_mode') == 'white'
    xbmcaddon.Addon().setSetting('acc_color_mode', 'none' if cur else 'white')
    if not cur:
        xbmcgui.Dialog().notification("EspaTV", "Texto blanco ACTIVADO", xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("EspaTV", "Texto blanco DESACTIVADO", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


# ACCESIBILIDAD: submenú y acciones de toggle

_ACC_COLOR_NAMES = {
    'none':       'Sin modificar (colores originales)',
    'white':      'Texto blanco (todos los colores → blanco)',
    'daltonic_rg':'Daltónico rojo-verde (deuteranopia/protanopia)',
    'daltonic_by':'Daltónico azul-amarillo (tritanopia)',
    'hc_dark':    'Alto contraste — fondo oscuro (amarillo)',
    'hc_light':   'Alto contraste — fondo claro (negro)',
}
_ACC_COLOR_KEYS = list(_ACC_COLOR_NAMES.keys())
_ACC_COLOR_LABELS = list(_ACC_COLOR_NAMES.values())

_ACC_COLOR_PLOTS = {
    'none': "Los textos aparecen con los colores originales del addon.\n\nLos colores se usan para localizar elementos a simple vista (gris = desactivado, verde = activo, rojo = borrar, etc.).",
    'white': "Todos los textos de color se muestran en blanco.\n\nÚtil si tu skin tiene fondo claro o si los colores del addon no se ven bien.",
    'daltonic_rg': "Optimizado para personas con daltonismo rojo-verde (deuteranopia o protanopia, ~6% de varones).\n\nLos rojos se convierten en naranja. Los verdes se convierten en cyan. Los azules se preservan.",
    'daltonic_by': "Optimizado para personas con daltonismo azul-amarillo (tritanopia, ~0.5%).\n\nLos amarillos se convierten en magenta. Los azules y cyans se convierten en rojo.",
    'hc_dark': "Alto contraste para skins con fondo oscuro (la más común en Kodi).\n\nTodos los textos en amarillo brillante. Solo el rojo se preserva en items destructivos (BORRAR, ERROR).",
    'hc_light': "Alto contraste para skins con fondo claro.\n\nTodos los textos en negro. Solo el rojo se preserva en items destructivos.",
}

def accessibility_menu():
    h = int(sys.argv[1])

    _cur_mode = xbmcaddon.Addon().getSetting('acc_color_mode') or 'none'
    _bold_on = xbmcaddon.Addon().getSetting('acc_force_bold') == 'true'
    _sym_on = xbmcaddon.Addon().getSetting('acc_strip_symbols') == 'true'

    mode_name = _ACC_COLOR_NAMES.get(_cur_mode, _ACC_COLOR_NAMES['none'])

    # Modo de color
    li = xbmcgui.ListItem(label="Modo de color: [COLOR deepskyblue]{0}[/COLOR]".format(mode_name))
    li.setArt({'icon': 'DefaultAddonSkin.png'})
    plot_base = "Selecciona cómo se muestran los colores en todos los menús del addon.\n\n"
    plot_base += _ACC_COLOR_PLOTS.get(_cur_mode, '')
    plot_base += "\n\n[I]Cierra y vuelve a abrir el addon para que el cambio se aplique a todos los menús.[/I]"
    li.setInfo('video', {'plot': plot_base})
    xbmcplugin.addDirectoryItem(h, url=_u(action="acc_set_color_mode"), listitem=li, isFolder=False)

    # Forzar negrita
    bold_label = "Forzar negrita en todas las etiquetas: [COLOR green]ACTIVADO[/COLOR]" if _bold_on else "Forzar negrita en todas las etiquetas: [COLOR grey]DESACTIVADO[/COLOR]"
    li = xbmcgui.ListItem(label=bold_label)
    li.setArt({'icon': 'DefaultAddonSkin.png'})
    li.setInfo('video', {'plot': "Muestra todas las etiquetas de los menús en negrita.\n\nÚtil para personas con baja visión o dificultad para leer texto fino.\n\n[I]Cierra y vuelve a abrir el addon para que el cambio se aplique a todos los menús.[/I]"})
    xbmcplugin.addDirectoryItem(h, url=_u(action="acc_toggle_bold"), listitem=li, isFolder=False)

    # Quitar símbolos
    sym_label = "Reemplazar símbolos (★●▲▼ → *-^v): [COLOR green]ACTIVADO[/COLOR]" if _sym_on else "Reemplazar símbolos (★●▲▼ → *-^v): [COLOR grey]DESACTIVADO[/COLOR]"
    li = xbmcgui.ListItem(label=sym_label)
    li.setArt({'icon': 'DefaultAddonSkin.png'})
    li.setInfo('video', {'plot': "Sustituye los símbolos Unicode (★ ● ○ ▲ ▼ ◑ ◐) por equivalentes de texto (* - ^ v ~).\n\nÚtil para lectores de pantalla o fuentes que no incluyen estos caracteres.\n\n[I]Cierra y vuelve a abrir el addon para que el cambio se aplique a todos los menús.[/I]"})
    xbmcplugin.addDirectoryItem(h, url=_u(action="acc_toggle_symbols"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _acc_set_color_mode():
    cur = xbmcaddon.Addon().getSetting('acc_color_mode') or 'none'
    try:
        cur_idx = _ACC_COLOR_KEYS.index(cur)
    except ValueError:
        cur_idx = 0
    sel = xbmcgui.Dialog().select("Modo de color — Accesibilidad", _ACC_COLOR_LABELS, preselect=cur_idx)
    if sel < 0:
        return
    new_mode = _ACC_COLOR_KEYS[sel]
    xbmcaddon.Addon().setSetting('acc_color_mode', new_mode)
    name = _ACC_COLOR_LABELS[sel]
    xbmcgui.Dialog().notification("Accesibilidad", "Color: {0}".format(name[:40]), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _acc_toggle_bold():
    cur = xbmcaddon.Addon().getSetting('acc_force_bold') == 'true'
    xbmcaddon.Addon().setSetting('acc_force_bold', 'false' if cur else 'true')
    xbmcgui.Dialog().notification("Accesibilidad", "Negrita " + ("DESACTIVADA" if cur else "ACTIVADA"), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _acc_toggle_symbols():
    cur = xbmcaddon.Addon().getSetting('acc_strip_symbols') == 'true'
    xbmcaddon.Addon().setSetting('acc_strip_symbols', 'false' if cur else 'true')
    xbmcgui.Dialog().notification("Accesibilidad", "Reemplazo de símbolos " + ("DESACTIVADO" if cur else "ACTIVADO"), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_dev_mode():
    dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
    if os.path.exists(dev_flag):
        try:
            os.remove(dev_flag)
            xbmcgui.Dialog().notification("EspaTV", "Modo Desarrollo DESACTIVADO", xbmcgui.NOTIFICATION_INFO)
        except OSError as e:
            xbmcgui.Dialog().ok("Error", "No se pudo desactivar: {0}".format(e))
    else:
        try:
            with open(dev_flag, 'w') as f:
                f.write('dev')
            xbmcgui.Dialog().notification("EspaTV", "Modo Desarrollo ACTIVO", xbmcgui.NOTIFICATION_WARNING)
        except OSError as e:
            xbmcgui.Dialog().ok("Error", "No se pudo activar: {0}".format(e))
    xbmc.executebuiltin("Container.Refresh")


def _get_debug_state_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, 'debug_state.json')


def _is_debug_active():
    f = _get_debug_state_file()
    if not os.path.exists(f):
        return False
    try:
        with open(f, 'r', encoding='utf-8') as o:
            return json.load(o).get('active', False)
    except (OSError, ValueError):
        return False

def _toggle_debug():
    new_state = not _is_debug_active()
    
    # Advertencia de seguridad SIEMPRE (tanto al activar como al desactivar)
    action_str = "activar" if new_state else "desactivar"
    if not xbmcgui.Dialog().yesno("ADVERTENCIA DE SEGURIDAD", 
        f"[COLOR red]ALERTA:[/COLOR] Vas a {action_str} el Modo Debug.\n\n"
        "Si no sabes lo que estás haciendo, esto podría causar errores o inestabilidad en el addon.\n"
        "¿Estás seguro de continuar?"):
        return


    log_to_file = False
    if new_state:
        if xbmcgui.Dialog().yesno("Generar Log de Errores", 
            "¿Quieres generar un archivo LOG en la raíz del addon con los errores del addon?\n\n"
            "Esto creará 'EspaTV_errors.log' en la carpeta del plugin."):
            log_to_file = True
            try:
                base_dir = os.path.dirname(os.path.abspath(__file__))
                log_file = os.path.join(base_dir, 'EspaTV_errors.log')
                ts = time.strftime('%Y-%m-%d %H:%M:%S')
                with open(log_file, 'a', encoding='utf-8') as lf:
                    lf.write(f"[{ts}] --- INICIO DE SESIÓN DE DEBUG ---\n")
            except OSError:
                pass
    else:
        try:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            log_file = os.path.join(base_dir, 'EspaTV_errors.log')
            if os.path.exists(log_file):
                os.remove(log_file)
        except OSError:
            pass

    with open(_get_debug_state_file(), 'w', encoding='utf-8') as o: json.dump({'active': new_state, 'log_to_file': log_to_file}, o)
    
    msg = "ACTIVADO" if new_state else "DESACTIVADO"
    if log_to_file: msg += " (Con Log Propio)"
    xbmcgui.Dialog().notification("EspaTV", f"Modo Debug {msg}", xbmcgui.NOTIFICATION_INFO)
    # Forzamos viaje al menu principal rompiendo la cache con un timestamp
    xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?reload={int(time.time())}, replace)")

def _log_error(msg):
    xbmc.log(f"[EspaTV ERROR] {msg}", xbmc.LOGERROR)
    try:
        f = _get_debug_state_file()
        if os.path.exists(f):
            with open(f, 'r', encoding='utf-8') as fh:
                st = json.load(fh)
            if st.get('active') and st.get('log_to_file'):
                base_dir = os.path.dirname(os.path.abspath(__file__))
                log_file = os.path.join(base_dir, 'EspaTV_errors.log')
                ts = time.strftime('%Y-%m-%d %H:%M:%S')
                with open(log_file, 'a', encoding='utf-8') as lf:
                    lf.write(f"[{ts}] {msg}\n")
    except (OSError, ValueError):
        pass

def _view_error_log():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    log_file = os.path.join(base_dir, 'EspaTV_errors.log')
    
    if not os.path.exists(log_file):
        xbmcgui.Dialog().ok("Error", "No existe el archivo de log.\nActiva el Modo Debug y genera errores primero.")
        return

    opts = ["Ver archivo completo", "Últimas 50 líneas", "Últimas 20 líneas", "Últimas 10 líneas"]
    sel = xbmcgui.Dialog().select("¿Qué deseas ver?", opts)
    if sel < 0: return
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except OSError as e:
        xbmcgui.Dialog().ok("Error Leyendo Log", str(e))
        return

    if not lines:
        content = "[El archivo está vacío]"
    elif sel == 0:
        content = "".join(lines)
    elif sel == 1:
        content = "".join(lines[-50:])
    elif sel == 2:
        content = "".join(lines[-20:])
    elif sel == 3:
        content = "".join(lines[-10:])
    else:
        content = ""

    xbmcgui.Dialog().textviewer("Log de Errores - EspaTV", content)



def _set_pelis_grid_mode():
    opciones = ['Lista', 'Botón', 'Grid directo', 'Preguntar']
    addon = xbmcaddon.Addon()
    cur = (addon.getSetting('pelis_grid_mode') or 'Preguntar').strip()
    preselect = opciones.index(cur) if cur in opciones else 1
    sel = xbmcgui.Dialog().select('Vista de secciones de películas', opciones, preselect=preselect)
    if sel < 0:
        return
    addon.setSetting('pelis_grid_mode', opciones[sel])
    xbmcgui.Dialog().notification('EspaTV', 'Vista de películas: ' + opciones[sel], xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')


def _toggle_cinema_auto():
    addon = xbmcaddon.Addon()
    new_state = addon.getSetting("cinema_mode_auto") != "true"
    addon.setSetting("cinema_mode_auto", "true" if new_state else "false")
    msg = "MODO CINE AUTOMÁTICO ACTIVADO" if new_state else "MODO CINE AUTOMÁTICO DESACTIVADO"
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _toggle_flix_lazy_load():
    new_state = not core_settings.is_flix_lazy_enabled()
    core_settings.set_flix_lazy_enabled(new_state)
    msg = "CARGA PEREZOSA ACTIVADA" if new_state else "CARGA PEREZOSA DESACTIVADA"
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_flix_remember_pos():
    new_state = not core_settings.is_flix_remember_pos_enabled()
    core_settings.set_flix_remember_pos_enabled(new_state)
    msg = "RECORDAR POSICIÓN ACTIVADO" if new_state else "RECORDAR POSICIÓN DESACTIVADO"
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

_TRAILER_HELP = (
    "[B]Tráiler en el Modo Cine[/B]\n"
    "Al pasar unos segundos sobre una película se reproduce su tráiler de YouTube en la zona del "
    "fanart. Requiere el addon de YouTube. En Android puede saltar a pantalla completa.\n\n"
    "[B]Tiempo hasta reproducir[/B]\n"
    "Segundos quieto sobre una ficha antes de lanzar el tráiler. Subirlo (8-15s) reduce cuántos "
    "tráilers se abren al navegar y, con ello, los cuelgues intermitentes.\n\n"
    "[B]Idioma del tráiler[/B]\n"
    "Español o Inglés. En inglés casi siempre está el tráiler oficial; en español puede no haber, "
    "y en ese caso se usa el inglés como respaldo.\n\n"
    "Nota: al cambiar de película, si YouTube va lento, el cierre del vídeo puede congelar Kodi "
    "unos segundos de forma intermitente. Es una limitación del addon de YouTube, no del Modo "
    "Cine.\n\n"
    "[B]Indicador de carga (spinner)[/B]\n"
    "Oculto: cierra el círculo de carga que oscurece la pantalla mientras YouTube prepara el "
    "vídeo. Puede parpadear o no funcionar igual en todos los dispositivos."
)


def _trailer_config():
    """Submenú único del comportamiento del tráiler (activar / reproducción / spinner)."""
    cfg = core_settings.load_trailer_config()
    while True:
        on = cfg['enabled']
        rows = []
        if on:
            rows.append(("enabled", "Tráiler: [COLOR green]ACTIVADO[/COLOR]"))
            rows.append(("hover", "   Tiempo hasta reproducir: [COLOR cyan]{0}s[/COLOR]".format(cfg['hover_s'])))
            lang_lbl = "Español" if cfg['lang'] == 'es-ES' else "Inglés (oficial)"
            rows.append(("lang", "   Idioma del tráiler: [COLOR cyan]{0}[/COLOR]".format(lang_lbl)))
            spin = ("[COLOR cyan]OCULTO (truco)[/COLOR]" if cfg['hide_busy']
                    else "[COLOR grey]VISIBLE[/COLOR]")
            rows.append(("hide_busy", "   Spinner al cargar: " + spin))
        else:
            rows.append(("enabled", "Tráiler: [COLOR grey]DESACTIVADO[/COLOR]"))
        rows.append(("help", "[COLOR blue]Ver ayuda de los modos[/COLOR]"))
        rows.append(("close", "[ Cerrar ]"))

        sel = xbmcgui.Dialog().select("Comportamiento del tráiler (YouTube)", [r[1] for r in rows])
        if sel < 0:
            break
        key = rows[sel][0]
        if key == "close":
            break
        if key == "help":
            xbmcgui.Dialog().textviewer("Tráiler del Modo Cine", _TRAILER_HELP)
            continue
        if key == "enabled":
            cfg['enabled'] = not cfg['enabled']
        elif key == "hide_busy":
            cfg['hide_busy'] = not cfg['hide_busy']
        elif key == "hover":
            opts = [2, 3, 5, 8, 10, 15]
            labels = ["{0} segundos".format(o) + ("  (más espera = menos cuelgues)" if o >= 8 else "") for o in opts]
            s = xbmcgui.Dialog().select("Segundos sobre una ficha antes de reproducir", labels)
            if s >= 0:
                cfg['hover_s'] = opts[s]
        elif key == "lang":
            cfg['lang'] = 'es-ES' if cfg['lang'] == 'en-US' else 'en-US'
        core_settings.save_trailer_config(cfg)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_prioritize_match():
    new_state = not core_settings.is_prioritize_match_active()
    core_settings.set_prioritize_match(new_state)
    msg = "MODO PRECISIÓN ACTIVADO" if new_state else "MODO DURACIÓN (ESTÁNDAR)"
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_recent():
    new_state = not core_settings.is_recent_active()
    core_settings.set_recent_active(new_state)
    msg = "ORDEN RECIENTE ACTIVADO" if new_state else "ORDEN RELEVANCIA REINSTAURADO"
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _set_min_duration_filter():
    opts = ["Desactivado", "Más de 2 min", "Más de 5 min", "Más de 10 min", "Más de 20 min (Solo Full)"]
    vals = [0, 2, 5, 10, 20]
    sel = xbmcgui.Dialog().select("Ocultar vídeos más cortos que...", opts)
    if sel < 0: return
    core_settings.set_min_duration(vals[sel])
    xbmc.executebuiltin("Container.Refresh")





def _cached_http_get(url, timeout=15):
    """GET con caché opcional basada en TTL de IPTV. Si activa y vigente, sirve desde disco."""
    import hashlib
    ttl = core_settings.get_iptv_cache_ttl()

    cache_file = None
    if ttl > 0:
        cache_dir = core_settings.get_iptv_cache_dir()
        cache_key = hashlib.md5(url.encode('utf-8')).hexdigest()
        cache_file = os.path.join(cache_dir, "{0}.json".format(cache_key))
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    cached = json.load(f)
                if (time.time() - cached.get("ts", 0)) < ttl:
                    return cached.get("content", "")
            except (OSError, ValueError):
                pass

    r = requests.get(url, timeout=timeout, headers=_browser_headers())
    if r.status_code != 200:
        raise RuntimeError("Error HTTP {0}".format(r.status_code))
    content = r.text

    if cache_file:
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump({"ts": time.time(), "url": url, "content": content}, f, ensure_ascii=False)
        except OSError:
            pass

    return content


def _sanitized_info():
    t = (
        "[B]EspaTV[/B]\nContacto: t.me/rubensdfa1laberot\n"
        "GitHub: https://github.com/espakodi\n"
        "Telegram: https://t.me/espadaily\n"
        "Contacto: fullstackcurso.github.io/donaciones/#mensaje\n\n"
        
        "[B]AVISO LEGAL:[/B]\n\n"
        
        "[B]1. No Afiliación:[/B]\n"
        "Este proyecto es independiente. NO tiene ninguna afiliación ni vinculación con ninguna cadena de televisión ni entidad oficial.\n\n"
        
        "[B]2. Naturaleza Técnica:[/B]\n"
        "Este software actúa como un agregador de búsqueda. NO contiene, aloja ni sube contenido protegido. Muestra resultados que ya son accesibles públicamente en internet.\n\n"
        
        "[B]3. Responsabilidad del Usuario:[/B]\n"
        "El usuario es el único responsable de verificar la legalidad del acceso a los contenidos según las leyes de su país. Este addon se proporciona \"tal cual\", sin garantías de ningún tipo.\n"
        "EspaTV no se hace responsable del contenido alojado en servidores de terceros.\n\n"
        
        "[B]4. Naturaleza del proyecto:[/B]\n"
        "Es GRATUITO y sin ánimo de lucro.\n\n"
        
        "[B]5. Telemetría Anónima:[/B]\n"
        "Para mejorar el addon, se envía de forma anónima la plataforma, versión del addon y de Kodi. No se recopilan datos personales, IPs ni hábitos de uso.\n\n"
        
        "[B]Contacto y Retirada:[/B]\n"
        "Si es titular de derechos y considera que este software le perjudica, puede solicitar cambios a través de Telegram o GitHub."
    )
    xbmcgui.Dialog().textviewer("Información de EspaTV", t)

def _info():
    t = (
        "[B]EspaTV[/B]\n"
        "GitHub: https://github.com/espakodi\n"
        "Contacto: t.me/rubensdfa1laberot\n"
        "Canal de Telegram: https://t.me/espadaily\n"
        "Chat de Telegram: https://t.me/espakodi\n"
        "Contacto 2: fullstackcurso.github.io/donaciones/#mensaje\n\n"
        
        "[B]AVISO LEGAL:[/B]\n\n"
        
        "[B]1. No Afiliación:[/B]\n"
        "Este proyecto es independiente. NO tiene ninguna afiliación ni vinculación con ninguna cadena de televisión ni entidad oficial.\n\n"
        
        "[B]2. Naturaleza Técnica:[/B]\n"
        "Este software actúa como un agregador de búsqueda. NO contiene, aloja ni sube contenido protegido. Muestra resultados que ya son accesibles públicamente en internet.\n\n"
        
        "[B]3. Responsabilidad del Usuario:[/B]\n"
        "El usuario es el único responsable de verificar la legalidad del acceso a los contenidos según las leyes de su país. Este addon se proporciona \"tal cual\", sin garantías de ningún tipo.\n"
        "EspaTV no se hace responsable del contenido alojado en servidores de terceros.\n\n"
        
        "[B]4. Naturaleza del proyecto:[/B]\n"
        "Es GRATUITO y sin ánimo de lucro.\n\n"
        
        "[B]5. Telemetría Anónima:[/B]\n"
        "Para mejorar el addon, se envía de forma anónima la plataforma, versión del addon y de Kodi. No se recopilan datos personales, IPs ni hábitos de uso.\n\n"
        
        "[B]Contacto y Retirada:[/B]\n"
        "Si es titular de derechos y considera que este software le perjudica, puede solicitar cambios a través de Telegram o GitHub."
    )
    xbmcgui.Dialog().textviewer("Información de EspaTV", t)

def _web_info():
    t = (
        "https://github.com/espakodi\n\n"
        "------------------------------------------------\n\n"
        "[B]Visita mi GitHub para más proyectos como este.[/B]\n\n"
        "Allí encontrarás mis otros trabajos y actualizaciones.\n"
        "Cualquier apoyo o difusión de mis proyectos se agradece enormemente.\n\n"
    )
    xbmcgui.Dialog().textviewer("Más en...", t)

def _version_notes():
    t = (
        "[B]GUÍA DE USUARIO DE ESPATV[/B]\n\n"
        "------------------------------------------------\n"
        "[B]¿CÓMO FUNCIONA?[/B]\n"
        "EspaTV es un centro multimedia con TV en directo (TDT, IPTV, RTVE Play), catálogo de canales de Dailymotion, búsqueda en YouTube, radio y más. Al elegir un contenido, el addon [B]busca automáticamente[/B] enlaces públicos en internet que coincidan.\n\n"
        "------------------------------------------------\n"
        "[B]HERRAMIENTAS PRINCIPALES[/B]\n\n"
        "• [B]Mis Favoritos:[/B] Guarda programas o series para acceder rápido. Pulsa clic derecho en cualquier ítem y elige 'Añadir a Favoritos'.\n"
        "• [B]Historial:[/B] Guarda tus últimas 50 búsquedas automáticamente.\n"
        "• [B]Mis Descargas:[/B] Gestiona los vídeos que hayas guardado localmente.\n"
        "• [B]Backup:[/B] Exporta tu historial y favoritos a un archivo ZIP para llevarlos a otro Kodi.\n\n"
        "------------------------------------------------\n"
        "[B]GUÍA DE OPCIONES AVANZADAS[/B]\n\n"
        "• [B]Contexto Completo:[/B] Es la opción más importante. Define qué texto se busca en internet.\n"
        "   - [I]Desactivado:[/I] Busca solo el título del capítulo (Ej: 'Capítulo 1').\n"
        "   - [I]Nivel 1 (Recomendado):[/I] Busca Serie + Capítulo (Ej: 'Cuéntame Capítulo 1').\n"
        "   - [I]Nivel 2/MAX:[/I] Añade más datos de la ruta para búsquedas muy específicas.\n\n"
        "• [B]Priorizar Ajuste vs Duración:[/B]\n"
        "   - [I]Duración:[/I] Prefiere vídeos largos (evita clips cortos).\n"
        "   - [I]Ajuste:[/I] Prefiere títulos que coincidan exactamente, aunque sean cortos.\n\n"
        "• [B]Filtro Anti-Trailers:[/B] Oculta automáticamente vídeos de menos de X minutos.\n\n"
        "• [B]Filtro Temporal:[/B] Decide si prefieres ver primero los resultados más nuevos (Reciente) o los que mejor coinciden (Relevancia).\n\n"
        "• [B]Control de Caché:[/B]\n"
        "   - [I]Apagado:[/I] Siempre carga de internet (más lento, menos espacio).\n"
        "   - [I]Híbrido:[/I] Guarda los menús en disco para que navegar sea instantáneo.\n\n"
        "• [B]Otras Utilidades:[/B]\n"
        "   - [I]Refrescar:[/I] Recarga el addon si notas que algún menú no se actualiza.\n"
        "   - [I]Modo Debug:[/I] Actívalo solo si tienes problemas graves para generar un registro de errores.\n"
        "   - [I]Borrar Caché:[/I] Elimina datos temporales. Úsalo si tienes problemas de espacio o errores visuales.\n\n"
        "------------------------------------------------\n"
        "¡Que disfrutes de EspaTV!"
    )
    xbmcgui.Dialog().textviewer("Guía de EspaTV", t)
def _version_notes_v1():
    t = (
        "[B]NOTAS DE LA VERSIÓN 1.0[/B]\n\n"
        "Versión inicial de EspaTV.\n\n"
        "[B]Funciones incluidas:[/B]\n"
        "• TV en directo (TDT, IPTV, RTVE Play)\n"
        "• Catálogo de canales de Dailymotion\n"
        "• Búsqueda en YouTube\n"
        "• Radio y podcasts\n"
        "• Favoritos, historial y descargas\n"
        "• Búsqueda avanzada con filtros de calidad\n"
        "• Integración con Elementum para torrents\n"
    )
    xbmcgui.Dialog().textviewer("Notas v1.0", t)
def _manual_search():
    if core_settings.is_advanced_search_active():
        _advanced_search_menu()
        return

    sel = core_settings.get_search_input_sel("¿Cómo introduces la búsqueda?")
    if sel < 0:
        return
    if sel == 1:
        import url_remote
        q = url_remote.receive_text("Introduce el nombre a buscar")
    else:
        kb = xbmc.Keyboard('', 'Introduce el nombre a buscar')
        kb.doModal()
        q = kb.getText() if kb.isConfirmed() else ''
    if q:
        _sh.add(q)
        _lfd(q, "", nh=True)

def _show_watch_providers(title, tmdb_id):
    import metadata_enricher as me

    if not tmdb_id and title:
        meta = me.enrich(title=title, media_type='movie')
        tmdb_id = str((meta.get('ids') or {}).get('tmdb', '')) if meta else ''

    if not tmdb_id:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo identificar la película en TMDB", xbmcgui.NOTIFICATION_WARNING)
        return

    providers = me.fetch_watch_providers(tmdb_id, media_type='movie')
    lines = []
    if providers.get('flatrate'):
        lines.append("Suscripción: " + ", ".join(providers['flatrate']))
    if providers.get('free'):
        lines.append("Gratis: " + ", ".join(providers['free']))
    if providers.get('rent'):
        lines.append("Alquiler: " + ", ".join(providers['rent']))
    if providers.get('buy'):
        lines.append("Compra: " + ", ".join(providers['buy']))

    if lines:
        xbmcgui.Dialog().textviewer(
            "¿Dónde ver '{0}' en España?".format(title),
            "\n".join(lines),
        )
    else:
        xbmcgui.Dialog().ok(
            "¿Dónde ver '{0}'?".format(title),
            "No disponible en ninguna plataforma de streaming en España según TMDB.\n\n"
            "Puede que aún esté en cines o que TMDB no tenga datos de España.",
        )


def _search_movie_multi(q, tmdb_id='', media_type='movie', season='', episode=''):
    if not q:
        return
    try:
        _n = int(tmdb_id)                   # descarta '', None, 'None', no numéricos
        _tmdb = str(_n) if _n > 0 else ''   # 0 y negativos no son IDs reproducibles
    except (ValueError, TypeError):
        _tmdb = ''

    es_serie = media_type in ('show', 'tv')

    # Serie con episodio concreto se reproduce; sin episodio se abre el navegador
    # de temporadas de TMDb Helper (info=seasons) para elegir allí.
    # AddonIsEnabled (no HasAddon): HasAddon es True aunque el addon esté
    # deshabilitado, y RunPlugin no puede ejecutar un addon deshabilitado.
    _season = _episode = None
    mostrar_tmdbh = False
    tmdbh_browse = False
    if _tmdb and xbmc.getCondVisibility('System.AddonIsEnabled(plugin.video.themoviedb.helper)'):
        if not es_serie:
            mostrar_tmdbh = True
        else:
            try:
                _season, _episode = int(season or 0), int(episode)
            except (ValueError, TypeError):
                _season = _episode = None
            mostrar_tmdbh = True
            tmdbh_browse = not (_episode and _episode >= 1)

    archive_q = 'mediatype:movies AND title:({0})'.format(re.sub(r'[()[\]{}]', '', q))
    opciones = [
        "[COLOR red]YouTube[/COLOR]",
        "[COLOR dodgerblue]Dailymotion (EspaTV)[/COLOR]",
        "[COLOR peru]Internet Archive[/COLOR]",
        "[COLOR peru]Torrents P2P (Elementum)[/COLOR]",
    ]
    tmdbh_idx = None
    if mostrar_tmdbh:
        opciones.append("[COLOR plum]Ver en otro addon[/COLOR]")
        tmdbh_idx = len(opciones) - 1

    sel = xbmcgui.Dialog().select(u"Buscar '{0}' en:".format(q), opciones)
    if sel < 0:
        return
    if sel == 0:
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='yt_search_results', query=q)))
    elif sel == 1:
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='lfr', q=q, ot='')))
    elif sel == 2:
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='archive_category', q=archive_q, page=1)))
    elif sel == 3:
        _search_elementum(q)
    elif tmdbh_idx is not None and sel == tmdbh_idx:
        if tmdbh_browse:
            url = f'plugin://plugin.video.themoviedb.helper/?info=seasons&tmdb_type=tv&tmdb_id={_tmdb}'
            xbmc.executebuiltin(f'Container.Update({url})')
        else:
            url = f'plugin://plugin.video.themoviedb.helper/?info=play&tmdb_type={"tv" if es_serie else "movie"}&tmdb_id={_tmdb}'
            if es_serie:
                url += f'&season={_season}&episode={_episode}'
            xbmc.executebuiltin(f'RunPlugin({url})')


def _topzilla_buscar_menu():
    h = int(sys.argv[1])
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.topzilla)"):
        import espakodi_installer
        espakodi_installer.launch_by_id("plugin.video.topzilla")
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        return

    _addon = xbmcaddon.Addon()
    _media = os.path.join(_addon.getAddonInfo('path'), 'resources', 'media')

    def _icon(name, fallback='DefaultVideoPlaylists.png'):
        p = os.path.join(_media, name)
        return p if os.path.exists(p) else fallback

    for label, plot, mode, icon in [
        ("Buscar película",
         "Escribe el título de una película y abre el menú completo de TopZilla: dónde verla en España, más información, críticas, YouTube, Dailymotion y más.",
         'movie', 'peliculas.png'),
        ("Buscar serie",
         "Escribe el título de una serie y abre el menú completo de TopZilla: dónde verla en España, más información, críticas, YouTube, Dailymotion y más.",
         'show', 'cat_series.png'),
    ]:
        li = xbmcgui.ListItem(label=f"[B]{label}[/B]")
        li.setArt({'icon': _icon(icon)})
        li.setInfo('video', {'plot': plot})
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="topzilla_buscar_go", mode=mode),
                                    listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _top_pelis_series_menu():
    h = int(sys.argv[1])
    _addon   = xbmcaddon.Addon()
    _media   = os.path.join(_addon.getAddonInfo('path'), 'resources', 'media')

    def _icon(name, fallback='DefaultVideoPlaylists.png'):
        p = os.path.join(_media, name)
        return p if os.path.exists(p) else fallback

    def _add(label, action, icon, plot, **kw):
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(label))
        li.setArt({'icon': icon})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action, **kw), listitem=li, isFolder=True)

    _add("Modo Cine", "pelis_flix",
         _icon('modo_grid.png'),
         "Interfaz interactiva a pantalla completa al estilo Netflix para explorar el mejor cine, estrenos, tendencias y plataformas.",
         mode="movie")

    _add("Modo Series", "pelis_flix",
         _icon('modo_grid.png'),
         "Explora series en una interfaz estilo Netflix. Accede al Top 10, tendencias, emisiones del día y plataformas, con catálogo de géneros, anime y más, ampliable desde los ajustes.",
         mode="show")

    _add("Buscar película o serie",      "buscar_tops_menu",
         _icon('adv_busqueda.png'),
         "Busca por título (TMDB + tus tops, tolera erratas), por director, por género o por año. Al pulsar un resultado abre el menú nativo: dónde verla, Dailymotion, YouTube, torrents y más.")

    _add("Mejores Películas",            "filmaffinity_menu",
         _icon('top_mejores.png'),
         "Top películas y series por género.\nAcción, Drama, Comedia, Terror, Ciencia Ficción, Series TV y más.")

    _add("FilmAffinity",                 "filmaffinity_submenu",
         _icon('top_filmaffinity.png'),
         "Cartelera, novedades de streaming (Netflix, HBO, Prime, Disney+, Movistar, Filmin, Apple TV+, SkyShowtime), cines internacional, alquiler y venta, y los tops de la comunidad.")

    _add("SensaCine",                    "sensacine_submenu",
         _icon('top_sensacine.png'),
         "Cartelera actual en cines de España y próximos estrenos.")

    _add("Cinemeta - Top Películas",     "cinemeta_submenu",
         _icon('top_cinemeta.png'),
         "Top películas más valoradas a nivel mundial, con navegación por género.\nActualizado cada 6 horas.")

    _add("Listas de Trakt.tv",           "trakt_root",
         _icon('top_trakt_listas.png'),
         "Listas curadas de películas y series, disponibles sin configuración adicional.")

    _add("Películas (Top Historia/Populares)", "peliculas_top",
         _icon('top_peliculas_hist.png'),
         "Lista curada de más de 130 películas legendarias y populares de todos los tiempos.",
         page=1)

    _add("Ganadoras del Oscar",          "oscar_movies",
         _icon('oscar.png'),
         "Todas las ganadoras del Oscar a Mejor Película desde 1939 hasta hoy, ordenadas por año de ceremonia con sinopsis, director y nota IMDb.")

    _add("TMDB — Listas oficiales",      "tmdb_lists_menu",
         _icon('top_tmdb.png'),
         "Listas de películas y series: top valoradas, populares, tendencias, próximos estrenos y mejores series.")

    _add("Trakt — Tops en tiempo real",  "trakt_tops_menu",
         _icon('top_trakt_real.png'),
         "Tendencia, populares, más vistas, más esperadas y taquilla USA — datos en tiempo real de Trakt.tv.")

    _add("MDbList — Listas populares",   "mdblist_menu",
         _icon('top_mdblist.png'),
         "Listas curadas que combinan valoraciones de IMDb, Letterboxd, Metacritic y Rotten Tomatoes.\nRequiere API key gratuita de mdblist.com.")

    _add("Por plataforma de streaming",  "streaming_tops_menu",
         _icon('top_streaming.png'),
         "Lo mejor de Netflix, Amazon Prime, Disney+, Max, Movistar Plus+ y Apple TV+ en España según TMDB.")

    _add("Anime — AniList y MyAnimeList","anime_menu",
         _icon('top_anime.png'),
         "Tops de anime: trending, populares, mejor valorados y por temporada.\nAniList no requiere configuración. MAL requiere Client ID gratuito.")

    _add("Letterboxd — Listas curadas",  "letterboxd_menu",
         _icon('top_lists_popular.png'),
         "Listas de culto de Letterboxd: su Top 500, el IMDb Top 250 y las 1001 películas que ver antes de morir, con enriquecido de TMDB.")

    _add("RTVE — Cine",                  "rtve_category",
         _icon('cat_cine.png', 'DefaultMovies.png'),
         "Películas disponibles gratuitamente en RTVE Play.",
         cat_id="866", cat_name="Cine")

    li = xbmcgui.ListItem(label="[B]Internet Archive — Dominio Público[/B]")
    li.setArt({'icon': _icon('archive.png', 'DefaultMovies.png')})
    li.setInfo('video', {'plot': "Biblioteca digital sin ánimo de lucro que preserva millones de obras culturales.\n\nContiene películas, documentales y cine clásico de dominio público reproducibles directamente y de forma completamente legal.\n\nFundada en 1996, alberga más de 40 millones de recursos digitalizados.\n\n[COLOR orange]La búsqueda se realiza al pulsar el botón correspondiente. Los resultados provienen directamente de Internet Archive y no están controlados ni filtrados por este addon.[/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="archive_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Calendario de Emisión de Series[/B]")
    li.setArt({'icon': _icon('top_series_air.png')})
    li.setInfo('video', {'plot': "Episodios programados en los próximos 14 días para las series actualmente en emisión, agrupados por día.\n\nDatos de TMDB, con horas de emisión de Trakt cuando están disponibles. Cacheado 6 horas."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="calendario_series"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Buscar en TopZilla[/B]")
    li.setArt({'icon': _icon('adv_busqueda.png')})
    li.setInfo('video', {'plot': "Busca una película o serie y abre el menú completo de TopZilla."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="topzilla_buscar_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Mi Biblioteca (TopZilla)[/B]")
    li.setArt({'icon': _icon('favoritos.png')})
    li.setInfo('video', {'plot': "Tus favoritos, categorías personalizadas, historial de visionado y de navegación en TopZilla."})
    li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="topzilla_library"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]TopZilla[/B] (sistema más completo)")
    li.setArt({'icon': _icon('topzilla.png')})
    li.setInfo('video', {'plot': "TopZilla muestra rankings, información y vídeos relacionados de películas y series. Además permite buscarlas, filtrarlas y guardar en tu biblioteca o consultar su ficha en dos clics, estés donde estés en tu Kodi."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="ek_launch", addon_id="plugin.video.topzilla"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _ls(cid, page=0):
    items = _dm_search(cid, extra_params={"page": page + 1} if page else None)
    if not items:
        if page == 0:
            xbmcgui.Dialog().ok("Error", "No se pudo obtener la lista de contenidos.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return

    _process_atres_items(items, cid, page=page)

def _process_atres_items(items, cid, page=0):
    addon = xbmcaddon.Addon(); ai = addon.getAddonInfo('icon'); af = addon.getAddonInfo('fanart')
    for i in items:
        try:
            tt = i.get("title", "Sin título"); im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr)
            if not th:
                try:
                    dr = _sr(tt)
                    th = dr[0].get("thumbnail_720_url") or dr[0].get("thumbnail_360_url") if dr else ai
                except (requests.RequestException, ValueError, KeyError, IndexError):
                    th = ai
            if not th: th = ai
            fa = th if th != ai else af
            lk = i.get("link", {}); au = lk.get("href")
            if not au: continue
            li = xbmcgui.ListItem(label=tt); li.setArt({'thumb': th, 'icon': th, 'fanart': fa})
            li.setInfo('video', {'title': tt, 'plot': i.get('description', '')})
            

            _add_fav_cm(li, tt, "atresplayer", "fs", {"au": au, "st": tt, "sth": th})
            

            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=au, st=tt, sth=th), listitem=li, isFolder=True)

        except (KeyError, AttributeError, TypeError) as e:
            _log_error(f"Error al procesar item del catálogo: {e}")
            continue

    # Paginacion: si hay items suficientes, probablemente hay mas paginas
    if len(items) >= 10:
        next_page = page + 1
        li = xbmcgui.ListItem(label="[COLOR cyan][B]>> Página Siguiente ({0})[/B][/COLOR]".format(next_page))
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls", cid=cid, page=next_page), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=core_settings.remember_list_position())

def _clear_cache():
    if not xbmcgui.Dialog().yesno("EspaTV",
"¿Borrar TODA la caché?\n\nEsto eliminará datos temporales de canales y el historial de red. NO borrará tus listas ni tu configuración.\n¿Estás seguro?"):
        return

    import storage_manager as _sm
    import core_settings
    # Whitelist: borra solo lo conocido como caché (_CACHES). La config del usuario
    # (menu_layout, ajustes del Modo Cine, toggles) queda a salvo por no estar en la lista.
    _sm.purgar_todas()
    core_settings.clear_iptv_cache_files()

    xbmcgui.Dialog().notification("EspaTV", "Caché borrada", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _fs(au, st, sth="", pu=""):
    if pu and au == pu: _fb(st, sth); return
    d = _dm_search(au)
    if not d: _fb(st, sth); return
    ss = d.get("seasons", []); rw = d.get("rows", []); id_ = d.get("items", [])
    erh = None
    for ro in rw:
        if ro.get("type") == "EPISODE": erh = ro.get("href"); break
    if erh: _lfr(erh, st, sth); return
    if id_: _rel(id_, st, sth); return
    if len(ss) > 1:
        for s in ss:
            t = s.get("title", "Temporada"); sh = s.get("link", {}).get("href")
            if sh and sh != au:
                li = xbmcgui.ListItem(label=t); li.setArt({'thumb': sth, 'icon': sth})
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=sh, st=st, sth=sth, pu=au), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1])); return
    elif len(ss) == 1:
        sh = ss[0].get("link", {}).get("href")
        if sh and sh != au: _fs(sh, st, sth, pu=au); return
    _fb(st, sth)

def _fb(st, sth):
    li = xbmcgui.ListItem(label=f"Buscar '{st}' en Internet..."); li.setArt({'thumb': sth, 'icon': sth})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=st, ot=sth), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _lfr(ru, st, sth=""):
    items = _dm_search(ru)
    if items: _rel(items, st, sth)

def _rel(items, st, sth=""):
    for i in items:
        tt = i.get("title", "Capítulo"); en = i.get("name", ""); dt = f"{en} - {tt}" if en else tt

        sq = f"{tt} {en}".strip() if en else tt
        im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr) or sth
        li = xbmcgui.ListItem(label=dt); li.setArt({'thumb': th, 'icon': th, 'fanart': th})
        li.setInfo('video', {'title': dt, 'plot': i.get('description', '')})

        # Menú contextual: añadir a favoritos (episodio individual)
        _add_fav_cm(li, dt, "atresplayer", "lfr", {"q": sq, "ot": th})

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=sq, ot=th), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _clean_title(t):
    # en "Canal : Título del video", la segunda parte suele ser el título real
    if " : " in t: parts = t.split(" : "); t = parts[1] if len(parts[1]) > len(parts[0]) else parts[0]
    return t.strip()

def _lfd(q, ot, mode="", extra_params=None, nh=None):
    cq = _clean_title(q)
    rs = []
    
    if mode == "movie":
        # Intentar varias combinaciones para encontrar contenido en español
        variations = [
            f"{cq} pelicula completa castellano",
            f"{cq} pelicula completa español",
            f"{cq} pelicula completa",
            f"{cq} completa español",
            f"{cq} castellano",
            cq # Como ultimo recurso, el titulo limpio a secas
        ]
        
        for v in variations:
            rs = _sr(v, extra_params)
            if rs: break # Si encontramos algo, nos quedamos con ello
            
    elif mode == "exact":
        # Busca exactamente lo que el usuario escribió
        rs = _sr(q, extra_params)

    elif mode == "keywords":
        # Busca solo por palabras clave de más de 3 letras
        kw = " ".join([w for w in re.findall(r'\w+', q) if len(w) > 3])
        if kw: rs = _sr(kw, extra_params)

    else:
        # Logica estandar para series/programas (o User, Long, Short)
        # Si es modo User/Long/Short, el 'q' puede ser el termino de busqueda normal, y 'extra_params' lleva el filtro.
        # Intentamos con titulo limpio primero
        rs = _sr(cq, extra_params) 
        if not rs and cq != q: rs = _sr(q, extra_params) # Intentar con el original si el limpio falla
    
    if not rs and mode not in ["exact", "keywords"]: 
        # Ultimo intento: buscar solo palabras clave (mayores de 3 letras)
        kw = " ".join([w for w in re.findall(r'\w+', q) if len(w) > 3])
        if kw: rs = _sr(kw, extra_params)
    
    # Botón de alternativas de búsqueda al inicio de resultados
    _has_alt_addons = (
        xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)") or
        xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)") or
        xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)")
    )
    if _has_alt_addons:
        _alt_label = "[COLOR yellow][B]¿No es lo que buscas? · Amplía tu búsqueda[/B][/COLOR]"
    else:
        _alt_label = "[COLOR yellow][B]Editar búsqueda y reintentar[/B][/COLOR]"
    li_alt = xbmcgui.ListItem(label=_alt_label)
    li_alt.setArt({'icon': 'DefaultAddonsSearch.png', 'thumb': 'DefaultAddonsSearch.png'})
    li_alt.setInfo('video', {'plot': "Busca en otros addons instalados o edita tu búsqueda."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_alt_prompt", q=cq, ot=ot, mode=mode), listitem=li_alt, isFolder=False)

    if not rs: 
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron resultados", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    sr = _gsr(cq, rs, mode)[:25] # Aumentamos un poco el limite para tener mas donde ordenar
    
    if not sr: 

        if xbmcgui.Dialog().yesno("EspaTV", "No se encontraron coincidencias relevantes.\n\n¿Quieres editar las palabras clave y probar otra vez?"):
             kb = xbmc.Keyboard(q, 'Editar Búsqueda')
             kb.doModal()
             if kb.isConfirmed():
                 nq = kb.getText()
                 if nq:
                     xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=nq, ot=ot)})")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    

    
    min_dur = core_settings.get_min_duration() * 60
    for sc, v in sr:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        
        # FILTRO ESTRICTO DE DURACIÓN
        if min_dur > 0 and du < min_dur: continue
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ot
        
        # En modo pelicula mostramos el titulo completo del video encontrado
        if mode == "movie":
             lb = vt
        else:
             lb = f"{vt} ({int(sc*100)}% match)"

        li = xbmcgui.ListItem(label=lb); li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Subido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        
        # MENU CONTEXTUAL PARA DESCARGAR Y ABRIR EN NAVEGADOR
        cm = []
        cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=vt)})"))
        cm.append(("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"))
        cm.append(("Abrir en navegador", f"RunPlugin({_u(action='dm_open_browser', url=vi)})"))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vi)))))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _pv(vid):
    """Reproductor principal Dailymotion. Cascada según plataforma + nivel de seguridad configurado."""
    try:
        dm_cfg = _load_dm_settings()
        dm_level = dm_cfg.get('dm_safe_level', 0)
        max_quality = dm_cfg.get('dm_max_quality', 1080)

        # Metadata opcional (no bloquea la reproducción si falla)
        d = _dm_resolve(vid)
        v_title = d.get('title', vid) if d else vid
        v_thumb = (d.get('thumbnail_url') or d.get('thumbnail_360_url', '')) if d else ''
        v_duration = d.get('duration', 0) if d else 0

        def _record_history():
            try:
                _wh.add(vid, v_title, thumb=v_thumb, duration=v_duration)
            except (OSError, ValueError):
                pass

        _is_windows = xbmc.getCondVisibility("System.Platform.Windows")
        
        # Solo usar YT-DLP si el usuario lo seleccionó explícitamente (Nivel 3)
        use_ytdlp = (dm_level == 3)

        if not _is_windows and not use_ytdlp:
            # No-Windows: resolucion directa (API) con fallback a dm_gujal
            result = _dm_play_android(vid, dm_level=dm_level, max_quality=max_quality)
            if result and result.get('url'):
                _record_history()
                stream_url = result['url']
                mime_type = result.get('mime', '')
                is_hls = 'mpegURL' in mime_type

                # Codificar headers si presentes (salvaguarda defensiva)
                headers_dict = result.get('headers')
                header_str = ""
                if headers_dict:
                    header_str = "&".join(
                        "{0}={1}".format(k, urllib.parse.quote(str(v)))
                        for k, v in headers_dict.items()
                    )

                if not is_hls and header_str:
                    stream_url = "{0}|{1}".format(stream_url, header_str)

                li = xbmcgui.ListItem(path=stream_url)
                if mime_type:
                    li.setMimeType(mime_type)
                if is_hls and header_str:
                    li.setProperty("inputstream", "inputstream.adaptive")
                    li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                    li.setProperty("inputstream.adaptive.stream_headers", header_str)
                li.setContentLookup(False)
                subs = result.get('subs')
                if subs and isinstance(subs, list):
                    li.setSubtitles(subs)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
                return

            # Fallback para no-Windows: plugin.video.dailymotion_com
            if xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
                xbmc.log("[EspaTV] _pv: Intentando plugin.video.dailymotion_com...", xbmc.LOGINFO)
                dm_plugin_url = "plugin://plugin.video.dailymotion_com/?url={0}&mode=playVideo".format(vid)
                xbmc.executebuiltin('PlayMedia("{0}")'.format(dm_plugin_url))
                try:
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                except RuntimeError:
                    pass
                return

            xbmcgui.Dialog().notification("EspaTV", "No se encontró stream válido", xbmcgui.NOTIFICATION_ERROR)
            try:
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            except RuntimeError:
                pass

        else:
            _dm_ok = False
            dm_web_url = "https://www.dailymotion.com/video/{0}".format(vid)
            _python_missing = False
            _ytdlp_missing = False

            # Paso 1: system-python script (no requiere yt-dlp)
            try:
                import subprocess as _sp, json as _json
                xbmcgui.Dialog().notification("EspaTV", v_title[:50] if v_title else "Cargando...", xbmcgui.NOTIFICATION_INFO, 2000)
                _proc = _sp.run(
                    ['python', '-c', _DM_SYSPY_SCRIPT, vid],
                    capture_output=True, text=True, timeout=20,
                    creationflags=0x08000000,
                )
                if _proc.returncode == 0 and _proc.stdout.strip():
                    stream_url = _json.loads(_proc.stdout).get('url', '')
                    if stream_url:
                        xbmc.log("[EspaTV] DM system-python OK", xbmc.LOGINFO)
                        _record_history()
                        li = xbmcgui.ListItem(path=stream_url)
                        li.setMimeType('application/x-mpegURL')
                        li.setProperty('IsPlayable', 'true')
                        li.setContentLookup(False)
                        try:
                            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
                        except RuntimeError:
                            xbmc.Player().play(stream_url, li)
                        _dm_ok = True
                if not _dm_ok:
                    xbmc.log("[EspaTV] DM system-python rc={0} err={1}".format(
                        _proc.returncode, _proc.stderr[:200] if _proc.stderr else ''), xbmc.LOGWARNING)
            except FileNotFoundError:
                _python_missing = True
                xbmc.log("[EspaTV] DM system-python: python no encontrado en PATH", xbmc.LOGWARNING)
            except Exception as _e:
                xbmc.log("[EspaTV] DM system-python fallido: {0}".format(_e), xbmc.LOGWARNING)

            # Paso 2: yt-dlp como fallback
            if not _dm_ok and not _python_missing:
                _ytdlp_present = ytdlp_resolver.is_installed()
                if _ytdlp_present:
                    xbmcgui.Dialog().notification("EspaTV", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
                    stream_url = ytdlp_resolver.resolve(dm_web_url)
                    if stream_url:
                        _record_history()
                        li = xbmcgui.ListItem(path=stream_url)
                        li.setProperty('IsPlayable', 'true')
                        li.setContentLookup(False)
                        try:
                            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
                        except RuntimeError:
                            xbmc.Player().play(stream_url, li)
                        _dm_ok = True
                else:
                    _ytdlp_missing = True

            # Notificacion no bloqueante si faltan herramientas
            if not _dm_ok and (_python_missing or _ytdlp_missing):
                _msg = (
                    "Instala Python desde python.org para reproduccion fiable en Windows"
                    if _python_missing else
                    "Instala yt-dlp (pip install yt-dlp) para mayor fiabilidad"
                )
                xbmcgui.Dialog().notification("EspaTV", _msg, xbmcgui.NOTIFICATION_INFO, 5000)

            # Paso 3: API directa en Kodi (silencioso, igual que TopZilla)
            if not _dm_ok:
                try:
                    result = _dm_play_direct(vid, max_quality=max_quality)
                    if result and result.get('url'):
                        _record_history()
                        stream_url = result['url']
                        mime_type = result.get('mime', '')
                        is_hls = 'mpegURL' in mime_type
                        headers_dict = result.get('headers') or {}
                        header_str = "&".join(
                            "{0}={1}".format(k, urllib.parse.quote(str(v)))
                            for k, v in headers_dict.items()
                        ) if headers_dict else ""
                        if not is_hls and header_str:
                            stream_url = "{0}|{1}".format(stream_url, header_str)
                        li = xbmcgui.ListItem(path=stream_url)
                        li.setMimeType(mime_type or 'application/x-mpegURL')
                        li.setContentLookup(False)
                        if is_hls and header_str:
                            li.setProperty("inputstream", "inputstream.adaptive")
                            li.setProperty("inputstream.adaptive.manifest_type", "hls")
                            li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                            li.setProperty("inputstream.adaptive.stream_headers", header_str)
                        subs = result.get('subs')
                        if subs and isinstance(subs, list):
                            li.setSubtitles(subs)
                        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
                        _dm_ok = True
                except (RuntimeError, OSError, ValueError):
                    pass

            # Paso 4: dm_gujal (silencioso, igual que TopZilla)
            if not _dm_ok:
                try:
                    result = _dm_play(vid, dm_level=dm_level, max_quality=max_quality)
                    if result and result.get('url'):
                        _record_history()
                        stream_url = result['url']
                        mime_type = result.get('mime', '')
                        is_hls = 'mpegURL' in mime_type
                        headers_dict = result.get('headers') or {}
                        header_str = "&".join(
                            "{0}={1}".format(k, urllib.parse.quote(str(v)))
                            for k, v in headers_dict.items()
                        ) if headers_dict else ""
                        if not is_hls and header_str:
                            stream_url = "{0}|{1}".format(stream_url, header_str)
                        li = xbmcgui.ListItem(path=stream_url)
                        if mime_type:
                            li.setMimeType(mime_type)
                        if is_hls and header_str:
                            li.setProperty("inputstream", "inputstream.adaptive")
                            li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                            li.setProperty("inputstream.adaptive.stream_headers", header_str)
                        li.setContentLookup(False)
                        subs = result.get('subs')
                        if subs and isinstance(subs, list):
                            li.setSubtitles(subs)
                        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
                        _dm_ok = True
                except (RuntimeError, OSError, ValueError):
                    pass

            # Paso 5: plugin dailymotion_com (silencioso)
            if not _dm_ok and xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
                try:
                    dm_plugin_url = "plugin://plugin.video.dailymotion_com/?url={0}&mode=playVideo".format(vid)
                    xbmc.executebuiltin('PlayMedia("{0}")'.format(dm_plugin_url))
                    import time as _t; _t.sleep(3)
                    if xbmc.Player().isPlaying():
                        _record_history()
                        _dm_ok = True
                except RuntimeError:
                    pass

            # Solo si todo falla: ofrecer navegador web
            if not _dm_ok:
                if xbmcgui.Dialog().yesno(
                    "EspaTV - Dailymotion",
                    "No se pudo reproducir el video en Kodi.\n\n"
                    "Activa una VPN e intentalo de nuevo, o abrelo en el navegador.",
                    yeslabel="Navegador Web", nolabel="Cerrar"
                ):
                    try:
                        import webbrowser
                        webbrowser.open(dm_web_url)
                        xbmcgui.Dialog().notification("EspaTV", "Enlace enviado al navegador", xbmcgui.NOTIFICATION_INFO)
                    except (OSError, webbrowser.Error):
                        xbmcgui.Dialog().ok("EspaTV", "Abre esta URL en tu navegador:\n\n{0}".format(dm_web_url))
                    _record_history()
                try:
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                except RuntimeError:
                    pass

    except (requests.RequestException, ValueError, RuntimeError, KeyError) as e:
        _l(f"Play Error: {e}")
        xbmcgui.Dialog().ok("Error", str(e))


def _sr(q, extra_params=None):
    p = {}
    if core_settings.is_recent_active():
        p["sort"] = "recent"
    if extra_params:
        p.update(extra_params)
    return _dm_search(q, p if p else None)

def _gsr(q, rs, mode=""):
    if not rs: return []
    sc = []; ql = q.lower().strip(); qn = re.findall(r'(\d+)', ql)
    for r in rs:
        t = r.get("title", "").strip(); tl = t.lower()
        if not t: continue
        

        rt = difflib.SequenceMatcher(None, ql, tl).ratio(); s = rt
        
        # FILTRO ESTRICTO: Si no contiene las palabras clave de la busqueda, penalizar fuertemente
        # (Esto evita que salgan resultados random como 'La Monja' buscando 'Top Gun')
        q_words = [w for w in ql.split() if len(w) > 3] # Palabras importantes (>3 letras)
        if q_words:
            matches = sum(1 for w in q_words if w in tl)
            if matches == 0: 
                s -= 1.0 # Penalizacion masiva si no coincide ninguna palabra clave
            elif matches < len(q_words):
                s -= 0.1 # Pequeña penalizacion si faltan palabras

        if ql in tl: s += 0.35 # Match contenido exacto
        

        words_q = set(ql.split())
        words_t = set(tl.split())
        common = words_q.intersection(words_t)
        if len(common) > 0: s += (len(common) / len(words_q)) * 0.2
        

        tn = re.findall(r'(\d+)', tl)
        if qn and tn:
            if qn[-1] in tn: s += 0.4
            if set(qn).issubset(set(tn)): s += 0.1
            

        # IMPORTANTE: Solo aplicamos bonus de duracion si el titulo coincide razonablemente bien (s > 0.3)
        # Esto evita que 'La Monja' (larga) gane a 'Iron Man 3' (corto) si el titulo no se parece.
        du = r.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        
        if s > 0.3: # Solo si hay match de titulo decente
            if not core_settings.is_prioritize_match_active():
                # Modo ESTÁNDAR: Fuerte bonus por duración
                if du > 600: s += 0.6    # Gran bonus si coincide titulo y es larga
                elif du > 300: s += 0.2
            else:
                # Modo PRECISIÓN: Bonus por duración mínimo
                if du > 600: s += 0.05
            
            if du < 180: s -= 0.1  # Penalizacion leve por ser muy corto (trailer)
        else:
            # Si el titulo no coincide bien, la duracion NO ayuda.
            pass
        

        if any(w in tl for w in ["español", "castellano", "spanish"]):
            s += 0.15

        # Filtrado especifico de peliculas
        if mode == "movie":
            # Penalizar contenido que no sea pelicula
            if any(w in tl for w in ["trailer", "avance", "entrevista", "making", "detras", "clip", "promo"]):
                s -= 0.5
            # Bonus por indicadores de pelicula
            if any(w in tl for w in ["pelicula", "completa", "movie", "film"]):
                s += 0.2

        s = min(s, 1.0)
        sc.append((s, r))
    sc.sort(key=lambda x: x[0], reverse=True); return sc


def _show_yt_fav_news():
    favs = core_settings.get_favorites()
    channels = []
    for f in favs:
        if f.get('action') != 'felicidad_play':
            continue
        params = f.get('params', {})
        if isinstance(params, str):
            try:
                params = json.loads(params)
            except (json.JSONDecodeError, TypeError):
                continue
        if params.get('ctype') == 'channel' and params.get('yt_id'):
            channels.append({'yt_id': params['yt_id'], 'name': params.get('name', 'Canal')})

    if not channels:
        xbmcgui.Dialog().ok("EspaTV", "No tienes canales de YouTube en favoritos.\n\nAñade canales desde las secciones de YouTube.")
        return

    pdp = xbmcgui.DialogProgress()
    pdp.create("Novedades YouTube", "Buscando vídeos recientes...")

    all_videos = []
    total = len(channels)
    for i, ch in enumerate(channels):
        if pdp.iscanceled():
            break
        pdp.update(int((i / max(total, 1)) * 100), "Analizando: [B]{0}[/B]".format(ch['name']))
        try:
            url = "https://www.youtube.com/channel/{0}/videos".format(ch['yt_id'])
            r = requests.get(url, headers={"Accept-Language": "es"}, timeout=12)
            if r.status_code != 200:
                continue
            data = _yts._yt_parse_initial_data(r.text)
            if not data:
                continue
            # Extraer de la pestaña de vídeos del canal
            vids = []
            try:
                tabs = data.get("contents", {}).get("twoColumnBrowseResultsRenderer", {}).get("tabs", [])
                for tab in tabs:
                    tr = tab.get("tabRenderer", {})
                    if tr.get("selected"):
                        contents = tr.get("content", {}).get("richGridRenderer", {}).get("contents", [])
                        for item in contents:
                            ri = item.get("richItemRenderer", {}).get("content", {}).get("videoRenderer")
                            if not ri:
                                continue
                            vid = ri.get("videoId", "")
                            if not vid:
                                continue
                            title = ""
                            runs = ri.get("title", {}).get("runs", [])
                            if runs:
                                title = runs[0].get("text", "")
                            dur = ri.get("lengthText", {}).get("simpleText", "")
                            views = ri.get("viewCountText", {}).get("simpleText", "")
                            if not views:
                                views = ri.get("shortViewCountText", {}).get("simpleText", "")
                            published = ri.get("publishedTimeText", {}).get("simpleText", "")
                            if title and vid:
                                vids.append({
                                    "vid": vid, "title": title, "duration": dur,
                                    "channel": ch['name'], "views": views,
                                    "published": published
                                })
                            if len(vids) >= 5:
                                break
                        break
            except (KeyError, TypeError):
                pass
            all_videos.extend(vids)
        except (requests.RequestException, ValueError, KeyError):
            continue

    pdp.close()

    if not all_videos:
        xbmcgui.Dialog().ok("Novedades YouTube", "No se encontraron vídeos recientes en tus canales favoritos.")
        return

    h = int(sys.argv[1])
    xbmcplugin.setContent(h, 'videos')
    for v in all_videos:
        vid = v["vid"]
        title = v["title"]
        li = xbmcgui.ListItem(label="[COLOR cyan][{0}][/COLOR] {1}".format(v["channel"], title))
        thumb = 'https://i.ytimg.com/vi/{0}/hqdefault.jpg'.format(vid)
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb})
        plot_lines = []
        if v.get("channel"):
            plot_lines.append("Canal: {0}".format(v["channel"]))
        if v.get("duration"):
            plot_lines.append("Duración: {0}".format(v["duration"]))
        if v.get("views"):
            plot_lines.append("Vistas: {0}".format(v["views"]))
        if v.get("published"):
            plot_lines.append("Subido: {0}".format(v["published"]))
        plot = "\n".join(plot_lines) if plot_lines else title
        li.setInfo('video', {'plot': plot, 'title': title})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_play", yt_id=vid, name=title, ctype="video"), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _show_fav_news():
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaTV", "No tienes favoritos guardados", xbmcgui.NOTIFICATION_WARNING)
        return
        
    opts = [
        "Últimas 24 horas",
        "Últimas 48 horas (Recomendado)",
        "Última semana (7 días)",
        "Último mes (30 días - Lento)"
    ]
    sel = xbmcgui.Dialog().select("Margen de búsqueda de Novedades", opts)
    if sel < 0: return # Cancelado
    
    margins = [86400, 172800, 604800, 2592000]
    time_limit = int(time.time()) - margins[sel]
    sel_label = opts[sel]

    pdp = xbmcgui.DialogProgress()
    pdp.create("Novedades Favoritos DM", "Buscando: {0}...".format(sel_label))
    
    all_results = []
    
    queries = []
    seen = set()
    for f in favs:
        q = None
        if f.get('action') == 'lfr':
            q = f.get('params', {}).get('q')
        
        if q and q.lower() not in seen:
            queries.append(q)
            seen.add(q.lower())
            
    if not queries:
        pdp.close()
        xbmcgui.Dialog().ok("Mi Periódico", "No hay series o búsquedas en favoritos para analizar.")
        return

    total = len(queries)
    for i, q in enumerate(queries):
        if pdp.iscanceled(): break
        pdp.update(int((i / max(total, 1)) * 100), f"Analizando: [B]{q}[/B]")
        
        rs = _sr(q, {"created_after": time_limit})
        if rs:
            sr = _gsr(q, rs, mode="keywords") 
            for score, v in sr:
                if score > 0.35: # Filtro de calidad para evitar basura
                    vid = v.get("id")
                    if not any(r[1].get("id") == vid for r in all_results):
                        all_results.append((score, v, q))

    pdp.close()
    
    if not all_results:
        xbmcgui.Dialog().ok("Novedades Favoritos DM", "No se han encontrado novedades en '{0}' para tus favoritos.".format(sel_label))
        return

    h = int(sys.argv[1])
    all_results.sort(key=lambda x: x[0], reverse=True)
    xbmcplugin.setContent(h, 'videos')
    
    for score, v, origin in all_results:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url")
        
        label = f"[COLOR yellow][{origin}][/COLOR] {vt}"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Favorito: {origin}\nSubido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        
        cm = []
        cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=vt)})"))
        cm.append(("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"))
        cm.append(("Abrir en navegador", f"RunPlugin({_u(action='dm_open_browser', url=vi)})"))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vi)))))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(h)

def _show_favorites():
    favs = core_settings.get_favorites()
    movie_favs = (core_settings.get_movie_favorites('movie')
                  + core_settings.get_movie_favorites('show'))

    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    _bk_ico = os.path.join(_mp, 'adv_backup.png')
    li_bk = xbmcgui.ListItem(label="[COLOR cyan]Backup/Restaurar favoritos[/COLOR]")
    li_bk.setArt({'icon': _bk_ico if os.path.isfile(_bk_ico) else 'DefaultHardDisk.png'})
    li_bk.setInfo('video', {'plot': "Exporta tus favoritos a un archivo JSON o importa una copia de seguridad."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_backup_menu"), listitem=li_bk, isFolder=True)

    _FLOWFAV_REPO_ID = 'repository.flowfavmanager'
    _FLOWFAV_ADDON_ID = 'plugin.program.flowfavmanager'
    _star_ico = os.path.join(_mp, 'favoritos.png')
    _flow_ico = _star_ico if os.path.isfile(_star_ico) else 'DefaultAddonProgram.png'
    try:
        xbmcaddon.Addon(_FLOWFAV_ADDON_ID)
        li_flow = xbmcgui.ListItem(label="[COLOR yellow][B]Flow FavManager[/B][/COLOR]")
        li_flow.setArt({'icon': _flow_ico})
        li_flow.setInfo('video', {'plot': 'Abre el editor avanzado de favoritos de Kodi.\nOrganiza, personaliza colores, iconos, formatos, crea secciones, perfiles y copias de seguridad.'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_flowfav"), listitem=li_flow, isFolder=False)
    except RuntimeError:
        li_flow = xbmcgui.ListItem(label="[COLOR gray]Flow FavManager (No instalado)[/COLOR]")
        li_flow.setArt({'icon': _flow_ico})
        li_flow.setInfo('video', {'plot': 'Gestor avanzado de favoritos para Kodi.\nPulsa para instalar o ver instrucciones.'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="flowfav_install"), listitem=li_flow, isFolder=False)

    _cat_ico = os.path.join(_mp, 'catalogo.png')
    li_sec = xbmcgui.ListItem(label="[COLOR springgreen]Añadir sección a estos Favoritos o a los de Kodi[/COLOR]")
    li_sec.setArt({'icon': _cat_ico if os.path.isfile(_cat_ico) else 'DefaultAddSource.png'})
    li_sec.setInfo('video', {'plot': "Muestra todas las secciones del addon.\nAl pulsar una, eliges si guardarla aquí (en estos Favoritos) o en los Favoritos de Kodi."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_add_section_picker"), listitem=li_sec, isFolder=True)


    cats = category_manager.load_cats()
    if cats:
         li_c = xbmcgui.ListItem(label=f"[COLOR yellow][B]Mis Categorías ({len(cats)})[/B][/COLOR]")
         li_c.setArt({'icon': 'DefaultAddonService.png'})
         li_c.setInfo('video', {'plot': "Accede a tus carpetas y listas ('Infantil', 'Noticias', etc).\n\nPuedes crear nuevas categorías desde el menú principal."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cat_menu"), listitem=li_c, isFolder=True)
    

    if favs:
         li_n = xbmcgui.ListItem(label="[COLOR pink][B]Novedades Favoritos DM[/B][/COLOR]")
         li_n.setArt({'icon': os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'fav_dm_news.png')})
         li_n.setInfo('video', {'plot': "Analiza automáticamente tus favoritos y busca contenido subido recientemente.\n\nPodrás elegir el margen de tiempo (24h, 48h, 7 días...).\n\nIdeal para ver qué hay de nuevo sin ir sección por sección."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_news"), listitem=li_n, isFolder=True)

         li_yt = xbmcgui.ListItem(label="[COLOR pink][B]Novedades YouTube de Favoritos[/B][/COLOR]")
         li_yt.setArt({'icon': 'DefaultMusicVideos.png'})
         li_yt.setInfo('video', {'plot': "Busca vídeos recientes en los canales de YouTube que tengas en favoritos.\n\nMuestra los 5 últimos vídeos de cada canal."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="yt_fav_news"), listitem=li_yt, isFolder=True)


    if not favs:
        if not cats and not movie_favs: # Only show 'empty' if no cats/movie favs either
             li = xbmcgui.ListItem(label="No tienes favoritos guardados")
             li.setArt({'icon': 'DefaultIconInfo.png'})
             li.setInfo('video', {'plot': "Haz clic derecho en cualquier programa o serie y selecciona 'Añadir a Mis Favoritos' para guardarlo aquí."})
             xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="nyan_cat"), listitem=li, isFolder=False)
    else:
        for f in favs:
            li = xbmcgui.ListItem(label=f['title'])
            li.setArt({'icon': f['icon'], 'thumb': f['icon']})
        
            cm = []
            cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=f['title'])})"))



            cm.append(("Editar nombre y buscar", f"RunPlugin({_u(action='edit_and_search', q=f['title'], ot=f['icon'])})"))

            cm.append(("Renombrar...", f"RunPlugin({_u(action='fav_rename', fav_url=f['url'], old_title=f['title'])})"))
            cm.append(("Mover arriba", f"RunPlugin({_u(action='fav_move_up', fav_url=f['url'])})"))
            cm.append(("Mover abajo", f"RunPlugin({_u(action='fav_move_down', fav_url=f['url'])})"))
            

            # Usar 'cat_move_from_favs' para MOVER (borra de favs y añade a cat) en lugar de solo añadir.
            cm.append(("Mover a Categoría...", f"RunPlugin({_u(action='cat_move_from_favs', fav_url=f['url'], q=f['title'])})"))
            

            cm.append(("Eliminar de Favoritos", f"RunPlugin({_u(action='remove_favorite', fav_url=f['url'])})"))
            
            li.addContextMenuItems(cm)
            
            # Reconstruir la URL con la acción y parámetros guardados
            # URL que se abre al hacer clic en el favorito:
            u_params = f"action={f['action']}"
            for k,v in f.get('params', {}).items():
                u_params += f"&{k}={urllib.parse.quote(str(v))}"
            

            if f['action'] == 'lfr' and '&nh=' not in u_params:
                u_params += "&nh=1"
            
            non_folder_actions = ('play_podcast', 'play_tdt', 'pv', 'play_ace_result')
            is_folder = f['action'] not in non_folder_actions
            if f['action'] == 'felicidad_play':
                fav_ctype = f.get('params', {}).get('ctype', 'channel')
                is_folder = (fav_ctype == 'video')
            if f['action'] == 'play_ace_result':
                li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?"+u_params, listitem=li, isFolder=is_folder)

    # Películas y series de "Mis Favoritos" (Modo Cine): viven en movie_favorites.json,
    # pero se listan también aquí. Al pulsarlas abren el menú "¿dónde ver?".
    for mf in movie_favs:
        mf_title = mf.get('title', '')
        if not mf_title:
            continue
        mf_poster = mf.get('poster', '')
        mf_mt = mf.get('media_type', 'movie')
        li = xbmcgui.ListItem(label=mf_title)
        li.setArt({'icon': mf_poster or 'DefaultVideo.png', 'thumb': mf_poster, 'poster': mf_poster})
        li.setInfo('video', {'plot': mf.get('plot', ''),
                             'year': int(mf['year']) if str(mf.get('year', '')).isdigit() else 0})
        rm = _u(action='remove_movie_fav', q=mf_title,
                tmdb_id=str(mf.get('tmdb_id') or ''), imdb_id=str(mf.get('imdb_id') or ''),
                mode=mf_mt)
        li.addContextMenuItems([("Quitar de Mis Favoritos", f"RunPlugin({rm})")])
        url = _u(action='search_alt_prompt', q=mf_title, ot=mf_poster,
                 mode=('tv' if mf_mt == 'show' else 'movie'), tmdb_id=str(mf.get('tmdb_id') or ''))
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _fav_add_section_picker():
    import re
    h = int(sys.argv[1])
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    spanish_data = _load_spanish_channels()
    main_keys, catalog_keys = _get_effective_layout()

    def _clean(s):
        return re.sub(r'\[/?[^\]]*\]', '', s).strip()

    for key in [k for k in (main_keys + catalog_keys) if k != 'show_favorites']:
        defn = _MENU_ITEMS_MASTER.get(key)
        if not defn:
            continue
        try:
            cond = defn.get('condition')
            if cond and not cond():
                continue
            sk = defn.get('section_key')
            if sk:
                sec = spanish_data.get(sk)
                if not sec:
                    continue
                label = "[B]{0}[/B]".format(sec.get('name', sk))
                icon = _resolve_icon(sec.get('icon', 'DefaultFolder.png'), 'DefaultFolder.png', _mp)
                action, params = 'spanish_section', {'section': sk}
            else:
                label = defn['label']() if callable(defn['label']) else defn['label']
                icon = _resolve_icon(defn.get('icon', ''), defn.get('fallback', 'DefaultFolder.png'), _mp)
                action = defn['action']
                params = defn.get('params', {})

            title = _clean(label)
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': icon, 'thumb': icon})
            li.setInfo('video', {'plot': f"Pulsa para añadir «{title}» a tus favoritos."})
            url = _u(action='fav_add_section_choose', title=title,
                     sec_action=action, params=json.dumps(params), icon=icon)
            xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)
        except Exception as e:
            _l("Picker favs: item '{0}' omitido: {1}".format(key, e))
            continue

    # Secciones que no están en _MENU_ITEMS_MASTER (subsecciones internas favoritables).
    for title, action, params, icon_name in (
        ("Addons EspaKodi", "espakodi_addons_menu", {}, "info_addons.png"),
    ):
        try:
            icon = _resolve_icon(icon_name, 'DefaultIconInfo.png', _mp)
            li = xbmcgui.ListItem(label=title)
            li.setArt({'icon': icon, 'thumb': icon})
            li.setInfo('video', {'plot': f"Pulsa para añadir «{title}» a tus favoritos."})
            url = _u(action='fav_add_section_choose', title=title,
                     sec_action=action, params=json.dumps(params), icon=icon)
            xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)
        except Exception as e:
            _l("Picker favs extra: '{0}' omitido: {1}".format(title, e))
            continue

    xbmcplugin.endOfDirectory(h)


def _add_kodi_favourite(title, sec_action, params, icon):
    try:
        plugin_url = _u(action=sec_action, **params)
        resp = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Favourites.AddFavourite',
            'params': {
                'title': title, 'type': 'window', 'window': 'videos',
                'windowparameter': plugin_url, 'thumbnail': icon,
            },
        })) or '{}')
        return resp.get('result') == 'OK'
    except (ValueError, TypeError, RuntimeError) as e:
        _l("Fav Kodi: error añadiendo '{0}': {1}".format(title, e))
        return False


def _fav_add_section_choose(p):
    title = p.get("title", "")
    sec_action = p.get("sec_action", "")
    icon = p.get("icon", "")
    try:
        params = json.loads(p.get("params", "{}"))
    except (ValueError, TypeError):
        params = {}
    dlg = xbmcgui.Dialog()
    choice = dlg.select(f"¿Dónde guardar «{title}»?",
                        ["Favoritos del addon", "Favoritos de Kodi", "En ambos"])
    if choice < 0:
        return
    destinos = []
    if choice in (0, 2):
        fav_url = f"section_{sec_action}"
        if params:
            fav_url += "_" + "_".join(f"{k}-{v}" for k, v in sorted(params.items()))
        added = core_settings.add_favorite(title, fav_url, icon, "seccion", sec_action, params)
        destinos.append("Favoritos del addon" if added else "Favoritos del addon (ya estaba)")
    if choice in (1, 2):
        if _add_kodi_favourite(title, sec_action, params, icon):
            destinos.append("Favoritos de Kodi")
    if destinos:
        dlg.notification("EspaTV", "Añadido a: " + " y ".join(destinos), xbmcgui.NOTIFICATION_INFO)
    else:
        dlg.notification("EspaTV", "No se pudo añadir", xbmcgui.NOTIFICATION_WARNING)


def _fav_backup_menu():
    h = int(sys.argv[1])
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ri(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    li = xbmcgui.ListItem(label="[COLOR cyan]Exportar Favoritos...[/COLOR]")
    li.setArt({'icon': _ri('fav_export.png')})
    li.setInfo('video', {'plot': "Guarda tus favoritos en un archivo JSON para hacer una copia de seguridad o compartirlos."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fav_export"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR cyan]Importar Favoritos...[/COLOR]")
    li.setArt({'icon': _ri('fav_import.png')})
    li.setInfo('video', {'plot': "Restaura favoritos desde un archivo JSON exportado anteriormente."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fav_import"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _show_downloads():
    _p2p_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'p2p.png')
    li = xbmcgui.ListItem(label="[COLOR peru][B]Torrents (P2P)[/B][/COLOR]")
    li.setArt({'icon': _p2p_icon if os.path.exists(_p2p_icon) else 'DefaultAddonProgram.png'})
    li.setInfo('video', {'plot': "Acceso a redes P2P (peer-to-peer) mediante Elementum.\n\nLas redes P2P permiten compartir archivos directamente entre nodos sin servidor central. BitTorrent es el protocolo P2P más utilizado.\n\nRequiere tener Elementum instalado.\n\nEste addon no aloja ni distribuye contenido. El usuario asume toda responsabilidad sobre el uso que haga de Elementum. Elementum es un addon de terceros independiente de EspaTV."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="elementum_search_prompt"), listitem=li, isFolder=False)



    dls = core_settings.get_downloads()
    if not dls:
        li = xbmcgui.ListItem(label="No hay historial de descargas")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'plot': "Cuando descargues un vídeo con éxito, aparecerá aquí.\nPuedes descargar vídeos desde los resultados de búsqueda pulsando clic derecho."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    else:
        for d in dls:
            path = d['path']
            if not os.path.exists(path):
                label = f"[COLOR grey][ELIMINADO][/COLOR] {d['title']}"
                is_valid = False
            else:
                label = f"{d['title']} ({d['date']})"
                is_valid = True
                
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': 'DefaultVideo.png'})
            li.setInfo('video', {'title': d['title'], 'plot': f"Archivo: {path}\nDescargado el: {d['date']}"})
            
            cm = [("Quitar del historial", f"RunPlugin({_u(action='remove_download', dl_path=path)})")]
            if is_valid:
                 li.setProperty("IsPlayable", "true")
                 cm.append(("[COLOR red]ELIMINAR ARCHIVO DEL DISCO[/COLOR]", f"RunPlugin({_u(action='delete_download_file', dl_path=path, title=d['title'])})"))
             
                 u = path
            else:
                 u = ""
                 
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=False if is_valid else True)
        
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _add_fav_cm(li, title, platform, action, params, extra_items=None):
    id_val = params.get('cid') or params.get('pid') or params.get('url') or params.get('au') or params.get('q')
    if not id_val:
        id_val = str(hash(json.dumps(params, sort_keys=True)))
    fav_url = f"{action}_{id_val}"
    params_json = json.dumps(params)
    items = list(extra_items) if extra_items else []
    items.append(("Añadir a Mis Favoritos", f"RunPlugin({_u(action='add_favorite', title=title, fav_url=fav_url, icon=li.getArt('icon'), platform=platform, fav_action=action, params=params_json)})"))
    li.addContextMenuItems(items)

def _delete_download_file(path, title):
    if xbmcgui.Dialog().yesno("Eliminar Archivo", f"¿Estás seguro de que quieres eliminar físicamente el archivo?\n\n[B]{title}[/B]\n\nEsta acción eliminará el archivo de tu disco duro para siempre."):
        try:
            if os.path.exists(path):
                os.remove(path)
                core_settings.remove_download(path)
                xbmcgui.Dialog().notification("EspaTV", "Archivo eliminado satisfactoriamente", xbmcgui.NOTIFICATION_INFO)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("EspaTV", "El archivo ya no existe en esa ruta.")
                core_settings.remove_download(path)
                xbmc.executebuiltin("Container.Refresh")
        except OSError as e:
            xbmcgui.Dialog().ok("EspaTV Error", f"No se pudo eliminar: {str(e)}")








def _toggle_advanced_search():
    new_state = not core_settings.is_advanced_search_active()
    core_settings.set_advanced_search_active(new_state)
    msg = "MENÚ AVANZADO ACTIVADO" if new_state else "BÚSQUEDA DIRECTA (SIMPLE)"
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _configure_cinema_rows():
    """Elegir qué filas se muestran en el Modo Cine (películas y series)."""
    import pelis_flix
    dlg = xbmcgui.Dialog()
    sel0 = dlg.select("Configurar filas del Modo Cine",
                      ["Películas (Cine)", "Series", "[Restaurar filas por defecto]"])
    if sel0 < 0:
        return
    if sel0 == 2:
        if dlg.yesno("Modo Cine", "¿Restaurar las filas por defecto en Cine y Series?"):
            core_settings.reset_flix_rows()
            dlg.notification("EspaTV", "Filas restauradas", xbmcgui.NOTIFICATION_INFO)
        return

    mode = pelis_flix.MODE_CINE if sel0 == 0 else pelis_flix.MODE_SERIES
    catalog = pelis_flix.catalog_for(mode)
    active = set(core_settings.load_flix_rows(mode) or pelis_flix.default_ids(catalog))
    labels = [r['title'] for r in catalog]
    preselect = [i for i, r in enumerate(catalog) if r['id'] in active]
    sel = dlg.multiselect("Filas a mostrar", labels, preselect=preselect)
    if sel is None:
        return
    if not sel:
        dlg.notification("EspaTV", "Deja al menos una fila activa", xbmcgui.NOTIFICATION_WARNING)
        return
    core_settings.save_flix_rows(mode, [catalog[i]['id'] for i in sel])
    dlg.notification("EspaTV", "Filas actualizadas", xbmcgui.NOTIFICATION_INFO)

def _advanced_search_menu():
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    # === BÚSQUEDAS BÁSICAS ===
    li = xbmcgui.ListItem(label="[B]— BÚSQUEDAS BÁSICAS —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda Estándar (Por Título)")
    li.setArt({'icon': _ico('srch_estandar.png', 'DefaultAddonWebSkin.png')})
    _add_fav_cm(li, "Búsqueda Estándar", "search", "execute_adv_search", {"mode": ""})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode=""), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda de Películas (Modo Cine)")
    li.setArt({'icon': _ico('srch_pelicula.png', 'DefaultMovies.png')})
    li.setInfo('video', {'plot': "Optimiza la búsqueda para encontrar películas completas en castellano.\nPrueba variantes como 'pelicula completa', 'castellano', etc."})
    _add_fav_cm(li, "Búsqueda de Películas", "search", "execute_adv_search", {"mode": "movie"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="movie"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda de Series (Temporada + Capítulo)")
    li.setArt({'icon': _ico('srch_serie.png', 'DefaultTVShows.png')})
    li.setInfo('video', {'plot': "Introduce el nombre de la serie y el addon te pedirá número de temporada y capítulo.\nConstruye automáticamente la mejor query posible."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="series"), listitem=li, isFolder=True)

    # === FILTROS DE DURACIÓN ===
    li = xbmcgui.ListItem(label="[B]— FILTROS DE DURACIÓN —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda de Vídeos Largos (+20 min)")
    li.setArt({'icon': _ico('srch_largo.png', 'DefaultVideo.png')})
    li.setInfo('video', {'plot': "Filtra los resultados para mostrar solo vídeos de más de 20 minutos.\nIdeal para encontrar episodios completos o películas."})
    _add_fav_cm(li, "Vídeos Largos (+20 min)", "search", "execute_adv_search", {"mode": "long"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="long"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda de Vídeos Cortos (-10 min)")
    li.setArt({'icon': _ico('srch_corto.png', 'DefaultVideo.png')})
    li.setInfo('video', {'plot': "Filtra los resultados para mostrar solo vídeos de menos de 10 minutos.\nIdeal para buscar clips, canciones o sketches."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="short"), listitem=li, isFolder=True)

    # === FILTROS TEMPORALES ===
    li = xbmcgui.ListItem(label="[B]— FILTROS TEMPORALES —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Contenido de Hoy (Últimas 24h)")
    li.setArt({'icon': _ico('srch_hoy.png', 'DefaultFolder.png')})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en las últimas 24 horas.\nPerfecto para informativos y programas diarios."})
    _add_fav_cm(li, "Contenido de Hoy (24h)", "search", "execute_adv_search", {"mode": "recent_24h"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_24h"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Contenido de Esta Semana")
    li.setArt({'icon': _ico('srch_semana.png', 'DefaultFolder.png')})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en los últimos 7 días."})
    _add_fav_cm(li, "Contenido de esta Semana", "search", "execute_adv_search", {"mode": "recent_week"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_week"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Contenido de Este Mes")
    li.setArt({'icon': _ico('srch_mes.png', 'DefaultFolder.png')})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en los últimos 30 días."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_month"), listitem=li, isFolder=True)

    # === FILTROS DE CALIDAD E IDIOMA ===
    li = xbmcgui.ListItem(label="[B]— CALIDAD E IDIOMA —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Solo HD (Alta Definición)")
    li.setArt({'icon': _ico('srch_hd.png', 'DefaultVideo.png')})
    li.setInfo('video', {'plot': "Filtra para mostrar únicamente vídeos en HD (720p o superior)."})
    _add_fav_cm(li, "Solo HD", "search", "execute_adv_search", {"mode": "hd"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="hd"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Solo Contenido en Español")
    li.setArt({'icon': _ico('srch_espanol.png', 'DefaultFolder.png')})
    li.setInfo('video', {'plot': "Filtra para mostrar solo vídeos con idioma español configurado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="spanish"), listitem=li, isFolder=True)

    # === FILTROS AVANZADOS ===
    li = xbmcgui.ListItem(label="[B]— FILTROS AVANZADOS —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda por Usuario / Canal")
    li.setArt({'icon': _ico('srch_usuario.png', 'DefaultFolder.png')})
    li.setInfo('video', {'plot': "Busca contenido subido ÚNICAMENTE por un usuario específico (ej: 'rtve', 'atresplayer').\n\nPuedes filtrar por texto dentro del canal."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="user"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Búsqueda Inversa (Excluir palabras)")
    li.setArt({'icon': _ico('srch_inversa.png', 'DefaultIconError.png')})
    li.setInfo('video', {'plot': "Busca X pero EXCLUYENDO resultados que contengan ciertas palabras.\nÚtil para evitar 'trailer', 'making of', 'clip', etc."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="exclude"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Búsqueda Exacta (Sin limpieza)")
    li.setArt({'icon': _ico('srch_exacta.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Busca EXACTAMENTE lo que escribas, sin intentar limpiar el título ni quitar paréntesis."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="exact"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Búsqueda por Palabras Clave")
    li.setArt({'icon': _ico('srch_keywords.png', 'DefaultAddonWebSkin.png')})
    li.setInfo('video', {'plot': "Extrae solo las palabras importantes (más de 3 letras) y busca por ellas. Útil si el título oficial es muy largo o complejo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="keywords"), listitem=li, isFolder=True)

    # === UTILIDADES ===
    li = xbmcgui.ListItem(label="[B]— UTILIDADES —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Repetir Última Búsqueda (con filtros)")
    li.setArt({'icon': _ico('srch_repetir.png', 'DefaultAddonRepository.png')})
    li.setInfo('video', {'plot': "Toma la última búsqueda de tu historial y te permite ejecutarla con cualquiera de los filtros anteriores."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="repeat_last"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Búsqueda Múltiple (varios términos)")
    li.setArt({'icon': _ico('srch_multiple.png', 'DefaultAddonWebSkin.png')})
    li.setInfo('video', {'plot': "Busca varios términos separados por comas en Dailymotion.\nEjemplo: 'saber y ganar, pasapalabra, el hormiguero'"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="multi_search"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _execute_adv_search(mode):
    ep = None
    exclude_words = None
    q = ""

    if mode == "user":
        kb = xbmc.Keyboard('', 'Introduce el ID de Usuario/Canal')
        kb.doModal()
        if not kb.isConfirmed(): return
        user = kb.getText()
        if not user: return
        ep = {"owner": user}

        kb = xbmc.Keyboard('', 'Buscar en canal de {0} (Opcional, vacío = últimos vídeos)'.format(user))
        kb.doModal()
        if kb.isConfirmed():
            q = kb.getText()
        if q: _sh.add(q)
        _lfd(q if q else " ", "", mode=mode, extra_params=ep, nh=True)
        return

    if mode == "series":
        kb = xbmc.Keyboard('', 'Nombre de la Serie')
        kb.doModal()
        if not kb.isConfirmed(): return
        series_name = kb.getText()
        if not series_name: return

        kb = xbmc.Keyboard('', 'Número de Temporada (vacío = cualquiera)')
        kb.doModal()
        if not kb.isConfirmed(): return
        season = kb.getText()

        kb = xbmc.Keyboard('', 'Número de Capítulo (vacío = cualquiera)')
        kb.doModal()
        if not kb.isConfirmed(): return
        episode = kb.getText()

        q = series_name
        if season:
            q += " T{0}".format(season)
        if episode:
            q += " Capitulo {0}".format(episode)

        _sh.add(q)
        _lfd(q, "", mode="", extra_params=None, nh=True)
        return

    if mode == "exclude":
        kb = xbmc.Keyboard('', '¿Qué quieres buscar?')
        kb.doModal()
        if not kb.isConfirmed(): return
        q = kb.getText()
        if not q: return

        kb = xbmc.Keyboard('trailer, clip, making of', 'Palabras a EXCLUIR (separadas por coma)')
        kb.doModal()
        if not kb.isConfirmed(): return
        exclude_text = kb.getText()
        if exclude_text:
            exclude_words = [w.strip().lower() for w in exclude_text.split(",") if w.strip()]

        _sh.add(q)
        _lfd_with_exclusions(q, "", exclude_words)
        return

    if mode == "repeat_last":
        h = _sh.load()
        if not h:
            xbmcgui.Dialog().notification("EspaTV", "No hay historial", xbmcgui.NOTIFICATION_WARNING)
            return

        filters = [
            ("Sin filtros (Estándar)", "", None),
            ("Modo Cine (Películas)", "movie", None),
            ("Solo +20 min", "", {"longer_than": 20}),
            ("Solo -10 min", "", {"shorter_than": 10}),
            ("Solo HD", "", {"hd": 1}),
            ("Solo Español", "", {"language": "es"}),
            ("Últimas 24h", "", {"created_after": int(time.time()) - 86400}),
            ("Última Semana", "", {"created_after": int(time.time()) - 604800}),
        ]

        opts = [f[0] for f in filters]
        sel = xbmcgui.Dialog().select("Repetir: '{0}' con filtro...".format(h[0]), opts)
        if sel < 0: return

        chosen_mode, chosen_ep = filters[sel][1], filters[sel][2]
        _lfd(h[0], "", mode=chosen_mode, extra_params=chosen_ep, nh=True)
        return

    sel = core_settings.get_search_input_sel("¿Cómo introduces la búsqueda?")
    if sel < 0:
        return
    if sel == 1:
        import url_remote
        q = url_remote.receive_text("Búsqueda Avanzada")
        if not q:
            return
    else:
        kb = xbmc.Keyboard('', 'Búsqueda Avanzada')
        kb.doModal()
        if not kb.isConfirmed(): return
        q = kb.getText()
        if not q: return

    _sh.add(q)

    if mode == "long":
        ep = {"longer_than": 20}
    elif mode == "short":
        ep = {"shorter_than": 10}
    elif mode == "recent_24h":
        ep = {"created_after": int(time.time()) - 86400, "sort": "recent"}
    elif mode == "recent_week":
        ep = {"created_after": int(time.time()) - 604800, "sort": "recent"}
    elif mode == "recent_month":
        ep = {"created_after": int(time.time()) - 2592000, "sort": "recent"}
    elif mode == "hd":
        ep = {"hd": 1}
    elif mode == "spanish":
        ep = {"language": "es"}

    ep = {} if ep is None else ep
    _lfd(q, "", mode=mode, extra_params=ep, nh=True)

def _lfd_with_exclusions(q, ot, exclude_words):
    cq = _clean_title(q)
    rs = _sr(cq)
    if not rs and cq != q: rs = _sr(q)
    
    if not rs:
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron resultados", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    # Filtrar resultados que contienen palabras excluidas
    if exclude_words:
        filtered = []
        for r in rs:
            title_lower = r.get("title", "").lower()
            if not any(ex in title_lower for ex in exclude_words):
                filtered.append(r)
        rs = filtered
    
    if not rs:
        xbmcgui.Dialog().notification("EspaTV", "Todos los resultados fueron excluidos", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    sr = _gsr(cq, rs, "")[:25]
    
    if not sr:
        xbmcgui.Dialog().notification("EspaTV", "Sin coincidencias relevantes", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    min_dur = core_settings.get_min_duration() * 60
    for sc, v in sr:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        
        if min_dur > 0 and du < min_dur: continue
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ot
        
        lb = f"{vt} ({int(sc*100)}% match)"

        li = xbmcgui.ListItem(label=lb); li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Subido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        cm = []
        cm.append(("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"))
        cm.append(("Abrir en navegador", f"RunPlugin({_u(action='dm_open_browser', url=vi)})"))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vi)))))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))





_TDT_JSON_URL = "https://www.tdtchannels.com/lists/tv.json"
_TDT_M3U_URL = "https://www.tdtchannels.com/lists/tv.m3u8"
_CUSTOM_IPTV_FILE = "custom_iptv.json"
_tdt_json_cache = {"data": None}

def _load_custom_iptv():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    fp = os.path.join(p, _CUSTOM_IPTV_FILE)
    if not os.path.exists(fp):
        return []
    try:
        with open(fp, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _save_custom_iptv(lists):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    fp = os.path.join(p, _CUSTOM_IPTV_FILE)
    try:
        with open(fp, 'w', encoding='utf-8') as f:
            json.dump(lists, f, ensure_ascii=False)
    except OSError:
        pass

def _parse_m3u_content(text):
    if '#EXTINF:' not in text:
        return []
    lines = text.splitlines()
    channels = []
    cur_name, cur_logo, cur_group = "", "", ""
    cur_ua, cur_ref = "", ""
    cur_tvg_id = ""
    for line in lines:
        line = line.strip()
        if line.startswith("#EXTINF:"):
            cur_name = line.split(",", 1)[-1].strip() if "," in line else "Canal"
            m = re.search(r'tvg-logo="([^"]*)"', line)
            cur_logo = m.group(1) if m else ""
            m_id = re.search(r'tvg-id="([^"]*)"', line)
            cur_tvg_id = m_id.group(1) if m_id else ""
            m2 = re.search(r'group-title="([^"]*)"', line)
            cur_group = m2.group(1) if m2 else ""
        elif line.upper().startswith("#EXTVLCOPT:HTTP-USER-AGENT="):
            cur_ua = line.split("=", 1)[1].strip()
        elif line.upper().startswith("#EXTVLCOPT:HTTP-REFERRER="):
            cur_ref = line.split("=", 1)[1].strip()
        elif line.upper().startswith("#EXTVLCOPT:HTTP-REFERER="):
            cur_ref = line.split("=", 1)[1].strip()
        elif line and not line.startswith("#"):
            entry = {"name": cur_name or "Canal", "url": line, "logo": cur_logo, "group": cur_group}
            if cur_tvg_id: entry["tvg_id"] = cur_tvg_id
            if cur_ua: entry["ua"] = cur_ua
            if cur_ref: entry["ref"] = cur_ref
            channels.append(entry)
            cur_name, cur_logo, cur_group = "", "", ""
            cur_ua, cur_ref = "", ""
            cur_tvg_id = ""
    return channels

_ACE_HEX = frozenset("0123456789abcdef")

def _render_m3u_channels(channels):
    h = int(sys.argv[1])
    xbmcplugin.setContent(h, 'videos')
    epg = _epg.fetch() if any(ch.get("tvg_id") for ch in channels) else {}
    for ch in channels:
        label = ch["name"]
        tvg_id = ch.get("tvg_id", "")
        epg_info = epg.get(tvg_id) if tvg_id else None
        if epg_info and epg_info.get("title"):
            epg_label = epg_info["title"]
            t1 = _epg.format_time(epg_info.get("start", ""))
            t2 = _epg.format_time(epg_info.get("stop", ""))
            time_str = "  ({0}-{1})".format(t1, t2) if t1 and t2 else ""
            label += "  [COLOR skyblue]Ahora: {0}{1}[/COLOR]".format(epg_label, time_str)
        if ch["group"]:
            label = "[COLOR gray][{0}][/COLOR] {1}".format(ch["group"], label)
        li = xbmcgui.ListItem(label=label)
        thumb = ch["logo"] or "DefaultAddonPVRClient.png"
        li.setArt({'icon': thumb, 'thumb': thumb})
        plot = "Canal: {0}".format(ch["name"])
        if epg_info and epg_info.get("title"):
            plot += "\n\nAhora: {0}".format(epg_info["title"])
            if epg_info.get("desc"): plot += "\n{0}".format(epg_info["desc"])
        if ch["group"]: plot += "\nGrupo: {0}".format(ch["group"])
        li.setInfo('video', {'title': ch["name"], 'plot': plot})
        li.setProperty("IsPlayable", "true")
        ch_url = ch["url"].strip()
        is_ace = False
        is_p2p = False
        infohash = ""
        lower_url = ch_url.lower()
        if lower_url.startswith("acestream://"):
            possible_hash = ch_url[12:].split("|")[0].split("?")[0].strip().lower()
            if len(possible_hash) == 40 and all(c in _ACE_HEX for c in possible_hash):
                is_ace = True
                infohash = possible_hash
        elif len(ch_url) == 40 and all(c in _ACE_HEX for c in lower_url):
            is_ace = True
            infohash = lower_url
        elif "ace/getstream" in lower_url and "id=" in lower_url:
            parsed = urllib.parse.urlparse(ch_url)
            qs = urllib.parse.parse_qs(parsed.query)
            if "id" in qs:
                possible_hash = qs["id"][0].strip().lower()
                if len(possible_hash) == 40 and all(c in _ACE_HEX for c in possible_hash):
                    is_ace = True
                    infohash = possible_hash
        elif lower_url.startswith("magnet:") or ".torrent" in lower_url:
            is_p2p = True

        if is_ace:
            _add_fav_cm(li, ch["name"], "acestream", "play_ace_result", {"infohash": infohash, "name": ch["name"]})
            play_args = {"action": "play_ace_result", "infohash": infohash, "name": ch["name"]}
        elif is_p2p:
            play_args = {"action": "play_p2p", "url": ch_url, "name": ch["name"]}
        else:
            cm = [
                ("Añadir a Favoritos", "RunPlugin({0})".format(
                    _u(action="add_favorite", title=ch["name"], fav_url=ch["url"], icon=thumb, platform="tdt", fav_action="play_tdt", params=json.dumps({}))
                )),
                ("[COLOR red]Grabar este canal[/COLOR]", "RunPlugin({0})".format(
                    _u(action="record_stream", url=ch["url"], name=ch["name"])
                ))
            ]
            li.addContextMenuItems(cm)
            play_args = {"action": "play_tdt", "url": ch["url"], "title": ch["name"]}
            if ch.get("ua"): play_args["ua"] = ch["ua"]
            if ch.get("ref"): play_args["ref"] = ch["ref"]
        xbmcplugin.addDirectoryItem(handle=h, url=_u(**play_args), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.is_iptv_cache_active())

def _open_atresdaily():
    try:
        xbmcaddon.Addon("plugin.video.atresdaily")
        xbmc.executebuiltin("RunAddon(plugin.video.atresdaily)")
        return
    except RuntimeError:
        pass
    choice = xbmcgui.Dialog().yesno("EspaTV",
        "AtresDaily no está instalado.\n\n"
        "Es un addon especializado centrado en Atresplayer.\n"
        "Disponible en:\nhttps://github.com/fullstackcurso\n\n"
        "¿Ver instrucciones de instalación?")
    if choice:
        xbmcgui.Dialog().textviewer("Instalar AtresDaily",
            "[B]Cómo instalar AtresDaily[/B]\n\n"
            "1. Descarga el ZIP desde:\n"
            "   [B]https://github.com/fullstackcurso[/B]\n\n"
            "2. En Kodi, ve a:\n"
            "   [B]Addons → Instalar desde ZIP[/B]\n\n"
            "3. Selecciona el archivo ZIP descargado\n\n"
            "4. Vuelve al Catálogo de EspaTV y pulsa AtresDaily")

def _search_acestream_prompt():
    sel = core_settings.get_search_input_sel("¿Cómo introduces la búsqueda?")
    if sel < 0:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    if sel == 1:
        import url_remote
        query = url_remote.receive_text("Buscar en AceStream")
        if not query:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            return
    else:
        kb = xbmc.Keyboard('', 'Buscar en AceStream')
        kb.doModal()
        query = kb.getText().strip()
        if not kb.isConfirmed() or not query:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            return
    _search_acestream_results(query)


def _search_acestream_results(query):
    h = int(sys.argv[1])
    if not query:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    encoded_q = urllib.parse.quote_plus(query)
    api_urls = [
        ("motor local", "http://127.0.0.1:6878/server/api?method=search&query={0}&page=0".format(encoded_q)),
        ("servidor publico", "https://search.acestream.net/?method=search&api_key=test_api_key&api_version=1&query={0}&page=0".format(encoded_q)),
    ]

    progress = xbmcgui.DialogProgressBG()
    try:
        progress.create("AceStream", "Buscando: {0}".format(query))
    except RuntimeError:
        progress = None

    data = None
    last_error = None
    used_endpoint = ""

    from urllib.request import urlopen as _urlopen, Request as _Request
    for label, api_url in api_urls:
        try:
            xbmc.log("[espatv] AceStream search via {0}: {1}".format(label, api_url), xbmc.LOGINFO)
            req = _Request(api_url, headers={"User-Agent": "Mozilla/5.0 (Kodi)"})
            resp = _urlopen(req, timeout=10)
            raw = resp.read().decode("utf-8", errors="replace")
            xbmc.log("[espatv] AceStream {0} response ({1} chars): {2}".format(label, len(raw), raw[:300]), xbmc.LOGINFO)
            try:
                parsed = json.loads(raw)
            except Exception as je:
                last_error = "Respuesta no es JSON ({0}): {1}".format(label, str(je))
                continue
            if isinstance(parsed, dict) and parsed.get("error"):
                last_error = "{0}: {1}".format(label, parsed.get("error"))
                continue
            data = parsed
            used_endpoint = label
            break
        except Exception as e:
            last_error = "{0}: {1}".format(label, str(e))
            xbmc.log("[espatv] AceStream {0} failed: {1}".format(label, e), xbmc.LOGWARNING)
            continue

    if progress:
        try:
            progress.close()
        except RuntimeError:
            pass

    if data is None:
        xbmcgui.Dialog().ok("Buscar en AceStream",
            "No se pudo realizar la busqueda.\n\n"
            "Detalle: {0}\n\n"
            "[COLOR yellow]Si el error persiste, puede que tu operador bloquee AceStream. Prueba con una VPN.[/COLOR]".format(last_error or "error desconocido"))
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    results = []
    if isinstance(data, list):
        results = data
    elif isinstance(data, dict):
        result_obj = data.get("result") or {}
        if "results" in result_obj:
            results = result_obj["results"]
        else:
            results = data.get("results") or []
    if not isinstance(results, list):
        results = []

    xbmc.log("[espatv] AceStream search returned {0} results from {1}".format(len(results), used_endpoint), xbmc.LOGINFO)

    if not results:
        xbmcgui.Dialog().ok("AceStream", "Sin resultados para: {0}".format(query))
        xbmcplugin.endOfDirectory(h, succeeded=True)
        return

    xbmcplugin.setPluginCategory(h, "AceStream: {0}".format(query))
    xbmcplugin.setContent(h, "videos")

    _HEX = frozenset("0123456789abcdef")
    items_added = 0
    for item in results:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or item.get("title") or "Sin nombre")
        infohash = str(item.get("infohash") or item.get("id") or "").lower().strip()
        if infohash.startswith("acestream://"):
            infohash = infohash[len("acestream://"):]
        if len(infohash) != 40 or not all(c in _HEX for c in infohash):
            continue

        categories = item.get("categories") or []
        if not isinstance(categories, list):
            categories = [categories] if categories else []
        categories = [str(c) for c in categories if c]

        availability = item.get("availability") or 0
        try:
            availability = float(availability)
            if availability > 1:
                availability = availability / 100
        except (TypeError, ValueError):
            availability = 0

        plot_lines = []
        if categories:
            plot_lines.append("Categoria: {0}".format(", ".join(categories)))
        desc = str(item.get("description") or "").strip()
        if desc:
            plot_lines.append(desc)
        if availability > 0:
            plot_lines.append("Disponibilidad: {0:.0f}%".format(availability * 100))
        plot = "\n".join(plot_lines) if plot_lines else name

        li = xbmcgui.ListItem(label=name)
        li.setInfo("video", {"title": name, "plot": plot})
        li.setArt({"icon": "DefaultAddonTvInfo.png"})
        li.setProperty("IsPlayable", "true")
        _add_fav_cm(li, name, "acestream", "play_ace_result", {"infohash": infohash, "name": name})
        play_url = _u(action="play_ace_result", infohash=infohash, name=name)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)
        items_added += 1

    if not items_added:
        xbmcgui.Dialog().ok("AceStream", "Sin resultados válidos para: {0}".format(query))
        xbmcplugin.endOfDirectory(h, succeeded=True)
        return

    xbmcplugin.endOfDirectory(h)


def _ace_engine_alive(timeout=1):
    """True si el motor AceStream responde en 127.0.0.1:6878. Si nada escucha, falla por refused o por timeout corto (depende del firewall)."""
    try:
        with socket.create_connection(("127.0.0.1", 6878), timeout=timeout):
            return True
    except OSError:
        return False


def _play_ace_result(infohash, name):
    h = int(sys.argv[1])
    xbmc.log("[espatv] _play_ace_result called: infohash={0} name={1}".format(infohash, name), xbmc.LOGINFO)
    if not infohash:
        xbmc.log("[espatv] _play_ace_result aborted: empty infohash", xbmc.LOGWARNING)
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    infohash = infohash.lower().strip()
    if infohash.startswith("acestream://"):
        infohash = infohash[len("acestream://"):]
    _HEX = frozenset("0123456789abcdef")
    if len(infohash) != 40 or not all(c in _HEX for c in infohash):
        xbmc.log("[espatv] _play_ace_result: infohash invalido: {0}".format(infohash), xbmc.LOGWARNING)
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("EspaTV", "Hash AceStream inválido", xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    def _addon_active(addon_id):
        try:
            xbmcaddon.Addon(addon_id)
            return True
        except RuntimeError:
            return False
    has_horus = _addon_active('script.module.horus')
    has_plexus = _addon_active('program.plexus')
    if has_horus:
        target = "plugin://script.module.horus/?" + urllib.parse.urlencode({"action": "play", "id": infohash})
    elif has_plexus:
        target = "plugin://program.plexus/?" + urllib.parse.urlencode({"url": "acestream://" + infohash, "mode": "1", "name": name or "AceStream"})
    elif not _ace_engine_alive():
        # Sin player y sin motor escuchando: cortamos aquí (si no, Kodi se cuelga 30s en el timeout del curl).
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok(
            "AceStream",
            "No se detectó el motor AceStream en este equipo (127.0.0.1:6878).\n\n"
            "Arranca el motor AceStream, o instala Horus (script.module.horus) "
            "o Plexus (program.plexus).",
        )
        return
    target = "http://127.0.0.1:6878/ace/getstream?id={0}".format(infohash)
    try:
        _wh.add("acestream://" + infohash, name or infohash[:12])
    except Exception as e:
        xbmc.log("[espatv] _play_ace_result: _wh.add failed: {0}".format(e), xbmc.LOGERROR)
    _ace_save_history(infohash, name)
    li = xbmcgui.ListItem(path=target)
    li.setProperty("IsPlayable", "true")
    if not (has_horus or has_plexus):
        # Stream MPEG-TS directo del motor: evita el probe HEAD de Kodi (sesión por cliente en el engine).
        li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(h, True, li)


def _play_p2p(url, name):
    """Reproduce un enlace magnet o .torrent delegando en Elementum."""
    h = int(sys.argv[1])
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok(
            "EspaTV",
            "Este enlace P2P (magnet/torrent) necesita Elementum.\n\n"
            "Instala el addon Elementum (plugin.video.elementum) para reproducirlo."
        )
        return
    target = "plugin://plugin.video.elementum/play?" + urllib.parse.urlencode({"uri": url})
    li = xbmcgui.ListItem(path=target)
    if name:
        li.setInfo('video', {'title': name})
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(h, True, li)


def _ace_history_path():
    return os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), 'acestream_history.json')


def _ace_save_history(infohash, name):
    path = _ace_history_path()
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, list):
            data = []
    except (OSError, ValueError):
        data = []
    data = [e for e in data if isinstance(e, dict) and e.get('infohash') != infohash]
    data.insert(0, {'infohash': infohash, 'name': name or infohash[:12], 'ts': int(time.time())})
    data = data[:50]
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
    except OSError as exc:
        xbmc.log("[espatv] acestream history write: {0}".format(exc), xbmc.LOGERROR)


def _acestream_show_history():
    h = int(sys.argv[1])
    path = _ace_history_path()
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, list):
            data = []
    except (OSError, ValueError):
        data = []

    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    xbmcplugin.setPluginCategory(h, "Historial AceStream")
    xbmcplugin.setContent(h, "videos")

    if not data:
        li = xbmcgui.ListItem(label="[I]El historial está vacío[/I]")
        li.setArt({"icon": _ico('info.png', "DefaultIconInfo.png")})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, succeeded=True)
        return

    _HEX = frozenset("0123456789abcdef")
    for entry in data:
        if not isinstance(entry, dict):
            continue
        infohash = entry.get('infohash', '')
        if len(infohash) != 40 or not all(c in _HEX for c in infohash):
            continue
        name = entry.get('name') or infohash[:12]
        li = xbmcgui.ListItem(label=name)
        li.setInfo("video", {"title": name, "plot": "Hash: {0}".format(infohash)})
        li.setArt({"icon": _ico('directo.png', "DefaultAddonTvInfo.png")})
        li.setProperty("IsPlayable", "true")
        cm = [("Eliminar del historial", "RunPlugin({0})".format(_u(action="acestream_history_delete", infohash=infohash)))]
        _add_fav_cm(li, name, "acestream", "play_ace_result", {"infohash": infohash, "name": name}, extra_items=cm)
        play_url = _u(action="play_ace_result", infohash=infohash, name=name)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR red]Borrar todo el historial[/COLOR]")
    li.setArt({"icon": _ico('adv_borrar.png', "DefaultAddonNone.png")})
    li.setInfo("video", {"plot": "Elimina todas las entradas del historial de AceStream."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acestream_history_clear"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _acestream_history_delete(infohash):
    if not infohash:
        return
    path = _ace_history_path()
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, list):
            data = []
    except (OSError, ValueError):
        return
    before = len(data)
    data = [e for e in data if isinstance(e, dict) and e.get('infohash') != infohash]
    if len(data) < before:
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)
            xbmcgui.Dialog().notification("EspaTV", "Eliminado del historial", xbmcgui.NOTIFICATION_INFO, 2000)
        except OSError as exc:
            xbmc.log("[espatv] acestream history delete: {0}".format(exc), xbmc.LOGERROR)
            xbmcgui.Dialog().notification("EspaTV", "Error al borrar del historial", xbmcgui.NOTIFICATION_ERROR, 3000)


def _acestream_history_clear():
    if not xbmcgui.Dialog().yesno("AceStream", "¿Borrar todo el historial de AceStream?"):
        return
    path = _ace_history_path()
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump([], f)
        xbmcgui.Dialog().notification("EspaTV", "Historial de AceStream borrado", xbmcgui.NOTIFICATION_INFO, 2000)
    except OSError as exc:
        xbmc.log("[espatv] acestream history clear: {0}".format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("EspaTV", "Error al borrar el historial", xbmcgui.NOTIFICATION_ERROR, 3000)


def live_tv_menu():
    h = int(sys.argv[1])

    li = xbmcgui.ListItem(label="[B]TDT Canales España[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Lista completa de canales TDT españoles.\nIncluye nacionales, autonómicos, temáticos y más."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tdt_channels_json"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]TDT Canales España (M3U)[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Lista M3U alternativa."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tdt_channels"), listitem=li, isFolder=True)


    li = xbmcgui.ListItem(label="[B][COLOR lightcyan]Programación TV (EPG en texto)[/COLOR][/B]")
    _mp_epg = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'cat_epg_texto.png')
    li.setArt({'icon': _mp_epg if os.path.isfile(_mp_epg) else 'DefaultIconInfo.png'})
    li.setInfo('video', {'plot': "Parrilla de programación de los canales TDT en formato texto."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="epg_texto_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B][COLOR skyblue]Radio en Directo[/COLOR][/B]")
    li.setArt({'icon': 'DefaultMusicSongs.png'})
    li.setInfo('video', {'plot': "Emisoras de radio españolas en directo.\nPopulares, musicales, deportivas, autonómicas y más."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="radio_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B][COLOR red]RTVE Play[/COLOR][/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales de RTVE en directo (La 1, La 2, 24h, Teledeporte, Clan).\nCatálogo de programas, series y documentales de RTVE Play."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="rtve_menu"), listitem=li, isFolder=True)
    
    _addon = xbmcaddon.Addon()
    li = xbmcgui.ListItem(label="[B][COLOR gold]Mis Grabaciones[/COLOR][/B]")
    _ico = os.path.join(_addon.getAddonInfo('path'), 'resources', 'media', 'mis_grabaciones.png')
    li.setArt({'icon': _ico if os.path.isfile(_ico) else 'DefaultVideo.png'})
    li.setInfo('video', {'plot': "Archivo de grabaciones de TV en directo.\nProgramas descargados localmente."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="my_recordings_menu"), listitem=li, isFolder=True)

    # --- Listas IPTV gratuitas y legales ---
    li = xbmcgui.ListItem(label="[B]España — IPTV Abierta[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Directorio comunitario con 300+ canales españoles verificados.\nIncluye nacionales, autonómicos, temáticos, deportes, música y más."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://iptv-org.github.io/iptv/countries/es.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B][COLOR white]TV Autonómicas en Directo[/COLOR][/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Señal en directo de las principales televisiones autonómicas españolas.\nTV3, ETB, TVG, Canal Sur, Aragón TV, À Punt, TPA, TV Canaria, IB3 y más."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tv_autonomicas_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Cine y Películas FAST[/B]")
    li.setArt({'icon': 'DefaultMovies.png'})
    li.setInfo('video', {'plot': "Canales FAST gratuitos de cine y películas.\nIncluye Rakuten TV, Pluto TV, Atrescine, Cine Western y más.\nContenido con publicidad."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://iptv-org.github.io/iptv/categories/movies.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Canales Internacionales en Español[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales internacionales disponibles en España.\nFrance 24, DW, euronews, RT y más en español."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://iptv-org.github.io/iptv/languages/spa.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Free-TV IPTV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Lista IPTV gratuita con canales de todo el mundo.\nIncluye canales en abierto verificados."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="freetv_menu"), listitem=li, isFolder=True)

    # --- Pluto TV y Samsung TV Plus (SlyGuy) ---
    li = xbmcgui.ListItem(label="[B]Pluto TV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "TV gratuita con canales temáticos (cine, series, noticias...).\nRequiere addon SlyGuy (se instala automáticamente)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="slyguy_install", addon_id="slyguy.pluto.tv.provider", title="Pluto TV"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]Samsung TV Plus[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales de TV gratuitos de Samsung.\nRequiere addon SlyGuy (se instala automáticamente)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="slyguy_install", addon_id="slyguy.samsung.tv.plus", title="Samsung TV Plus"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]Roku Channel[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales de TV gratuitos de Roku.\nPelículas, series y TV en vivo sin suscripción.\nRequiere addon SlyGuy (se instala automáticamente)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="slyguy_install", addon_id="slyguy.roku", title="Roku Channel"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]Plex Live TV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Decenas de canales lineales gratuitos de cine, noticias y entretenimiento.\nRequiere el módulo de SlyGuy (se instala automáticamente)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="slyguy_install", addon_id="slyguy.plex.live", title="Plex Live TV"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]Rakuten TV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Más de 90 canales gratuitos con películas, series y documentales (FAST)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://raw.githubusercontent.com/iptv-org/iptv/master/streams/es_rakuten.m3u"), listitem=li, isFolder=True)

    import pvr_manager
    if pvr_manager.is_pvr_installed():
        li_p = xbmcgui.ListItem(label="[B]Abrir Guía de Televisión Nativa (PVR)[/B]")
        li_p.setArt({'icon': 'DefaultAddonPVRClient.png'})
        li_p.setInfo('video', {'plot': "Salta instantáneamente a la sección 'TV' de Kodi para ver la parrilla de horarios interactiva de TDT."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="open_pvr"), listitem=li_p, isFolder=False)

    # --- Listas IPTV ---
    custom_lists = _load_custom_iptv()
    for lst in custom_lists:
        name = lst.get("name", "Lista")
        url = lst.get("url", "")
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(name))
        li.setArt({'icon': 'DefaultAddonPVRClient.png'})
        li.setInfo('video', {'plot': "Lista personalizada\nURL: {0}".format(url)})
        cm = [("Eliminar esta lista", "RunPlugin({0})".format(_u(action="delete_custom_iptv", url=url)))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url=url), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Añadir[/B]")
    li.setArt({'icon': 'DefaultAddSource.png'})
    li.setInfo('video', {'plot': "Pega la URL de una lista M3U/M3U8 o de cualquier página web (foro, canal de Telegram, web de canales...) para escanear sus enlaces de streaming, AceStream, HLS, magnets e iframes. También puedes subir un archivo .m3u/.m3u8/.txt desde el dispositivo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="add_custom_iptv"), listitem=li, isFolder=False)
    
    xbmcplugin.endOfDirectory(h)

def tdt_channels_json():
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Canales TDT", "Descargando lista actualizada...")
    try:
        dp.update(30, "Conectando...")
        content = _cached_http_get(_TDT_JSON_URL, timeout=15)
        dp.update(70, "Procesando canales...")
        data = json.loads(content)
        dp.close()
        countries = data.get("countries", [])
        if not countries:
            xbmcgui.Dialog().ok("TDT Canales", "No se encontraron datos.")
            xbmcplugin.endOfDirectory(h); return
        _tdt_json_cache["data"] = countries[0].get("ambits", [])
        
        # Boton PVR rapido
        import pvr_manager
        if pvr_manager.is_pvr_installed():
            li_pvr = xbmcgui.ListItem(label="Abrir la Parrilla Completa (PVR)")
            li_pvr.setArt({'icon': 'DefaultAddonPVRClient.png'})
            li_pvr.setInfo('video', {'plot': "Salta automáticamente a la cuadrícula de televisión de Kodi."})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="open_pvr"), listitem=li_pvr, isFolder=False)
        else:
            li_pvr = xbmcgui.ListItem(label="Ver en Parrilla Nativa Completa (PVR)")
            li_pvr.setArt({'icon': 'DefaultAddonPVRClient.png'})
            li_pvr.setInfo('video', {'plot': "Auto-configura Kodi para mostrar estos canales en una cuadrícula horaria visual."})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="setup_pvr"), listitem=li_pvr, isFolder=False)

        for ambit in _tdt_json_cache["data"]:
            name = ambit.get("name", "Sin nombre")
            num = len(ambit.get("channels", []))
            li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(name, num))
            li.setArt({'icon': 'DefaultAddonPVRClient.png'})
            li.setInfo('video', {'plot': "Categoría: {0}\nCanales: {1}".format(name, num)})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tdt_json_ambit", url=name), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
    except (requests.RequestException, ValueError, RuntimeError, KeyError) as e:
        dp.close()
        _log_error("Error TDT JSON: {0}".format(e))
        xbmcgui.Dialog().ok("TDT Canales", "No se pudo cargar:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h)
        except RuntimeError:
            pass

def tdt_json_ambit(ambit_name):
    h = int(sys.argv[1])
    ambits = _tdt_json_cache.get("data")
    if not ambits:
        try:
            content = _cached_http_get(_TDT_JSON_URL, timeout=15)
            data = json.loads(content)
            countries = data.get("countries", [])
            if countries:
                ambits = countries[0].get("ambits", [])
                _tdt_json_cache["data"] = ambits
        except (requests.RequestException, ValueError, RuntimeError):
            xbmcgui.Dialog().ok("TDT Canales", "No se pudo cargar la lista.")
            xbmcplugin.endOfDirectory(h); return
    if not ambits:
        xbmcplugin.endOfDirectory(h); return
    target = None
    for a in ambits:
        if a.get("name") == ambit_name:
            target = a; break
    if not target:
        xbmcplugin.endOfDirectory(h); return
    channels = []
    for ch in target.get("channels", []):
        name = ch.get("name", "Canal")
        opts = ch.get("options", [])
        logo = ch.get("logo", "")
        for opt in opts:
            fmt = opt.get("format", "")
            url = opt.get("url", "")
            if url and fmt.lower() in ("m3u8", "mp4", ""):
                channels.append({"name": name, "url": url, "logo": logo, "group": ambit_name})
                break
    if channels:
        _render_m3u_channels(channels)
    else:
        xbmcgui.Dialog().ok("TDT Canales", "No se encontraron streams para {0}.".format(ambit_name))
        xbmcplugin.endOfDirectory(h)

def tdt_channels():
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Canales TDT", "Descargando lista M3U...")
    try:
        dp.update(30, "Conectando...")
        content = _cached_http_get(_TDT_M3U_URL, timeout=15)
        dp.update(70, "Procesando canales...")
        channels = _parse_m3u_content(content)
        dp.close()
        if not channels:
            xbmcgui.Dialog().ok("TDT Canales", "No se encontraron canales.")
            xbmcplugin.endOfDirectory(h); return
        _render_m3u_channels(channels)
    except (requests.RequestException, RuntimeError, OSError) as e:
        dp.close()
        _log_error("Error TDT M3U: {0}".format(e))
        xbmcgui.Dialog().ok("TDT Canales", "No se pudo cargar:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h)
        except RuntimeError:
            pass

def play_tdt(url, title="", ua="", ref=""):
    h = int(sys.argv[1])
    try:
        play_url = url
        is_m3u8 = '.m3u8' in url.lower()

        use_ia = False
        if is_m3u8:
            import xbmcaddon
            if xbmcaddon.Addon().getSetting('use_inputstream') == 'true':
                try:
                    xbmcaddon.Addon('inputstream.adaptive')
                    use_ia = True
                except RuntimeError:
                    xbmc.log("[EspaTV] InputStream Adaptive activado en ajustes pero no instalado. Usando reproductor normal.", xbmc.LOGWARNING)

        # Modo Anti-Errores: inyectar UA de navegador si no hay uno propio
        import xbmcaddon as _xa
        anti_err = _xa.Addon().getSetting('iptv_anti_errors') == 'true'
        if anti_err and not ua:
            ua = UA_DESKTOP

        # Construir URL con headers en formato pipe si no se usa InputStream Adaptive
        # InputStream Adaptive NO soporta el formato pipe (|User-Agent=...)
        if (ua or ref) and not use_ia:
            parts = []
            if ua: parts.append("User-Agent={0}".format(requests.utils.quote(ua)))
            if ref: parts.append("Referer={0}".format(requests.utils.quote(ref)))
            play_url = "{0}|{1}".format(url, "&".join(parts))

        li = xbmcgui.ListItem(path=play_url)
        if title: li.setInfo('video', {'title': title})
        
        if is_m3u8:
            li.setMimeType('application/x-mpegURL')

        if use_ia:
            xbmc.log("[EspaTV] Reproduciendo {0} con InputStream Adaptive".format(title), xbmc.LOGINFO)
            # Kodi 19+ / Kodi 18
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstreamaddon', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            
            # Pasar headers a InputStream Adaptive por su via nativa
            hdr_parts = []
            if ua:
                hdr_parts.append("User-Agent={0}".format(ua))
            if ref: 
                hdr_parts.append("Referer={0}".format(ref))
            if hdr_parts:
                li.setProperty('inputstream.adaptive.stream_headers', "&".join(hdr_parts))

        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(h, True, li)
    except (RuntimeError, AttributeError, ValueError) as e:
        _log_error("Error TDT play: {0}".format(e))
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())


def _scan_web_for_channels(html_content, base_url):
    import html_scanner
    results = html_scanner.scan_page(base_url, timeout=15, html_content=html_content)

    channels = []
    seen_urls = set()

    for item in results:
        url = item.get("url", "")
        if not url or url in seen_urls:
            continue

        title = item.get("title", "")
        # El título de un acestream suelto en texto de Telegram llega como la URL cruda.
        # Detectamos por esquema (no por 'kind': el extractor de Telegram no lo marca).
        if url.lower().startswith("acestream://") and (not title or title.lower().startswith(("acestream", "http"))):
            title = "AceStream {0}".format(url[len("acestream://"):][:8])
        if not title:
            title = "Canal Detectado"

        seen_urls.add(url)
        channels.append({
            "name": title,
            "url": url,
            "logo": "",
            "group": ""
        })

    return channels


def _read_local_list_file(path):
    """Lee un archivo de lista local (M3U/M3U8/TXT). Devuelve el texto o None si falla o está vacío."""
    f = xbmcvfs.File(path)
    try:
        content = f.read()
    except OSError:
        return None
    finally:
        f.close()
    return content or None


def add_custom_iptv():
    sel = xbmcgui.Dialog().select("¿Cómo introduces la URL?", ["Teclado", "Desde móvil/PC", "Subir archivo"])
    if sel < 0:
        return

    if sel == 2:
        path = xbmcgui.Dialog().browse(1, "Selecciona la lista (M3U/M3U8/TXT)", "files", ".m3u|.m3u8|.txt")
        if not path:
            return
        content = _read_local_list_file(path)
        if content is None:
            xbmcgui.Dialog().ok("EspaTV", "No se pudo leer el archivo o está vacío."); return
        source = path
    else:
        if sel == 1:
            import url_remote
            url = url_remote.receive_text("URL de la lista o web a escanear")
            if not url:
                return
        else:
            kb = xbmc.Keyboard('', 'URL de la lista o web a escanear')
            kb.doModal()
            if not kb.isConfirmed(): return
            url = kb.getText().strip()
            if not url: return
        if not url.startswith(('http://', 'https://')):
            xbmcgui.Dialog().ok(
                "EspaTV",
                "La URL debe ser una dirección web (http:// o https://).\n\n"
                "Puede ser un archivo M3U/M3U8 o una página web para escanear sus enlaces de streaming y archivos de vídeo."
            )
            return
        # t.me/canal → t.me/s/canal (versión web con mensajes; la versión sin /s/ no tiene los posts)
        _tg = re.match(r'^(https?://t\.me/)(?!s/)([a-zA-Z][a-zA-Z0-9_]{3,})/?$', url, re.I)
        if _tg:
            url = f'https://t.me/s/{_tg.group(2)}'
        try:
            r = requests.get(url, timeout=15, headers=_browser_headers())
            if r.status_code != 200:
                xbmcgui.Dialog().ok("EspaTV", "No se pudo acceder a la URL.\nError HTTP {0}".format(r.status_code)); return
            content = r.text
        except (requests.RequestException, ValueError) as e:
            xbmcgui.Dialog().ok("EspaTV", "Error al verificar la URL:\n{0}".format(e)); return
        source = url

    channels = _parse_m3u_content(content)
    if not channels:
        channels = _scan_web_for_channels(content, source)
    if not channels:
        xbmcgui.Dialog().ok(
            "EspaTV",
            "No contiene canales válidos en formato M3U ni se detectaron enlaces de streaming."
        )
        return

    kb2 = xbmc.Keyboard('', 'Nombre para la lista ({0} canales encontrados)'.format(len(channels)))
    kb2.doModal()
    if not kb2.isConfirmed() or not kb2.getText().strip(): return
    name = kb2.getText().strip()
    lists = _load_custom_iptv()
    if any(l.get("url") == source for l in lists):
        xbmcgui.Dialog().notification("EspaTV", "Esta lista ya está añadida", xbmcgui.NOTIFICATION_WARNING); return
    lists.append({"name": name, "url": source})
    _save_custom_iptv(lists)
    xbmcgui.Dialog().notification("EspaTV", "Lista '{0}' añadida".format(name), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def view_custom_iptv(url):
    h = int(sys.argv[1])
    is_remote = url.lower().startswith(('http://', 'https://'))
    if is_remote:
        _tg = re.match(r'^https?://t\.me/(?!s/)([a-zA-Z][a-zA-Z0-9_]{3,})/?$', url, re.I)
        if _tg:
            url = f'https://t.me/s/{_tg.group(1)}'
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Cargando lista...")
    try:
        dp.update(30, "Cargando...")
        if is_remote:
            content = _cached_http_get(url, timeout=15)
        else:
            content = _read_local_list_file(url)
            if content is None:
                raise OSError("No se pudo leer el archivo local")
        dp.update(70, "Procesando...")
        channels = _parse_m3u_content(content)
        if not channels:
            channels = _scan_web_for_channels(content, url)
        dp.close()
        if not channels:
            xbmcgui.Dialog().ok("EspaTV", "No se encontraron canales.")
            xbmcplugin.endOfDirectory(h); return
        _render_m3u_channels(channels)
    except (requests.RequestException, RuntimeError, OSError) as e:
        dp.close()
        _log_error("Error lista IPTV: {0}".format(e))
        xbmcgui.Dialog().ok("EspaTV", "No se pudo cargar:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h)
        except RuntimeError:
            pass

def freetv_menu():
    h = int(sys.argv[1])
    li = xbmcgui.ListItem(label="[B]Free-TV IPTV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Lista IPTV gratuita con canales de todo el mundo.\nIncluye canales en abierto verificados."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]España[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales españoles."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://raw.githubusercontent.com/iptv-org/iptv/master/streams/es.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]España Regional[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales regionales españoles."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://raw.githubusercontent.com/iptv-org/iptv/master/streams/es_45.95.78.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Pluto TV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales Pluto TV España."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://raw.githubusercontent.com/iptv-org/iptv/master/streams/es_pluto.m3u"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Samsung TV Plus[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales Samsung TV Plus España."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url="https://raw.githubusercontent.com/iptv-org/iptv/master/streams/es_samsung.m3u"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)

def delete_custom_iptv(url):
    lists = _load_custom_iptv()
    name = next((l.get("name", "Lista") for l in lists if l.get("url") == url), "Lista")
    if xbmcgui.Dialog().yesno("EspaTV", "¿Eliminar la lista '{0}'?".format(name)):
        new_lists = [l for l in lists if l.get("url") != url]
        _save_custom_iptv(new_lists)
        xbmcgui.Dialog().notification("EspaTV", "Lista eliminada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")


# --- YOUTUBE EN DIRECTO ---
# --- FELICIDAD VERANIEGA (YouTube) ---
from youtube_data import FELICIDAD_VERANIEGA_YT as _FELICIDAD_VERANIEGA_YT
from youtube_data import COCINA_ESPANOLA_YT as _COCINA_ESPANOLA_YT
from youtube_data import ARTE_MUSEOS_YT as _ARTE_MUSEOS_YT
from youtube_data import EDUCACION_DIVULGACION_YT as _EDUCACION_DIVULGACION_YT
import loteria as _loteria_mod
import clasificaciones as _clasif_mod
import dgt as _dgt_mod
import tv_autonomicas as _tvaut_mod
import rtve_alacarta as _rtve_mod
import archive_org



def _yt_queue_add(yt_id, name=""):
    if not yt_id:
        return
    if not _check_youtube_addon():
        _youtube_install_prompt()
        return
    url = "plugin://plugin.video.youtube/play/?video_id={0}".format(yt_id)
    li = xbmcgui.ListItem(name or yt_id)
    li.setArt({"thumb": "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)})
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    if not xbmc.Player().isPlaying():
        playlist.clear()
        playlist.add(url, li)
        xbmc.Player().play(playlist)
        xbmcgui.Dialog().notification(
            "EspaTV", "Reproduciendo — pulsa Atrás para añadir más",
            xbmcgui.NOTIFICATION_INFO, 3000,
        )
    else:
        playlist.add(url, li)
        xbmcgui.Dialog().notification(
            "EspaTV",
            "Añadido a la cola ({0} vídeos)".format(playlist.size()),
            xbmcgui.NOTIFICATION_INFO, 2000,
        )

def _felicidad_menu():
    h = int(sys.argv[1])
    if not _check_youtube_addon():
        li = xbmcgui.ListItem(label="[COLOR red][B]Instalar addon YouTube (necesario)[/B][/COLOR]")
        li.setArt({'icon': 'DefaultAddonHelper.png'})
        li.setInfo('video', {'plot': "El addon YouTube de Kodi es necesario para ver este contenido.\nPulsa aqui para ver las instrucciones."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="youtube_install"), listitem=li, isFolder=False)
    for cat_name, channels in _FELICIDAD_VERANIEGA_YT.items():
        li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(cat_name, len(channels)))
        li.setArt({'icon': 'DefaultMusicVideos.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_list", cat=cat_name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)

def _felicidad_list(cat_name):
    h = int(sys.argv[1])
    channels = _FELICIDAD_VERANIEGA_YT.get(cat_name, [])
    if not channels:
        xbmcplugin.endOfDirectory(h); return
    if xbmcaddon.Addon().getSetting("cinema_mode_auto") == "true":
        xbmcplugin.endOfDirectory(h, succeeded=False)
        _run_cinema(channels, cat_name)
        return

    watched = _ywt.load()

    li_cinema = xbmcgui.ListItem(label="[COLOR limegreen][B]Modo Cine[/B][/COLOR]")
    li_cinema.setArt({'icon': 'DefaultMovies.png'})
    li_cinema.setInfo('video', {'plot': "Navega los vídeos con miniaturas grandes, metadata completa y fondo dinámico."})
    xbmcplugin.addDirectoryItem(handle=h,
        url=_u(action="felicidad_cinema", cat=cat_name),
        listitem=li_cinema, isFolder=False)

    for ch in channels:
        name = ch.get("name", "Canal")
        ctype = ch.get("type", "channel")
        desc = ch.get("desc", "")
        yt_id = ch.get("yt_id", "")
        burl = ch.get("url", "")
        is_watched = ctype == "video" and yt_id in watched
        if ctype == "browser":
            label = "[COLOR orange]{0}[/COLOR]".format(name)
            plot = "{0}\nSe abre en el navegador.".format(desc)
        elif ctype == "video":
            if is_watched:
                label = "[COLOR gray](Visto) {0}[/COLOR]".format(name)
            else:
                label = "[COLOR lime]{0}[/COLOR]".format(name)
            plot = "{0}\nVideo individual.".format(desc)
        elif ctype == "playlist":
            label = "[COLOR skyblue]{0}[/COLOR]".format(name)
            plot = "{0}\nPlaylist de YouTube.".format(desc)
        else:
            label = "[B]{0}[/B]".format(name)
            plot = "{0}\nCanal de YouTube.".format(desc)
        li = xbmcgui.ListItem(label=label)
        art = {'icon': 'DefaultMusicVideos.png'}
        if ctype == "video" and yt_id:
            thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
            art['thumb'] = thumb
            art['icon'] = thumb
        li.setArt(art)
        li.setInfo('video', {'title': name, 'plot': plot})
        fav_params = json.dumps({"yt_id": yt_id, "name": name, "ctype": ctype, "burl": burl})
        cm = []
        if ctype == "video" and yt_id:
            if is_watched:
                cm.append(("Desmarcar como visto", "RunPlugin({0})".format(
                    _u(action='yt_toggle_watched', yt_id=yt_id))))
            else:
                cm.append(("Marcar como visto", "RunPlugin({0})".format(
                    _u(action='yt_toggle_watched', yt_id=yt_id))))
            cm.append(("Añadir a cola de reproducción", "RunPlugin({0})".format(
                _u(action='yt_queue_add', yt_id=yt_id, name=name))))
        cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(
            _u(action='add_favorite', title=name, fav_url='yt_{0}'.format(yt_id),
               icon='DefaultMusicVideos.png', platform='youtube',
               fav_action='felicidad_play', params=fav_params))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_play", yt_id=yt_id, name=name, ctype=ctype, burl=burl), listitem=li, isFolder=(ctype == "video"))
    xbmcplugin.endOfDirectory(h)

class _FelicidadCinemaWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, xml_file, addon_path, skin_folder, res_folder, items_list=None, cat_name=""):
        super().__init__(xml_file, addon_path, skin_folder, res_folder)
        self.items_list = items_list or []
        self._displayed_items = []
        self.cat_name = cat_name
        self.selected_yt_id = None
        self.selected_title = ""
        self.selected_ctype = None
        self.selected_burl = ""
        self.play_all = False
        self._closing = False
        self._poll_thread = None

    def onInit(self):
        self.setProperty("yt_playlist_name", self.cat_name)
        self._load_and_show()

    def _load_and_show(self):
        try:
            if not self.items_list:
                self._show_error("No hay vídeos en esta categoría")
                return
            items = []
            self._displayed_items = []
            n_shown = 0
            for ch in self.items_list:
                name = ch.get("name", "")
                yt_id = ch.get("yt_id", "")
                ctype = ch.get("type", "channel")
                desc = ch.get("desc", "")
                burl = ch.get("url", "")

                if not name:
                    continue

                n_shown += 1
                li = xbmcgui.ListItem(label=name)
                thumb = ""
                if yt_id and ctype in ("video", "channel"):
                    thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)

                li.setArt({"thumb": thumb})
                li.setProperty("yt_thumb", thumb)
                li.setProperty("yt_number", str(n_shown))
                li.setProperty("yt_label", name)
                li.setProperty("yt_vid", yt_id or "")
                li.setProperty("yt_title", name)
                if ctype == "video":
                    li.setProperty("yt_channel", ch.get("channel", ""))
                    li.setProperty("yt_views", ch.get("views", ""))
                    li.setProperty("yt_date", ch.get("date", ""))
                    li.setProperty("yt_duration", ch.get("duration", ""))
                else:
                    li.setProperty("yt_channel", {"channel": "Canal", "browser": "Web"}.get(ctype, ""))
                    li.setProperty("yt_views", "")
                    li.setProperty("yt_date", "")
                    li.setProperty("yt_duration", "")
                li.setProperty("yt_plot", desc)
                li.setProperty("yt_img", thumb)
                items.append(li)
                self._displayed_items.append(ch)

            try:
                ctrl = self.getControl(200)
                ctrl.addItems(items)
                self.getControl(500).setVisible(False)
                self._poll_thread = threading.Thread(target=self._focus_poll_loop, daemon=True)
                self._poll_thread.start()
            except Exception as e:
                xbmc.log(f"[EspaTV/FelicidadCinema] Error al rellenar lista: {e}", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[EspaTV/FelicidadCinema] Error al cargar: {e}", xbmc.LOGERROR)
            self._show_error(f"Error: {e}")

    def _focus_poll_loop(self):
        monitor = xbmc.Monitor()
        while not self._closing and not monitor.abortRequested():
            try:
                ctrl = self.getFocus()
                if ctrl.getId() == 200:
                    pos = ctrl.getSelectedPosition()
                    if pos >= 0:
                        li = ctrl.getListItem(pos)
                        if li:
                            self.setProperty("yt_focused_img", li.getProperty("yt_img"))
                            self.setProperty("yt_focused_title", li.getProperty("yt_title"))
                            self.setProperty("yt_focused_channel", li.getProperty("yt_channel"))
                            self.setProperty("yt_focused_views", li.getProperty("yt_views"))
                            self.setProperty("yt_focused_date", li.getProperty("yt_date"))
                            self.setProperty("yt_focused_duration", li.getProperty("yt_duration"))
                            self.setProperty("yt_focused_plot", li.getProperty("yt_plot"))
                            self.setProperty("yt_fanart", li.getProperty("yt_img"))
            except Exception:
                pass
            if monitor.waitForAbort(0.25):
                break

    def _show_error(self, msg):
        try:
            ctrl = self.getControl(500)
            ctrl.setLabel(f"[COLOR red]{msg}[/COLOR]")
            ctrl.setVisible(True)
        except Exception:
            pass

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self._closing = True
            self.close()

    def onClick(self, controlId):
        if controlId == 101:
            self.play_all = True
            self._closing = True
            self.close()
        elif controlId == 100:
            self._closing = True
            self.close()
        elif controlId == 200:
            try:
                ctrl = self.getControl(200)
                pos = ctrl.getSelectedPosition()
                if pos >= 0 and pos < len(self._displayed_items):
                    item = self._displayed_items[pos]
                    self.selected_yt_id = item.get("yt_id", "")
                    self.selected_title = item.get("name", "")
                    self.selected_ctype = item.get("type", "channel")
                    self.selected_burl = item.get("url", "")
                    self._closing = True
                    self.close()
            except Exception as e:
                xbmc.log(f"[EspaTV/FelicidadCinema] onClick error: {e}", xbmc.LOGERROR)


class _CinemaPlayer(xbmc.Player):
    """Espera el fin de la reproducción para que el bucle del Modo Cine reabra el modal."""
    def __init__(self):
        super().__init__()
        self._ended = threading.Event()

    def onPlayBackEnded(self):
        self._ended.set()

    def onPlayBackStopped(self):
        self._ended.set()

    def onPlayBackError(self):
        self._ended.set()

    def wait_finished(self, monitor):
        # Esperar el arranque (máx 30s): si no, confundiríamos "aún no empezó" con "ya acabó"
        for _ in range(120):
            if monitor.abortRequested() or self._ended.is_set():
                return
            if self.isPlaying():
                break
            monitor.waitForAbort(0.25)
        else:
            return  # nunca arrancó: evita cuelgue indefinido
        while not self._ended.is_set() and not monitor.abortRequested():
            monitor.waitForAbort(0.5)


def _cinema_play_queue(all_items):
    pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    pl.clear()
    for ch in all_items:
        if ch.get("type", "video") == "video" and ch.get("yt_id"):
            li = xbmcgui.ListItem(label=ch.get("name", ""))
            li.setProperty("IsPlayable", "true")
            pl.add("plugin://plugin.video.youtube/play/?video_id={0}".format(ch["yt_id"]), li)
    if pl.size() > 0:
        xbmc.Player().play(pl)


def _run_cinema(items_list, cat_name):
    """Bucle del Modo Cine: muestra el modal, reproduce el vídeo elegido y al terminar
    reabre el modal. Sale al pulsar X/Back, al elegir Reproducir todo (>>) o un item
    de canal/navegador. Bloquea el hilo del plugin durante la reproducción: así el
    script sigue vivo y el Player recibe los callbacks (un hilo daemon no sobrevive
    al fin de la invocación del plugin)."""
    if not items_list:
        return
    addon_path = xbmcaddon.Addon().getAddonInfo("path")
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        win = _FelicidadCinemaWindow("yt_cinema.xml", addon_path, "Default", "1080i",
                                     items_list=items_list, cat_name=cat_name)
        try:
            win.doModal()
            yt_id = win.selected_yt_id
            title = win.selected_title
            ctype = win.selected_ctype
            burl = win.selected_burl
            play_all = win.play_all
            all_items = list(win._displayed_items) if play_all else []
        finally:
            del win

        if play_all:
            _cinema_play_queue(all_items)
            return
        if ctype == "video" and yt_id:
            player = _CinemaPlayer()
            try:
                _felicidad_play_exec(yt_id=yt_id, name=title, method="addon")
                player.wait_finished(monitor)
            finally:
                del player
            continue  # vuelve a abrir el modal
        if ctype in ("browser", "channel"):
            _felicidad_play(yt_id=yt_id, name=title, ctype=ctype, burl=burl)
            return
        return  # cerrado con X/Back sin seleccionar


def _spanish_section_cinema(section):
    data = _load_spanish_channels()
    sec = data.get(section)
    if not sec:
        return
    items_list = []
    for ch in sec.get('channels', []):
        direct_url = ch.get('url', '')
        m = re.search(r'[?&]v=([^&]+)', direct_url) if direct_url else None
        yt_id = m.group(1) if m else ''
        if not yt_id:
            continue
        _views = ch.get('views', 0)
        items_list.append({
            "name": ch.get('name', ''), "yt_id": yt_id, "type": "video",
            "channel": ch.get('channel', ''),
            "date": str(ch.get('year', '')) if ch.get('year') else '',
            "views": '{:,}'.format(_views).replace(',', '.') + ' vistas' if _views else '',
            "desc": ch.get('description', ''),
            "url": direct_url,
        })
    _run_cinema(items_list, sec.get('title', section))


def _yt_search_cinema(query, sp=""):
    if not query:
        return
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Buscando en YouTube: {0}...".format(query))
    try:
        results = _yts.fetch_search_results(query, sp)
        dp.close()
    except (OSError, ValueError) as e:
        dp.close()
        xbmcgui.Dialog().ok("EspaTV", "Error al buscar:\n{0}".format(str(e)))
        return
    if not results:
        xbmcgui.Dialog().ok("EspaTV", "Sin resultados para:\n{0}".format(query))
        return
    items_list = [
        {"name": r["title"], "yt_id": r["vid"], "type": "video",
         "channel": r.get("channel", ""),
         "duration": r.get("duration", ""),
         "views": r.get("views", ""),
         "desc": "",
         "url": ""}
        for r in results if r.get("vid")
    ]
    _run_cinema(items_list, query)


def _yt_playlist_cinema(list_id, name=""):
    if not list_id:
        return
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Cargando playlist...")
    try:
        videos = _ytp.fetch_videos(list_id, include_extra=True)
        dp.close()
    except (OSError, ValueError) as e:
        dp.close()
        xbmcgui.Dialog().ok("EspaTV", "Error al cargar la playlist:\n{0}".format(str(e)))
        return
    if not videos:
        xbmcgui.Dialog().ok("EspaTV", "No se pudieron obtener los vídeos de la playlist")
        return
    items_list = [
        {"name": v.get("title", ""), "yt_id": v["vid"], "type": "video",
         "channel": v.get("channel", ""),
         "duration": v.get("duration", ""),
         "views": v.get("views", ""),
         "date": v.get("date", ""),
         "desc": v.get("description", ""),
         "url": ""}
        for v in videos if v.get("vid")
    ]
    _run_cinema(items_list, name)


def _felicidad_cinema(cat_name):
    if not cat_name:
        return
    channels = _FELICIDAD_VERANIEGA_YT.get(cat_name, [])
    if not channels:
        xbmcgui.Dialog().ok("Modo Cine", "No hay contenido en esta categoría")
        return
    _run_cinema(channels, cat_name)


def _felicidad_open_browser(url, name=""):
    url = url.replace('"', '').replace("'", '') if url else ""
    try:
        if xbmc.getCondVisibility("System.Platform.Android"):
            xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","text/html","{0}")'.format(url))
        else:
            import webbrowser
            webbrowser.open(url)
        xbmcgui.Dialog().notification("EspaTV", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
    except (ImportError, OSError):
        xbmcgui.Dialog().ok("Abrir en navegador", "No se pudo abrir automaticamente.\n\nAbre esta URL:\n{0}".format(url))


def _felicidad_open_yt_app(url, name=""):
    url = url.replace('"', '').replace("'", '') if url else ""
    try:
        xbmc.executebuiltin('StartAndroidActivity("com.google.android.youtube","android.intent.action.VIEW","","{0}")'.format(url))
        xbmcgui.Dialog().notification("EspaTV", "Abriendo app YouTube...", xbmcgui.NOTIFICATION_INFO, 2000)
    except (RuntimeError, OSError):
        xbmcgui.Dialog().ok("App YouTube", "No se pudo abrir la app YouTube.\nAsegurate de que esta instalada.")

# Buscar en YouTube

def _felicidad_play(yt_id="", name="", ctype="channel", burl=""):
    if ctype == "browser":
        is_youtube = burl and ("youtube.com" in burl or "youtu.be" in burl)
        if is_youtube:
            is_android = xbmc.getCondVisibility("System.Platform.Android")
            if is_android:
                opts = ["Abrir en la app YouTube", "Abrir en el navegador", "Buscar en YouTube (Kodi)"]
            else:
                opts = ["Abrir en el navegador", "Buscar en YouTube (Kodi)"]
            
            sel = xbmcgui.Dialog().select("{0}".format(name or "YouTube"), opts)
            if sel < 0:
                return
            
            if is_android:
                if sel == 0:
                    _felicidad_open_yt_app(burl or "https://www.youtube.com", name)
                    return
                elif sel == 1:
                    _felicidad_open_browser(burl or "https://www.youtube.com", name)
                    return
                elif sel == 2:
                    pass
            else:
                if sel == 0:
                    _felicidad_open_browser(burl or "https://www.youtube.com", name)
                    return
                elif sel == 1:
                    pass
            
            # Extraer término de búsqueda inteligente
            query = ""
            m = re.search(r'youtube\.com/(@[\w\-\.]+)', burl)
            if m:
                query = m.group(1)
            if not query:
                m2 = re.search(r'youtube\.com/(?:c|user|channel)/([\w\-\.]+)', burl)
                if m2:
                    query = m2.group(1)
            if not query:
                query = name.lstrip('*').strip()
            
            xbmc.executebuiltin("Container.Update({0})".format(_u(action="yt_search_results", query=query)))
            return

        if xbmc.getCondVisibility("System.Platform.Android"):
            opts = ["Abrir en la app YouTube", "Abrir en el navegador"]
            sel = xbmcgui.Dialog().select("{0}".format(name or "YouTube"), opts)
            if sel < 0: return
            if sel == 0:
                _felicidad_open_yt_app(burl or "https://www.youtube.com", name)
            else:
                _felicidad_open_browser(burl or "https://www.youtube.com", name)
        else:
            _felicidad_open_browser(burl or "https://www.youtube.com", name)
        return
    if ctype == "video":
        h = int(sys.argv[1])
        yt_thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
        is_android = xbmc.getCondVisibility("System.Platform.Android")
        is_pc = not is_android
        li = xbmcgui.ListItem(label="[COLOR limegreen][B]Reproducir aquí[/B][/COLOR]")
        li.setArt({"icon": "DefaultVideo.png", "thumb": yt_thumb})
        li.setInfo("video", {"plot": "Reproduce con el addon YouTube de Kodi."})
        xbmcplugin.addDirectoryItem(handle=h,
            url=_u(action="felicidad_play_exec", yt_id=yt_id, name=name, method="addon"),
            listitem=li, isFolder=False)
        if is_android:
            li = xbmcgui.ListItem(label="[COLOR lightskyblue]Abrir en la app YouTube[/COLOR]")
            li.setArt({"icon": "DefaultAddonProgram.png", "thumb": yt_thumb})
            li.setInfo("video", {"plot": "Abre en la aplicación YouTube de Android."})
            xbmcplugin.addDirectoryItem(handle=h,
                url=_u(action="felicidad_play_exec", yt_id=yt_id, name=name, method="yt_app"),
                listitem=li, isFolder=False)
        li = xbmcgui.ListItem(label="[COLOR orange]Abrir en el navegador[/COLOR]")
        li.setArt({"icon": "DefaultNetwork.png", "thumb": yt_thumb})
        li.setInfo("video", {"plot": "Abre la página de YouTube en el navegador."})
        xbmcplugin.addDirectoryItem(handle=h,
            url=_u(action="felicidad_play_exec", yt_id=yt_id, name=name, method="browser"),
            listitem=li, isFolder=False)
        if is_pc:
            li = xbmcgui.ListItem(label="[COLOR mediumpurple]Reproducir con yt-dlp[/COLOR]")
            li.setArt({"icon": "DefaultAddonVideo.png", "thumb": yt_thumb})
            li.setInfo("video", {"plot": "Resuelve el vídeo con yt-dlp y lo reproduce."})
            xbmcplugin.addDirectoryItem(handle=h,
                url=_u(action="felicidad_play_exec", yt_id=yt_id, name=name, method="ytdlp"),
                listitem=li, isFolder=False)
            li = xbmcgui.ListItem(label="[COLOR gray]¿YouTube no funciona? Lee esto[/COLOR]")
            li.setArt({"icon": "DefaultIconInfo.png", "thumb": yt_thumb})
            li.setInfo("video", {"plot": (
                "YouTube bloquea peticiones desde IPs residenciales sin sesión activa "
                "(error: 'Sign in to confirm you’re not a bot'). "
                "Afecta tanto al addon de YouTube como a yt-dlp.\n\n"
                "[B]Solución 1 — VPN[/B]\n"
                "Activa una VPN. Funciona con cualquier método de reproducción.\n\n"
                "[B]Solución 2 — Fallback automático con curl_cffi (solo yt-dlp)[/B]\n"
                "Si usas 'Reproducir con yt-dlp', EspaTV reintenta automáticamente "
                "imitando el fingerprint TLS de Chrome si tienes instalado curl_cffi:\n"
                "   pip install curl_cffi\n\n"
                "Con curl_cffi instalado el reintento ocurre solo, sin que tengas que hacer nada."
            )})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h,
                url=_u(action="yt_pc_info"),
                listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    # --- Canales y playlists: mantener diálogo ---
    yt_url_map = {
        "channel": ("plugin://plugin.video.youtube/channel/{0}/", "https://www.youtube.com/channel/{0}"),
        "playlist": ("plugin://plugin.video.youtube/playlist/{0}/", "https://www.youtube.com/playlist?list={0}"),
    }
    addon_tpl, web_tpl = yt_url_map.get(ctype, yt_url_map["channel"])
    is_android = xbmc.getCondVisibility("System.Platform.Android")
    if is_android:
        opts = ["Abrir aquí", "Abrir en la app YouTube", "Abrir en el navegador"]
    else:
        opts = ["Abrir aquí", "Abrir en el navegador"]
    sel = xbmcgui.Dialog().select("{0}".format(name or "YouTube"), opts)
    if sel < 0:
        return
    if sel == 0:
        if not _check_youtube_addon():
            if not _youtube_install_prompt():
                return
        xbmc.executebuiltin("ActivateWindow(Videos,{0})".format(addon_tpl.format(yt_id)))
    elif is_android and sel == 1:
        _felicidad_open_yt_app(web_tpl.format(yt_id), name)
    else:
        _felicidad_open_browser(web_tpl.format(yt_id), name)


def _felicidad_play_exec(yt_id="", name="", method="addon"):
    if not yt_id:
        return
    yt_web = "https://www.youtube.com/watch?v={0}".format(yt_id)
    if method == "addon":
        if not _check_youtube_addon():
            if not _youtube_install_prompt():
                return
        yt_thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
        try:
            _wh.add(yt_id, name or yt_id, thumb=yt_thumb, duration=0)
        except (OSError, ValueError):
            pass
        plugin_url = "plugin://plugin.video.youtube/play/?video_id={0}".format(yt_id)
        xbmc.executebuiltin("PlayMedia({0})".format(plugin_url))
    elif method == "yt_app":
        _felicidad_open_yt_app(yt_web, name)
    elif method == "browser":
        _felicidad_open_browser(yt_web, name)
    elif method == "ytdlp":
        _felicidad_play_ytdlp(yt_id, name)


def _felicidad_play_ytdlp(yt_id, name=""):
    yt_web = "https://www.youtube.com/watch?v={0}".format(yt_id)
    xbmcgui.Dialog().notification(
        "EspaTV", "Resolviendo con yt-dlp...",
        xbmcgui.NOTIFICATION_INFO, 2000,
    )
    stream_url = ytdlp_resolver.resolve(yt_web)
    if stream_url:
        li = xbmcgui.ListItem(path=stream_url)
        li.setProperty("IsPlayable", "true")
        li.setContentLookup(False)
        xbmc.Player().play(stream_url, li)
        yt_thumb = 'https://i.ytimg.com/vi/{0}/hqdefault.jpg'.format(yt_id)
        try:
            _wh.add(yt_id, name or yt_id, thumb=yt_thumb, duration=0)
        except (OSError, ValueError):
            pass
        return
    xbmcgui.Dialog().ok(
        "EspaTV",
        "yt-dlp no pudo resolver el vídeo.\n\n"
        "Asegúrate de tener yt-dlp instalado:\npip install yt-dlp",
    )

# --- COCINA ESPAÑOLA ---
def _cocina_menu():
    h = int(sys.argv[1])
    if not _COCINA_ESPANOLA_YT:
        xbmcgui.Dialog().ok("Cocina Española", "Aún no hay contenido. ¡Próximamente!")
        return
    for cat_name, channels in _COCINA_ESPANOLA_YT.items():
        li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(cat_name, len(channels)))
        li.setArt({'icon': 'DefaultMusicVideos.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cocina_list", cat=cat_name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)

def _cocina_list(cat_name):
    h = int(sys.argv[1])
    channels = _COCINA_ESPANOLA_YT.get(cat_name, [])
    if not channels:
        xbmcplugin.endOfDirectory(h); return
    watched = _ywt.load()
    for ch in channels:
        name = ch.get("name", "Canal")
        ctype = ch.get("type", "channel")
        desc = ch.get("desc", "")
        yt_id = ch.get("yt_id", "")
        burl = ch.get("url", "")
        is_watched = ctype == "video" and yt_id in watched
        if ctype == "browser":
            label = "[COLOR orange]{0}[/COLOR]".format(name)
            plot = "{0}\nSe abre en el navegador.".format(desc)
        elif ctype == "video":
            if is_watched:
                label = "[COLOR gray](Visto) {0}[/COLOR]".format(name)
            else:
                label = "[COLOR lime]{0}[/COLOR]".format(name)
            plot = "{0}\nVideo individual.".format(desc)
        elif ctype == "playlist":
            label = "[COLOR skyblue]{0}[/COLOR]".format(name)
            plot = "{0}\nPlaylist de YouTube.".format(desc)
        else:
            label = "[B]{0}[/B]".format(name)
            plot = "{0}\nCanal de YouTube.".format(desc)
        li = xbmcgui.ListItem(label=label)
        art = {'icon': 'DefaultMusicVideos.png'}
        if ctype == "video" and yt_id:
            thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
            art['thumb'] = thumb
            art['icon'] = thumb
        li.setArt(art)
        li.setInfo('video', {'title': name, 'plot': plot})
        fav_params = json.dumps({"yt_id": yt_id, "name": name, "ctype": ctype, "burl": burl})
        cm = []
        if ctype == "video" and yt_id:
            if is_watched:
                cm.append(("Desmarcar como visto", "RunPlugin({0})".format(
                    _u(action='yt_toggle_watched', yt_id=yt_id))))
            else:
                cm.append(("Marcar como visto", "RunPlugin({0})".format(
                    _u(action='yt_toggle_watched', yt_id=yt_id))))
            cm.append(("Añadir a cola de reproducción", "RunPlugin({0})".format(
                _u(action='yt_queue_add', yt_id=yt_id, name=name))))
        cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(
            _u(action='add_favorite', title=name, fav_url='yt_{0}'.format(yt_id),
               icon='DefaultMusicVideos.png', platform='cocina',
               fav_action='felicidad_play', params=fav_params))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_play", yt_id=yt_id, name=name, ctype=ctype, burl=burl), listitem=li, isFolder=(ctype == "video"))
    xbmcplugin.endOfDirectory(h)

# --- EDUCACIÓN Y DIVULGACIÓN ---
def _educacion_menu():
    h = int(sys.argv[1])
    if not _EDUCACION_DIVULGACION_YT:
        xbmcgui.Dialog().ok("Educación y Divulgación", "Aún no hay contenido. ¡Próximamente!")
        return
    edu_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'cat_educacion.png')
    if not os.path.isfile(edu_icon):
        edu_icon = 'DefaultFolder.png'

    for cat_name, channels in _EDUCACION_DIVULGACION_YT.items():
        li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(cat_name, len(channels)))
        li.setArt({'icon': edu_icon})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="educacion_list", cat=cat_name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)

def _educacion_list(cat_name):
    h = int(sys.argv[1])
    channels = _EDUCACION_DIVULGACION_YT.get(cat_name, [])
    if not channels:
        xbmcplugin.endOfDirectory(h); return
    edu_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'cat_educacion.png')
    if not os.path.isfile(edu_icon):
        edu_icon = 'DefaultFolder.png'
    watched = _ywt.load()
    for ch in channels:
        name = ch.get("name", "Canal")
        ctype = ch.get("type", "channel")
        desc = ch.get("desc", "")
        yt_id = ch.get("yt_id", "")
        burl = ch.get("url", "")
        is_watched = ctype == "video" and yt_id in watched
        if ctype == "browser":
            label = "[COLOR orange]{0}[/COLOR]".format(name)
            plot = "{0}\nSe abre en el navegador.".format(desc)
        elif ctype == "video":
            label = "[COLOR gray](Visto) {0}[/COLOR]".format(name) if is_watched else "[COLOR lime]{0}[/COLOR]".format(name)
            plot = "{0}\nVideo individual.".format(desc)
        elif ctype == "playlist":
            label = "[COLOR skyblue]{0}[/COLOR]".format(name)
            plot = "{0}\nPlaylist de YouTube.".format(desc)
        else:
            label = "[B]{0}[/B]".format(name)
            plot = "{0}\nCanal de YouTube.".format(desc)
        li = xbmcgui.ListItem(label=label)
        art = {'icon': edu_icon}
        if ctype == "video" and yt_id:
            thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
            art['thumb'] = thumb
            art['icon'] = thumb
        li.setArt(art)
        li.setInfo('video', {'title': name, 'plot': plot})
        fav_params = json.dumps({"yt_id": yt_id, "name": name, "ctype": ctype, "burl": burl})
        cm = []
        if ctype == "video" and yt_id:
            if is_watched:
                cm.append(("Desmarcar como visto", "RunPlugin({0})".format(_u(action='yt_toggle_watched', yt_id=yt_id))))
            else:
                cm.append(("Marcar como visto", "RunPlugin({0})".format(_u(action='yt_toggle_watched', yt_id=yt_id))))
            cm.append(("Añadir a cola de reproducción", "RunPlugin({0})".format(_u(action='yt_queue_add', yt_id=yt_id, name=name))))
        cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(
            _u(action='add_favorite', title=name, fav_url='yt_{0}'.format(yt_id),
               icon=edu_icon, platform='educacion',
               fav_action='felicidad_play', params=fav_params))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="felicidad_play", yt_id=yt_id, name=name, ctype=ctype, burl=burl), listitem=li, isFolder=(ctype == "video"))
    xbmcplugin.endOfDirectory(h)

# --- ARTE Y MUSEOS ---
def _arte_museos_menu():
    h = int(sys.argv[1])
    if not _ARTE_MUSEOS_YT:
        xbmcgui.Dialog().ok("Arte y Museos", "Aún no hay contenido. ¡Próximamente!")
        return
    for cat_name, items in _ARTE_MUSEOS_YT.items():
        li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(cat_name, len(items)))
        li.setArt({'icon': 'DefaultPicture.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="arte_museos_list", cat=cat_name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _arte_museos_list(cat_name):
    h = int(sys.argv[1])
    items = _ARTE_MUSEOS_YT.get(cat_name, [])
    if not items:
        xbmcplugin.endOfDirectory(h)
        return
    watched = _ywt.load()
    for ch in items:
        name = ch.get("name", "")
        ctype = ch.get("type", "browser")
        desc = ch.get("desc", "")
        yt_id = ch.get("yt_id", "")
        burl = ch.get("url", "")
        is_watched = ctype == "video" and yt_id in watched
        if ctype == "info":
            li = xbmcgui.ListItem(label="[COLOR gray][I]Pendiente de actualizar[/I][/COLOR]")
            li.setArt({'icon': 'DefaultIconInfo.png'})
            li.setInfo('video', {'title': "Pendiente de actualizar", 'plot': desc})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="arte_info_dialog", title=cat_name, msg=desc),
                listitem=li, isFolder=False,
            )
            continue
        if ctype == "browser":
            label = "[COLOR orange]{0}[/COLOR]".format(name)
            plot = "{0}\nSe abre en el navegador.".format(desc)
        elif ctype == "video":
            label = "[COLOR gray](Visto) {0}[/COLOR]".format(name) if is_watched else "[COLOR lime]{0}[/COLOR]".format(name)
            plot = "{0}\nVideo individual.".format(desc)
        elif ctype == "playlist":
            label = "[COLOR skyblue]{0}[/COLOR]".format(name)
            plot = "{0}\nPlaylist de YouTube.".format(desc)
        else:
            label = "[B]{0}[/B]".format(name)
            plot = "{0}\nCanal de YouTube.".format(desc)
        li = xbmcgui.ListItem(label=label)
        art = {'icon': 'DefaultPicture.png'}
        if ctype == "video" and yt_id:
            thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)
            art['thumb'] = thumb
            art['icon'] = thumb
        li.setArt(art)
        li.setInfo('video', {'title': name, 'plot': plot})
        cm = []
        if ctype == "video" and yt_id:
            toggle_label = "Desmarcar como visto" if is_watched else "Marcar como visto"
            cm.append((toggle_label, "RunPlugin({0})".format(_u(action='yt_toggle_watched', yt_id=yt_id))))
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="felicidad_play", yt_id=yt_id, name=name, ctype=ctype, burl=burl),
            listitem=li,
            isFolder=(ctype != "video"),
        )
    xbmcplugin.endOfDirectory(h)


_YT_LIVE_CHANNELS = {
    "Noticias 24h": [
        {"name": "RTVE 24h", "yt_id": "UCfHptOfCGvKbHdFhfjJnWpA"},
        {"name": "euronews en español", "yt_id": "UCjwHpMgZoLPasxBswgFshKg"},
        {"name": "France 24 Español", "yt_id": "UCUdOoVWuWmgo1wByzcsyKDQ"},
        {"name": "DW Español", "yt_id": "UCT2VMLy-aMTdfnCjTmYgUbg"},
        {"name": "Televisión de Galicia", "yt_id": "UC7dxTqnuQI6IxCZMmJG_MOw"},
    ],
    "Música": [
        {"name": "Lo-fi Girl", "yt_id": "UCSJ4gkVC6NrvII8umztf0A"},
        {"name": "Steezy Beats", "yt_id": "UCwNw0w-CorPkMNy5vRxatZg"},
        {"name": "Chillhop Music", "yt_id": "UCOxqgCwgOqC2lMqC5PYz_Dg"},
    ],
    "Naturaleza y Documentales": [
        {"name": "Explore.org Live Cams", "yt_id": "UCOhMiSLNDD0D7xTuHCYgEhw"},
    ],
}

def _check_youtube_addon():
    try:
        xbmcaddon.Addon("plugin.video.youtube")
        return True
    except RuntimeError:
        return False



def _youtube_install_prompt():
    """Pide confirmación y llama a InstallAddon(plugin.video.youtube). Devuelve siempre False (la instalación es asíncrona)."""
    import xbmc
    import xbmcgui
    import traceback
    

    dialog = xbmcgui.Dialog()
    
    try:
        if dialog.yesno("Instalar YouTube", 
                        "El addon oficial de YouTube no está instalado.\n\n"
                        "¿Quieres instalarlo ahora?",
                        nolabel="Cancelar", yeslabel="Sí, Instalar"):
            
            xbmc.log("[EspaTV] YouTube: el usuario acepta, instalando", xbmc.LOGINFO)
            
            xbmc.executebuiltin("InstallAddon(plugin.video.youtube)")
            
            dialog.notification("EspaTV", "Instalando YouTube...", xbmcgui.NOTIFICATION_INFO, 2500)
            

            return False
        else:
            xbmc.log("[EspaTV] YouTube: instalación cancelada por el usuario", xbmc.LOGINFO)
            dialog.notification("EspaTV", "Tendrás que instalar YouTube manualmente.", xbmcgui.NOTIFICATION_WARNING)
            return False
            
    except (RuntimeError, AttributeError) as script_error:
        tb = traceback.format_exc()
        xbmc.log("[EspaTV] YouTube: error al instalar: {0}\n\t{1}".format(str(script_error), str(tb)), xbmc.LOGERROR)
        dialog.notification("EspaTV Error", "Fallo al llamar la API del sistema", xbmcgui.NOTIFICATION_ERROR)
        return False




def _play_dash(stream_url, title=""):
    h = int(sys.argv[1])
    if not stream_url:
        xbmcgui.Dialog().notification("EspaTV", "Streaming DASH no disponible.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    xbmc.log("[EspaTV] Reproduciendo flujo DASH: {0}".format(stream_url), xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=stream_url)
    li.setInfo('video', {'title': title})
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    li.setMimeType('application/dash+xml')
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(h, True, li)


def _youtube_live_menu():
    h = int(sys.argv[1])
    if not _check_youtube_addon():
        li = xbmcgui.ListItem(label="[COLOR red][B]Instalar addon YouTube (necesario)[/B][/COLOR]")
        li.setArt({'icon': 'DefaultAddonHelper.png'})
        li.setInfo('video', {'plot': "El addon YouTube de Kodi es necesario para reproducir estos canales.\nPulsa aquí para ver las instrucciones de instalación."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="youtube_install"), listitem=li, isFolder=False)
    for cat_name, channels in _YT_LIVE_CHANNELS.items():
        li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(cat_name, len(channels)))
        li.setArt({'icon': 'DefaultAddonPVRClient.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="youtube_live_list", cat=cat_name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)

def _youtube_live_list(cat_name):
    h = int(sys.argv[1])
    channels = _YT_LIVE_CHANNELS.get(cat_name, [])
    if not channels:
        xbmcplugin.endOfDirectory(h); return
    has_yt = _check_youtube_addon()
    for ch in channels:
        name = ch.get("name", "Canal")
        yt_id = ch.get("yt_id", "")
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(name))
        li.setArt({'icon': 'DefaultAddonPVRClient.png', 'thumb': 'DefaultAddonPVRClient.png'})
        if has_yt:
            li.setInfo('video', {'title': name, 'plot': "YouTube Live: {0}\nPulsa para ver en directo.".format(name)})
        else:
            li.setInfo('video', {'title': name, 'plot': "YouTube Live: {0}\n[COLOR red]Necesitas instalar el addon YouTube.[/COLOR]".format(name)})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_youtube_live", yt_id=yt_id, title=name), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def _play_youtube_live(yt_id, title=""):
    h = int(sys.argv[1])
    if not _check_youtube_addon():
        _youtube_install_prompt()
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    yt_url = "plugin://plugin.video.youtube/play/?channel_id={0}&live=1".format(yt_id)
    xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
    xbmc.executebuiltin("PlayMedia({0})".format(yt_url))

def _play_latest_news():
    h = int(sys.argv[1])
    url = "https://fapi-top.prisasd.com/podcast/playser/hora_14/itunestfp/podcast.xml"
    try:
        import xml.etree.ElementTree as ET
        r = requests.get(url, timeout=8)
        r.raise_for_status()
        r.encoding = 'utf-8'
        root = ET.fromstring(r.text)
        item = root.find('.//item')
        if item is None:
            xbmcgui.Dialog().notification("EspaTV", "No hay boletines disponibles.", xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
            return
        enclosure = item.find('enclosure')
        if enclosure is None or not enclosure.get('url'):
            xbmcgui.Dialog().notification("EspaTV", "Boletín sin audio disponible.", xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
            return
        audio_url = enclosure.get('url')
        title_el = item.find('title')
        title = title_el.text if title_el is not None and title_el.text else "Boletín Informativo"
        xbmc.log("[EspaTV] Reproduciendo RSS Noticias: {0}".format(audio_url), xbmc.LOGINFO)
        xbmcgui.Dialog().notification("EspaTV", "Reproduciendo: {0}".format(title), xbmcgui.NOTIFICATION_INFO, 3000)
        li = xbmcgui.ListItem(path=audio_url)
        li.setInfo(type="Music", infoLabels={"Title": title, "Artist": "SER Noticias"})
        xbmcplugin.setResolvedUrl(h, True, li)
        return
    except (requests.RequestException, ValueError, ImportError) as exc:
        _log_error("Error obteniendo boletín de noticias: {0}".format(exc))
        xbmcgui.Dialog().notification("EspaTV", "Error obteniendo el boletín de noticias.", xbmcgui.NOTIFICATION_ERROR)
    xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())

# --- LO MÁS VISTO ---
def _most_watched():
    h = int(sys.argv[1])
    history = _wh._load()
    if not history:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay historial aún. Reproduce vídeos para ver tus más vistos.[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h); return

    entries_to_show = []
    for entry in history:
        if len(entries_to_show) >= 20: break
        vid = entry.get('vid', '')
        if not vid: continue
        entries_to_show.append(entry)

    # Algunas entradas guardan el ID de DM como título: los resolvemos en lote vía API
    ids_to_resolve = []
    for entry in entries_to_show:
        vt = entry.get('title', '')
        vid = entry.get('vid', '')
        if not vt or vt == vid or (len(vt) < 12 and ' ' not in vt):
            ids_to_resolve.append(vid)

    resolved = {}
    if ids_to_resolve:
        try:
            batch_ids = ",".join(ids_to_resolve[:20])
            r = requests.get("https://api.dailymotion.com/videos",
                params={"ids": batch_ids, "fields": "id,title,thumbnail_720_url,thumbnail_url,duration"},
                timeout=10)
            if r.status_code == 200:
                for v in r.json().get("list", []):
                    resolved[v.get("id", "")] = v
        except (requests.RequestException, ValueError):
            pass

    # Actualizar el historial con títulos reales obtenidos de la API (mejora las entradas con IDs como título)
    if resolved:
        updated = False
        for entry in history:
            vid = entry.get('vid', '')
            if vid in resolved:
                info = resolved[vid]
                real_title = info.get("title", "")
                real_thumb = info.get("thumbnail_720_url") or info.get("thumbnail_url", "")
                real_dur = info.get("duration", 0)
                if real_title and (not entry.get('title') or entry['title'] == vid or (len(entry['title']) < 12 and ' ' not in entry['title'])):
                    entry['title'] = real_title
                    updated = True
                if real_thumb and not entry.get('thumb'):
                    entry['thumb'] = real_thumb
                    updated = True
                if real_dur and not entry.get('duration'):
                    entry['duration'] = real_dur
                    updated = True
        if updated:
            _wh._save(history)

    xbmcplugin.setContent(h, 'videos')
    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    for idx, entry in enumerate(entries_to_show):
        vid = entry.get('vid', '')
        vt = entry.get('title', 'Video')
        dth = entry.get('thumb', '') or ai
        du = entry.get('duration', 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0

        # Si la API devolvió datos reales para este vídeo, sobreescribir los del historial
        if vid in resolved:
            info = resolved[vid]
            vt = info.get("title", vt) or vt
            dth = info.get("thumbnail_720_url") or info.get("thumbnail_url", "") or dth
            try: du = int(info.get("duration", du))
            except (ValueError, TypeError): pass

        label = "[COLOR gold]{0}.[/COLOR] {1}".format(idx + 1, vt)
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': dth, 'icon': dth})
        plot = "Acceso rápido a tus vídeos recientes."
        if du: plot += "\nDuración: {0}m {1}s".format(du // 60, du % 60)
        li.setInfo('video', {'title': vt, 'plot': plot, 'duration': du})
        li.setProperty("IsPlayable", "true")
        cm = []
        cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action='download_video', vid=vid, title=vt))))
        cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action='dm_open_browser', url=vid))))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vid)))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vid), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR red][B]Limpiar lista de lo más visto[/B][/COLOR]")
    li.setArt({'icon': 'DefaultIconError.png'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="clear_most_watched"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)






def _show_trending():
    h = int(sys.argv[1])
    try:
        time_limit = int(time.time()) - 604800
        params = {
            "sort": "trending", "language": "es", "created_after": time_limit,
            "limit": 50,
            "fields": "id,title,thumbnail_720_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"
        }
        resp = requests.get("https://api.dailymotion.com/videos", params=params, timeout=15)
        rs = resp.json().get("list", [])
        if not rs:
            xbmcgui.Dialog().ok("Tendencias", "No se han encontrado vídeos en tendencia.")
            xbmcplugin.endOfDirectory(h); return
        xbmcplugin.setContent(h, 'videos')
        watched_ids = _wh.get_watched_ids()
        addon = xbmcaddon.Addon()
        ai = addon.getAddonInfo('icon')
        for i, v in enumerate(rs):
            vt = v.get("title", "Video")
            vi = v.get("id")
            ow = v.get("owner.screenname") or v.get("owner.username", "")
            du = 0
            try: du = int(v.get("duration", 0))
            except (ValueError, TypeError): pass
            vw = 0
            try: vw = int(v.get("views_total", 0))
            except (ValueError, TypeError): pass
            dth = v.get("thumbnail_720_url") or v.get("thumbnail_url") or ai
            is_watched = vi in watched_ids if vi else False
            watched_mark = "[COLOR lime][V][/COLOR] " if is_watched else ""
            label = "[COLOR orange]{0}.[/COLOR] {1}{2}".format(i + 1, watched_mark, vt)
            li = xbmcgui.ListItem(label=label)
            li.setArt({'thumb': dth, 'icon': dth})
            li.setInfo('video', {'title': vt, 'plot': "Canal: {0}\nVistas: {1:,}\nDuración: {2}m {3}s".format(ow, vw, du // 60, du % 60), 'duration': du})
            li.setProperty("IsPlayable", "true")
            cm = []
            if vi:
                cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action="download_video", vid=vi, title=vt))))
                cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action="dm_open_browser", url=vi))))
                cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vi)))))
                fav_params = json.dumps({"q": vt, "ot": dth})
                cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(_u(action='add_favorite', title=vt, fav_url='lfr_{0}'.format(vi), icon=dth, platform='tendencias', fav_action='lfr', params=fav_params))))
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
    except (requests.RequestException, ValueError) as e:
        xbmcgui.Dialog().ok("Error", "Error al cargar tendencias:\n{0}".format(str(e)))
        try:
            xbmcplugin.endOfDirectory(h)
        except RuntimeError:
            pass




def _multi_search():
    kb = xbmc.Keyboard('', 'Términos separados por comas')
    kb.doModal()
    if not kb.isConfirmed(): return
    raw = kb.getText().strip()
    if not raw: return
    terms = [t.strip() for t in raw.split(',') if t.strip()]
    if not terms:
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron términos válidos", xbmcgui.NOTIFICATION_WARNING)
        return
    if len(terms) > 10:
        terms = terms[:10]
        xbmcgui.Dialog().notification("EspaTV", "Limitado a 10 términos", xbmcgui.NOTIFICATION_INFO)
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Búsqueda Múltiple", "Buscando {0} términos...".format(len(terms)))
    all_results = []
    seen_ids = set()
    try:
        for idx, term in enumerate(terms):
            if dp.iscanceled(): break
            dp.update(int((idx / len(terms)) * 100), "Buscando: {0}".format(term))
            try:
                params = {"search": term, "sort": "relevance", "language": "es", "limit": 10,
                          "fields": "id,title,thumbnail_720_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"}
                resp = requests.get("https://api.dailymotion.com/videos", params=params, timeout=15)
                for item in resp.json().get("list", []):
                    vid = item.get("id", "")
                    if vid and vid not in seen_ids:
                        seen_ids.add(vid)
                        all_results.append((term, item))
            except (requests.RequestException, ValueError):
                pass
    finally:
        dp.close()
    if not all_results:
        xbmcgui.Dialog().ok("Búsqueda Múltiple", "No se encontraron resultados para ningún término.")
        xbmcplugin.endOfDirectory(h); return
    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    for term, item in all_results:
        vid = item.get("id", "")
        title = item.get("title", "Sin título")
        thumb = item.get("thumbnail_720_url") or item.get("thumbnail_url", "") or ai
        dur = 0
        try: dur = int(item.get("duration", 0))
        except (ValueError, TypeError): pass
        owner = item.get("owner.screenname") or item.get("owner.username", "")
        views = 0
        try: views = int(item.get("views_total", 0))
        except (ValueError, TypeError): pass
        dur_min = dur // 60 if dur else 0
        label = "[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(title, term)
        if dur_min: label += " [COLOR cyan]{0}min[/COLOR]".format(dur_min)
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb, 'thumb': thumb})
        li.setInfo('video', {'plot': "Canal: {0}\nBúsqueda: {1}\nDuración: {2}min\nVisitas: {3:,}".format(owner, term, dur_min, views), 'duration': dur})
        li.setProperty("IsPlayable", "true")
        cm = []
        cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action='download_video', vid=vid, title=title))))
        cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action='dm_open_browser', url=vid))))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vid)))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vid), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)
    xbmcgui.Dialog().notification("Búsqueda Múltiple", "{0} resultados de {1} términos".format(len(all_results), len(terms)))




def _dm_open_browser(vid):
    vid = str(vid).replace('"', '').replace("'", '').strip() if vid else ""
    if not vid: return
    url = "https://www.dailymotion.com/video/{0}".format(vid)
    try:
        if xbmc.getCondVisibility("System.Platform.Android"):
            xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","","{0}")'.format(url))
        else:
            import webbrowser
            webbrowser.open(url)
        xbmcgui.Dialog().notification("EspaTV", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
    except (ImportError, OSError):
        xbmcgui.Dialog().ok("Abrir en navegador", "No se pudo abrir automáticamente.\n\nAbre esta URL:\n{0}".format(url))


def _copy_url(url):
    url = str(url).strip() if url else ""
    if not url:
        return
    try:
        xbmcgui.Window(10000).setProperty("espatv.clipboard.url", url)
    except (RuntimeError, AttributeError):
        xbmc.log("EspaTV: Fallo al escribir en portapapeles (Window 10000 unavailable).", xbmc.LOGWARNING)
        return
    display = (url[:60] + "...") if len(url) > 60 else url
    xbmcgui.Dialog().notification(
        "EspaTV", "URL copiada: {0}".format(display),
        xbmcgui.NOTIFICATION_INFO, 2500
    )


def _open_flowfav():
    if xbmc.getCondVisibility("System.HasAddon(plugin.program.flowfavmanager)"):
        xbmc.executebuiltin("RunAddon(plugin.program.flowfavmanager)")
    else:
        xbmcgui.Dialog().ok("EspaTV",
            "Flow FavManager no está instalado.\n\n"
            "Descárgalo desde:\nhttps://github.com/loioloio/flowfav")

def _open_loiolog():
    if xbmc.getCondVisibility("System.HasAddon(plugin.program.loiolog)"):
        xbmc.executebuiltin("RunAddon(plugin.program.loiolog)")
    else:
        xbmcgui.Dialog().ok("EspaTV",
            "LoioLog no está instalado.\n\n"
            "Descárgalo desde:\nhttps://github.com/loioloio/loiolog")

def _open_atresdaily():
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.atresdaily)"):
        xbmc.executebuiltin("RunAddon(plugin.video.atresdaily)")
    else:
        xbmcgui.Dialog().ok("AtresDaily",
            "AtresDaily no está instalado.\n\n"
            "Para instalarlo:\n"
            "1. Ajustes > Explorador de archivos > Añadir fuente\n"
            "2. Escribe: https://fullstackcurso.github.io/atresdaily/\n"
            "3. Instalar desde ZIP > atresdaily > repository.atresdaily-1.0.1.zip\n"
            "4. Instalar desde repositorio > AtresDaily Repository")

def _open_espadaily():
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.espadaily)"):
        xbmc.executebuiltin("RunAddon(plugin.video.espadaily)")
    else:
        xbmcgui.Dialog().ok("EspaDaily",
            "EspaDaily no está instalado.\n\n"
            "Para instalarlo:\n"
            "1. Ajustes > Explorador de archivos > Añadir fuente\n"
            "2. Escribe: https://fullstackcurso.github.io/espadaily/\n"
            "3. Instalar desde ZIP > espadaily > repository.espadaily-1.0.2.zip\n"
            "4. Instalar desde repositorio > EspaDaily Repository")

def _set_cache_config():
    cfg = _load_dm_settings()
    current = cfg.get('cache_expiry', 0)
    options = [
        "Apagado" + (" [ACTIVO]" if current == 0 else ""),
        "1 día" + (" [ACTIVO]" if current == 86400 else ""),
        "1 semana" + (" [ACTIVO]" if current == 604800 else ""),
        "1 mes" + (" [ACTIVO]" if current == 2592000 else ""),
        "Indefinido" + (" [ACTIVO]" if current == -1 else ""),
    ]
    vals = [0, 86400, 604800, 2592000, -1]
    sel = xbmcgui.Dialog().select("Duración de la caché", options)
    if sel < 0: return
    cfg['cache_expiry'] = vals[sel]
    _save_dm_settings(cfg)
    xbmcgui.Dialog().notification("EspaTV", "Caché: {0}".format(options[sel].replace(" [ACTIVO]", "")), xbmcgui.NOTIFICATION_INFO)

def _toggle_iptv_cache():
    current = core_settings.is_iptv_cache_active()
    new_state = not current
    core_settings.set_iptv_cache_active(new_state)
    if new_state:
        xbmcgui.Dialog().notification("EspaTV", "Caché IPTV ACTIVADA", xbmcgui.NOTIFICATION_INFO)
    else:
        core_settings.clear_iptv_cache_files()
        xbmcgui.Dialog().notification("EspaTV", "Caché IPTV DESACTIVADA", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _set_iptv_cache_ttl_dialog():
    options = []
    current_ttl = core_settings.get_iptv_cache_ttl()
    for val, name in core_settings._IPTV_CACHE_TTL_OPTIONS:
        if val == 0:
            continue  # no mostrar "Desactivada", para eso está el toggle
        label = name
        if val == current_ttl:
            label += " [ACTIVO]"
        options.append((val, label))
    sel = xbmcgui.Dialog().select("Duración de caché IPTV", [o[1] for o in options])
    if sel < 0:
        return
    core_settings.set_iptv_cache_ttl(options[sel][0])
    core_settings.clear_iptv_cache_files()  # limpiar al cambiar TTL
    xbmcgui.Dialog().notification("EspaTV", "Caché: {0}".format(options[sel][1].replace(" [ACTIVO]", "")), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _reset_iptv_cache():
    if not xbmcgui.Dialog().yesno("EspaTV",
        "¿Restaurar la caché IPTV por defecto?\n\n"
        "Se desactivará la caché y se borrarán "
        "todos los archivos guardados.\n"
        "Los canales se descargarán de internet cada vez que entres, como venía de fábrica."):
        return
    core_settings.reset_iptv_cache_defaults()
    xbmcgui.Dialog().notification("EspaTV", "Caché restaurada por defecto", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _set_download_path():
    path = xbmcgui.Dialog().browse(0, 'Seleccionar carpeta de descargas', 'files')
    if not path: return
    cfg = _load_dm_settings()
    cfg['download_path'] = path
    _save_dm_settings(cfg)
    xbmcgui.Dialog().notification("EspaTV", "Ruta configurada", xbmcgui.NOTIFICATION_INFO)














def _load_dm_settings():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    sp = os.path.join(p, 'dm_settings.json')
    if not os.path.exists(sp):
        return {}
    try:
        with open(sp, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}

def _save_dm_settings(cfg):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    sp = os.path.join(p, 'dm_settings.json')
    try:
        with open(sp, 'w', encoding='utf-8') as f:
            json.dump(cfg, f, ensure_ascii=False)
    except IOError:
        pass

def _set_dm_safe_level():
    options = [
        "Desactivado (Conexión Normal)",
        "Básico (Móvil + Cookies)",
        "Extremo (Todas las técnicas de Gujal00)",
        "YT-DLP (TLS Spoofing - Recomendado en PC)"
    ]
    cfg = _load_dm_settings()
    current = cfg.get('dm_safe_level', 0)
    
    sel = xbmcgui.Dialog().select("Modo Anti-Errores Dailymotion", options, preselect=current)
    if sel >= 0:
        if sel == 3:
            try:
                import yt_dlp
                xbmc.log(f"[EspaTV] yt-dlp v{yt_dlp.version.__version__} disponible", xbmc.LOGINFO)
            except ImportError:
                xbmcgui.Dialog().ok("EspaTV", "yt-dlp no está instalado.\n\nInstálalo con:\npip install yt-dlp curl-cffi")
                return
        cfg['dm_safe_level'] = sel
        _save_dm_settings(cfg)
        xbmcgui.Dialog().notification("EspaTV", f"Modo Anti-Errores DM: {options[sel].split(' (')[0]}")
        xbmc.executebuiltin("Container.Refresh")

def _set_dl_mode():
    opts = [
        "Nivel 1: DIRECTO (Elegir calidad)", 
        "Nivel 2: SAFE MODE (Mejor MP4 directo)", 
        "Nivel 3: EspaTV (Descargar por HLS)",
        "Nivel 4: YT-DLP (Mejor calidad, Python 3.10+)",
        "Nivel 5: ULTRA (Mejor calidad, Python 3.10+)"
    ]
    cfg = _load_dm_settings()
    current = cfg.get('dl_mode', 0)
    idx = xbmcgui.Dialog().select("Modo de Descarga", opts, preselect=current)
    if idx >= 0:
        cfg['dl_mode'] = idx
        _save_dm_settings(cfg)
        xbmcgui.Dialog().notification("EspaTV", f"Modo descarga: Nivel {idx+1} guardado")
        xbmc.executebuiltin("Container.Refresh")

def _dm_playlists_search():
    kb = xbmc.Keyboard("", "Buscar canal de Dailymotion")
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return
    channels = _dm_search_channels(query)
    if not channels:
        xbmcgui.Dialog().ok("EspaTV", "No se encontraron canales para: " + query)
        return
    h = int(sys.argv[1])
    for ch in channels:
        name = ch.get("screenname") or ch.get("username", "Canal")
        user = ch.get("username", "")
        li = xbmcgui.ListItem(label=name)
        li.setArt({'icon': 'DefaultActor.png'})
        li.setInfo('video', {'plot': "Usuario: " + user})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="dm_user_playlists", user=user),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)

def _dm_user_playlists(user):
    if not user:
        return
    playlists = _dm_list_user_playlists(user)
    if not playlists:
        xbmcgui.Dialog().ok("EspaTV", "Este canal no tiene playlists.")
        return
    h = int(sys.argv[1])
    for pl in playlists:
        name = pl.get("name", "Playlist")
        count = pl.get("count", 0)
        label = "{0} ({1} videos)".format(name, count) if count else name
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultVideoPlaylists.png'})
        desc = pl.get("description", "")
        if desc:
            li.setInfo('video', {'plot': desc})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="dm_view_playlist", pid=pl.get("id")),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)

def _dm_view_playlist(pid):
    if not pid:
        return
    videos = _dm_view_playlist_api(pid)
    if not videos:
        xbmcgui.Dialog().ok("EspaTV", "No se encontraron videos en esta playlist.")
        return
    h = int(sys.argv[1])
    for v in videos:
        vid = v.get("id")
        if not vid:
            continue
        tt = v.get("title", "Video")
        th = v.get("thumbnail_720_url", "")
        dur = v.get("duration", 0)
        owner = v.get("owner.screenname", "")
        li = xbmcgui.ListItem(label=tt)
        li.setArt({'thumb': th, 'icon': th})
        info = {'title': tt, 'duration': dur}
        if owner:
            info['plot'] = "Canal: " + owner
        li.setInfo('video', info)
        li.setProperty("IsPlayable", "true")
        cm = []
        cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action='download_video', vid=vid, title=tt))))
        cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action='dm_open_browser', url=vid))))
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vid)))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="pv", vid=vid),
            listitem=li, isFolder=False,
        )
    xbmcplugin.endOfDirectory(h)

def _search_external_prompt(query):
    if not query:
        return
    options = []
    actions = []


    if xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        options.append("Buscar en addon Dailymotion (Gujal)")
        actions.append(("dm_gujal_search", query))

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        options.append("Buscar en YouTube")
        actions.append(("youtube_search", query))

    if not options:
        xbmcgui.Dialog().ok(
            "EspaTV",
            "No hay addons de terceros instalados.\n\n"
            "Addons compatibles:\n"
            u"  • Dailymotion (Gujal)\n"
            u"  • YouTube",
        )
        return

    sel = xbmcgui.Dialog().select(
        u"¿Dónde quieres buscar '{0}'?".format(query), options
    )
    if sel < 0:
        return

    action_name, q = actions[sel]
    if action_name == "dm_gujal_search":
        _search_dailymotion_gujal(q)
    elif action_name == "youtube_search":
        yt_url = "plugin://plugin.video.youtube/kodion/search/query/?q=" + urllib.parse.quote(q)
        xbmc.executebuiltin('Container.Update("{0}")'.format(yt_url))

def _search_dailymotion_gujal(query):
    if not query:
        return
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        xbmcgui.Dialog().ok("EspaTV", "El addon Dailymotion de Gujal no está instalado.")
        return
    url = "plugin://plugin.video.dailymotion_com/?action=search&query=" + urllib.parse.quote(query)
    xbmc.executebuiltin('Container.Update("{0}")'.format(url))

def _get_system_clipboard_text():
    try:
        import ctypes
        import ctypes.wintypes
        CF_UNICODETEXT = 13
        _gcd = ctypes.windll.user32.GetClipboardData
        _gcd.restype = ctypes.c_void_p
        _gcd.argtypes = [ctypes.wintypes.UINT]
        _gl = ctypes.windll.kernel32.GlobalLock
        _gl.restype = ctypes.c_void_p
        _gl.argtypes = [ctypes.c_void_p]
        _gu = ctypes.windll.kernel32.GlobalUnlock
        _gu.argtypes = [ctypes.c_void_p]
        if not ctypes.windll.user32.OpenClipboard(None):
            return ""
        try:
            handle = _gcd(CF_UNICODETEXT)
            if not handle:
                return ""
            ptr = _gl(handle)
            if not ptr:
                return ""
            try:
                return ctypes.wstring_at(ptr).strip()
            finally:
                _gu(handle)
        finally:
            ctypes.windll.user32.CloseClipboard()
    except Exception:
        return ""


def _elementum_search_prompt():
    opciones = ["Escribir búsqueda", "Pegar desde portapapeles", "Desde móvil/PC", "Ver descargas (P2P - torrents)"]
    eleccion = xbmcgui.Dialog().select("Buscar torrents", opciones)
    if eleccion == 0:
        kb = xbmc.Keyboard("", "Buscar torrents en Elementum")
        kb.doModal()
        if kb.isConfirmed() and kb.getText().strip():
            _search_elementum(kb.getText().strip())
    elif eleccion == 1:
        texto = _get_system_clipboard_text()
        if not texto:
            xbmcgui.Dialog().ok("Portapapeles vacío",
                "El portapapeles no contiene texto.\n\n"
                "Copia primero el título que quieres buscar.")
            return
        kb = xbmc.Keyboard(texto, "Buscar torrents en Elementum")
        kb.doModal()
        if kb.isConfirmed() and kb.getText().strip():
            _search_elementum(kb.getText().strip())
    elif eleccion == 2:
        import url_remote
        query = url_remote.receive_text("Buscar torrents en Elementum")
        if query:
            _search_elementum(query)
    elif eleccion == 3:
        xbmc.executebuiltin("Container.Update(plugin://plugin.video.elementum/torrents/)")


def _search_elementum(query):
    if not query:
        return
    
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
        xbmcgui.Dialog().ok("EspaTV", 
            "El addon Elementum no está instalado.\n\n"
            "Esta función requiere Elementum para buscar torrents en webs como 1337x, RARBG, etc.\n\n"
            "Puedes instalarlo desde el repositorio oficial de Kodi o desde GitHub.")
        return
    
    # Abrir búsqueda en Elementum
    elementum_url = "plugin://plugin.video.elementum/search?q={0}".format(urllib.parse.quote(query))
    xbmc.executebuiltin("Container.Update({0})".format(elementum_url))

def _search_youtube_from_results(query):
    if not query:
        return
    kb = xbmc.Keyboard(query, 'Buscar en YouTube')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        q = kb.getText().strip()
        if q:
            _yts._add_yt_to_history(q)
            xbmc.executebuiltin(f"Container.Update({_u(action='yt_search_results', query=q)})")


_RUNADDON_RE = re.compile(r'RunAddon\s*\(\s*"?([\w.\-]+)"?\s*\)', re.IGNORECASE)
_PLUGIN_URL_RE = re.compile(r'plugin://([\w.\-]+)', re.IGNORECASE)


def _shortcut_addon_id(sc):
    aid = sc.get('addon_id') or ''
    if aid:
        return aid
    cmd = sc.get('command') or ''
    m = _RUNADDON_RE.search(cmd) or _PLUGIN_URL_RE.search(cmd)
    return m.group(1) if m else ''


# Opciones fijas del diálogo "¿Dónde buscar?". El orden de inserción = orden por
# defecto. Solo etiqueta estática; la condición de visibilidad por llamada (tmdb_id,
# mode, addons instalados, settings) se calcula inline en el diálogo, no aquí.
_SEARCH_OPTIONS_MASTER = {
    'espadaily':       {'label': "[COLOR violet]Buscar en EspaDaily[/COLOR]"},
    'topzilla':        {'label': "[COLOR yellow]Buscar en TopZilla[/COLOR]"},
    'watch_providers': {'label': "[COLOR cyan]¿Dónde ver en España?[/COLOR]"},
    'tmdbhelper':      {'label': "[COLOR plum]Ver en otro addon[/COLOR]"},
    'dm_espatv':       {'label': "[COLOR dodgerblue]Buscar en Dailymotion (EspaTV)[/COLOR]"},
    'youtube':         {'label': "[COLOR red]Buscar en YouTube[/COLOR]"},
    'edit':            {'label': "[COLOR orange]Editar búsqueda y reintentar[/COLOR]"},
    'clipboard':       {'label': "[COLOR limegreen]Copiar título al portapapeles[/COLOR]"},
    'archive':         {'label': "[COLOR gold]Internet Archive[/COLOR]"},
    'elementum':       {'label': "[COLOR tomato]Torrents P2P (Elementum)[/COLOR]"},
    'dm_gujal':        {'label': "[COLOR deepskyblue]Buscar en Dailymotion (Gujal)[/COLOR]"},
    'debrid':          {'label': "[COLOR aquamarine]Buscar en mi nube (Debrid)[/COLOR]"},
}


def _compute_search_layout(saved_layout, shortcuts, legacy_order):
    """Puro, sin I/O. Devuelve (order, hidden_set) del diálogo de búsqueda.
    defaults = opciones fijas (orden del registro) + sc:<name> (los atajos, ordenados
    por la semilla legacy para que la apariencia por defecto sea la de hoy)."""
    if legacy_order:
        idx = {n: i for i, n in enumerate(legacy_order)}
        shortcuts = sorted(shortcuts, key=lambda sc: idx.get(sc['name'], 10 ** 6))
    defaults = list(_SEARCH_OPTIONS_MASTER) + [f"sc:{sc['name']}" for sc in shortcuts]
    valid = set(defaults)
    order = _ordered_merge(saved_layout.get('order', []), defaults, valid)
    hidden = {h for h in saved_layout.get('hidden', []) if h in valid}
    return order, hidden


def _search_effective_order(shortcuts):
    return _compute_search_layout(
        core_settings.load_search_dialog_layout(),
        shortcuts,
        core_settings.load_search_shortcuts_order(),
    )


def _search_alternatives_prompt(query, ot='', mode='', on_navigate=None,
                                tmdb_id='', season='', episode=''):
    opciones = []
    acciones = []

    # tmdb_id vía TMDB Helper (instalado y habilitado). Película y episodio
    # concreto se reproducen; serie sin episodio abre el navegador de temporadas
    # (info=seasons) para elegir allí. AddonIsEnabled (no HasAddon): RunPlugin no
    # ejecuta un addon deshabilitado.
    try:
        _n = int(tmdb_id)
        _tmdb = str(_n) if _n > 0 else ''
    except (ValueError, TypeError):
        _tmdb = ''
    es_serie = mode in ('show', 'tv')
    _season = _episode = None
    tmdbh_ok = False
    tmdbh_browse = False
    if _tmdb and xbmc.getCondVisibility('System.AddonIsEnabled(plugin.video.themoviedb.helper)'):
        if not es_serie:
            tmdbh_ok = True
        else:
            try:
                _season, _episode = int(season or 0), int(episode)
            except (ValueError, TypeError):
                _season = _episode = None
            tmdbh_ok = True
            tmdbh_browse = not (_episode and _episode >= 1)

    # Disponibilidad por llamada de las opciones fijas. Las siempre-visibles no
    # dependen del contexto; las condicionales se añaden según tmdb_id/mode/addons/settings.
    available_fixed = {'watch_providers', 'dm_espatv', 'youtube', 'edit', 'clipboard', 'archive', 'elementum'}
    if (core_settings.is_espadaily_integration_enabled()
            and xbmc.getCondVisibility("System.HasAddon(plugin.video.espadaily)")):
        available_fixed.add('espadaily')
    if (core_settings.is_topzilla_integration_enabled()
            and xbmc.getCondVisibility("System.HasAddon(plugin.video.topzilla)")):
        available_fixed.add('topzilla')
    if tmdbh_ok:
        available_fixed.add('tmdbhelper')
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        available_fixed.add('dm_gujal')
    # Un fallo aquí no debe tumbar el resto del diálogo de búsqueda.
    try:
        import url_player
        if url_player._debrid_active():
            available_fixed.add('debrid')
    except Exception as e:
        xbmc.log(f"[EspaTV] gate debrid en búsqueda: {e}", xbmc.LOGWARNING)

    shortcuts = core_settings.load_search_shortcuts()
    sc_by_name = {sc['name']: sc for sc in shortcuts}
    order, hidden = _search_effective_order(shortcuts)
    for key in order:
        if key in hidden:
            continue
        if key.startswith('sc:'):
            sc = sc_by_name.get(key[3:])
            if not sc:
                continue
            aid = _shortcut_addon_id(sc)
            if aid and not xbmc.getCondVisibility(f"System.HasAddon({aid})"):
                lbl = f"[COLOR grey]{sc['name']} (no instalado)[/COLOR]"
            else:
                lbl = f"[COLOR gold]{sc['name']}[/COLOR]"
            opciones.append(lbl)
            acciones.append(key)
        elif key in available_fixed:
            opciones.append(_SEARCH_OPTIONS_MASTER[key]['label'])
            acciones.append(key)

    if not opciones:
        xbmcgui.Dialog().notification("EspaTV", "Tienes todas las opciones ocultas. Restáuralas en Atajos «¿Dónde buscar?»", xbmcgui.NOTIFICATION_INFO, 4000)
        return

    sel = xbmcgui.Dialog().select(f"¿Dónde quieres buscar '{query}'?", opciones)
    if sel < 0:
        return
    accion = acciones[sel]

    def _nav():
        # Cierra el Modo Cine (si fue quien abrió el menú) antes de navegar,
        # para que el resultado no quede tapado por su ventana modal.
        if on_navigate:
            on_navigate()

    if accion == "watch_providers":
        _show_watch_providers(query, '')
    elif accion == "tmdbhelper":
        _nav()
        if tmdbh_browse:
            url = f'plugin://plugin.video.themoviedb.helper/?info=seasons&tmdb_type=tv&tmdb_id={_tmdb}'
            xbmc.executebuiltin(f'Container.Update({url})')
        else:
            url = f'plugin://plugin.video.themoviedb.helper/?info=play&tmdb_type={"tv" if es_serie else "movie"}&tmdb_id={_tmdb}'
            if es_serie:
                url += f'&season={_season}&episode={_episode}'
            xbmc.executebuiltin(f'RunPlugin({url})')
    elif accion == "dm_gujal":
        _nav()
        _search_dailymotion_gujal(query)
    elif accion == "debrid":
        import url_player
        resolver = url_player._get_debrid()
        if resolver is None:
            xbmcgui.Dialog().notification("EspaTV", "Debrid no disponible", xbmcgui.NOTIFICATION_WARNING, 2500)
            return
        try:
            items = resolver.list_library()
        except Exception as e:
            xbmc.log(f"[EspaTV/Debrid] búsqueda nube: {e}", xbmc.LOGWARNING)
            items = []
        q_low = query.lower()
        matches = [it for it in items if it.get("ready") and q_low in (it.get("filename") or "").lower()]
        if not matches:
            xbmcgui.Dialog().notification("EspaTV", f"Sin coincidencias en tu nube para '{query}'", xbmcgui.NOTIFICATION_INFO, 3000)
            return
        if len(matches) == 1:
            chosen = matches[0]
        else:
            labels = [f"{it.get('filename', '?')}  ({(it.get('size', 0) or 0) / 1e9:.2f} GB)" for it in matches]
            idx = xbmcgui.Dialog().select(f"Tu nube: resultados para '{query}'", labels)
            if idx < 0:
                return
            chosen = matches[idx]
        _nav()
        url_player.debrid_library_play(chosen.get("id"))
    elif accion == "dm_espatv":
        _nav()
        xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=query, ot=ot)})")
    elif accion == "youtube":
        _nav()
        _search_youtube_from_results(query)
    elif accion == "edit":
        kb = xbmc.Keyboard(query, 'Editar Búsqueda')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            _nav()
            xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=kb.getText(), ot=ot)})")
    elif accion == "clipboard":
        if _copy_to_clipboard(query):
            xbmcgui.Dialog().notification("EspaTV", f"'{query}' copiado al portapapeles", xbmcgui.NOTIFICATION_INFO, 2500)
        else:
            xbmcgui.Dialog().notification("EspaTV", "No se pudo copiar al portapapeles", xbmcgui.NOTIFICATION_WARNING, 2000)
    elif accion == "archive":
        archive_q = 'mediatype:movies AND title:({0})'.format(re.sub(r'[()[\]{}]', '', query))
        _nav()
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='archive_category', q=archive_q, page=1)))
    elif accion == "elementum":
        kb = xbmc.Keyboard(query, 'Buscar en Elementum')
        kb.doModal()
        if kb.isConfirmed() and kb.getText().strip():
            _nav()
            _search_elementum(kb.getText().strip())
    elif accion == "espadaily":
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.espadaily)"):
            xbmcgui.Dialog().notification("EspaTV", "EspaDaily no está instalado", xbmcgui.NOTIFICATION_WARNING, 2500)
            return
        eda_params = {'action': 'search_alt_prompt', 'q': query}
        if ot:
            eda_params['ot'] = ot
        eda_url = "plugin://plugin.video.espadaily/?" + urllib.parse.urlencode(eda_params)
        _nav()
        xbmc.executebuiltin(f'RunPlugin({eda_url})')
    elif accion == "topzilla":
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.topzilla)"):
            xbmcgui.Dialog().notification("EspaTV", "TopZilla no está instalado", xbmcgui.NOTIFICATION_WARNING, 2500)
            return
        tz_mode = 'movie' if mode == 'movie' else 'show'
        tz_params = {'action': 'search_alt_prompt', 'q': query, 'mode': tz_mode}
        if ot:
            tz_params['ot'] = ot
        tz_url = "plugin://plugin.video.topzilla/?" + urllib.parse.urlencode(tz_params)
        _nav()
        xbmc.executebuiltin(f'RunPlugin({tz_url})')
    elif accion.startswith("sc:"):
        sc = sc_by_name.get(accion[3:])
        if not sc:
            return
        aid = _shortcut_addon_id(sc)
        if aid and not xbmc.getCondVisibility(f"System.HasAddon({aid})"):
            xbmcgui.Dialog().notification("EspaTV", f"'{sc['name']}' no está instalado", xbmcgui.NOTIFICATION_WARNING, 2500)
            return
        # {mode} normalizado a movie/tv (los orígenes pasan 'show' o 'tv'
        # indistintamente); vacío si el tipo no se conoce.
        mode_token = ('tv' if es_serie else 'movie') if mode else ''
        cmd = ((sc.get('command') or '')
               .replace('{query}', urllib.parse.quote(query, safe=''))
               .replace('{queryraw}', query)
               .replace('{tmdb_id}', _tmdb)
               .replace('{mode}', mode_token))
        _nav()
        xbmc.executebuiltin(cmd)


def _search_options_manager():
    """Reordena y oculta TODAS las opciones del diálogo «¿Dónde buscar?» (fijas y
    atajos del usuario) en un único bucle modal. Los cambios se guardan al instante."""
    shortcuts = core_settings.load_search_shortcuts()
    sc_by_name = {sc['name']: sc for sc in shortcuts}

    def _label(key):
        if key.startswith('sc:'):
            sc = sc_by_name.get(key[3:])
            return sc['name'] if sc else key[3:]
        defn = _SEARCH_OPTIONS_MASTER.get(key)
        return defn['label'] if defn else key

    while True:
        order, hidden = _search_effective_order(shortcuts)
        labels = []
        for i, key in enumerate(order):
            arrows = ('↑ ' if i > 0 else '') + ('↓' if i < len(order) - 1 else '')
            tag = " [COLOR grey][oculto][/COLOR]" if key in hidden else ""
            labels.append((f"{arrows} " if arrows else "") + _label(key) + tag)
        labels.append("[COLOR orange]Restaurar orden y visibilidad por defecto[/COLOR]")

        sel = xbmcgui.Dialog().select("Reordenar / ocultar opciones (se guarda al instante)", labels)
        if sel < 0:
            return
        if sel == len(order):
            if xbmcgui.Dialog().yesno("EspaTV", "¿Restaurar el orden y la visibilidad por defecto?"):
                core_settings.reset_search_dialog_layout()
                core_settings.reset_search_shortcuts_order()
                xbmcgui.Dialog().notification("EspaTV", "Opciones restauradas", xbmcgui.NOTIFICATION_INFO, 1500)
                return
            continue

        key = order[sel]
        opts = []
        if sel > 0:
            opts.append(('up', "↑ Subir"))
        if sel < len(order) - 1:
            opts.append(('down', "↓ Bajar"))
        opts.append(('show', "Mostrar") if key in hidden else ('hide', "Ocultar"))
        opts.append(('cancel', "Cancelar"))
        choice = xbmcgui.Dialog().select(_label(key), [o[1] for o in opts])
        if choice < 0 or opts[choice][0] == 'cancel':
            continue
        act = opts[choice][0]
        if act in ('up', 'down'):
            j = sel + (-1 if act == 'up' else 1)
            order[sel], order[j] = order[j], order[sel]
        elif act == 'hide':
            hidden.add(key)
        elif act == 'show':
            hidden.discard(key)
        core_settings.save_search_dialog_layout({'order': order, 'hidden': sorted(hidden)})


def _search_shortcut_add_addon():
    addons = []
    for addon_type in ('xbmc.addon.video', 'xbmc.addon.audio', 'xbmc.addon.image', 'xbmc.addon.executable'):
        try:
            req = json.dumps({
                'jsonrpc': '2.0', 'method': 'Addons.GetAddons',
                'params': {'type': addon_type, 'enabled': True, 'properties': ['name', 'thumbnail']},
                'id': 1,
            })
            data = json.loads(xbmc.executeJSONRPC(req) or '{}')
            addons += (data.get('result') or {}).get('addons') or []
        except Exception:
            pass

    own_id = xbmcaddon.Addon().getAddonInfo('id')
    seen = set()
    unique = []
    for a in addons:
        if not isinstance(a, dict):
            continue
        aid = a.get('addonid')
        if not aid or aid == own_id or aid in seen:
            continue
        seen.add(aid)
        unique.append(a)
    unique.sort(key=lambda x: (x.get('name') or '').lower())

    if not unique:
        xbmcgui.Dialog().notification('EspaTV', 'No se encontraron addons instalados', xbmcgui.NOTIFICATION_INFO, 3000)
        return

    names = [a.get('name') or a.get('addonid', '') for a in unique]
    sel = xbmcgui.Dialog().select('Seleccionar addon para añadir como atajo', names)
    if sel < 0:
        return

    addon = unique[sel]
    addon_id = addon.get('addonid', '')
    if not addon_id:
        return
    name = (addon.get('name') or addon_id).strip()
    thumb = addon.get('thumbnail') if isinstance(addon.get('thumbnail'), str) else 'DefaultAddonVideo.png'
    command = f'RunAddon("{addon_id}")'

    shortcuts = core_settings.load_search_shortcuts()
    for sc in shortcuts:
        if sc.get('addon_id') == addon_id or sc.get('command') == command:
            xbmcgui.Dialog().notification('EspaTV', 'Este addon ya está en los atajos', xbmcgui.NOTIFICATION_INFO, 2000)
            return
    if any(sc.get('name') == name for sc in shortcuts):
        xbmcgui.Dialog().notification('EspaTV', 'Ya existe un atajo con ese nombre', xbmcgui.NOTIFICATION_INFO, 2000)
        return

    shortcuts.append({'name': name, 'icon': thumb, 'command': command, 'addon_id': addon_id})
    core_settings.save_search_shortcuts(shortcuts)
    xbmcgui.Dialog().notification('EspaTV', f'Atajo añadido: {name}', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _search_shortcut_add_manual():
    via_red = xbmcgui.Dialog().yesno(
        'Añadir comando manual',
        'Escribir nombre y comando con:',
        nolabel='Teclado Kodi', yeslabel='Red local'
    )
    if via_red:
        import url_remote
        name = (url_remote.receive_text('Nombre del atajo (red local)') or '').strip()
        if not name:
            return
        command = (url_remote.receive_text('Comando (RunAddon, RunPlugin...) (red local)') or '').strip()
        if not command:
            return
    else:
        kb = xbmc.Keyboard('', 'Nombre del atajo')
        kb.doModal()
        if not kb.isConfirmed():
            return
        name = kb.getText().strip()
        if not name:
            return
        kb2 = xbmc.Keyboard('', 'Comando (RunAddon, RunPlugin, ActivateWindow...)')
        kb2.doModal()
        if not kb2.isConfirmed():
            return
        command = kb2.getText().strip()
        if not command:
            return
    shortcuts = core_settings.load_search_shortcuts()
    for sc in shortcuts:
        if sc.get('command') == command:
            xbmcgui.Dialog().notification('EspaTV', 'Ya existe un atajo con ese comando', xbmcgui.NOTIFICATION_INFO, 2000)
            return
    if any(sc.get('name') == name for sc in shortcuts):
        xbmcgui.Dialog().notification('EspaTV', 'Ya existe un atajo con ese nombre', xbmcgui.NOTIFICATION_INFO, 2000)
        return
    m = _RUNADDON_RE.search(command) or _PLUGIN_URL_RE.search(command)
    addon_id = m.group(1) if m else ''
    shortcuts.append({'name': name, 'icon': 'DefaultIconInfo.png', 'command': command, 'addon_id': addon_id})
    core_settings.save_search_shortcuts(shortcuts)
    xbmcgui.Dialog().notification('EspaTV', f'Atajo añadido: {name}', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _search_shortcut_add_favourite():
    import xml.etree.ElementTree as ET
    fav_path = xbmcvfs.translatePath('special://profile/favourites.xml')
    if not os.path.isfile(fav_path):
        xbmcgui.Dialog().notification('EspaTV', 'No tienes favoritos guardados en Kodi', xbmcgui.NOTIFICATION_INFO, 2500)
        return
    try:
        root = ET.parse(fav_path).getroot()
    except (ET.ParseError, OSError):
        xbmcgui.Dialog().notification('EspaTV', 'No se pudieron leer los favoritos de Kodi', xbmcgui.NOTIFICATION_ERROR, 2500)
        return
    favs = []
    for fav in root.findall('favourite'):
        cmd = (fav.text or '').strip()
        if not cmd:
            continue
        favs.append({'name': (fav.get('name') or cmd[:40]).strip(), 'thumb': fav.get('thumb') or '', 'cmd': cmd})
    if not favs:
        xbmcgui.Dialog().notification('EspaTV', 'No hay favoritos en Kodi', xbmcgui.NOTIFICATION_INFO, 2500)
        return
    items = []
    for f in favs:
        it = xbmcgui.ListItem(label=f['name'])
        if f['thumb']:
            it.setArt({'icon': f['thumb'], 'thumb': f['thumb']})
        items.append(it)
    sel = xbmcgui.Dialog().select('Seleccionar favorito de Kodi', items, useDetails=True)
    if sel < 0:
        return
    chosen = favs[sel]
    command = chosen['cmd']
    shortcuts = core_settings.load_search_shortcuts()
    for sc in shortcuts:
        if sc.get('command') == command:
            xbmcgui.Dialog().notification('EspaTV', 'Ya existe un atajo con ese comando', xbmcgui.NOTIFICATION_INFO, 2000)
            return
    if any(sc.get('name') == chosen['name'] for sc in shortcuts):
        xbmcgui.Dialog().notification('EspaTV', 'Ya existe un atajo con ese nombre', xbmcgui.NOTIFICATION_INFO, 2000)
        return
    m = _RUNADDON_RE.search(command) or _PLUGIN_URL_RE.search(command)
    addon_id = m.group(1) if m else ''
    icon = chosen['thumb'] or 'DefaultFavourites.png'
    shortcuts.append({'name': chosen['name'], 'icon': icon, 'command': command, 'addon_id': addon_id})
    core_settings.save_search_shortcuts(shortcuts)
    xbmcgui.Dialog().notification('EspaTV', f"Atajo añadido: {chosen['name']}", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _goto_kodi_favourite():
    import xml.etree.ElementTree as ET
    fav_path = xbmcvfs.translatePath('special://profile/favourites.xml')
    if not os.path.isfile(fav_path):
        xbmcgui.Dialog().notification('EspaTV', 'No tienes favoritos guardados en Kodi', xbmcgui.NOTIFICATION_INFO, 2500)
        return
    try:
        root = ET.parse(fav_path).getroot()
    except (ET.ParseError, OSError):
        xbmcgui.Dialog().notification('EspaTV', 'No se pudieron leer los favoritos de Kodi', xbmcgui.NOTIFICATION_ERROR, 2500)
        return
    favs = []
    for fav in root.findall('favourite'):
        cmd = (fav.text or '').strip()
        if not cmd:
            continue
        favs.append({'name': (fav.get('name') or cmd[:40]).strip(), 'thumb': fav.get('thumb') or '', 'cmd': cmd})
    if not favs:
        xbmcgui.Dialog().notification('EspaTV', 'No hay favoritos en Kodi', xbmcgui.NOTIFICATION_INFO, 2500)
        return
    items = []
    for f in favs:
        it = xbmcgui.ListItem(label=f['name'])
        if f['thumb']:
            it.setArt({'icon': f['thumb'], 'thumb': f['thumb']})
        items.append(it)
    sel = xbmcgui.Dialog().select('Ir a un favorito de Kodi', items, useDetails=True)
    if sel < 0:
        return
    xbmc.executebuiltin(favs[sel]['cmd'])


def _goto_kodi_addon():
    try:
        req = json.dumps({
            'jsonrpc': '2.0', 'method': 'Addons.GetAddons',
            'params': {'type': 'xbmc.addon.video', 'enabled': True, 'properties': ['name', 'thumbnail']},
            'id': 1,
        })
        data = json.loads(xbmc.executeJSONRPC(req) or '{}')
        addons = (data.get('result') or {}).get('addons') or []
    except Exception:
        addons = []

    own_id = xbmcaddon.Addon().getAddonInfo('id')
    seen = set()
    unique = []
    for a in addons:
        if not isinstance(a, dict):
            continue
        aid = a.get('addonid')
        if not aid or aid == own_id or aid in seen:
            continue
        seen.add(aid)
        unique.append(a)
    unique.sort(key=lambda x: (x.get('name') or '').lower())

    if not unique:
        xbmcgui.Dialog().notification('EspaTV', 'No hay addons de vídeo instalados', xbmcgui.NOTIFICATION_INFO, 3000)
        return

    items = []
    for a in unique:
        it = xbmcgui.ListItem(label=a.get('name') or a.get('addonid', ''))
        thumb = a.get('thumbnail') if isinstance(a.get('thumbnail'), str) else ''
        if thumb:
            it.setArt({'icon': thumb, 'thumb': thumb})
        items.append(it)
    sel = xbmcgui.Dialog().select('Abrir en un addon de vídeo', items, useDetails=True)
    if sel < 0:
        return
    addon_id = unique[sel].get('addonid', '')
    if addon_id:
        xbmc.executebuiltin(f'RunAddon("{addon_id}")')


def _search_layout_drop_key(key):
    layout = core_settings.load_search_dialog_layout()
    upd = {'order': [k for k in layout['order'] if k != key],
           'hidden': [k for k in layout['hidden'] if k != key]}
    if upd != layout:
        core_settings.save_search_dialog_layout(upd)


def _search_layout_rename_key(old, new):
    layout = core_settings.load_search_dialog_layout()
    upd = {'order': [new if k == old else k for k in layout['order']],
           'hidden': [new if k == old else k for k in layout['hidden']]}
    if upd != layout:
        core_settings.save_search_dialog_layout(upd)


def _search_shortcut_remove(idx):
    shortcuts = core_settings.load_search_shortcuts()
    if not (0 <= idx < len(shortcuts)):
        return
    name = shortcuts[idx].get('name', '')
    del shortcuts[idx]
    core_settings.save_search_shortcuts(shortcuts)
    order = core_settings.load_search_shortcuts_order()
    if name in order:
        core_settings.save_search_shortcuts_order([n for n in order if n != name])
    _search_layout_drop_key(f"sc:{name}")
    xbmcgui.Dialog().notification('EspaTV', f'Atajo eliminado: {name}', xbmcgui.NOTIFICATION_INFO, 2000)


def _search_shortcut_rename(idx):
    shortcuts = core_settings.load_search_shortcuts()
    if not (0 <= idx < len(shortcuts)):
        return
    old_name = shortcuts[idx].get('name', '')
    kb = xbmc.Keyboard(old_name, 'Nuevo nombre')
    kb.doModal()
    if not kb.isConfirmed():
        return
    new_name = kb.getText().strip()
    if not new_name or new_name == old_name:
        return
    if any(i != idx and sc.get('name') == new_name for i, sc in enumerate(shortcuts)):
        xbmcgui.Dialog().notification('EspaTV', 'Ya existe un atajo con ese nombre', xbmcgui.NOTIFICATION_INFO, 2000)
        return
    shortcuts[idx]['name'] = new_name
    core_settings.save_search_shortcuts(shortcuts)
    order = core_settings.load_search_shortcuts_order()
    if old_name in order:
        core_settings.save_search_shortcuts_order(
            [new_name if n == old_name else n for n in order]
        )
    _search_layout_rename_key(f"sc:{old_name}", f"sc:{new_name}")


def _search_shortcuts_menu():
    handle = int(sys.argv[1])
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    li = xbmcgui.ListItem(label="[B]+ Añadir atajo de addon instalado[/B]")
    li.setArt({'icon': _ico('adv_busqueda.png')})
    li.setInfo('video', {'plot': "Selecciona cualquier addon instalado en Kodi para añadirlo como acceso directo en el menú '¿Dónde buscar?'."})
    xbmcplugin.addDirectoryItem(handle=handle, url=_u(action='search_shortcut_add_addon'), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]+ Añadir comando manual[/B]")
    li.setArt({'icon': _ico('adv_busqueda.png')})
    li.setInfo('video', {'plot': (
        "Escribe manualmente un nombre y un comando Kodi para añadirlo al menú '¿Dónde buscar?'. Ejemplos:\n"
        "  ActivateWindow(Videos,plugin://plugin.video.youtube/search/?q={query})\n"
        "  RunPlugin(plugin://plugin.video.dailymotion_com/?mode=search&keyword={query})\n"
        "  RunScript(script.foo,query={queryraw})\n"
        "  RunAddon(\"plugin.video.youtube\")\n\n"
        "Tokens disponibles:\n"
        "  {query}    - consulta URL-encoded (úsala dentro de URLs y plugin://...).\n"
        "  {queryraw} - consulta tal cual (úsala en RunScript, Notification, etc.).\n"
        "  {tmdb_id}  - ID de TMDb del título (vacío si no se conoce).\n"
        "  {mode}     - tipo: movie o tv (vacío si no se conoce).")})
    xbmcplugin.addDirectoryItem(handle=handle, url=_u(action='search_shortcut_add_manual'), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]+ Añadir desde favoritos de Kodi[/B]")
    li.setArt({'icon': 'DefaultFavourites.png'})
    li.setInfo('video', {'plot': "Elige uno de tus favoritos de Kodi para añadirlo como atajo en el menú '¿Dónde buscar?'."})
    xbmcplugin.addDirectoryItem(handle=handle, url=_u(action='search_shortcut_add_favourite'), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]↕ Reordenar / ocultar opciones[/B]")
    li.setArt({'icon': _ico('adv_busqueda.png')})
    li.setInfo('video', {'plot': "Cambia el orden y oculta cualquier opción del menú '¿Dónde buscar?', tanto las fijas como tus atajos."})
    xbmcplugin.addDirectoryItem(handle=handle, url=_u(action='search_options_manager'), listitem=li, isFolder=False)

    shortcuts = core_settings.load_search_shortcuts()

    for i, sc in enumerate(shortcuts):
        aid = _shortcut_addon_id(sc)
        if aid and not xbmc.getCondVisibility(f"System.HasAddon({aid})"):
            lbl = f"[COLOR grey]{sc['name']} (no instalado)[/COLOR]"
        else:
            lbl = f"[COLOR gold]{sc['name']}[/COLOR]"
        icon = sc.get('icon') or 'DefaultAddonVideo.png'
        li = xbmcgui.ListItem(label=lbl)
        li.setArt({'icon': icon})
        li.setInfo('video', {'plot': f"Comando: {sc.get('command', '')}\n\nMenú contextual: Renombrar / Eliminar"})
        cm = [
            ("Renombrar", f"RunPlugin({_u(action='search_shortcut_rename', idx=i)})"),
            ("[COLOR red]Eliminar atajo[/COLOR]", f"RunPlugin({_u(action='search_shortcut_remove', idx=i)})"),
        ]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=handle, url=_u(action='search_shortcut_rename', idx=i), listitem=li, isFolder=False)

    xbmcplugin.setPluginCategory(handle, "Opciones de «¿Dónde buscar?»")
    xbmcplugin.endOfDirectory(handle)


def _setup_pvr():
    import pvr_manager
    if not xbmcgui.Dialog().yesno(
        "Auto-Configuración PVR",
        "EspaTV va a vincular la lista TDT y la Guía (EPG) con la sección nativa de TV de Kodi para que puedas ver el Timeline de horas.\n\nAtención: Se sobrescribirán tus ajustes de 'PVR IPTV Simple Client'. ¿Continuar?"
    ):
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Configurando la Guía de Televisión...")
    dp.update(30, "Ajustando reproductor...")

    m3u_url = "https://www.tdtchannels.com/lists/tv.m3u8"
    epg_url = "https://www.tdtchannels.com/epg/TV.xml.gz"

    success = pvr_manager.check_and_setup_pvr(m3u_url, epg_url)

    dp.update(100, "¡Hecho!")
    dp.close()

    if success:
        if xbmcgui.Dialog().yesno("¡Éxito!", "Guía nativa configurada con éxito.\n\nNota: Si se queda al 0% un momento, es normal. Está procesando los datos por primera vez.\n\nVe a la pantalla principal de Kodi y busca la sección 'TV'.\n¿Saltar a la Parrilla ahora?"):
            xbmc.executebuiltin("ActivateWindow(TVGuide)")

def _show_ytdlp_instructions():
    text = (
        "Para ver videos de YouTube, Dailymotion y otras webs\n"
        "necesitas instalar dos programas gratuitos en tu PC.\n"
        "No te preocupes, es facil. Sigue estos pasos:\n\n"

        "============================================\n"
        "  PRIMERO: ABRIR LA TERMINAL\n"
        "============================================\n\n"
        "La terminal es una ventana donde escribes\n"
        "comandos. Para abrirla:\n\n"
        "  Windows:\n"
        "    1. Pulsa la tecla Windows del teclado\n"
        "       (la que tiene el logo de Windows)\n"
        "    2. Escribe:  cmd\n"
        "    3. Haz clic en 'Simbolo del sistema'\n"
        "    Se abrira una ventana negra. Ahi es donde\n"
        "    vas a escribir los comandos.\n\n"
        "    TRUCO: Para pegar un comando en esa ventana,\n"
        "    haz CLIC DERECHO con el raton (no Ctrl+V).\n\n"
        "  Mac:\n"
        "    1. Pulsa Cmd + Espacio a la vez\n"
        "    2. Escribe:  Terminal\n"
        "    3. Pulsa Enter\n\n"
        "  Linux:\n"
        "    Pulsa Ctrl + Alt + T a la vez\n\n"

        "============================================\n"
        "  PASO 1: INSTALAR PYTHON\n"
        "============================================\n\n"
        "Puede que ya lo tengas. Para comprobarlo,\n"
        "escribe en la terminal:\n\n"
        "   python --version\n\n"
        "Si aparece algo como 'Python 3.12.0', perfecto,\n"
        "ya lo tienes. Salta al Paso 2.\n\n"
        "Si da error, prueba con:\n"
        "   py --version\n\n"
        "Si tambien falla, necesitas instalarlo:\n\n"
        "   1. Ve a: https://www.python.org/downloads/\n"
        "   2. Descarga la version para tu sistema\n"
        "   3. Ejecuta el instalador\n\n"
        "   >>> MUY IMPORTANTE en Windows: <<<\n"
        "   En la primera pantalla del instalador,\n"
        "   MARCA la casilla que dice:\n"
        "       'Add Python to PATH'\n"
        "   Si no la marcas, nada funcionara.\n\n"
        "   4. Cierra la terminal y vuelve a abrirla\n"
        "      (para que detecte el Python nuevo)\n\n"

        "============================================\n"
        "  PASO 2: INSTALAR YT-DLP\n"
        "============================================\n\n"
        "Escribe (o pega) este comando en la terminal:\n\n"
        '   pip install -U "yt-dlp[default]"\n\n'
        ">>> IMPORTANTE: Escribe el comando TAL CUAL, <<<\n"
        ">>> con las comillas y el [default].          <<<\n"
        ">>> Sin eso, YouTube no funcionara.           <<<\n\n"
        "Si 'pip' da error, prueba con este otro:\n\n"
        '   python -m pip install -U "yt-dlp[default]"\n\n'
        "Espera a que termine (puede tardar un minuto).\n"
        "Cuando vuelva a aparecer el cursor parpadeante,\n"
        "ya esta listo.\n\n"

        "============================================\n"
        "  PASO 3: INSTALAR DENO (para YouTube)\n"
        "============================================\n\n"
        "YouTube necesita este programa adicional.\n"
        "Sin el, los videos de YouTube no funcionaran.\n\n"
        "  Windows:\n"
        "    Escribe en la terminal:\n"
        "    winget install DenoLand.Deno\n\n"
        "    Si 'winget' da error o no lo reconoce:\n"
        "    1. Ve a: https://github.com/denoland/deno/\n"
        "       releases/latest\n"
        "    2. Descarga el archivo que diga:\n"
        "       deno-x86_64-pc-windows-msvc.zip\n"
        "    3. Descomprime el ZIP\n"
        "    4. Mueve deno.exe a C:\\Windows\\\n"
        "       (o a cualquier carpeta que este en PATH)\n\n"
        "  Mac:\n"
        "    Escribe en la terminal:\n"
        "    curl -fsSL https://deno.land/install.sh | sh\n\n"
        "  Linux:\n"
        "    Escribe en la terminal:\n"
        "    curl -fsSL https://deno.land/install.sh | sh\n\n"
        "  Nota: Si ya tienes Node.js version 20 o\n"
        "  superior, tambien vale y no necesitas Deno.\n\n"
        "  Tras instalar Deno, CIERRA la terminal\n"
        "  y vuelve a abrirla para que lo detecte.\n\n"

        "============================================\n"
        "  PASO 4: COMPROBAR QUE TODO FUNCIONA\n"
        "============================================\n\n"
        "Escribe en la terminal:\n\n"
        "   python -m yt_dlp --version\n\n"
        "Si aparece una fecha (ej: 2026.03.13),\n"
        "todo esta correcto.\n\n"
        "Si da error, revisa los pasos anteriores.\n\n"
        ">>> ULTIMO PASO: Cierra Kodi completamente <<<\n"
        ">>> y vuelve a abrirlo.                    <<<\n\n"

        "============================================\n"
        "  PARA ACTUALIZAR EN EL FUTURO\n"
        "============================================\n\n"
        "Si YouTube deja de funcionar, abre la\n"
        "terminal y repite el comando del Paso 2:\n\n"
        '   pip install -U "yt-dlp[default]"\n\n'
        "Despues, cierra y abre Kodi.\n\n"
        "Se recomienda actualizar cada pocas semanas.\n\n"

        "============================================\n"
        "  AYUDA RAPIDA\n"
        "============================================\n\n"
        "Tambien puedes pulsar 'Comprobar estado'\n"
        "en los Ajustes de EspaTV para ver que\n"
        "tienes instalado y que te falta."
    )
    xbmcgui.Dialog().textviewer("EspaTV \u2014 Instalar yt-dlp", text)


def _check_ytdlp_status():
    import subprocess
    lines = []
    creation_flags = 0x08000000 if xbmc.getCondVisibility("System.Platform.Windows") else 0

    # Comprobar yt-dlp
    try:
        proc = subprocess.run(
            ["python", "-m", "yt_dlp", "--version"],
            capture_output=True, text=True, timeout=15,
            creationflags=creation_flags,
        )
        if proc.returncode == 0:
            ver = proc.stdout.strip()
            lines.append("[OK] yt-dlp instalado: v{0}".format(ver))
        else:
            lines.append("[ERROR] yt-dlp encontrado pero devolvió error")
    except FileNotFoundError:
        lines.append("[ERROR] Python no encontrado en PATH")
    except subprocess.TimeoutExpired:
        lines.append("[AVISO] yt-dlp tardó demasiado en responder")
    except OSError as exc:
        lines.append("[ERROR] Error de sistema: {0}".format(exc))

    # Comprobar Deno
    try:
        proc = subprocess.run(
            ["deno", "--version"],
            capture_output=True, text=True, timeout=10,
            creationflags=creation_flags,
        )
        if proc.returncode == 0:
            deno_ver = proc.stdout.strip().split("\n")[0]
            lines.append("[OK] Deno instalado: {0}".format(deno_ver))
        else:
            lines.append("[NO] Deno no disponible")
    except (FileNotFoundError, OSError):
        lines.append("[NO] Deno no encontrado en PATH")
    except subprocess.TimeoutExpired:
        lines.append("[AVISO] Deno tardó demasiado")

    # Comprobar Node.js
    try:
        proc = subprocess.run(
            ["node", "--version"],
            capture_output=True, text=True, timeout=10,
            creationflags=creation_flags,
        )
        if proc.returncode == 0:
            node_ver = proc.stdout.strip()
            lines.append("[OK] Node.js instalado: {0}".format(node_ver))
        else:
            lines.append("[NO] Node.js no disponible")
    except (FileNotFoundError, OSError):
        lines.append("[NO] Node.js no encontrado en PATH")
    except subprocess.TimeoutExpired:
        lines.append("[AVISO] Node.js tardó demasiado")

    # Comprobar yt-dlp-ejs
    try:
        proc = subprocess.run(
            ["python", "-c", "import yt_dlp_ejs"],
            capture_output=True, text=True, timeout=10,
            creationflags=creation_flags,
        )
        if proc.returncode == 0:
            lines.append("[OK] yt-dlp-ejs instalado")
        else:
            lines.append("[NO] yt-dlp-ejs no instalado")
            lines.append("     Instálalo: pip install -U \"yt-dlp[default]\"")
    except (FileNotFoundError, OSError):
        lines.append("[NO] No se pudo comprobar yt-dlp-ejs")
    except subprocess.TimeoutExpired:
        pass

    # Resumen
    has_ytdlp = any("[OK] yt-dlp instalado:" in l for l in lines)
    has_js = any("[OK] Deno" in l or "[OK] Node" in l for l in lines)
    has_ejs = any("[OK] yt-dlp-ejs" in l for l in lines)
    lines.append("")
    lines.append("===== RESUMEN =====")
    if has_ytdlp and has_js and has_ejs:
        lines.append("Todo OK. YouTube debería funcionar correctamente.")
    elif has_ytdlp and has_js and not has_ejs:
        lines.append("Falta yt-dlp-ejs. Ejecuta:")
        lines.append('   pip install -U "yt-dlp[default]"')
    elif has_ytdlp and not has_js:
        lines.append("Falta un runtime JS (Deno o Node.js).")
        lines.append("YouTube podría fallar sin él.")
        lines.append("Pulsa 'Instrucciones' en Ajustes para más info.")
    else:
        lines.append("yt-dlp no detectado. Pulsa 'Instrucciones' en Ajustes.")

    xbmcgui.Dialog().textviewer("EspaTV — Estado de yt-dlp", "\n".join(lines))


def _ytdlp_proactive_check():
    """Devuelve True si yt-dlp parece estar disponible. Si no, ofrece instrucciones al usuario."""
    if xbmc.getCondVisibility("System.Platform.Android"):
        return False

    import subprocess
    creation_flags = 0x08000000 if xbmc.getCondVisibility("System.Platform.Windows") else 0
    try:
        proc = subprocess.run(
            ["python", "-m", "yt_dlp", "--version"],
            capture_output=True, text=True, timeout=10,
            creationflags=creation_flags,
        )
        if proc.returncode == 0:
            return True
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass

    if xbmcgui.Dialog().yesno(
        "EspaTV",
        "No se encuentra yt-dlp en tu sistema, o no está en el PATH.\n"
        "Es necesario para reproducir este vídeo.\n\n"
        "¿Quieres ver las instrucciones de instalación?",
    ):
        _show_ytdlp_instructions()
    return False


def _copy_to_clipboard(text):
    import subprocess
    import shutil
    try:
        if xbmc.getCondVisibility("System.Platform.Windows"):
            import ctypes
            import ctypes.wintypes
            CF_UNICODETEXT = 13
            GMEM_MOVEABLE  = 0x0002
            _ga = ctypes.windll.kernel32.GlobalAlloc
            _ga.restype = ctypes.c_void_p
            _ga.argtypes = [ctypes.wintypes.UINT, ctypes.c_size_t]
            _gl = ctypes.windll.kernel32.GlobalLock
            _gl.restype = ctypes.c_void_p
            _gl.argtypes = [ctypes.c_void_p]
            _gu = ctypes.windll.kernel32.GlobalUnlock
            _gu.argtypes = [ctypes.c_void_p]
            _scd = ctypes.windll.user32.SetClipboardData
            _scd.restype = ctypes.c_void_p
            _scd.argtypes = [ctypes.wintypes.UINT, ctypes.c_void_p]
            text_bytes = (text + '\0').encode('utf-16-le')
            h_mem = _ga(GMEM_MOVEABLE, len(text_bytes))
            if not h_mem:
                return False
            ptr = _gl(h_mem)
            if not ptr:
                return False
            ctypes.memmove(ptr, text_bytes, len(text_bytes))
            _gu(h_mem)
            if not ctypes.windll.user32.OpenClipboard(None):
                return False
            ctypes.windll.user32.EmptyClipboard()
            _scd(CF_UNICODETEXT, h_mem)
            ctypes.windll.user32.CloseClipboard()
            return True
        elif xbmc.getCondVisibility("System.Platform.OSX"):
            p = subprocess.Popen(['pbcopy'], stdin=subprocess.PIPE, text=True, encoding='utf-8')
            p.communicate(input=text)
            return True
        elif xbmc.getCondVisibility("System.Platform.Linux"):
            if shutil.which("xclip"):
                p = subprocess.Popen(['xclip', '-selection', 'clipboard'], stdin=subprocess.PIPE, text=True, encoding='utf-8')
                p.communicate(input=text)
                return True
            elif shutil.which("xsel"):
                p = subprocess.Popen(['xsel', '--clipboard', '--input'], stdin=subprocess.PIPE, text=True, encoding='utf-8')
                p.communicate(input=text)
                return True
    except (OSError, subprocess.SubprocessError):
        pass

    try:
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        r.clipboard_clear()
        r.clipboard_append(text)
        r.update()
        r.destroy()
        return True
    except (ImportError, RuntimeError):
        pass
    return False


def _ytdlp_menu():
    opts = [
        "Instrucciones: Instalar / Actualizar yt-dlp",
        "Comprobar estado de yt-dlp",
        "Copiar comando de instalación al Portapapeles"
    ]
    sel = xbmcgui.Dialog().select("Mantenimiento yt-dlp", opts)
    if sel == 0:
        _show_ytdlp_instructions()
    elif sel == 1:
        _check_ytdlp_status()
    elif sel == 2:
        cmd_ytdlp = 'pip install -U "yt-dlp[default]"'
        if xbmc.getCondVisibility("System.Platform.Windows"):
            cmd_deno = 'winget install DenoLand.Deno'
        else:
            cmd_deno = 'curl -fsSL https://deno.land/install.sh | sh'
            
        full_text = cmd_ytdlp + "\n" + cmd_deno
        
        if _copy_to_clipboard(full_text):
            xbmcgui.Dialog().ok("Portapapeles", "Los comandos se han copiado con exito.\nAhora puedes pegarlos (clic derecho o Ctrl+V) en tu terminal.")
        else:
            xbmcgui.Dialog().ok("Error", "No se pudo copiar al portapapeles. Tendras que escribirlo a mano copiando las instrucciones.")


def router(ps):
    p = dict(urllib.parse.parse_qsl(ps)); a = p.get("action")

    if _extras.dispatch(a, p):
        return

    if a == "ls": _ls(p.get("cid"), page=int(p.get("page", 0)))
    elif a == "fs": _fs(p.get("au"), p.get("st"), p.get("sth", ""), p.get("pu", ""))
    elif a == "lfr":
        ep_str = p.get("ep") or ""
        ep = json.loads(ep_str) if ep_str else None
        _lfd(p.get("q"), p.get("ot"), p.get("mode", ""), extra_params=ep, nh=p.get("nh"))
    elif a == "lfd_exclude":
        exc = p.get("exclude") or ""
        words = [w.strip() for w in exc.split(",") if w.strip()] if exc else None
        _lfd_with_exclusions(p.get("q", ""), p.get("ot", ""), words)
    elif a == "pv": _pv(p.get("vid"))
    elif a == "catalog_menu": _catalog_menu()
    elif a == "customize_menu_screen": _customize_menu_screen()
    elif a == "reorder_menu": _reorder_menu(p.get("location", "main"))
    elif a == "reset_menu_layout": _reset_menu_layout_action()
    elif a == "menu_move_to_main": _menu_move(p.get("key"), "main")
    elif a == "menu_move_to_catalog": _menu_move(p.get("key"), "catalog")
    elif a == "menu_item_up": _menu_shift(p.get("key"), p.get("location", "main"), -1)
    elif a == "menu_item_down": _menu_shift(p.get("key"), p.get("location", "main"), 1)
    elif a == "youtube_live_menu": _youtube_live_menu()
    elif a == "todavia_mas_menu":             import todavia_mas; todavia_mas.show_menu()
    elif a == "todavia_mas_archive":          import todavia_mas; todavia_mas.show_archive_extra()
    elif a == "webcams_menu": _webcams.menu()
    elif a == "webcams_list": _webcams.lista(p.get("cat", ""), p.get("subcat", ""))
    elif a == "play_webcam": _webcams.play()
    elif a == "skyline_menu": _webcams.sky_menu()
    elif a == "skyline_paises": _webcams.sky_paises()
    elif a == "skyline_regiones": _webcams.sky_regiones()
    elif a == "skyline_categorias": _webcams.sky_categorias()
    elif a == "skyline_camaras": _webcams.sky_camaras()
    elif a == "skyline_open_browser": _webcams.sky_open_browser()
    elif a == "play_dash": _play_dash(p.get("stream_url", ""), p.get("title", ""))
    elif a == "play_latest_news": _play_latest_news()
    elif a == "press_menu": _pr.menu()
    elif a == "press_list": _pr.show_list(p.get("raw_url", ""), p.get("name", ""))
    elif a == "press_read": _pr.read(p.get("title", ""), p.get("desc", ""))
    elif a == "press_add_feed": _pr.add_custom_feed()
    elif a == "press_delete_feed": _pr.delete_custom_feed(p.get("raw_url", ""))
    elif a == "felicidad_menu": _felicidad_menu()
    elif a == "felicidad_list": _felicidad_list(p.get("cat", ""))
    elif a == "felicidad_cinema": _felicidad_cinema(p.get("cat", ""))
    elif a == "yt_search": _yts.search()
    elif a == "yt_search_results": _yts.search_results(p.get("query", ""), p.get("sp", ""))
    elif a == "yt_search_cinema": _yt_search_cinema(p.get("query", ""), p.get("sp", ""))
    elif a == "remove_yt_history_item": _yts.remove_yt_history_item(p.get("q", ""))
    elif a == "clear_yt_history": _yts.clear_yt_history()
    elif a == "yt_toggle_watched": _ywt.toggle(p.get("yt_id", ""))
    elif a == "yt_queue_add": _yt_queue_add(p.get("yt_id", ""), p.get("name", ""))
    elif a == "felicidad_play": _felicidad_play(p.get("yt_id", ""), p.get("name", ""), p.get("ctype", "channel"), p.get("burl", ""))
    elif a == "felicidad_play_exec": _felicidad_play_exec(p.get("yt_id", ""), p.get("name", ""), p.get("method", "addon"))
    elif a == "cocina_menu": _cocina_menu()
    elif a == "cocina_list": _cocina_list(p.get("cat", ""))
    elif a == "educacion_menu": _educacion_menu()
    elif a == "educacion_list": _educacion_list(p.get("cat", ""))
    elif a == "arte_museos_menu": _arte_museos_menu()
    elif a == "arte_museos_list": _arte_museos_list(p.get("cat", ""))
    elif a == "arte_info_dialog":
        xbmcgui.Dialog().ok(p.get("title", "Info"), p.get("msg", ""))
    elif a == "loteria_menu": _loteria_mod.loteria_menu()
    elif a == "loteria_result": _loteria_mod.loteria_result(p.get("game_id", ""))
    elif a == "loteria_refresh": _loteria_mod.loteria_refresh(p.get("game_id", ""))
    elif a == "precio_luz_menu": precio_luz.precio_luz_menu()
    elif a == "precio_luz_refresh": precio_luz.precio_luz_refresh()
    elif a == "librivox_menu": librivox.librivox_menu()
    elif a == "librivox_list": librivox.librivox_list(
        page=p.get("page", 1),
        title_search=p.get("title_search", ""),
        author_search=p.get("author_search", ""),
        language=p.get("language", "Spanish"))
    elif a == "librivox_book": librivox.librivox_book(p.get("book_id", ""), p.get("title", ""))
    elif a == "librivox_search": librivox.librivox_search()
    elif a == "archive_documentales_es":      archive_org.show_documentales_es_menu()
    elif a == "archive_documentales_archive": archive_org.show_documentales_archive_submenu()
    elif a == "archive_felix":                archive_org.show_felix_menu()
    elif a == "archive_felix_archive":        archive_org.show_felix_archive_submenu()
    elif a == "archive_felix_rtve":           _rtve_mod.show_felix_rtve(int(p.get("page", 1)), p.get("prog_id", ""))
    elif a == "archive_felix_yt":             archive_org.show_felix_yt()
    elif a == "archive_punset":               archive_org.show_punset_menu()
    elif a == "archive_punset_rtve":          _rtve_mod.show_punset_rtve(int(p.get("page", 1)), p.get("prog_id", ""))
    elif a == "play_raw_url":                 import url_player; url_player.play_url_action(p.get("url", ""))
    elif a == "archive_audiobooks_es":     archive_org.show_audiobooks_es_menu()
    elif a == "archive_audiobooks_category": archive_org.show_audiobooks_category(p.get("q",""), p.get("page",1))
    elif a == "archive_play_audio":        archive_org.play_audio(p.get("archive_id",""), p.get("title",""))
    elif a == "efemerides_menu": efemerides.efemerides_menu()
    elif a == "ibex_menu":       ibex.ibex_menu()
    elif a == "ibex_historico":  ibex.ibex_historico()
    elif a == "ibex_empresas":   ibex.ibex_empresas()
    elif a == "ibex_refresh":    ibex.ibex_refresh()
    elif a == "sp500_menu":      ibex.sp500_menu()
    elif a == "sp500_historico": ibex.sp500_historico()
    elif a == "sp500_empresas":  ibex.sp500_empresas()
    elif a == "sp500_refresh":   ibex.sp500_refresh()
    elif a == "crypto_menu":     ibex.crypto_menu()
    elif a == "crypto_historico":ibex.crypto_historico()
    elif a == "crypto_empresas": ibex.crypto_empresas()
    elif a == "crypto_refresh":  ibex.crypto_refresh()
    elif a == "market_detail":   ibex.market_detail(p.get("ticker", ""), p.get("symbol", ""), p.get("name", ""))
    elif a == "stock_historico": ibex.stock_historico(p.get("symbol", ""), p.get("name", ""))
    elif a == "filmoteca_menu": _rtve_mod.show_filmoteca_menu()
    elif a == "filmoteca_seccion": _rtve_mod.show_filmoteca_seccion(p.get("q", ""), p.get("name", ""))
    elif a == "filmoteca_search": _rtve_mod.filmoteca_search()
    elif a == "dgt_menu": _dgt_mod.dgt_menu()
    elif a == "dgt_provincias": _dgt_mod.dgt_provincias()
    elif a == "dgt_lista": _dgt_mod.dgt_lista(p.get("filtro", ""), p.get("provincia", ""))
    elif a == "dgt_refresh": _dgt_mod.dgt_refresh()
    elif a == "dgt_camaras_provincia": _dgt_mod.dgt_camaras_provincia(p.get("provincia", ""))
    elif a == "dgt_camaras_refresh": _dgt_mod.dgt_camaras_refresh()
    elif a == "tv_autonomicas_menu": _tvaut_mod.tv_autonomicas_menu()
    elif a == "tv_autonomicas_refresh": _tvaut_mod.tv_autonomicas_refresh()
    elif a == "clasificaciones_menu": _clasif_mod.clasificaciones_menu()
    elif a == "clasificacion_tabla": _clasif_mod.clasificacion_tabla(p.get("comp_id", ""))
    elif a == "clasificacion_refresh": _clasif_mod.clasificacion_refresh(p.get("comp_id", ""))
    elif a == "resultados_menu": _clasif_mod.resultados_menu()
    elif a == "resultados_liga": _clasif_mod.resultados_liga(p.get("comp_id", ""))
    elif a == "resultados_refresh": _clasif_mod.resultados_refresh(p.get("comp_id", ""))
    elif a == "resultados_detalle": _clasif_mod.resultados_detalle(p.get("title", ""), p.get("plot", ""))
    elif a == "youtube_live_list": _youtube_live_list(p.get("cat", ""))
    elif a == "play_youtube_live": _play_youtube_live(p.get("yt_id", ""), p.get("title", ""))
    elif a == "youtube_install": _youtube_install_prompt()
    elif a == "yt_playlists_menu": _ytp.menu()
    elif a == "yt_playlist_add": _ytp.add_action()
    elif a == "yt_playlist_add_remote": _ytp.add_remote()
    elif a == "yt_playlist_open":
        _lid, _nm = p.get("list_id", ""), p.get("name", "")
        if _lid and _ytp._has_yt_addon() and xbmcaddon.Addon().getSetting("cinema_mode_auto") == "true":
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            _yt_playlist_cinema(_lid, _nm)
        else:
            _ytp.open_playlist(_lid, _nm)
    elif a == "yt_playlist_list": _ytp.show_list(p.get("list_id", ""), p.get("name", ""))
    elif a == "yt_cinema_mode": _yt_playlist_cinema(p.get("list_id", ""), p.get("name", ""))
    elif a == "yt_playlist_open_exec":
        import threading
        threading.Thread(target=_ytp.open_exec, args=(p.get("list_id", ""), p.get("name", ""), p.get("method", "addon"))).start()
    elif a == "yt_playlist_remove":
        _ytp.remove_playlist(p.get("list_id", ""))
        xbmcgui.Dialog().notification("EspaTV", "Playlist eliminada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "podcast_menu": _podcast_menu()
    elif a == "podcast_feed": _podcast_feed(p.get("url", ""), p.get("title", ""))
    elif a == "play_podcast": _play_podcast(p.get("url", ""), p.get("title", ""))
    elif a == "podcast_add_custom": _podcast_add_custom()
    elif a == "podcast_delete_custom": _podcast_delete_custom(p.get("url", ""))
    elif a == "most_watched": _most_watched()
    elif a == "clear_most_watched":
        if xbmcgui.Dialog().yesno("Confirmar", "¿Limpiar toda la lista de lo más visto?"):
            _wh._save([])
            xbmcgui.Dialog().notification("EspaTV", "Lista limpiada", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    elif a == "spanish_section": _spanish_section_menu(p.get("section", ""))
    elif a == "spanish_section_play_all": _spanish_section_play_all(p.get("section", ""))
    elif a == "spanish_section_cinema": _spanish_section_cinema(p.get("section", ""))
    elif a == "play_ytdlp_by_id": _play_ytdlp_by_id(p.get("yt_id", ""), p.get("name", ""))
    elif a == "spanish_channel_videos": _spanish_channel_videos(p.get("user", ""), p.get("name", ""))
    elif a == "dm_playlists_search": _dm_playlists_search_menu()
    elif a == "dm_user_playlists": _dm_user_playlists_menu(p.get("user", ""))
    elif a == "dm_saved_playlists": _dm_saved_playlists_menu()
    elif a == "dm_view_playlist": _dm_view_playlist_menu(p.get("pid", ""))
    elif a == "dm_save_playlist":
        if _add_saved_playlist(p.get("pid", ""), p.get("name", ""), p.get("user", ""), int(p.get("count", 0))):
            xbmcgui.Dialog().notification("EspaTV", "Playlist guardada", xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification("EspaTV", "Ya estaba guardada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "dm_unsave_playlist":
        _remove_saved_playlist(p.get("pid", ""))
        xbmcgui.Dialog().notification("EspaTV", "Playlist eliminada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "info_menu": info_menu()
    elif a == "espakodi_addons_menu":
        import espakodi_installer
        espakodi_installer.render_menu(int(sys.argv[1]))
    elif a == "ek_launch":
        import espakodi_installer
        espakodi_installer.launch_by_id(p.get("addon_id", ""))
    elif a == "ek_open_repo":
        import espakodi_installer
        espakodi_installer.open_repo_unificado()
    elif a == "info_note":
        easter_egg_manager.trigger("info_note")
        _felicidad_play_exec(yt_id="dQw4w9WgXcQ", name="Never Gonna Give You Up", method="addon")
    elif a == "play_version_video": _play_version_video()
    elif a == "noop": pass
    elif a == "trololo":
        easter_egg_manager.trigger("trololo")
        _felicidad_play_exec(yt_id="2Z4m4lnjxkY", name="Trololo", method="addon")
    elif a == "keyboard_cat":
        easter_egg_manager.trigger("keyboard_cat")
        _felicidad_play_exec(yt_id="8WEe-MmC4ag", name="Keyboard Cat", method="addon")
    elif a == "caramelldansen":
        easter_egg_manager.trigger("caramelldansen")
        _felicidad_play_exec(yt_id="PfYnvDL0Qcw", name="Caramelldansen", method="addon")
    elif a == "nyan_cat":
        easter_egg_manager.trigger("nyan_cat")
        _felicidad_play_exec(yt_id="P6antjcBFZ4", name="Nyan Cat", method="addon")
    elif a == "money_money":
        easter_egg_manager.trigger("money_money")
        _felicidad_play_exec(yt_id="ETxmCCsMoD0", name="Money Money Money", method="addon")
    elif a == "video_killed_radio":
        easter_egg_manager.trigger("video_killed_radio")
        _felicidad_play_exec(yt_id="W8r-tXRLazs", name="Video Killed the Radio Star", method="addon")
    elif a == "check_repo_status": _check_repo_status_espatv()
    elif a == "vpn_info": _vpn_info()
    elif a == "yt_pc_info": _yt_pc_info()
    elif a == "info": _info()

    elif a == "install_espatv_repo": _install_espatv_repo()
    elif a == "web_info": _web_info()
    elif a == "manual_search": _manual_search()
    elif a == "peliculas_top": _tm.show(p.get("page"))
    elif a == "pelis_grid_cinemeta":
        import pelis_grid; pelis_grid.show_from_cinemeta()
    elif a == "pelis_grid_historia":
        import pelis_grid; pelis_grid.show_from_peliculas_top()
    elif a == "pelis_grid_filmaffinity":
        import pelis_grid; pelis_grid.show_from_filmaffinity_top()
    elif a == "pelis_grid_open":
        import pelis_grid
        _grid_params = {k: v for k, v in p.items() if k not in ('action', 'source')}
        pelis_grid.show_from_source(p.get('source', ''), _grid_params)
    elif a == "pelis_flix":
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        import pelis_flix
        pelis_flix.show(_search_alternatives_prompt, initial_mode=p.get("mode") or None)
    elif a == "remove_movie_fav":
        _mfav = {'tmdb_id': p.get('tmdb_id', ''), 'imdb_id': p.get('imdb_id', ''),
                 'title': p.get('q', '')}
        if core_settings.remove_movie_favorite(_mfav, p.get('mode', 'movie')):
            xbmcgui.Dialog().notification("EspaTV", "Quitada de Mis Favoritos",
                                          xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('Container.Refresh')
    elif a == "top_pelis_series_menu": _top_pelis_series_menu()
    elif a == "filmaffinity_menu":
        import filmaffinity; filmaffinity.menu()
    elif a == "filmaffinity_submenu":
        h = int(sys.argv[1])
        _fa_media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
        _fa_items = [
            ("En Cines España",        "top_encines.png",      _u(action="filmaffinity_cartelera")),
            ("Estrenos en streaming",  "top_netflix.png",      _u(action="filmaffinity_cat_submenu", group="streaming")),
            ("En cines internacional", "fa_cines_intl.png",    _u(action="filmaffinity_cat_submenu", group="cines")),
            ("Alquiler y compra",      "fa_alquiler.png",      _u(action="filmaffinity_cat_submenu", group="rent")),
            ("Próximos y actualidad",  "top_encines_tv.png",   _u(action="filmaffinity_cat_submenu", group="otros")),
            ("Top Valoradas",          "top_mejores.png",      _u(action="filmaffinity_top")),
            ("Top de la Comunidad",    "top_filmaffinity.png", _u(action="filmaffinity_topfa")),
        ]
        for lbl, ico, url in _fa_items:
            li = xbmcgui.ListItem(label=lbl)
            _ipath = os.path.join(_fa_media, ico)
            li.setArt({'icon': _ipath if os.path.exists(_ipath) else 'DefaultVideoPlaylists.png'})
            xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
    elif a == "filmaffinity_cat_submenu":
        import filmaffinity
        h = int(sys.argv[1])
        _fa_media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
        for s in filmaffinity.cat_sections_for(p.get("group", "")):
            li = xbmcgui.ListItem(label=s["label"])
            _ipath = os.path.join(_fa_media, s["icon"])
            li.setArt({'icon': _ipath if os.path.exists(_ipath) else 'DefaultVideoPlaylists.png'})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="filmaffinity_cat", src=s["src"]), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
    elif a == "filmaffinity_list":
        import filmaffinity; filmaffinity.show_list(p.get("genre", ""))
    elif a == "filmaffinity_cartelera":
        import filmaffinity; filmaffinity.show_cartelera()
    elif a == "filmaffinity_cat":
        import filmaffinity; filmaffinity.show_cat(p.get("src", ""))
    elif a == "filmaffinity_top":
        import filmaffinity; filmaffinity.show_top()
    elif a == "filmaffinity_topfa":
        import filmaffinity; filmaffinity.show_topfa()
    elif a == "filmaffinity_cache_cartelera_meta":
        import filmaffinity; filmaffinity.cache_cartelera_meta()
    elif a == "filmaffinity_clear_cartelera_meta":
        import filmaffinity; filmaffinity.clear_cartelera_meta()
    elif a == "sensacine_submenu":
        h = int(sys.argv[1])
        _sc_media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
        for lbl, act, ico in [("En Cartelera", "sensacine_menu", "top_encines.png"),
                              ("Estrenos", "sensacine_estrenos", "top_anticipated.png"),
                              ("Mejores Películas", "sensacine_mejores", "top_mejores.png"),
                              ("Taquilla", "sensacine_taquilla", "top_boxoffice.png")]:
            li = xbmcgui.ListItem(label=lbl)
            _ipath = os.path.join(_sc_media, ico)
            li.setArt({'icon': _ipath if os.path.exists(_ipath) else 'DefaultVideoPlaylists.png'})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action=act), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
    elif a == "sensacine_menu":
        import sensacine; sensacine.show_cartelera()
    elif a == "sensacine_estrenos":
        import sensacine; sensacine.show_estrenos()
    elif a == "sensacine_mejores":
        import sensacine; sensacine.show_mejores()
    elif a == "sensacine_taquilla":
        import sensacine; sensacine.show_taquilla()
    elif a == "sensacine_cache_cartelera_meta":
        import sensacine; sensacine.cache_cartelera_meta()
    elif a == "sensacine_clear_cartelera_meta":
        import sensacine; sensacine.clear_cartelera_meta()
    elif a == "sensacine_cache_estrenos_meta":
        import sensacine; sensacine.cache_estrenos_meta()
    elif a == "sensacine_clear_estrenos_meta":
        import sensacine; sensacine.clear_estrenos_meta()
    elif a == "cinemeta_submenu":
        h = int(sys.argv[1])
        _cm_media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
        for lbl, act in [("Top Películas", "cinemeta_top"), ("Por Género", "cinemeta_genres_menu")]:
            li = xbmcgui.ListItem(label=lbl)
            li.setArt({'icon': os.path.join(_cm_media, 'top_cinemeta.png')})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action=act), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
    elif a == "cinemeta_top":
        import cinemeta; cinemeta.show_top()
    elif a == "cinemeta_genres_menu":
        import cinemeta; cinemeta.show_genres_menu()
    elif a == "cinemeta_genre":
        import cinemeta; cinemeta.show_genre(p.get("slug", ""))
    elif a == "cinemeta_cache_meta":
        import cinemeta; cinemeta.cache_meta()
    elif a == "cinemeta_clear_meta":
        import cinemeta; cinemeta.clear_meta()
    elif a == "oscar_movies":
        import oscar_movies; oscar_movies.show_oscar(p.get("page", 1))
    elif a == "cache_oscar_movies_covers":
        import oscar_movies; oscar_movies.cache_covers()
    elif a == "clear_oscar_movies_cache":
        import oscar_movies; oscar_movies.clear_cache()
    elif a == "copy_title":
        t = p.get('title', '')
        if t and _copy_to_clipboard(t):
            xbmcgui.Dialog().notification("EspaTV", u"'{0}' copiado al portapapeles".format(t), xbmcgui.NOTIFICATION_INFO, 2500)
    elif a == "show_watch_providers":
        _show_watch_providers(p.get('title', ''), p.get('tmdb_id', ''))
    elif a == "search_movie_multi":
        _search_movie_multi(p.get('q', ''), p.get('tmdb_id', ''),
                            p.get('media_type', 'movie'),
                            p.get('season', ''), p.get('episode', ''))
    elif a == "archive_menu":
        archive_org.show_menu()
    elif a == "archive_category":
        archive_org.show_category(p.get("q", ""), p.get("page", 1))
    elif a == "archive_search_ui":
        archive_org.search_ui()
    elif a == "archive_play":
        archive_org.play(p.get("archive_id", ""), p.get("title", ""))
    elif a == "calendario_series":
        import calendario_series; calendario_series.show_calendar()
    elif a == "calendario_series_refresh":
        import calendario_series; calendario_series.refresh()
    elif a == "tmdb_lists_menu":
        import tmdb_lists; tmdb_lists.show_menu()
    elif a == "tmdb_lists_show":
        import tmdb_lists; tmdb_lists.show_list(p.get("endpoint", ""), p.get("media_type", "movie"), p.get("page", 1))
    elif a == "letterboxd_menu":
        import letterboxd; letterboxd.show_menu()
    elif a == "letterboxd_list":
        import letterboxd; letterboxd.show_list(p.get("list_key", ""), p.get("list_url", ""))
    elif a == "letterboxd_cache_meta":
        import letterboxd; letterboxd.cache_list_meta(p.get("list_key", ""), p.get("list_url", ""))
    elif a == "letterboxd_clear_meta":
        import letterboxd; letterboxd.clear_list_meta(p.get("list_key", ""), p.get("list_url", ""))
    elif a == "advanced_menu": advanced_menu()
    elif a == "show_history": _sh.menu()
    elif a == "history_menu": _history_menu()
    elif a == "search_alt_prompt": _search_alternatives_prompt(p.get("q", ""), p.get("ot", ""), p.get("mode", ""), tmdb_id=p.get("tmdb_id", ""), season=p.get("season", ""), episode=p.get("episode", ""))
    elif a == "search_shortcuts_menu": _search_shortcuts_menu()
    elif a == "search_shortcut_add_addon": _search_shortcut_add_addon()
    elif a == "search_shortcut_add_manual": _search_shortcut_add_manual()
    elif a == "search_shortcut_add_favourite": _search_shortcut_add_favourite()
    elif a == "search_options_manager":
        _search_options_manager()
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False, cacheToDisc=False)
    elif a == "search_shortcut_remove":
        _search_shortcut_remove(int(p.get("idx", -1)))
        xbmc.executebuiltin("Container.Refresh")
    elif a == "search_shortcut_rename":
        _search_shortcut_rename(int(p.get("idx", -1)))
        xbmc.executebuiltin("Container.Refresh")
    elif a == "toggle_espadaily_integration":
        new_state = not core_settings.is_espadaily_integration_enabled()
        core_settings.set_espadaily_integration_enabled(new_state)
        msg = "EspaDaily activado en búsqueda" if new_state else "EspaDaily desactivado en búsqueda"
        xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "toggle_topzilla_integration":
        new_state = not core_settings.is_topzilla_integration_enabled()
        core_settings.set_topzilla_integration_enabled(new_state)
        msg = "TopZilla activado en búsqueda" if new_state else "TopZilla desactivado en búsqueda"
        xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "topzilla_buscar_menu":
        _topzilla_buscar_menu()
    elif a == "topzilla_buscar_go":
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.topzilla)"):
            import espakodi_installer
            espakodi_installer.launch_by_id("plugin.video.topzilla")
        else:
            tz_mode = p.get("mode", "movie")
            kb = xbmc.Keyboard('', "Buscar serie en TopZilla" if tz_mode == "show" else "Buscar película en TopZilla")
            kb.doModal()
            if kb.isConfirmed():
                q = kb.getText().strip()
                if q:
                    tz_url = "plugin://plugin.video.topzilla/?" + urllib.parse.urlencode(
                        {'action': 'search_alt_prompt', 'q': q, 'mode': tz_mode})
                    xbmc.executebuiltin(f'RunPlugin({tz_url})')
    elif a == "topzilla_library":
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.topzilla)"):
            import espakodi_installer
            espakodi_installer.launch_by_id("plugin.video.topzilla")
        else:
            xbmc.executebuiltin("Container.Update(plugin://plugin.video.topzilla/?action=my_library_menu)")
    elif a == "buscar_tops_menu":
        import buscar_tops
        buscar_tops.menu(int(sys.argv[1]))
    elif a == "bt_titulo":
        import buscar_tops
        h = int(sys.argv[1])
        q = p.get("q", "").strip()
        if not q:
            kb = xbmc.Keyboard('', 'Buscar película o serie')
            kb.doModal()
            q = kb.getText().strip() if kb.isConfirmed() else ''
        if not q:
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        elif len(q) < 2:
            xbmcgui.Dialog().notification("EspaTV", "Escribe al menos 2 caracteres", xbmcgui.NOTIFICATION_INFO, 2500)
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        else:
            buscar_tops.buscar_titulo(h, q)
    elif a == "bt_director":
        import buscar_tops
        h = int(sys.argv[1])
        kb = xbmc.Keyboard('', 'Nombre del director')
        kb.doModal()
        name = kb.getText().strip() if kb.isConfirmed() else ''
        if not name:
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        else:
            buscar_tops.buscar_director(h, name)
    elif a == "bt_generos":
        import buscar_tops
        buscar_tops.generos_menu(int(sys.argv[1]))
    elif a == "bt_genero":
        import buscar_tops
        buscar_tops.buscar_genero(int(sys.argv[1]), p.get("id", ""), p.get("label", ""))
    elif a == "bt_anio":
        import buscar_tops
        h = int(sys.argv[1])
        year = xbmcgui.Dialog().numeric(0, 'Año (ej. 1999)')
        if not year:
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        else:
            buscar_tops.buscar_anio(h, year)
    elif a == "bt_historial":
        import buscar_tops
        buscar_tops.historial_menu(int(sys.argv[1]))
    elif a == "bt_hist_remove":
        import buscar_tops
        buscar_tops.hist_remove(p.get("q", ""))
    elif a == "bt_hist_clear":
        import buscar_tops
        buscar_tops.hist_clear_ui()
    elif a == "clear_history": _sh.clear()
    elif a == "remove_history_item": _sh.remove(p.get("q"))
    elif a == "import_backup": _bk.import_backup()
    elif a == "toggle_debug": _toggle_debug()

    elif a == "toggle_cinema_auto": _toggle_cinema_auto()
    elif a == "toggle_flix_lazy_load": _toggle_flix_lazy_load()
    elif a == "toggle_flix_remember_pos": _toggle_flix_remember_pos()
    elif a == "trailer_config": _trailer_config()
    elif a == "set_pelis_grid_mode": _set_pelis_grid_mode()
    elif a == "toggle_recent": _toggle_recent()
    elif a == "set_min_duration": _set_min_duration_filter()
    elif a == "toggle_prioritize_match": _toggle_prioritize_match()
    elif a == "show_favorites": _show_favorites()
    elif a == "fav_add_section_picker": _fav_add_section_picker()
    elif a == "fav_add_section_choose": _fav_add_section_choose(p)
    elif a == "add_favorite":
         try:
             params = json.loads(p.get("params", "{}"))
         except (ValueError, TypeError):
             # Si el JSON viene mal formado, extraemos solo la 'q' del título
             params = {'q': p.get("title", "")}
         added = core_settings.add_favorite(p.get("title"), p.get("fav_url"), p.get("icon"), p.get("platform"), p.get("fav_action"), params)
         if added:
             xbmcgui.Dialog().notification("EspaTV", "Añadido a Favoritos", xbmcgui.NOTIFICATION_INFO)
         else:
             xbmcgui.Dialog().notification("EspaTV", "Ya existe en Favoritos", xbmcgui.NOTIFICATION_WARNING)
    elif a == "remove_favorite":
         core_settings.remove_favorite(p.get("fav_url"))
         xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_rename":
         kb = xbmc.Keyboard(p.get("old_title"), 'Renombrar Favorito')
         kb.doModal()
         if kb.isConfirmed():
             new_t = kb.getText()
             if new_t:
                 core_settings.rename_favorite(p.get("fav_url"), new_t)
                 xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_up":
         if core_settings.move_favorite(p.get("fav_url"), "up"):
             xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_down":
         if core_settings.move_favorite(p.get("fav_url"), "down"):
             xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_news": _show_fav_news()
    elif a == "yt_fav_news": _show_yt_fav_news()
    elif a == "fav_backup_menu": _fav_backup_menu()
    elif a == "fav_export": _bk.export_favorites()
    elif a == "fav_import": _bk.import_favorites()
    elif a == "show_downloads": _show_downloads()
    elif a == "remove_download":
         core_settings.remove_download(p.get("dl_path"))
         xbmc.executebuiltin("Container.Refresh")
    elif a == "delete_download_file":
         _delete_download_file(p.get("dl_path"), p.get("title"))
    elif a == "clear_cache": _clear_cache()
    elif a == "config_remote_port":
        _addon = xbmcaddon.Addon()
        _old = _addon.getSetting('remote_port') or '8089'
        _new = xbmcgui.Dialog().input("Puerto del servidor remoto", defaultt=_old, type=xbmcgui.INPUT_NUMERIC)
        if _new:
            _port_num = int(_new)
            if 1024 <= _port_num <= 65535:
                _addon.setSetting('remote_port', str(_port_num))
                xbmcgui.Dialog().notification("EspaTV", "Puerto cambiado a {0}".format(_port_num), xbmcgui.NOTIFICATION_INFO, 2000)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("EspaTV", "Puerto no válido.\nDebe estar entre 1024 y 65535.")
    elif a == "download_video": _download_video(p.get("vid"), p.get("title"))
    elif a == "toggle_advanced_search": _toggle_advanced_search()
    elif a == "configure_cinema_rows": _configure_cinema_rows()
    elif a == "advanced_search_menu": _advanced_search_menu()
    elif a == "setup_pvr": _setup_pvr()
    elif a == "open_pvr": xbmc.executebuiltin("ActivateWindow(TVGuide)")
    elif a == "execute_adv_search": _execute_adv_search(p.get("mode", ""))

    # --- CATEGORY MANAGER ROUTES ---
    elif a == "cat_menu": category_manager.main_menu()
    elif a == "cat_create": category_manager.create_category()
    elif a == "cat_delete": category_manager.delete_category(p.get("name"))
    elif a == "cat_rename": category_manager.rename_category(p.get("name"))
    elif a == "cat_view": category_manager.view_category(p.get("name"))
    elif a == "cat_add_item_dialog": category_manager.add_item_dialog(p.get("q"))
    elif a == "cat_remove_item": category_manager.remove_item(p.get("cat"), p.get("q"))
    elif a == "cat_move_item": category_manager.move_item(p.get("from_cat"), p.get("q"))
    elif a == "cat_export": category_manager.export_categories()
    elif a == "cat_import": category_manager.import_categories()
    elif a == "cat_io_menu": category_manager.io_menu()
    elif a == "cat_move_from_favs": 
         # Acción compuesta: Añadir a categoría -> Si éxito -> Borrar de favoritos
         if category_manager.add_item_dialog(p.get("q")):
             removed = core_settings.remove_favorite(p.get("fav_url"))
             if not removed:
                 # Si el borrado de favoritos falla, avisamos; raro pero puede pasar con JSON corrupto
                 xbmcgui.Dialog().notification("EspaTV", "Error: No se pudo quitar de favoritos", xbmcgui.NOTIFICATION_ERROR)
             else:
                 time.sleep(0.2) # Pequeña pausa para asegurar escritura
                 xbmc.executebuiltin("Container.Refresh")
    

    

    elif a == "sanitized_info": _sanitized_info()
    elif a == "version_notes": _version_notes()
    elif a == "version_notes_v1": _version_notes_v1()
    elif a == "view_error_log": _view_error_log()
    elif a == "cache_peliculas_top_covers": _tm.cache_covers()
    elif a == "clear_peliculas_top_cache": _tm.clear_cache()
    elif a == "edit_and_search":

        q = p.get("q", "")
        ot = p.get("ot", "")
        kb = xbmc.Keyboard(q, 'Editar y Buscar')
        kb.doModal()
        if kb.isConfirmed():
             nq = kb.getText()
             if nq:


                 xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=nq, ot=ot)})")


    # --- TRAKT ACTIONS ---
    elif a == "elementum_search_prompt": _elementum_search_prompt()
    elif a == "elementum_search": _search_elementum(p.get("q"))
    elif a == "menu_collections":
        import trakt_manager
        trakt_manager.menu_collections()
    elif a == "trakt_root":
        import trakt_manager
        trakt_manager.menu_trakt_root()
    elif a == "trakt_options":
        import trakt_manager
        trakt_manager.menu_options()
    elif a == "trakt_help_guide":
        import trakt_manager
        trakt_manager.help_guide()
    elif a == "trakt_set_key":
        import trakt_manager
        trakt_manager.set_api_key()
    elif a == "trakt_import":
        import trakt_manager
        trakt_manager.import_list()
    elif a == "trakt_view_list":
        import trakt_manager
        trakt_manager.view_list(p.get("list_id"), p.get("show_covers") == "1")
    elif a == "trakt_delete_list":
        import trakt_manager
        trakt_manager.delete_list(p.get("list_id"))
    elif a == "trakt_cache_covers":
        import trakt_manager
        trakt_manager.cache_covers(p.get("list_id"))
    elif a == "trakt_clear_cache":
        import trakt_manager
        trakt_manager.clear_cache(p.get("list_id"))
    elif a == "trakt_refresh_defaults":
        import trakt_manager
        trakt_manager.refresh_all_lists()

    # --- TRAKT DISCOVERY ---
    elif a == "trakt_discover_menu":
        import trakt_manager
        trakt_manager.menu_discover_lists()
    elif a == "trakt_browse_list_index":
        import trakt_manager
        trakt_manager.browse_list_index(p.get('path', ''), int(p.get('page') or 1))
    elif a == "trakt_search_lists":
        import trakt_manager
        trakt_manager.search_trakt_lists()

    # --- TRAKT TOPS ---
    elif a == "trakt_tops_menu":
        import trakt_tops
        trakt_tops.show_menu()
    elif a == "trakt_tops_list":
        import trakt_tops
        trakt_tops.show_list(
            p.get('path', ''), p.get('media_type', 'movie'),
            p.get('wrapped') == '1', int(p.get('page') or 1),
        )

    # --- MDBLIST ---
    elif a == "mdblist_menu":
        import mdblist
        mdblist.show_menu()
    elif a == "mdblist_setup_key":
        import mdblist
        mdblist._setup_api_key()
    elif a == "mdblist_top":
        import mdblist
        mdblist.show_top_lists()
    elif a == "mdblist_user":
        import mdblist
        mdblist.show_user_lists()
    elif a == "mdblist_list":
        import mdblist
        mdblist.show_list_items(
            p.get('list_id', ''), p.get('list_name', ''), int(p.get('page') or 1))
    elif a == "mdblist_category":
        import mdblist
        mdblist.show_category_lists(p.get('query', ''), p.get('label', ''))
    elif a == "mdblist_search":
        import mdblist
        mdblist.search_lists()
    elif a == "mdblist_manage_keys":
        import mdblist
        mdblist._manage_api_keys()
    elif a == "mdblist_add_key":
        import mdblist
        mdblist._add_api_key()
    elif a == "mdblist_remove_key":
        import mdblist
        mdblist._remove_api_key(p.get('key', ''))
    elif a == "api_keys_menu":
        _api_keys_menu()
    elif a == "api_key_tmdb_setup":
        _api_key_tmdb_setup()
    elif a == "api_key_trakt_setup":
        _api_key_trakt_setup()

    # --- STREAMING TOPS ---
    elif a == "streaming_tops_menu":
        import streaming_tops
        streaming_tops.show_menu()
    elif a == "streaming_tops_list":
        import streaming_tops
        streaming_tops.show_provider_list(
            p.get('provider_id', 8), p.get('media_type', 'movie'), int(p.get('page') or 1))

    # --- ANIME ---
    elif a == "anime_menu":
        import anime_tops
        anime_tops.show_menu()
    elif a == "anime_anilist_menu":
        import anime_tops
        anime_tops.show_anilist_menu()
    elif a == "anime_anilist_list":
        import anime_tops
        anime_tops.show_anilist_list(p.get('sort_key', 'anilist_trending'), int(p.get('page') or 1))
    elif a == "anime_mal_menu":
        import anime_tops
        anime_tops.show_mal_menu()
    elif a == "anime_mal_setup":
        import anime_tops
        anime_tops._setup_mal_key()
    elif a == "anime_mal_list":
        import anime_tops
        anime_tops.show_mal_list(p.get('ranking_type', 'all'), int(p.get('page') or 1))

    # --- URL PLAYER ---
    elif a == "open_url":
        import url_player; url_player.open_url_dialog()
    elif a == "url_input":
        import url_player; url_player.url_input()
    elif a == "url_remote":
        import url_remote; url_remote.start_remote()
    elif a == "url_history":
        import url_player; url_player.url_history_menu()
    elif a == "url_history_clear":
        import url_player; url_player.history_clear()
    elif a == "url_history_remove":
        import url_player; url_player.history_remove(p.get("url"))
    elif a == "url_bookmarks":
        import url_player; url_player.url_bookmarks_menu()
    elif a == "url_bookmark_save_from_history":
        import url_player; url_player.bookmark_save_from_history(p.get("url"))
    elif a == "url_bookmark_rename":
        import url_player; url_player.bookmark_rename(p.get("url"))
    elif a == "url_bookmark_delete":
        import url_player; url_player.bookmark_delete(p.get("url"))
    elif a == "url_play":
        import url_player; url_player.play_url_action(p.get("url"))
    elif a == "url_scan":
        import url_player; url_player.scan_videos_dialog()
    elif a == "url_scan_telegram":
        import url_player; url_player.scan_telegram_dialog()
    elif a == "url_player_ensure_sn":
        import url_player; url_player.url_player_ensure_streamninja()
    elif a == "url_player_config":        _url_player_config_menu()
    elif a == "set_webremote_mode":       _set_webremote_mode()
    elif a == "toggle_webremote_confirm": _toggle_webremote_confirm()
    elif a == "set_webremote_server":     _set_webremote_server()
    elif a == "reset_webremote_topic":    _reset_webremote_topic()
    elif a == "debrid_menu":              _debrid_menu()
    elif a == "debrid_toggle_enabled":    _debrid_toggle_enabled()
    elif a == "debrid_set_provider":      _debrid_set_provider()
    elif a == "debrid_authorize_pin":     _debrid_authorize_pin()
    elif a == "debrid_authorize_key":     _debrid_authorize_key()
    elif a == "debrid_deauthorize":       _debrid_deauthorize()
    elif a == "debrid_account":           _debrid_account()
    elif a == "debrid_toggle_cached":     _debrid_toggle_cached()
    elif a == "debrid_toggle_cleanup":    _debrid_toggle_cleanup()
    elif a == "debrid_toggle_quality":    _debrid_toggle_quality()
    elif a == "debrid_library":
        import url_player; url_player.debrid_library_menu()
    elif a == "debrid_library_files":
        import url_player; url_player.debrid_library_files(p.get("id"))
    elif a == "debrid_library_play":
        import url_player; url_player.debrid_library_play(p.get("id"), p.get("file"))
    elif a == "debrid_library_delete":
        import url_player; url_player.debrid_library_delete(p.get("id"))
    elif a == "debrid_download":
        import url_player; url_player.debrid_download(p.get("id"), p.get("title", ""))

    # --- DM PLAYLISTS ---
    elif a == "dm_playlists_search": _dm_playlists_search()
    elif a == "dm_user_playlists": _dm_user_playlists(p.get("user"))
    elif a == "dm_view_playlist": _dm_view_playlist(p.get("pid"))

    # --- DM SETTINGS ---
    elif a == "set_dm_safe_level": _set_dm_safe_level()
    elif a == "set_dl_mode": _set_dl_mode()

    # --- SEARCH EXTERNAL ---
    elif a == "search_external_prompt": _search_external_prompt(p.get("q"))
    elif a == "dm_gujal_search": _search_dailymotion_gujal(p.get("q"))

    # --- TDT / TV EN DIRECTO ---
    elif a == "live_tv_menu": live_tv_menu()
    elif a == "slyguy_install": _slyguy.install(p.get("addon_id", ""), p.get("title", "Addon"))
    elif a == "tdt_channels_json": tdt_channels_json()
    elif a == "tdt_json_ambit": tdt_json_ambit(p.get("url", ""))
    elif a == "tdt_channels": tdt_channels()
    elif a == "play_tdt": play_tdt(p.get("url", ""), p.get("title", ""), p.get("ua", ""), p.get("ref", ""))
    elif a == "play_p2p": _play_p2p(p.get("url", ""), p.get("name", ""))
    elif a == "add_custom_iptv": add_custom_iptv()
    elif a == "freetv_menu": freetv_menu()
    elif a == "view_custom_iptv": view_custom_iptv(p.get("url", ""))
    elif a == "delete_custom_iptv": delete_custom_iptv(p.get("url", ""))

    # --- RADIO / TDT POR REGIÓN ---
    elif a == "radio_menu":
        import tdt_canales; tdt_canales.radio_menu()
    elif a == "radio_group":
        import tdt_canales; tdt_canales.radio_group(p.get("group", ""))
    elif a == "play_radio":
        import tdt_canales; tdt_canales.play_radio(p.get("url", ""), p.get("title", ""))
    elif a == "tdt_region":
        import tdt_canales; tdt_canales.tdt_region(p.get("region", ""))


    # --- RTVE PLAY ---
    elif a == "rtve_menu":
        import rtve_alacarta; rtve_alacarta.main_menu()
    elif a == "rtve_live":
        import rtve_alacarta; rtve_alacarta.live_channels()
    elif a == "play_rtve_live":
        import rtve_alacarta; rtve_alacarta.play_live(p.get("url", ""), p.get("title", ""))
    elif a == "rtve_category":
        import rtve_alacarta; rtve_alacarta.category(p.get("cat_id", ""), p.get("cat_name", ""), int(p.get("page", "1")), p.get("parent_id", ""))
    elif a == "rtve_search":
        import rtve_alacarta; rtve_alacarta.search()
    elif a == "rtve_open_web":
        import rtve_alacarta; rtve_alacarta.open_web(p.get("url", ""), p.get("title", ""))
    elif a == "play_rtve_video":
        import rtve_alacarta; rtve_alacarta.play_video(p.get("video_id", ""), p.get("title", ""))

    # --- WATCH HISTORY ---
    elif a == "watch_history": _wh.show()
    elif a == "del_watch_entry": _wh.del_entry(p.get("url", ""))
    elif a == "clear_watch_history": _wh.clear()

    # --- PVR NATIVO ---
    elif a == "record_stream":
        import pvr_recorder_manager
        pvr_recorder_manager.start_recording_ui(p.get("url", ""), p.get("name", "Grabacion Automatica"))
    elif a == "stop_recording":
        import pvr_recorder_manager
        pvr_recorder_manager.stop_all_recordings()
    elif a == "my_recordings_menu":
        _my_recordings_menu()
    elif a == "delete_recording":
        file_path = p.get("file", "")
        if file_path and xbmcvfs.exists(file_path):
            if xbmcgui.Dialog().yesno("Borrar Grabación", "¿Seguro que quieres borrar este archivo de tu disco duro?\n\n{0}".format(os.path.basename(file_path))):
                xbmcvfs.delete(file_path)
                xbmc.executebuiltin("Container.Refresh")
    elif a == "open_settings":
        xbmcaddon.Addon().openSettings()

    # --- TRENDING / MULTI-SEARCH ---
    elif a == "trending": _show_trending()
    elif a == "multi_search": _multi_search()

    # --- UTILIDADES ---
    elif a == "dm_open_browser": _dm_open_browser(p.get("url", ""))
    elif a == "agenda_open_browser":
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        _felicidad_open_browser(p.get("url", ""))
    elif a == "copy_url": _copy_url(p.get("url", ""))
    elif a == "url_play_clipboard":
        import url_player; url_player.play_clipboard()
    elif a == "log_menu": _lm.menu()
    elif a == "view_kodi_log": _lm.view_log()
    elif a == "view_kodi_log_full": _lm.view_full()
    elif a == "view_kodi_log_errors": _lm.view_errors()
    elif a == "search_kodi_log": _lm.search()
    elif a == "log_info": _lm.info()
    elif a == "export_log": _lm.export()
    elif a == "view_log_visual": _lm.view_visual()
    elif a == "show_log_line": _lm.show_line(p.get("data", ""))
    elif a == "clear_error_log": _lm.clear_error()
    elif a == "open_flowfav": _open_flowfav()
    elif a == "flowfav_install": _flowfav_install()
    elif a == "set_cache_config": _set_cache_config()
    elif a == "toggle_iptv_cache": _toggle_iptv_cache()
    elif a == "set_iptv_cache_ttl": _set_iptv_cache_ttl_dialog()
    elif a == "reset_iptv_cache": _reset_iptv_cache()
    elif a == "set_download_path": _set_download_path()
    elif a == "toggle_inputstream": _toggle_inputstream()
    elif a == "toggle_iptv_anti_errors": _toggle_iptv_anti_errors()
    elif a == "set_search_input_method": _set_search_input_method()
    elif a == "toggle_remote_secure": _toggle_remote_secure()
    elif a == "toggle_remember_position": _toggle_remember_position()
    elif a == "autostart_menu": _autostart_menu()
    elif a == "autostart_config_slot": _autostart_config_slot(int(p.get("slot", 1)))
    elif a == "autofav_menu": _autofav_menu()
    elif a == "autofav_config_slot": _autofav_config_slot(int(p.get("slot", 1)))
    elif a == "toggle_force_white_text": _toggle_force_white_text()
    elif a == "manage_custom_fanart": _manage_custom_fanart()
    elif a == "toggle_dev_mode": _toggle_dev_mode()
    elif a == "accessibility_menu": accessibility_menu()
    elif a == "acc_set_color_mode": _acc_set_color_mode()
    elif a == "acc_toggle_bold": _acc_toggle_bold()
    elif a == "acc_toggle_symbols": _acc_toggle_symbols()

    # --- BACKUPS ---
    elif a == "backups_menu": _bk.menu()
    elif a == "create_backup_full": _bk.create_full()
    elif a == "list_backups": _bk.list_backups()
    elif a == "restore_backup_selective": _bk.restore_selective(p.get("file", ""))
    elif a == "delete_single_backup": _bk.delete_single(p.get("file", ""))
    elif a == "slyguy_install": _slyguy.install(p.get("addon_id", ""), p.get("title", "Addon"))
    elif a == "export_favs_txt": _bk.export_favorites_txt()
    elif a == "open_atresdaily": _open_atresdaily()
    elif a == "open_espadaily": _open_espadaily()
    elif a == "open_loiolog": _open_loiolog()
    elif a == "loiolog_install": _loiolog_install()
    elif a == "loiolink_launch": _loiolink_launch()

    # --- EL TIEMPO (AEMET) ---
    elif a == "aemet_menu":
        import aemet_tiempo
        aemet_tiempo.show_aemet_menu(int(sys.argv[1]), _u)
    elif a == "aemet_search":
        import aemet_tiempo
        aemet_tiempo.search_location_ui(int(sys.argv[1]), _u)
    elif a == "aemet_save":
        import aemet_tiempo
        aemet_tiempo.save_location(p.get("name", ""), p.get("code", ""))
        xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="aemet_menu")))
    elif a == "aemet_remove":
        import aemet_tiempo
        aemet_tiempo.remove_location(p.get("code", ""))
        xbmc.executebuiltin("Container.Refresh")
    elif a == "aemet_forecast":
        import aemet_tiempo
        aemet_tiempo.show_forecast(int(sys.argv[1]), _u, p.get("code", ""), p.get("name", ""))
    elif a == "aemet_day_info":
        import aemet_tiempo
        aemet_tiempo.show_day_info(p.get("code", ""), p.get("name", ""), p.get("day_index", "0"))
    elif a == "aemet_weather_view":
        import aemet_tiempo
        aemet_tiempo.show_weather_view(int(sys.argv[1]), p.get("code", ""), p.get("name", ""))

    # --- AGENDA DEPORTIVA ---
    elif a == "agenda_menu":
        import espatv_agenda
        espatv_agenda.show_agenda_menu(int(sys.argv[1]), _u)
    elif a == "agenda_events":
        import espatv_agenda
        espatv_agenda.show_agenda_events(int(sys.argv[1]), _u, p.get("sport", ""))
    elif a == "agenda_event_options":
        import espatv_agenda
        espatv_agenda.show_event_options(int(sys.argv[1]), _u, p)
    elif a == "agenda_event_info":
        import espatv_agenda
        espatv_agenda.show_event_info(p)
    elif a == "agenda_futbolenlatv":
        import espatv_agenda
        espatv_agenda.show_futbolenlatv(int(sys.argv[1]), _u)
    elif a == "agenda_futbolhoy":
        import espatv_agenda
        espatv_agenda.show_futbolhoy(int(sys.argv[1]), _u)
    elif a == "agenda_baloncestohoy":
        import espatv_agenda
        espatv_agenda.show_baloncestohoy(int(sys.argv[1]), _u)
    elif a == "agenda_tenishoy":
        import espatv_agenda
        espatv_agenda.show_tenishoy(int(sys.argv[1]), _u)
    elif a == "agenda_sport_channels":
        import espatv_agenda
        espatv_agenda.show_sport_channels_menu(int(sys.argv[1]), _u)
    elif a == "agenda_formulatv":
        import espatv_agenda
        espatv_agenda.show_formulatv_channel(int(sys.argv[1]), _u, p.get("slug", ""), p.get("day", ""))
    elif a == "agenda_refresh":
        import espatv_agenda
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        espatv_agenda.force_refresh()
        try:
            xbmcgui.Dialog().notification(
                "Agenda Deportiva",
                "Actualizando datos…",
                xbmcgui.NOTIFICATION_INFO,
                2500,
            )
        except RuntimeError:
            pass
        xbmc.executebuiltin("Container.Refresh")
    elif a == "agenda_day":
        import espatv_agenda
        espatv_agenda.show_agenda_day(int(sys.argv[1]), _u, int(p.get("day", 1)))
    elif a == "agenda_filters":
        import espatv_agenda
        espatv_agenda.show_agenda_filters(int(sys.argv[1]), _u)
    elif a == "agenda_channels":
        import espatv_agenda
        espatv_agenda.show_agenda_channels(int(sys.argv[1]), _u)
    elif a == "agenda_competitions":
        import espatv_agenda
        espatv_agenda.show_agenda_competitions(int(sys.argv[1]), _u)
    elif a == "agenda_search":
        import espatv_agenda
        espatv_agenda.show_agenda_search(int(sys.argv[1]), _u, prefilled_query=p.get("query"))
    elif a == "agenda_search_all":
        import espatv_agenda
        espatv_agenda.show_agenda_search_all(int(sys.argv[1]), _u, prefilled_query=p.get("query"))
    elif a == "agenda_live_all":
        import espatv_agenda
        espatv_agenda.show_agenda_live_all(int(sys.argv[1]), _u)
    elif a == "search_acestream_prompt":
        _search_acestream_prompt()
    elif a == "search_acestream_results":
        _search_acestream_results(p.get("q", ""))
    elif a == "play_ace_result":
        _play_ace_result(p.get("infohash", ""), p.get("name", ""))
    elif a == "acestream_history":
        _acestream_show_history()
    elif a == "acestream_history_delete":
        _acestream_history_delete(p.get("infohash", ""))
        xbmc.executebuiltin("Container.Refresh")
    elif a == "acestream_history_clear":
        _acestream_history_clear()
        xbmc.executebuiltin("Container.Refresh")
    elif a == "agenda_favorite_toggle":
        import espatv_agenda
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        espatv_agenda.toggle_favorite(p.get("category", ""), p.get("value", ""))
        xbmc.executebuiltin("Container.Refresh")
    elif a == "agenda_goto_kodi_favourite":
        _goto_kodi_favourite()
    elif a == "agenda_goto_kodi_addon":
        _goto_kodi_addon()

    # --- UNIVERSO ---
    elif a == "show_universo":
        import universo; universo.show()

    # --- YT-DLP MANTENIMIENTO PC ---
    elif a == "ytdlp_menu": _ytdlp_menu()
    elif a == "ytdlp_instructions": _show_ytdlp_instructions()
    elif a == "ytdlp_check": _check_ytdlp_status()

    else: 
        main_menu()

if __name__ == "__main__":
    try:
        _old = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), '.legal_accepted')
        if os.path.exists(_old):
            os.remove(_old)
    except OSError:
        pass

    stats.ping()

    # Comprobación remota de validez (fail-open: sin red, no bloqueamos al usuario)
    try:
        if not _check_validity():
            xbmcgui.Dialog().ok("EspaTV", "La versión actual del addon está obsoleta o ha sido desactivada temporalmente.\n\nPor favor, actualiza el addon desde el repositorio oficial (GitHub).")
            sys.exit(0)
    except (requests.RequestException, ValueError, OSError):
        pass

    # Sistema de hotfixes eliminado por seguridad

    # Auto-limpieza silenciosa de archivos dated viejos (scores_*_YYYYMMDD.json
    # con > 14 días). No bloquea ni avisa al usuario; nunca rompe el arranque.
    try:
        import storage_manager as _sm
        _sm.limpiar_dated()
    except Exception:
        pass

    try:
        router(sys.argv[2][1:])
    except Exception as e:
        import traceback
        _log_error("Unhandled exception: {0}\n{1}".format(e, traceback.format_exc()))
        xbmcgui.Dialog().ok("EspaTV - Error", "Ocurrió un error inesperado al procesar la ruta.\n\nConsulta el log de errores en Ajustes Avanzados.")
