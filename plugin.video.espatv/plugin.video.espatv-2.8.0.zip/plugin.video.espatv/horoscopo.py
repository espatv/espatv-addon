# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import html
import json
import os
import re
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


_LOG     = "[EspaTV-HOR]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_FILE    = os.path.join(_PROFILE, "horoscopo_cache.json")
_CACHE_TTL     = 24 * 3600
_CACHE_VERSION = 3
_TIMEOUT    = 15
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_SIGNOS = [
    ("Aries",       "aries"),
    ("Tauro",       "tauro"),
    ("Géminis",     "geminis"),
    ("Cáncer",      "cancer"),
    ("Leo",         "leo"),
    ("Virgo",       "virgo"),
    ("Libra",       "libra"),
    ("Escorpio",    "escorpio"),
    ("Sagitario",   "sagitario"),
    ("Capricornio", "capricornio"),
    ("Acuario",     "acuario"),
    ("Piscis",      "piscis"),
]

_SIGNO_KEY = {nombre: key for nombre, key in _SIGNOS}


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _load_cache(signo_key):
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if obj.get("version") != _CACHE_VERSION:
            return None
        entry = obj.get(signo_key, {})
        if time.time() - entry.get("ts", 0) < _CACHE_TTL:
            return entry.get("texto")
    except (OSError, ValueError):
        pass
    return None


def _save_cache(signo_key, texto):
    try:
        try:
            with open(_CACHE_FILE, "r", encoding="utf-8") as f:
                obj = json.load(f)
            if obj.get("version") != _CACHE_VERSION:
                obj = {"version": _CACHE_VERSION}
        except (OSError, ValueError):
            obj = {"version": _CACHE_VERSION}
        obj[signo_key] = {"ts": time.time(), "texto": texto}
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except OSError as e:
        xbmc.log("{0} Error caché: {1}".format(_LOG, e), xbmc.LOGWARNING)


_URL_20MIN = "https://www.20minutos.es/horoscopo/{signo_key}/hoy/"
_URL_HOROSCOPE_API      = "https://freehoroscopeapi.com/api/v1/get-horoscope/daily?sign={signo}&day=TODAY"
_URL_HOROSCOPE_FALLBACK = "https://ohmanda.com/api/horoscope/{signo}/"

_HEADERS_HOR = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept": "text/html,application/xhtml+xml,*/*",
    "Accept-Language": "es-ES,es;q=0.9",
}

_SIGNO_KEY_EN = {
    "aries":      "Aries",
    "tauro":      "Taurus",
    "geminis":    "Gemini",
    "cancer":     "Cancer",
    "leo":        "Leo",
    "virgo":      "Virgo",
    "libra":      "Libra",
    "escorpio":   "Scorpio",
    "sagitario":  "Sagittarius",
    "capricornio":"Capricorn",
    "acuario":    "Aquarius",
    "piscis":     "Pisces",
}


def _scrape_descripcion_es(signo_key):
    url = _URL_20MIN.format(signo_key=signo_key)
    try:
        resp = requests.get(url, headers=_HEADERS_HOR, timeout=_TIMEOUT)
        if resp.status_code != 200:
            return None
        text = resp.text
        paras = re.findall(r'<p[^>]*>(.*?)</p>', text, re.DOTALL)
        for p in paras:
            clean = re.sub(r'<[^>]+>', ' ', p)
            clean = html.unescape(clean)
            clean = re.sub(r'\s+', ' ', clean).strip()
            if len(clean) < 80 or len(clean) > 700:
                continue
            low = clean.lower()
            if any(w in low for w in ["reproducción sin permiso", "propiedad intelectual", "empresa publicadora"]):
                continue
            xbmc.log("{0} Descripcion ES obtenida de 20minutos".format(_LOG), xbmc.LOGINFO)
            return clean
    except Exception as e:
        xbmc.log("{0} 20minutos fallo: {1}".format(_LOG, e), xbmc.LOGWARNING)
    return None


def _fetch_prediccion_en(signo_key):
    sign_en = _SIGNO_KEY_EN.get(signo_key, signo_key.capitalize())
    try:
        r = requests.get(
            _URL_HOROSCOPE_API.format(signo=sign_en),
            headers=_HEADERS_HOR, timeout=_TIMEOUT
        )
        if r.status_code == 200:
            pred = r.json().get("data", {}).get("horoscope")
            if pred:
                return pred
    except Exception:
        pass
    try:
        r = requests.get(
            _URL_HOROSCOPE_FALLBACK.format(signo=signo_key),
            headers=_HEADERS_HOR, timeout=_TIMEOUT
        )
        if r.status_code == 200:
            pred = r.json().get("horoscope")
            if pred:
                return pred
    except Exception:
        pass
    return None


def _fetch_horoscopo(signo_key):
    cached = _load_cache(signo_key)
    if cached is not None:
        return cached
    desc_es = _scrape_descripcion_es(signo_key)
    pred_en = _fetch_prediccion_en(signo_key)
    partes = []
    if desc_es:
        partes.append("[B]Tu signo:[/B]\n{0}".format(desc_es))
    if pred_en:
        partes.append("[B]Today's reading (EN):[/B]\n{0}".format(pred_en))
    texto = "\n\n".join(partes) if partes else None
    if texto:
        _save_cache(signo_key, texto)
    return texto


def horoscopo_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_horoscopo.png")

    for nombre, key in _SIGNOS:
        label = "[B]{0}[/B]".format(nombre)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": nombre, "plot": "Pulsa para ver la predicción del día."})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="horoscopo_signo", signo_nombre=nombre, signo_key=key),
            listitem=li,
            isFolder=False,
        )
    xbmcplugin.endOfDirectory(h)


def horoscopo_signo(signo_nombre, signo_key):
    try:
        xbmcgui.Dialog().notification("Horóscopo", "Consultando…", xbmcgui.NOTIFICATION_INFO, 1200)
        texto = _fetch_horoscopo(signo_key)
    except Exception as e:
        xbmc.log("{0} Error: {1}".format(_LOG, e), xbmc.LOGERROR)
        texto = None

    if not texto:
        xbmcgui.Dialog().ok(
            signo_nombre,
            "No se pudo obtener la predicción.\nComprueba la conexión o inténtalo más tarde."
        )
        return

    titulo = "Horóscopo de {0} — hoy".format(signo_nombre)
    xbmcgui.Dialog().textviewer(titulo, texto)
