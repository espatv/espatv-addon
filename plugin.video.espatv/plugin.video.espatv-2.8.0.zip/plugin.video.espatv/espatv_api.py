# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""API de consulta de películas para otros addons.

Otro addon obtiene el catálogo de cine de EspaTV (sin duplicar scraping ni
claves) consultando el plugin vía JSON-RPC Files.GetDirectory, que es síncrono
y bloquea hasta recibir el listado completo:

    import json, xbmc
    req = {"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory", "params": {
        "directory": "plugin://plugin.video.espatv/?action=api_consulta_pelis&categoria=top&limit=20",
        "media": "video",
        "properties": ["title", "year", "plot", "genre", "director",
                       "cast", "rating", "art", "uniqueid", "mediatype"]}}
    resp  = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    items = resp.get("result", {}).get("files", [])
    # cada item: label, year, plot, art["poster"], uniqueid["tmdb"] / uniqueid["imdb"] ...

Categorías:
    top          Top global de Cinemeta
    cartelera    En cines España (FilmAffinity); solo título + póster
    tmdb_top     Top valoradas de TMDB
    tmdb_search  Búsqueda en TMDB; requiere &q=titulo
"""
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

_LIMIT_CAP = 100


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _to_year(value):
    s = str(value or "")[:4]
    return int(s) if s.isdigit() else 0


def _to_rating(value):
    try:
        return round(float(str(value).replace(",", ".")), 1)
    except (TypeError, ValueError):
        return 0.0


def _normalize_cinemeta(f):
    return {
        "tmdb_id":    "",
        "imdb_id":    f.get("id", ""),
        "title":      f.get("title", ""),
        "year":       _to_year(f.get("year")),
        "poster":     f.get("poster", ""),
        "overview":   f.get("plot", ""),
        "genres":     [g.strip() for g in str(f.get("genre", "")).split("/") if g.strip()],
        "rating":     _to_rating(f.get("rating")),
        "runtime":    0,
        "director":   "",
        "cast":       [],
        "media_type": "movie",
    }


def _normalize_fa_cartelera(f):
    return {
        "tmdb_id":    "",
        "imdb_id":    "",
        "title":      f.get("title", ""),
        "year":       0,
        "poster":     f.get("poster", ""),
        "overview":   "",
        "genres":     [],
        "rating":     0.0,
        "runtime":    0,
        "director":   "",
        "cast":       [],
        "media_type": "movie",
    }


def _normalize_fa_top(f):
    return {
        "tmdb_id":    str(f.get("tmdb_id") or ""),
        "imdb_id":    "",
        "title":      f.get("title", ""),
        "year":       _to_year(f.get("year")),
        "poster":     f.get("poster", ""),
        "overview":   f.get("overview", ""),
        "genres":     [],
        "rating":     _to_rating(f.get("rating")),
        "runtime":    0,
        "director":   "",
        "cast":       [],
        "media_type": "movie",
    }


def _normalize_tmdb_search(it):
    return {
        "tmdb_id":    str(it.get("tmdb_id") or ""),
        "imdb_id":    "",
        "title":      it.get("title", ""),
        "year":       _to_year(it.get("year")),
        "poster":     it.get("poster", ""),
        "overview":   it.get("overview", ""),
        "genres":     [],
        "rating":     0.0,
        "runtime":    0,
        "director":   "",
        "cast":       [],
        "media_type": "movie",
    }


def _source_top(q):
    import cinemeta
    return [_normalize_cinemeta(f) for f in (cinemeta._get_top_films() or [])]


def _source_cartelera(q):
    import filmaffinity
    # FilmAffinity etiqueta series con "(Serie de TV)"; las descartamos para que
    # esta API devuelva solo películas (igual que tmdb_search).
    films = filmaffinity._fetch_en_cines() or []
    return [_normalize_fa_cartelera(f) for f in films if f.get("media_type") != "show"]


def _source_tmdb_top(q):
    import filmaffinity
    return [_normalize_fa_top(f) for f in (filmaffinity._fetch_top() or [])]


def _source_tmdb_search(q):
    if not q:
        return []
    import metadata_enricher
    items = metadata_enricher.search_multi(q, limit=_LIMIT_CAP) or []
    return [_normalize_tmdb_search(it) for it in items if it.get("media_type") == "movie"]


_SOURCES = {
    "top":         _source_top,
    "cartelera":   _source_cartelera,
    "tmdb_top":    _source_tmdb_top,
    "tmdb_search": _source_tmdb_search,
}


def query_movies(categoria="top", q="", limit=20, offset=0):
    """Lista de películas normalizadas. Ver docstring del módulo para el formato."""
    q = (q or "").strip()
    try:
        limit = min(max(int(limit), 1), _LIMIT_CAP)
    except (TypeError, ValueError):
        limit = 20
    try:
        offset = max(int(offset), 0)
    except (TypeError, ValueError):
        offset = 0

    try:
        items = _SOURCES.get(categoria, _source_top)(q)
    except Exception as e:
        xbmc.log("[EspaTV-API] query_movies error (categoria={0}): {1}".format(categoria, e), xbmc.LOGERROR)
        return []

    if q and categoria != "tmdb_search":
        ql = q.lower()
        items = [it for it in items if ql in it["title"].lower()]

    return items[offset:offset + limit]


def render_directory(params):
    """Genera el directorio Kodi que consume otro addon vía Files.GetDirectory."""
    try:
        handle = int(sys.argv[1])
    except (IndexError, ValueError):
        xbmc.log("[EspaTV-API] render_directory sin handle de plugin válido", xbmc.LOGERROR)
        return
    try:
        items = query_movies(
            categoria=params.get("categoria", "top"),
            q=params.get("q", ""),
            limit=params.get("limit", 20),
            offset=params.get("offset", 0),
        )
        xbmcplugin.setContent(handle, "movies")
        for it in items:
            li = xbmcgui.ListItem(label=it["title"])
            info = {
                "title":     it["title"],
                "year":      it["year"],
                "plot":      it["overview"],
                "genre":     " / ".join(it["genres"]),
                "mediatype": "movie",
            }
            if it["rating"]:
                info["rating"] = it["rating"]
            if it["director"]:
                info["director"] = it["director"]
            li.setInfo("video", info)
            li.setArt({"icon": "DefaultVideo.png", "thumb": it["poster"], "poster": it["poster"]})
            ids = {k: v for k, v in (("tmdb", it["tmdb_id"]), ("imdb", it["imdb_id"])) if v}
            if ids:
                li.setUniqueIDs(ids)
            li.setProperty("IsPlayable", "false")
            url = _u(action="search_alt_prompt", q=it["title"], ot=it["poster"], mode="movie")
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        xbmc.log("[EspaTV-API] {0} pelis servidas (categoria={1})".format(
            len(items), params.get("categoria", "top")), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log("[EspaTV-API] render_directory error: {0}".format(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
